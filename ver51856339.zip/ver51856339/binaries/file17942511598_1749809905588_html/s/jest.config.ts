import type { Config } from '@jest/types';
import { pathsToModuleNameMapper } from "ts-jest";
import { compilerOptions } from './tsconfig.json'

// Sync object
const config: Config.InitialOptions = {
    verbose: true,
    roots: [
        "<rootDir>/src"
    ],
    collectCoverageFrom: [
        "src/**/*.{js,jsx,ts,tsx}",
        "!src/**/*.d.ts"
    ],
    setupFiles: [
        "react-app-polyfill/jsdom"
    ],
    setupFilesAfterEnv: [
        "<rootDir>/jest/setupTests.ts"
    ],
    testMatch: [
        "<rootDir>/src/**/__tests__/**/*.{spec,test}.{js,jsx,ts,tsx}",
        "<rootDir>/src/**/*.{spec,test}.{js,jsx,ts,tsx}"
    ],
    testEnvironment: "jsdom",
    transform: {
        "^.+\\.(js|jsx|mjs|cjs|ts|tsx)$": "@swc/jest",
        "^.+\\.css$": "<rootDir>/jest/cssTransform.js",
        "^(?!.*\\.(js|jsx|mjs|cjs|ts|tsx|css|json)$)": "<rootDir>/jest/fileTransform.js"
    },
    transformIgnorePatterns: [
        "[/\\\\]node_modules[/\\\\].+\\.(js|jsx|mjs|cjs|ts|tsx)$",
        "^.+\\.module\\.(css|sass|scss)$",
        '/node_modules/(?!(@ag-grid-community|@ag-grid-enterprise)/)'
    ],
    moduleNameMapper: pathsToModuleNameMapper(compilerOptions.paths, { prefix: '<rootDir>/' }),
    // modulePaths: [],
    // moduleNameMapper: {
    //     "^react-native$": "react-native-web",
    //     "^.+\\.module\\.(css|sass|scss)$": "identity-obj-proxy"
    // },
    // moduleFileExtensions: [
    //     "web.js",
    //     "js",
    //     "web.ts",
    //     "ts",
    //     "web.tsx",
    //     "tsx",
    //     "json",
    //     "web.jsx",
    //     "jsx",
    //     "node"
    // ],
    watchPlugins: [
        "jest-watch-typeahead/filename",
        "jest-watch-typeahead/testname"
    ],
    resetMocks: true
};
export default config;