const defaultConfig = require('./webpack.config')

const ENDPOINT = 'https://financialmarkets-dev.pwcinternal.com/'
// const ENDPOINT = 'https://financialmarketstest.pwcinternal.com/'

/** @type {import('webpack').Configuration} */
const config = {
    ...defaultConfig({
        APPLICATION_NAME: JSON.stringify(""),
        // API_ROOT: JSON.stringify("https://localhost:7127"), // local
        API_ROOT: JSON.stringify(ENDPOINT + 'DueDiligence'), // dev site
        AUTH_URL: JSON.stringify(ENDPOINT),
    }),
    mode: "development",
    devtool: "eval-source-map",
    devServer: {
        hot: true,
        open: false,
        historyApiFallback: true,
        host: "127.0.0.1",
        port: 3002,
    },
    watchOptions: {
        aggregateTimeout: 1000,
        ignored: /node_modules/,
    },
};

module.exports = config