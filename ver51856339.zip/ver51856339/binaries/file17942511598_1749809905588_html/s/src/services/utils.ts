export function responseHandler<T>(res: API.IResponse<T>): Promise<T> {
    if (res.status === 500) {
        return Promise.reject({ message: res.message })
    }
    return Promise.resolve(res.data)
}

export default {
    responseHandler
}