import request from "../request"
import { responseHandler } from "../utils"

const API_PREFIX = '/api/Loan'

const getLoans = (dealId: number, isActive?: boolean) => request.get<API.IResponse<API.ILoan[]>>(`${API_PREFIX}/${dealId}/Loans`, { isActive }).then(responseHandler)

const updateLoan = (loan: API.ILoan) => request.post<API.IResponse>(`${API_PREFIX}/UpdateLoan`, loan).then(responseHandler)

const generateRandomlyLoan = (randomLoan: API.ILoanRandom) =>
    request.post<API.IResponse, API.ILoanRandom>(`${API_PREFIX}/UpdateLoanRandom`, randomLoan).then(responseHandler)

const getLoanDependency = (dealId: number) =>
    request.get<API.IResponse<API.ILoanDependency[]>>(`${API_PREFIX}/${dealId}/LoanDependency`).then(responseHandler)

const updateLoanDependency = (dealId: number, loans: API.ILoanDependency[]) =>
    request.post<API.IResponse, API.ILoanDependency[]>(`${API_PREFIX}/${dealId}/UpdateLoanDependency`, loans)

export default {
    getLoans,
    updateLoan,
    generateRandomlyLoan,
    getLoanDependency,
    updateLoanDependency,
}