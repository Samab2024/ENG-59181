import request from "../request"
import { responseHandler } from "../utils"

const API_PREFIX = '/api/HeaderReview/'

export const getHeaderStatusById = (dealId: number) => request.get<API.IResponse<API.IReviewStatus>>(`${API_PREFIX}${dealId}/HeaderReviewStatus`).then(responseHandler)

export const updateHeader = (header: API.IHeader) => request.post<API.IResponse<API.IHeader>>(`${API_PREFIX}UpdateHeader`, header).then(responseHandler)

export const getHeaderReview = (dealId: number, headerId: number) => request.get<API.IResponse<API.IHeaderReview>>(API_PREFIX + dealId + "/Headers/" + headerId).then(responseHandler)

export const updateHeaderReview = (dealId: number, headerId: number, headerReviews: API.IHeaderReviewSection) =>
    request.post<API.IResponse<API.ILoanReviewSection>>(`${API_PREFIX}${dealId}/Headers/${headerId}/UpdateHeaderReview`, headerReviews).then(responseHandler)

export const updateHeaderReviewCell = (dealId: number, headerId: number, reviewData: API.IHeaderReviewCell) =>
    request.post<API.IResponse<void>, API.IHeaderReviewCell>(`${API_PREFIX}${dealId}/Headers/${headerId}/UpdateHeaderReviewCell`, reviewData).then(responseHandler)

export default {
    getHeaderStatusById,
    updateHeader,
    getHeaderReview,
    updateHeaderReview,
    updateHeaderReviewCell,
}