import request from "../request"
import { responseHandler } from "../utils"

const API_PREFIX = '/api/Reviewer'

const getAttributeReviewers = (dealId: number) => request.get<API.IResponse<API.IHeader[]>>(`${API_PREFIX}/${dealId}/AttributeReviewers`).then(responseHandler)

const getAttributeReviewerByHeaderMap = (headerId: number) => request.get<API.IResponse<API.IHeader>>(`${API_PREFIX}/HeaderMaps/${headerId}`).then(responseHandler)

const updateAttributeReviewer = (entity: API.IHeader) => request.post(`${API_PREFIX}/UpdateAttributeReviewer`, entity)

const getLoanReviewers = (dealId: number, sectionId: number) => request.get<API.IResponse<API.IReviewer[]>>(`${API_PREFIX}/${dealId}/Sections/${sectionId}/LoanReviewers`).then(responseHandler)

const getLoanReviewer = (loanId: number, sectionId: number) => request.get<API.IResponse<API.IReviewer>>(`${API_PREFIX}/Loans/${loanId}/Sections/${sectionId}`).then(responseHandler)

const updateLoanReviewer = (entity: API.IReviewer) => request.post<API.IResponse<API.IReviewer>>(`${API_PREFIX}/UpdateLoanReviewer`, entity).then(responseHandler)

export default {
    getAttributeReviewers,
    getAttributeReviewerByHeaderMap,
    updateAttributeReviewer,
    getLoanReviewers,
    getLoanReviewer,
    updateLoanReviewer
}