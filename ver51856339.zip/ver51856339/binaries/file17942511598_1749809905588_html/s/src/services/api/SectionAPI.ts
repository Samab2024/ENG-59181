import request from "../request"
import { responseHandler } from "../utils";

const API_PREFIX = '/api/Section'

const getSections = (dealId: number) => request.get<API.IResponse<API.ISection[]>>(`${API_PREFIX}/${dealId}`).then(responseHandler)

const updateSection = (dealId: number, sections: API.ISection[]) => request.post(`${API_PREFIX}/${dealId}/UpdateSection`, sections)

export default {
    getSections,
    updateSection
}