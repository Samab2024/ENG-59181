import request from "../request"
import { responseHandler } from "../utils";

const API_PREFIX = '/api/Seller'

const getSellers = (dealId: number) => request.get<API.IResponse<API.ISeller[]>>(`${API_PREFIX}/${dealId}`).then(responseHandler)
const updateSellers = (dealId: number, sources: API.ISeller[]) => request.post<API.IResponse<API.ISeller[]>>(`${API_PREFIX}/${dealId}/UpdateSeller`, sources).then(responseHandler)
export default {
    getSellers,
    updateSellers
}