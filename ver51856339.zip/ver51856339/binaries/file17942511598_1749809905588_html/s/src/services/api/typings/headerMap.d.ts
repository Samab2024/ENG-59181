declare namespace API {
    interface ICopyHeaderMapConfig {
        dealIdRef: number;
        isOverride: boolean
    }

    interface IDataFormat {
        dataFormatId: number;
        name: string;
        type: string;
        format: string;
        code?: string;

        displayOrder: number
        isEditable?: boolean
    }

    interface IDealHeaderMap {
        dealId: number;
        dealName: string;
        levelOfReview: number;
        headerMap: IHeaderMap[];
        isEditable: boolean;
    }

    interface IHeaderMap {
        headerMapId: number;
        displayOrder: number;
        levelOfReview: number;
        clientHeader?: string;
        pwCHeader?: string;
        calculatorHeader?: string
        calculatorFormula?: string
        processType?: string;
        sourceDocSectionId: number;
        sourceId: number
        dataFormatId?: number;
        screenShotId?: number;
        fieldGuide?: string;
        isActive: boolean;
        isExcludedInReport: boolean
        isBlindReview: boolean;
        dropdownCategoryId?: number
        threadhold: number
        field: string
        formula: string
    }

    interface ISourceDocSection {
        sourceDocSectionId: number;
        sectionId?: number
        name: string;
        displayOrder: number;
        isAllowCopy: boolean;
        isDeleteable: boolean
    }

    interface ISource {
        sourceId: number
        name: string
        displayOrder: number
        isDeleteable: boolean
    }

    interface IDropdownCategory {
        categoryId: number
        categoryName?: string
        displayOrder: number
        isDeleteable: boolean
        dropdownCategoryOptions: IDropdownCategoryOption[]
    }

    interface IDropdownCategoryOption {
        categoryOptionId: number
        optionName?: string
        displayOrder: number
    }

    interface IImportHeaderMapData {
        dealId: number
        file: File
        sheetName: string
    }

    interface IExportHeaderMapData {
        fileName: string
    }

}