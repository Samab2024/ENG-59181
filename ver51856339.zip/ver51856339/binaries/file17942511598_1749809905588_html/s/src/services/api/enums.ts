
export enum ReviewStatus {
    NotStarted = 0,
    InProgress,
    Complete
}

export enum ProcessType {
    Provided = 0,
    Review,
    Calculation,
    PassThrough,
    ReviewAttribute
}

export enum ReportType {
    ExportMasterTapeReport = 1,
    ExportExceptionReport,
    PwCTapeReport
}

export enum DataFormatType {
    IsString = 0,
    IsDateTime,
    IsNumeric
}

export enum ReviewLevel {
    FirstReview = 1,
    SecondReview,
    ThirdReview
}

export enum ImportRunTypeEnum {
    ValidateClientData,
    ImportClientData,
    ValidateReviewData,
    ImportReviewData
}

export enum DealStateEnum {
    Active,
    Archived,
    Deleted
}

export type DealState = 'Active' | 'Archived' | 'Deleted'