import QueryString from "qs";
import request from "../request"
import { responseHandler } from "../utils";
import { DealState } from "./enums";

const API_PREFIX = '/api/Deal/'

export const getAll = (dealState: DealState) => request.get<API.IResponse<API.IDealSetup[]>>(API_PREFIX + `Deals`, { dealState }).then(responseHandler)

export const createDeal = (deal: API.IDealSetup) => request.post<API.IResponse<API.IDealSetup>>(`${API_PREFIX}CreateDeal`, deal).then(responseHandler)

export const updateDeal = (deal: API.IDealSetup) => request.post<API.IResponse<API.IDealSetup>>(`${API_PREFIX}UpdateDeal`, deal).then(responseHandler)

export const updateDealState = (dealId: number, dealState: DealState) => request.post<API.IResponse>(`${API_PREFIX}${dealId}/UpdateDealState${QueryString.stringify({ dealState }, { addQueryPrefix: true })}`).then(responseHandler)

export const getDealById = (dealId: number) => request.get<API.IResponse<API.IDealSetup>>(API_PREFIX + dealId).then(responseHandler)

export const deleteDealById = (dealId: number) => request.delete(`${API_PREFIX}${dealId}/DeleteDeal`).then(responseHandler)

export default {
    getAll,
    createDeal,
    updateDeal,
    updateDealState,
    getDealById,
    deleteDealById
}