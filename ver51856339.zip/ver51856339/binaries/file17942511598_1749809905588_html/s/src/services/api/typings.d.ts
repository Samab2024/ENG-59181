declare namespace API {

    type ReviewLevel = import('./enums').ReviewLevel

    //#region System

    interface ILookupCodeDisplay {
        code: string
        display: string
        sequence: number
    }

    interface ILookupIdName {
        id: number
        name: string
        dealId?: number
    }

    interface IUser extends IBasic {
        name: string
        identity: string
        guid: string
        email: string
        accessToken: string
        isAuthenticated: boolean
        currentClientId: number
        currentPermissionCode: number
        isAdmin: boolean
        isSupport: boolean
    }

    type UserInfo = Omit<IUser, 'accessToken'>


    //#endregion

    interface ILoanValidateInfo {
        loanId: number
        loanNumber: string
        isAllowRemap: boolean
    }

    interface IHeaderValidateInfo {
        headerId: number
        headerName: string
    }

    interface IImportDataResponse {
        missingFields: IHeaderValidateInfo[]
        newFields: IHeaderValidateInfo[]
        missingLoans: ILoanValidateInfo[]
        newLoans: ILoanValidateInfo[]

        updateFields: string[]
        updateLoans: string[]

        statusMsg?: string,
        warningMsg?: string
    }

    interface IImportLoanMap {
        OrgLoanId: number
        NewLoanId: number
    }

    interface IImportHeaderMap {
        OrgHeaderId: number
        NewHeaderId: number
    }

    interface ILastImportInfo {
        fileName?: string
        importBy?: string
        importTime?: string
    }

}
