import request from "../request";
import { RcFile } from "antd/lib/upload";
import { IHeaderMapFrom } from "@/pages/HeaderMapFormPage/index";
import { responseHandler } from "../utils";

const API_PREFIX = '/api/HeaderMap'

export const getHeaderMapsById = (dealId: number) => request.get<API.IResponse<API.IDealHeaderMap>>(`${API_PREFIX}/${dealId}/DealHeaderMap`).then(responseHandler);

export const updateDealHeaderMap = (dealId: number, headerMaps: API.IHeaderMap[]) => request.post<API.IResponse<API.IHeaderMap>>(`${API_PREFIX}/${dealId}/UpdateDealHeaderMap`, headerMaps).then(responseHandler);

export const getSourceDocSections = (dealId: number) => request.get<API.IResponse<API.ISourceDocSection[]>>(`${API_PREFIX}/${dealId}/SourceDocSection`).then(responseHandler);

export const updateSourceDocSection = (dealId: number, sourceDocSections: API.ISourceDocSection[]) => request.post<API.IResponse<API.IHeaderMap>>(`${API_PREFIX}/${dealId}/UpdateSourceDocSection`, sourceDocSections).then(responseHandler)

export const getSources = (dealId: number) => request.get<API.IResponse<API.ISource[]>>(`${API_PREFIX}/${dealId}/Source`).then(responseHandler);

export const updateSources = (dealId: number, sources: API.ISource[]) => request.post<API.IResponse<API.IHeaderMap>>(`${API_PREFIX}/${dealId}/UpdateSource`, sources).then(responseHandler)

export const getDataFormats = () => request.get<API.IResponse<API.IDataFormat[]>>(`${API_PREFIX}/PFDataFormat`).then(responseHandler);

export const updateDateFormats = (data: API.IDataFormat[]) => request.post<API.IResponse, API.IDataFormat[]>(`${API_PREFIX}/UpdatePFDataFormat`, data).then(responseHandler)

export const getProcessTypes = () => request.get<API.IResponse<string[]>>(`${API_PREFIX}/PFProcessType`).then(responseHandler);

export const copyHeaderMap = (dealId: number, copyHeaderMapConfig: API.ICopyHeaderMapConfig) =>
    request.post<API.IResponse<API.ICopyHeaderMapConfig>>(`${API_PREFIX}/${dealId}/CopyHeaderMap`, copyHeaderMapConfig)
        .then(responseHandler);

export const uploadScreenShot = (dealId: number, file?: RcFile) => {
    if (!file) return Promise.reject({ message: "File not found" });
    const form = new FormData()
    form.append('Image', file)
    form.append('DealId', dealId.toString())
    return request.postFile<API.IResponse<number>>(`${API_PREFIX}/UploadScreenShot`, form).then(r => {
        if (r.status === 500) {
            return Promise.reject({ message: r.message })
        }
        return r.data
    })
}

export const downloadScreenShot = (id: number) => {
    return request.downloadAndOpenFile(`${API_PREFIX}/DownloadScreenShot?screenShotId=${id}`)
}

export const createHeaderMap = (dealId: number, headerMap: IHeaderMapFrom) => request.post<API.IResponse<IHeaderMapFrom>>(`${API_PREFIX}/${dealId}/CreateHeaderMap`, headerMap).then(responseHandler)

export const updateHeaderMap = (headerMaps: API.IHeaderMap) => request.post<API.IResponse<API.IHeaderMap>>(`${API_PREFIX}/UpdateHeaderMap`, headerMaps).then(responseHandler);

export const getDropdownCategory = (dealId: number) => request.get<API.IResponse<API.IDropdownCategory[]>>(`${API_PREFIX}/${dealId}/DropdownCategory`).then(responseHandler)

export const updateDropdownCategory = (dealId: number, dropdownCategorys: API.IDropdownCategory[]) => request.post<API.IResponse>(`${API_PREFIX}/${dealId}/UpdateDropdownCategory`, dropdownCategorys)

const downloadHeaderMap = (dealId: number) => request.download(`${API_PREFIX}/${dealId}/DownloadHeaderMap`)

const importHeaderMap = (data: Omit<API.IImportHeaderMapData, 'file'>, file?: RcFile) => {
    if (!file) return Promise.reject({ message: "File not found" });
    const form = new FormData()
    Object.keys(data).forEach(key => {
        // form.append(key.charAt(0).toUpperCase() + key.slice(1), (data[key] + ''))
        form.append(key, (data[key] + ''))
    })
    form.append('file', file)
    return request.postFile<API.IResponse<{
        statusMsg: string,
        exceptionFile: string
    }>>(`${API_PREFIX}/ImportHeaderMap`, form).then(responseHandler)
}

const downloadHeaderMapException = (data: API.IExportHeaderMapData) => request.download(`${API_PREFIX}/DownloadHeaderMapException`, data)

export default {
    getHeaderMapsById,
    updateDealHeaderMap,
    createHeaderMap,
    getSourceDocSections,
    updateSourceDocSection,
    getSources,
    updateSources,
    getDataFormats,
    updateDateFormats,
    getProcessTypes,
    copyHeaderMap,
    uploadScreenShot,
    downloadScreenShot,
    updateHeaderMap,
    getDropdownCategory,
    updateDropdownCategory,
    downloadHeaderMap,
    importHeaderMap,
    downloadHeaderMapException,
}