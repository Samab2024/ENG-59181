declare namespace API {

    interface IDealSetup {
        dealId: number;
        dealName: string;
        dealDesc?: string;
        cutOffDate: DateInput;
        levelOfReview: number;
        levelOfReviewForCalculation: number
        dealAdmin: string;
        assetType?: string;
        keyColumn?: string;
        isBlindReview: boolean;
        dealStatus?: string;
        isEditable?: boolean
        clientName?: string
        dealContact?: string
        isRandomReview?: boolean
        isAllowRandomReview?: boolean
        isDealAdmin?: boolean
        docSections?: string[]
        isExRptIncludePwCComments?: boolean
        loanNumberDisplayColumn?: string
        isReadOnly: boolean

        //custom fields
        dealAdminArr?: string[];
        dealContactArr?: string[];

    }

    interface ISection {
        sectionId: number
        dealId: number
        name?: string
        displayOrder: number
        isDeleteable: boolean
    }

    interface ISeller {
        sellerId: number
        dealId: number
        name?: string
        displayOrder: number
        isDeleteable: boolean
    }

}