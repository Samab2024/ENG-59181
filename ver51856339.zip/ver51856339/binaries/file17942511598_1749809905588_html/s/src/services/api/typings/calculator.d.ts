declare namespace API {

    interface ICalculatorInfo {
        dealId: number
        headerMapId: number
        script: string
        isCalculateAllReferenceFormulas?: boolean

        calculatedResult?: ICalculatorField[]
    }

    interface ICalculatorField {
        dealId: number
        loanId: number
        field: string
        value: string
        displayValue: string
        dataFormatType: string
        dataFormat: string
        displayOrder: number

        isDealLevel: boolean
        isTie: boolean
    }

    interface ICalculatorGlobalField {
        calculatorGlobalFieldId: number
        dealId: number
        fieldName?: string
        fieldValue?: string
        dataFormatId?: number
        calculatorFormula?: string
        displayOrder: number
        isActive: boolean
    }
}