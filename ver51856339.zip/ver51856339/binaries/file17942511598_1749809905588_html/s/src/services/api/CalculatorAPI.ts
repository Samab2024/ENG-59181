import request from "../request"
import { responseHandler } from "../utils";

const API_PREFIX = '/api/Calculator'

type TestFormulaResponse = {
    errors: string[]
    results: API.ICalculatorField[]
}

export const testFormula = (info: API.ICalculatorInfo) => request.post<API.IResponse<TestFormulaResponse>, API.ICalculatorInfo>(`${API_PREFIX}/TestFormula`, info).then(responseHandler)

export const saveFormula = (info: API.ICalculatorInfo) => request.post<API.IResponse<API.ICalculatorField[]>, API.ICalculatorInfo>(`${API_PREFIX}/SaveFormulaAndCaculatedResult`, info).then(responseHandler)

export const getCalculatorGlobalField = (dealId: number) => request.get<API.IResponse<API.ICalculatorGlobalField[]>>(`${API_PREFIX}/${dealId}/CalculatorGlobalField`).then(responseHandler)

export const updateCalculatorGlobalField = (dealId: number, data: API.ICalculatorGlobalField[]) => request.post<API.IResponse>(`${API_PREFIX}/${dealId}/UpdateCalculatorGlobalField`, data).then(responseHandler)

export default {
    testFormula,
    saveFormula,
    getCalculatorGlobalField,
    updateCalculatorGlobalField,
}