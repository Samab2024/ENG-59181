import request from "../request"
import { RcFile } from "antd/lib/upload"
import { ImportRunTypeEnum } from "./enums"
import { responseHandler } from "../utils"

const API_PREFIX = '/api/Import/'

interface IImportDataRequest {
    DealId: number
    SheetName: string
    SellerIds: number[]
    ImportRunType: ImportRunTypeEnum
    ReviewLevel: number
    LoanMaps?: API.IImportLoanMap[]
    HeaderMaps?: API.IImportHeaderMap[]
}

export const loadSheets = (file?: RcFile) => {
    if (!file) return Promise.reject({ message: "File not found" })
    return request.postFile<API.IResponse<string[]>>(`${API_PREFIX}LoadSheets`, { File: file }).then(r => {
        if (r.status === 500) {
            return Promise.reject({ message: r.message })
        }
        return r.data
    })
}

export const importData = (entity: IImportDataRequest, file?: RcFile) => {
    if (!file) return Promise.reject({ message: "File not found" })
    return request.postFile<API.IResponse<API.IImportDataResponse>>(`${API_PREFIX}ImportData`, { File: file, ...entity }).then(r => {
        if (r.status === 500) {
            return Promise.reject({ message: r.message })
        }
        return r.data
    })
}

export const compareFile = (clientfile?: RcFile, pwcfile?: RcFile) => {
    if (!clientfile || !pwcfile) return Promise.reject({ message: "File not found" })
    const formData = new FormData()
    formData.append('ClientFile', clientfile)
    formData.append('PwCFile', pwcfile)
    request.download(`${API_PREFIX}CompareFile`, formData)
}

const getLastImportInfo = (dealId: number) => request.get<API.IResponse<API.ILastImportInfo>>(`${API_PREFIX}${dealId}/GetLastImportInfo`).then(responseHandler)

const downloadLastImportFile = (dealId: number) => request.download(`${API_PREFIX}${dealId}/GetLastImportFile`)

export default {
    loadSheets,
    importData,
    compareFile,
    getLastImportInfo,
    downloadLastImportFile
}