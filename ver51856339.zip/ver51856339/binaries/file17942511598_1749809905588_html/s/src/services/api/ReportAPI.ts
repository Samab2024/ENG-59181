import request from "../request"
import qs from 'qs'

const API_PREFIX = '/api/Report'

interface DownloadReportRequest {
    dealId: number
    reportType: number
    levelOfReview?: number,
    reportOrder?: number
    includeCalculationException?: boolean
    includePwcComments?: boolean
    includePwcHeaderFields?: boolean
    sellerIds?: number[]
}

export const downloadReport = ({ dealId, reportType, includeCalculationException, includePwcHeaderFields, includePwcComments, levelOfReview, reportOrder, sellerIds }: DownloadReportRequest) =>
    request.download(`${API_PREFIX}/${dealId}/DownloadReport/ReportType/${reportType}/${levelOfReview ?? 2}?${qs.stringify({ reportOrder })}`, {
        includeCalculationException,
        includePwcHeaderFields,
        includePwcComments,
        sellerIds
    })

export default {
    downloadReport
}