declare namespace API {

    interface IHeader {
        reviewerId: number
        dealId: number
        headerMapId: number
        displayOrder?: number
        clientHeader?: string
        pwCHeader?: string
        missingDoc?: string
        reviewer1?: string
        reviewerStatus1?: string
        reviewer2?: string
        reviewerStatus2?: string
        reviewer3?: string
        reviewerStatus3?: string
    }

    interface ILoan {
        loanId: number;
        loanNumber?: string
        propertyName?: string
        missingDoc?: string;
        isActive?: boolean
        createdTime?: string
        createdBy?: string
        lastUpdatedTime?: string
        lastUpdatedBy?: string
    }

    interface ILoanRandom {
        dealId: number;
        randomNumber: number;
    }

    interface IReviewer {
        reviewerId: number
        dealId: number
        loanId?: number
        headerMapId?: number
        sectionId?: number
        displayOrder?: number
        loanNumber: string
        propertyName?: string
        sellerName?: string
        missingDoc?: string
        reviewer1?: string
        reviewerStatus1?: string
        reviewer2?: string
        reviewerStatus2?: string
        reviewer3?: string
        reviewerStatus3?: string
        loanReviewStatus?: string
    }

    interface ILoanDependency {
        loanId: number
        parentId?: number
        sellerId: number
        loanNumber: string
        propertyName: string
        sellerName: string
        displayOrder: number
    }

}