import cacheStore from "@/utils/cacheStore"
import request from "../request"

const API_PREFIX = '/api/Auth/'

interface ILoginForm {
    oaToken: string
    accessToken: string
}

interface ILoginResponse {
    currentUser: API.IUser
    currentPermissionCode: number
}

type ILoginRes = API.IResponse<ILoginResponse>

const login = (oaToken: string) =>
    request.owin<ILoginRes, ILoginForm>(API_PREFIX + "login", {
        method: "POST",
        data: {
            oaToken: oaToken,
            accessToken: ''
        }
    }).then<{
        userInfo: API.UserInfo
        res: ILoginRes
    }>(res => {
        if (res.status === 500) {
            return Promise.reject({ message: res.message })
        }
        const { currentUser: { accessToken, ...userInfo } } = res.data
        cacheStore.setToken(accessToken)
        return {
            userInfo,
            res,
        }
    })

const logout = () => request.post(API_PREFIX + 'logout')

const getCurrentUser = () => request.get<API.IResponse<API.UserInfo>>(API_PREFIX + 'CurrentUser').then(r => {
    if (r.status === 500) {
        return Promise.reject({ message: r.message })
    }
    return r.data
})

const getAllUsers = () => request.get<API.IResponse<API.UserInfo[]>>(API_PREFIX + 'Users').then(r => {
    if (r.status === 500) {
        return Promise.reject({ message: r.message })
    }
    return r.data
})

const getReviewers = (dealId: number) => request.get<API.IResponse<API.UserInfo[]>>(API_PREFIX + 'Reviewers/' + dealId).then(r => {
    if (r.status === 500) {
        return Promise.reject({ message: r.message })
    }
    return r.data
})

export default {
    login,
    logout,
    getCurrentUser,
    getAllUsers,
    getReviewers
}