declare namespace API {

    interface IHeaderReview {
        headerMapId: number;
        clientHeader?: string;
        pwCHeader?: string;
        fieldGuide?: string;
        dataFormatId?: number;
        dataFormatType?: string;
        dataFormatCode?: string;
        threadhold?: number
        processType?: string
        dropdownCategoryId?: number
        dropdownCategoryOptions?: string[]
        levelOfReview: number;
        dealName: string;
        missingDoc?: string;
        isBlindReview: boolean;
        isDealAdmin?: boolean
        reviewSection: IHeaderReviewSection[]

        nextHeaderMapId?: number
        nextClientHeader?: string
        prvHeaderMapId?: number
        prvClientHeader?: string
    }

    interface IHeaderReviewSection {
        sourceDocSectionId?: number;
        sourceDocSectionName: string;
        isAllowCopy: boolean;
        displayOrder?: number;
        permission: string;
        reviewData: IHeaderReviewData[]
    }

    interface IHeaderReviewData {
        loanId: number
        loanNumber?: string
        propertyName?: string
        clientValue?: string
        clientDisplayValue?: string

        firstReviewValue?: string
        secondReviewValue?: string
        thirdReviewValue?: string

        firstReviewFormula?: string
        secondReviewFormula?: string
        thirdReviewFormula?: string

        isFirstReviewed?: boolean
        isSecondReviewed?: boolean
        isThirdReviewed?: boolean

        pwCComments?: string
        internalComments?: string
        isTie?: boolean
        levelOfReview: number
    }

    interface ILoanReview {
        dealName: string;
        loanId: number;
        loanNumber: string;
        propertyName: string;
        levelOfReview: number;
        isBlindReview: boolean;
        isDealAdmin?: boolean
        missingDoc?: string
        displayOrder?: number
        reviewSection: ILoanReviewSection[]

        nextLoanId?: number
        nextLoanNumber?: string
        prvLoanId?: number
        prvLoanNumber?: string
    }

    interface ILoanReviewSection {
        sectionId?: number
        sourceDocSectionId?: number;
        sourceDocSectionName: string;
        isAllowCopy: boolean;
        displayOrder?: number;
        permission: string;
        reviewData: ILoanReviewData[]
    }

    interface ILoanReviewData {
        headerMapId: number;
        clientHeader?: string;
        pwCHeader?: string;
        displayOrder?: number

        clientValue?: string;
        clientDisplayValue?: string;

        firstReviewValue?: string;
        secondReviewValue?: string;
        thirdReviewValue?: string;

        firstReviewFormula?: string;
        secondReviewFormula?: string;
        thirdReviewFormula?: string;

        isFirstReviewed?: boolean
        isSecondReviewed?: boolean
        isThirdReviewed?: boolean

        fieldGuide?: string;
        dataFormatId?: string;
        dataFormatCode?: string;
        dataFormatType?: string;
        threadhold?: number
        processType?: string
        dropdownCategoryId?: number
        dropdownCategoryOptions?: string[]
        isTie?: boolean;
        pwCComments?: string;
        internalComments?: string
        levelOfReview: number;
        isBlindReview?: boolean

        parentId?: number
        loanNumber?: string
        propertyName?: string
    }

    interface ILoanReviewCell {
        headerMapId: number
        sectionId: number
        reviewLevel: ReviewLevel
        isReviewed: boolean
        oldReviewValue?: string
        newReviewValue?: string
        formula?: string
        pwCComments?: string
        internalComments?: string
        isTie?: boolean
    }

    type IHeaderReviewCell = Omit<ILoanReviewCell, 'sectionId' | 'headerMapId'> & { loanId: number }

    interface IReviewStatus {
        readyFor1stReviewCount: number
        readyFor1stReviewPercentage: number
        readyFor2ndReviewCount: number
        readyFor2ndReviewPercentage: number
        readyForFinalReviewCount: number
        readyForFinalReviewPercentage: number
        completedCount: number
        completedPercentage: number
        totalCount: number
        totalPercentage: number
    }


}