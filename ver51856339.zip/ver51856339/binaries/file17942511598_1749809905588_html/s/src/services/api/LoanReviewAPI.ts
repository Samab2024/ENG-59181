import request from "../request"
import { responseHandler } from "../utils"

const API_PREFIX = '/api/LoanReview'

export const getLoanReview = (dealId: number, loanId: number) => request.get<API.IResponse<API.ILoanReview>>(`${API_PREFIX}/${dealId}/Loans/${loanId}`).then(responseHandler)

export const getLoanReviewBySection = (dealId: number, loanId: number, sectionId: number) => request.get<API.IResponse<API.ILoanReview>>(`${API_PREFIX}/${dealId}/Loans/${loanId}/Sections/${sectionId}`).then(responseHandler)

export const updateLoanReview = (dealId: number, loanId: number, loanReviewSection: API.ILoanReviewSection) =>
    request.post<API.IResponse<API.ILoanReviewSection[]>>(`${API_PREFIX}/${dealId}/Loans/${loanId}/UpdateLoanReview`, loanReviewSection).then(responseHandler)

// export const updateLoanReviewRow = (dealId: number, loanId: number, reviewData: API.ILoanReviewData) =>
//     request.post<API.IResponse<void>, API.ILoanReviewData>(`${API_PREFIX}/${dealId}/Loans/${loanId}/UpdateLoanReviewRow`, reviewData).then(responseHandler)

export const updateLoanReviewCell = (dealId: number, loanId: number, reviewData: API.ILoanReviewCell) =>
    request.post<API.IResponse<void>, API.ILoanReviewCell>(`${API_PREFIX}/${dealId}/Loans/${loanId}/UpdateLoanReviewCell`, reviewData).then(responseHandler)

export const getLoanReviewStatus = (dealId: number, sectionId: number) =>
    request.get<API.IResponse<API.IReviewStatus>>(`${API_PREFIX}/${dealId}/Sections/${sectionId}/LoanReviewStatus`).then(responseHandler)

export default {
    getLoanReview,
    getLoanReviewBySection,
    updateLoanReview,
    // updateLoanReviewRow,
    getLoanReviewStatus,
    updateLoanReviewCell
}