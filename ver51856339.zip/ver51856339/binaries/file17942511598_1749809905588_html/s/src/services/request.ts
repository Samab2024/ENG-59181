import axios, { AxiosRequestConfig, AxiosResponse, ResponseType } from 'axios'
import QueryString from 'qs'
import fileDownload from 'react-file-download'
import cacheStore from '@/utils/cacheStore'
import { getFileNameFromHeader } from '@/utils/stringHelper'
import { Location, NavigateFunction } from 'react-router-dom'

let isNeedSetupOnce = true
export const setupAxios = (navigate: NavigateFunction, location: Location) => {
    if (isNeedSetupOnce) {
        axios.interceptors.response.use((response) => {
            return response
        }, function (error) {
            if (!error.response) {
                return Promise.reject({ message: error.message + ', please try again.', isNetworkError: true })
            }
            // if (error.config.url.indexOf('healthCheck') >= 0) {
            //     return Promise.reject(error.response.data)
            // }
            if (error.response.status === 401) {
                // const regex = new RegExp('/' + APPLICATION_NAME, 'gi')
                cacheStore.clearAll()
                cacheStore.setReturnURL(location.pathname || '/')
                navigate('/login')
                return Promise.reject({ message: "Session timeout, please login again." } as API.IException)
            }
            return Promise.reject(
                typeof error.response.data === 'string' &&
                { message: error.response.data } ||
                typeof error.response.data === 'object' &&
                typeof error.response.data.message === 'string' &&
                { message: error.response.data.message } ||
                typeof error.response.data === 'object' &&
                typeof error.response.data.title === 'string' &&
                { message: error.response.data.title } ||
                { message: "Error occurred, please try again." }
            )
        })
        isNeedSetupOnce = false
    }
}

const handleStatus = <T>(res: AxiosResponse<T>) => {
    return res.data
}

const authConfig = (responseType?: ResponseType) => {

    const auth: AxiosRequestConfig<any> = { headers: {} }
    // auth.headers = { 'Content-Type': 'application/json; charset=utf-8' }
    // const accessToken = sessionStorage.getItem(AuthInfo.AccessToken)
    const token = cacheStore.getToken()
    // const usertype = sessionStorage.getItem(AuthInfo.UserType)
    // const userrole = sessionStorage.getItem(AuthInfo.UserRole)
    if (token) {
        // const user_type = JSON.parse(sessionStorage.getItem("permission")).user_type
        auth.headers.Authorization = 'Bearer ' + token;
        //auth.headers.usertype = user_type;
    }
    // if (accessToken) {
    //     auth.headers.Authorization = 'Bearer ' + accessToken;
    // }
    // if (usertype) {
    //     auth.headers.usertype = usertype;
    // }
    // if (userrole) {
    //     auth.headers.userrole = userrole;
    // }
    if (responseType !== undefined) {
        auth.responseType = responseType
    }
    return auth
}

const downloadFile = async <T = any>(url: string, data?: T): Promise<string | null> => {
    try {
        const response = await axios.post(API_ROOT + url, data, authConfig('blob'))
        fileDownload(response.data, getFileNameFromHeader(response))
        if (response.headers.errormsg) {
            return response.headers.errormsg
        }
        return null
    } catch (error: any) {
        if (typeof error.message === 'string') {
            throw error
        } else {
            return new Promise<any>((r, c) => {
                const reader = new window.FileReader()
                reader.readAsText(error.message)
                reader.onloadend = () => {
                    c({ message: reader.result || 'Download failed, please try again.' })
                }
            })
        }
    }
}

const downloadAndOpenFile = async <T = any>(url: string, data?: T): Promise<string | null> => {
    try {
        const response = await axios.get(API_ROOT + url, authConfig('blob'))
        const fileURL = URL.createObjectURL(response.data);
        window.open(fileURL, '_blank');
        if (response.headers.errormsg) {
            return response.headers.errormsg
        }
        return null
    } catch (error: any) {
        if (typeof error.message === 'string') {
            throw error
        } else {
            return new Promise<any>((r, c) => {
                const reader = new window.FileReader()
                reader.readAsText(error.message)
                reader.onloadend = () => {
                    c({ message: reader.result || 'Download failed, please try again.' })
                }
            })
        }
    }
}

const get = <T = any, P = any>(url: string, params?: P) => {
    return axios
        .get<T>(API_ROOT + url + (params && ('?' + QueryString.stringify(params)) || ''), authConfig())
        .then(handleStatus)
}

const post = <T = any, P = any>(url: string, params?: P) => {
    return axios
        .post<T>(API_ROOT + url, params, authConfig())
        .then(handleStatus)
}

const postFile = <T = any, P = any>(url: string, params?: P) => {
    return axios
        .postForm<T>(API_ROOT + url, params, authConfig())
        .then(handleStatus)
}

const put = <T = any, P = any>(url: string, params?: P) => {
    return axios
        .put<T>(API_ROOT + url, params, authConfig())
        .then(handleStatus)
}

const del = (url: string) => {
    return axios
        .delete(API_ROOT + url, authConfig())
        .then(handleStatus)
}

const owin = <T = any, D = any>(url: string, config?: AxiosRequestConfig<D>) => {
    return axios(API_ROOT + url, config)
        .then<T>(handleStatus)
}

export default {
    get: get,
    post: post,
    put: put,
    delete: del,
    download: downloadFile,
    downloadAndOpenFile,
    owin: owin,
    postFile: postFile,
}