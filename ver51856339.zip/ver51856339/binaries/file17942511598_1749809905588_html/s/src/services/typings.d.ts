declare namespace API {

    type DateInput = import("dayjs").ConfigType;

    interface IResponse<T = null> {
        status?: number;
        message?: string;
        data?: T;
    }

    interface IException {
        message: string
        isNetworkError?: boolean
    }

    interface IBasic {
        createdBy?: string
        createdDate?: DateInput
        lastModifiedBy?: string
        lastModifiedDate?: DateInput
    }
}