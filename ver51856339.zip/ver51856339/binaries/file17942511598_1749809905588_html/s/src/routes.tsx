import DealListPage from '@/pages/DealListPage'
import DealLoanPage from '@/pages/DealLoanPage'
import DealHeaderPage from '@/pages/DealHeaderPage'
import DealPage from '@/pages/DealPage'
import DemoPage from '@/pages/DemoPage'
import ErrorPage from '@/pages/ErrorPage'
import HeaderMapPage from '@/pages/HeaderMapPage'
import HomePage from '@/pages/HomePage'
import LoginPage from '@/pages/LoginPage'
import cacheStore from '@/utils/cacheStore'
import React, { FC } from 'react'
import { Navigate, RouteObject, useLocation } from 'react-router-dom'
import notification from '@/utils/notification'

const RequireAuth: FC<React.PropsWithChildren<any>> = ({ children }) => {
    const isAuthed = cacheStore.hasToken()
    const location = useLocation()
    if (!isAuthed) {
        // Redirect them to the /login page, but save the current location they were
        // trying to go to when they were redirected. This allows us to send them
        // along to that page after they login, which is a nicer user experience
        // than dropping them off on the home page.
        return <Navigate to="/login" state={{ from: location }} replace />;
    }

    return children;
}

const NotFound: FC = () => {
    const location = useLocation()
    console.log(location)
    notification.error('Page not found.')
    return <Navigate to="/" />
}

export const routes: RouteObject[] = [
    { path: '/demo', element: <DemoPage /> },
    { path: '/login', element: <LoginPage /> },
    {
        path: '/',
        element: (
            <RequireAuth>
                <HomePage />
            </RequireAuth>
        ),
        errorElement: <ErrorPage />,
        children: [
            {
                path: '',
                element: <DealListPage />,
                errorElement: <ErrorPage />,
            },
            {
                path: '/:id',
                element: <DealPage />,
                errorElement: <ErrorPage />,
            },
            {
                path: '/:id/map',
                element: <HeaderMapPage />,
                errorElement: <ErrorPage />,
            },
            {
                path: '/:id/loan/:lid/section/:sid',
                element: <DealLoanPage />,
                errorElement: <ErrorPage />,
            },
            {
                path: '/:id/header/:hid',
                element: <DealHeaderPage />,
                errorElement: <ErrorPage />,
            },

        ]
    },
    {
        path: '/' + APPLICATION_NAME,
        element: <Navigate to="/" />
    },
    {
        path: '*',
        element: <NotFound />
    }
]

export default routes