export const __esModule: true;
export const textAlignLeft: string;
export const textAlignCenter: string;
export const textAlignRight: string;
export const fontBold: string;
export const fontItalic: string;
export const uppercase: string;
export const required: string;
export const preLine: string;
export const breakWord: string;

