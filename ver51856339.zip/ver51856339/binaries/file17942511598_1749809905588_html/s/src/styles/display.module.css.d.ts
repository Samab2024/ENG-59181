export const __esModule: true;
export const hiden: string;
export const hidden: string;
export const floatLeft: string;
export const floatRight: string;
export const flex: string;
export const absolute: string;
export const inlineBlock: string;
export const flexCenter: string;
export const flexStart: string;
export const flexEnd: string;
export const flexStretch: string;
export const flexSpaceBetween: string;
export const flexJustifyEnd: string;
export const flex0: string;
export const flex1: string;
export const wholeScreen: string;

