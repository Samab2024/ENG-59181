import { css } from '@emotion/react';
import createStyle from '@/hooks/createStyle';
const useStyle = createStyle(token => css`
    /* Layout */
    .ant-layout-header {
        padding-inline: ${token.padding}px;
    }

    .ant-layout-footer {
        padding: 0.75rem 20px;
        background-color: #F3F3F5;
    }

    /* Button */
    .ant-btn {
        text-transform: uppercase;
    }

    /* Tabs */
    .ant-tabs-tab {
        text-transform: uppercase;
    }

    /* Table */
    .ant-table-tbody>tr.ant-table-row {
        &:nth-of-type(2n) {
            background-color: #fbfbfb;
        }
        &:hover > td {
            background-color: ${token.colorPrimaryBg};
        }
    }

    /* Modal */
    .ant-modal{
        .ant-modal-header{
            border-bottom: none;
            padding-bottom: 0;
            border-top: 4px solid ${token.colorPrimary};
            font-weight: bold;
            font-size: 16px;
        }
        .ant-modal-title {
            font-weight: bold;
        }

        .ant-modal-body{
            padding: 12px 24px 12px 24px;
        }

        .ant-modal-footer {
            border-top: none;
            padding-top: 0px;
            padding-bottom: 10px;
        }
    }

    /**antd table */
    .ant-table{
        .ant-table-header>table {
            .ant-table-thead>tr {
                th.ant-table-cell{
                    background: #cdcdcd;
                    padding-left: 12px;
                }
            }
        }
    }

    /* Antd drawer */
    .ant-drawer .ant-drawer-body {
        padding: 8px 24px 16px 24px;
    }


    /***font size */
    h4.ant-typography,
    .ant-modal .ant-modal-title,
    .ant-drawer .ant-drawer-title,
    .ant-space-item .ant-statistic .ant-statistic-content .ant-statistic-content-value-int{
        font-size: 14px;
    }

    .ant-space-item>button svg{
        font-size: 16px;
        margin-top: 2px;
    }

    .ant-space-item i.anticon svg{
        /* font-size: 18px; */
    }

    .ant-card .ant-card-body{
        padding: 8px;
        .ant-table-wrapper .ant-table-pagination.ant-pagination{
            margin-top: 10px;
            margin-bottom: 6px;
        }
    }

    .wrap-text {
        &.ant-select-dropdown .ant-select-item-option-content {
            white-space: normal;
        }
    }

`)
export default useStyle
