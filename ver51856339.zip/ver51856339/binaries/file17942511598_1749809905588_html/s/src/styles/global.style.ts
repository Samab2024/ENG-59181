import { css } from '@emotion/react';
import createStyle from '@/hooks/createStyle';
const useStyle = createStyle(token => css`
    :root {
        ${Object.keys(token).filter(x => x.startsWith('color')).map(key => `--${key}: ${token[key]};`)}
    }

    /* Base */
    b,
    strong {
        font-weight: bold;
    }

    h3,
    h4,
    h6 {
        font-weight: bold;
    }

    h3 {
        font-size: 22px;
    }

    h4 {
        font-size: 18px;
    }

    h6 {
        margin-bottom: 12px;
        color: ${token.colorText};
        font-size: 14px;
    }

    p {
        margin-bottom: 8px;
    }

    li {
        list-style-type: none;
    }

    .hidden {
        display: none;
    }

`)
export default useStyle