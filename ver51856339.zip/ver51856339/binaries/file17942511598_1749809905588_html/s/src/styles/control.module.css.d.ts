export const __esModule: true;
export const pointer: string;
export const noSelectable: string;
export const fullWidth: string;

