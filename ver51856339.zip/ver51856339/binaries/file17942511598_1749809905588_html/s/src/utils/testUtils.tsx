import { AppStore, RootState } from "@/redux/store";
import { configureStore, PreloadedState } from '@reduxjs/toolkit';
import { act, fireEvent, MatcherFunction, render, RenderOptions, screen } from '@testing-library/react';
import { ConfigProvider } from 'antd';
import enUS from 'antd/locale/en_US';
import React, { FC } from 'react';
import { Provider } from "react-redux";

import userReducer from '@/redux/userSlice';

interface ExtendedRenderOptions extends Omit<RenderOptions, 'queries'> {
    preloadedState?: PreloadedState<RootState>
    store?: AppStore
}

export function renderWithProviders(
    ui: React.ReactElement,
    {
        preloadedState = {},
        // Automatically create a store instance if no store was passed in
        store = configureStore({ reducer: { user: userReducer }, preloadedState }),
        ...renderOptions
    }: ExtendedRenderOptions = {}
) {

    const Wrapper: FC<React.PropsWithChildren> = ({ children }) => (
        <ConfigProvider locale={enUS} popupMatchSelectWidth={false}>
            <Provider store={store}>{children}</Provider>
        </ConfigProvider>
    )

    // Return an object with the store and all of RTL's query functions
    return { store, ...render(ui, { wrapper: Wrapper, ...renderOptions }) }
}

export const tagMatcher = (tagName: string): MatcherFunction => (content, element) => element.tagName.toLowerCase() === tagName

export const classMatcher = (name: string): MatcherFunction => (content, element) => element.classList.contains(name)

export const colIdMatcher = (colId: string): MatcherFunction => (content, element) => element.getAttribute('col-id') === colId

export const rowIdMatcher = (rowId: string): MatcherFunction => (content, element) => element.getAttribute('row-id') === rowId

export const sleep = async (timeout = 0) => {
    await act(async () => {
        await new Promise(r => setTimeout(r, timeout))
    })
}

export const findSpinner = () => screen.findByText((_c, e) => e.classList.contains('ant-spin-spinning'))

export const selectFile = async () => {
    const file = new File(["file"], "file.png", { type: "image/png" });
    const uploader = screen.getByText((content, element) => element.tagName.toLowerCase() === 'input' && element.getAttribute('type') === 'file')
    // simulate ulpoad event and wait until finish
    fireEvent.change(uploader, { target: { files: [file] } })
    await sleep()
}

export * from '@testing-library/react';
export { renderWithProviders as render };

