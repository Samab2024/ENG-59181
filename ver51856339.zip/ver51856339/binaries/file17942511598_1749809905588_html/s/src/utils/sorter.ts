import { CompareFn } from "antd/lib/table/interface";
import dayjs, { Dayjs } from "dayjs";

export const stringSorter: CompareFn<string> = (a, b) => ("" + a).toLowerCase().localeCompare(("" + b).toLowerCase())

export const dateSorter: CompareFn<API.DateInput> = (a, b) => {
    const dateA = dayjs(a);
    const dateB = dayjs(b);
    if (dateA > dateB) return 1;
    else if (dateA < dateB) return -1;
    else return 0;
}

export const lookupSorter: <T, K extends keyof T>(data: T[], field: K) => CompareFn<string> = (data, field) => (a, b) => {
    const indexA = data.findIndex(x => x[field] === a)
    const indexB = data.findIndex(x => x[field] === b)
    if (indexA > indexB) return 1;
    else if (indexA < indexB) return -1;
    else return 0;
}

export default {
    stringSorter,
    dateSorter,
    lookupSorter
}