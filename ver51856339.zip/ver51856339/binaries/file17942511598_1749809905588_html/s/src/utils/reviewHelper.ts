import { ReviewLevel } from "@/services/api/enums"
import { getFormatedValue, isNullOrEmpty } from "./stringHelper"
import { math, NotAvailable } from "./numberHelper";
import { FormatTypeEnum, PROCESS_TYPES, VARIOUS } from "@/constants"
import dayjs from "dayjs";
import { CellClassFunc, CellEditorSelectorFunc, CellKeyDownEvent, ColSpanParams, GetContextMenuItems, IRowNode, KeyCode, SuppressKeyboardEventParams, ValueParserParams } from "ag-grid-community";
import { getDefaultColumn } from "@/components/Grid";
import numericCellEditor, { INumericCellEditorProps } from "@/components/Grid/numericCellEditor";
import TextCellEditor, { ITextCellEditorProps } from "@/components/Grid/TextCellEditor";
import dateCellEditor, { IDateCellEditorProps } from "@/components/Grid/dateCellEditor";
import { FORMATS } from "./dateHelper";

type IDataRow = API.ILoanReviewData | API.IHeaderReviewData
type getReviewFieldsFn = <T extends IDataRow>(field?: keyof T | ReviewLevel) => {
    valueField: keyof Pick<T, 'firstReviewValue' | 'secondReviewValue' | 'thirdReviewValue'>,
    formulaField: keyof Pick<T, 'firstReviewFormula' | 'secondReviewFormula' | 'thirdReviewFormula'>,
    reviewField: keyof Pick<T, 'isFirstReviewed' | 'isSecondReviewed' | 'isThirdReviewed'>,
    reviewLevel: ReviewLevel,
}

export type LoanContextType = { isBlindReview: boolean }
export type HeaderContextType = { headerReview: API.IHeaderReview }

export const defaultColumn = getDefaultColumn({
    resizable: true,
    // suppressSizeToFit: true,
    sortable: false,
    wrapText: true,
    // autoHeight: true,
})

export const getReviewFields: getReviewFieldsFn = (field) => {
    let reviewLevel: ReviewLevel, valueField: keyof IDataRow, formulaField: keyof IDataRow, reviewField: keyof IDataRow
    switch (field) {
        case 'firstReviewValue':
        case 'firstReviewFormula':
        case 'isFirstReviewed':
        case ReviewLevel.FirstReview:
            reviewLevel = ReviewLevel.FirstReview
            valueField = 'firstReviewValue'
            formulaField = 'firstReviewFormula'
            reviewField = 'isFirstReviewed'
            break;
        case 'secondReviewValue':
        case 'secondReviewFormula':
        case 'isSecondReviewed':
        case ReviewLevel.SecondReview:
            reviewLevel = ReviewLevel.SecondReview
            valueField = 'secondReviewValue'
            formulaField = 'secondReviewFormula'
            reviewField = 'isSecondReviewed'
            break;
        case 'thirdReviewValue':
        case 'thirdReviewFormula':
        case 'isThirdReviewed':
        case ReviewLevel.ThirdReview:
            reviewLevel = ReviewLevel.ThirdReview
            valueField = 'thirdReviewValue'
            formulaField = 'thirdReviewFormula'
            reviewField = 'isThirdReviewed'
            break;
        default:
            break;
    }
    return {
        reviewLevel: reviewLevel as any,
        valueField: valueField as any,
        formulaField: formulaField as any,
        reviewField: reviewField as any
    }
}

const getParamsFromLoanOrHeader = <T extends IDataRow>(record: T, headerReview?: API.IHeaderReview) => {
    const r = headerReview ?? (record as API.ILoanReviewData)
    return {
        clientHeader: r.clientHeader,
        dataFormatType: r.dataFormatType,
        dataFormatCode: r.dataFormatCode,
        threadhold: r.threadhold
    }
}

export const checkIsFinalReviewValueTie = <T extends IDataRow>(updateRecord: T, levelOfReview: number, headerReview?: API.IHeaderReview) => {
    const { clientHeader, dataFormatCode, dataFormatType, threadhold } = getParamsFromLoanOrHeader(updateRecord, headerReview)
    if (levelOfReview === 0) {
        return false //all fields are empty and nothing reviewed, not tie
    }

    if (!clientHeader) {
        return true //pwc value, always tie
    }

    const { valueField, reviewField } = getReviewFields<IDataRow>(levelOfReview)
    if (isNullOrEmpty(updateRecord[valueField])) {
        if (updateRecord[reviewField]) {
            return isNullOrEmpty(updateRecord.clientValue) //current review value marked as reviewed, isTie depends on client value is empty or not.
        } else {
            return checkIsFinalReviewValueTie(updateRecord, levelOfReview - 1); // current review value is empty and mark as not reviewed, look into previous level of review value
        }
    }

    const reviewDisplayValue = getFormatedValue(updateRecord[valueField], dataFormatType, dataFormatCode);
    if (updateRecord.clientDisplayValue === reviewDisplayValue) {
        return true //value totally same, tie
    }

    //exclude all speicial cases
    // 1. client value is empty
    // 2. no threadhold allowed
    // 3. a string field
    // 4. number field but user can input anything include N/A, include client value
    // 5. date field but user can input N/A and Various, include client value
    if (isNullOrEmpty(updateRecord.clientValue)
        || threadhold === 0
        || dataFormatType === FormatTypeEnum.IsString
        || dataFormatType === FormatTypeEnum.IsNumeric && (!math.hasNumericValue(updateRecord[valueField]) || !math.hasNumericValue(updateRecord.clientValue))
        || dataFormatType === FormatTypeEnum.IsDateTime && (!dayjs(updateRecord[valueField]).isValid() || !dayjs(updateRecord.clientValue).isValid())) {
        return false
    }

    if (dataFormatType === FormatTypeEnum.IsNumeric) {
        return math.abs(math.bignumber(updateRecord[valueField]).minus(math.bignumber(updateRecord.clientValue))).lessThanOrEqualTo(math.bignumber(threadhold)) // values diff less than or equal to threadhold
    } else if (dataFormatType === FormatTypeEnum.IsDateTime) {
        return Math.abs(dayjs(updateRecord[valueField]).diff(dayjs(updateRecord.clientValue), 'day')) <= threadhold // days diff less than or equal to threadhold, days always be the integer, not using bignumber to do the calculation
    }

    // did I missing anything?
    console.log('checkIsFinalReviewValueTie:should not reach here.')
    return false
}

const getContextFromLoanOrHeader = <T extends IDataRow>(context: any, node: IRowNode<T>) => {
    if (Object.prototype.hasOwnProperty.call(context, 'headerReview' as keyof HeaderContextType)) {
        const headerReview = (context as HeaderContextType).headerReview
        return {
            isBlindReview: headerReview.isBlindReview,
            dataFormatType: headerReview.dataFormatType,
            dataFormatCode: headerReview.dataFormatCode,
            dropdownCategoryId: headerReview.dropdownCategoryId,
            dropdownCategoryOptions: headerReview.dropdownCategoryOptions,
            processType: headerReview.processType
        }
    } else {
        const data = node.data as API.ILoanReviewData
        return {
            isBlindReview: (context as LoanContextType).isBlindReview || data.isBlindReview,
            dataFormatType: data.dataFormatType,
            dataFormatCode: data.dataFormatCode,
            dropdownCategoryId: data.dropdownCategoryId,
            dropdownCategoryOptions: data.dropdownCategoryOptions,
            processType: data.processType
        }
    }
}

export const createContextMenuFn = <T extends IDataRow>(field?: keyof Pick<T, 'firstReviewValue' | 'secondReviewValue' | 'thirdReviewValue'>): GetContextMenuItems<T> => {
    return ({ column, node, context, value }) => {
        const isEditable = column.isCellEditable(node)
        const { isBlindReview } = getContextFromLoanOrHeader(context, node)
        const menuItems: ReturnType<GetContextMenuItems<T>> = ['copy']
        const { reviewField } = getReviewFields<T>(field)
        if (isEditable) {
            menuItems.push(...[
                'paste',
                'separator',
                {
                    name: node.data[reviewField] ? 'Mark as not reviewed' : 'Mark as reviewed',
                    shortcut: 'Alt + R',
                    disabled: !!value,
                    action: () => {
                        node.setDataValue(reviewField, !node.data[reviewField])
                    },
                },
                'separator',
                {
                    name: 'Set to N/A',
                    shortcut: 'Alt + N',
                    action: () => {
                        node.setDataValue(field, NotAvailable)
                    },
                },
                {
                    name: 'Set to Various',
                    shortcut: 'Alt + V',
                    action: () => {
                        node.setDataValue(field, VARIOUS)
                    },
                },
                {
                    name: 'Copy from',
                    subMenu: [
                        {
                            name: 'Client Value',
                            shortcut: 'Alt + C',
                            action: () => {
                                node.setDataValue(field, node.data.clientValue)
                            },
                            disabled: isBlindReview,
                        },
                        {
                            name: 'First Reviewer',
                            shortcut: 'Alt + P',
                            action: () => {
                                node.setDataValue(field, node.data.firstReviewValue)
                            },
                            disabled: field === 'firstReviewValue'
                        },
                        {
                            name: 'Second Reviewer',
                            shortcut: 'Alt + S',
                            action: () => {
                                node.setDataValue(field, node.data.secondReviewValue)
                            },
                            disabled: field !== 'thirdReviewValue'
                        },
                    ]
                }
            ] as typeof menuItems)
        }
        return menuItems
    }
}

export const handleGridKeyDown = <T extends IDataRow>(e: CellKeyDownEvent<T>) => {
    const { node, event, colDef, column, context, value } = e
    const keyboardEvent = event as KeyboardEvent
    const { isBlindReview } = getContextFromLoanOrHeader(context, node)
    const { reviewField } = getReviewFields<T>(colDef.field as keyof T)

    //only works for review value columns and the cell should editable
    if (['firstReviewValue', 'secondReviewValue', 'thirdReviewValue'].includes(colDef.field) &&
        column.isCellEditable(node) &&
        keyboardEvent.altKey) {

        switch (keyboardEvent.code) {
            case 'KeyC':
                if (!isBlindReview) {
                    node.setDataValue(colDef.field, node.data.clientValue)
                }
                break;
            case 'KeyP':
                if (colDef.field !== 'firstReviewValue') {
                    node.setDataValue(colDef.field, node.data.firstReviewValue)
                }
                break;
            case 'KeyS':
                if (colDef.field === 'thirdReviewValue') {
                    node.setDataValue(colDef.field, node.data.secondReviewValue)
                }
                break;
            case 'KeyN':
                node.setDataValue(colDef.field, NotAvailable)
                break;
            case 'KeyV':
                node.setDataValue(colDef.field, VARIOUS)
                break;
            case 'KeyR':
                if (!value) {
                    node.setDataValue(reviewField, !node.data[reviewField])
                }
                break;
            default:
                break;
        }
    }

}

export const valueCellEditorSelector: CellEditorSelectorFunc<IDataRow> = ({ node, colDef, context }) => {
    const { dataFormatType, dataFormatCode, dropdownCategoryOptions } = getContextFromLoanOrHeader(context, node)
    if (dataFormatType === FormatTypeEnum.IsDateTime) {
        return {
            component: dateCellEditor,
            params: { format: [dataFormatCode, FORMATS.L, FORMATS.JSONDate] } as IDateCellEditorProps
        }
    } else if (dataFormatType === FormatTypeEnum.IsNumeric) {
        // "0.00" => ".00" => fixed=2; "0" => null
        const fixed = /\.0+/.exec(dataFormatCode)
        return {
            component: numericCellEditor,
            params: {
                fixed: fixed && (fixed[0].length - 1) || 0,
                isPercentage: dataFormatCode.includes('%'),
                isNegativeAllowed: true,
                maxLength: colDef.cellEditorParams?.maxLength,
                isTextAllowd: true
            } as INumericCellEditorProps
        }
    } else {
        return {
            component: TextCellEditor,
            popup: true,
            params: {
                options: dropdownCategoryOptions
            } as ITextCellEditorProps
        }
    }
}

export const suppressKeyboardEvent = <T extends IDataRow>(params: SuppressKeyboardEventParams<T>) => {
    // return true (to suppress) if editing and user hit up/down keys
    const key = params.event.key
    const { dropdownCategoryId, dataFormatType } = getContextFromLoanOrHeader(params.context, params.node)
    const gridShouldDoNothing = ([FormatTypeEnum.IsDateTime].includes(dataFormatType as FormatTypeEnum) || dropdownCategoryId > 0) && params.editing && (key === KeyCode.ENTER)
    return gridShouldDoNothing
}

export const valueParser = <T extends IDataRow>({ newValue }: ValueParserParams<T>) => newValue && newValue !== NotAvailable ? ('' + newValue) : newValue

export const colSpanFn = <T extends IDataRow>({ context, node }: ColSpanParams<T, any>) => {
    const { processType } = getContextFromLoanOrHeader(context, node)
    return processType === PROCESS_TYPES.ReviewCalculation ? 1 : 2
}

export const cellClassFn: CellClassFunc<IDataRow> = ({ column, node, data, colDef, context }) => {
    const editable = column.isCellEditable(node)
    const { valueField, reviewField, reviewLevel } = getReviewFields<IDataRow>(colDef.field as keyof IDataRow)
    const cellValue = data[valueField]

    if (Object.hasOwn(data, 'parentId') && (data as API.ILoanReviewData).parentId) {
        return null
    }

    if (isNullOrEmpty(cellValue)) {
        if (data[reviewField]) {
            return isNullOrEmpty(data.clientValue) ? 'ag-cell-match' : 'ag-cell-different' //mark as reviewed and client value is empty, tie
        } else {
            return editable ? 'ag-cell-empty' : null
        }
    }

    //replace recursion related logic to and make the logic more simple and consist.
    const isTie = checkIsFinalReviewValueTie<IDataRow>(data, reviewLevel, (context as HeaderContextType)?.headerReview)
    return isTie ? 'ag-cell-match' : 'ag-cell-different'

}