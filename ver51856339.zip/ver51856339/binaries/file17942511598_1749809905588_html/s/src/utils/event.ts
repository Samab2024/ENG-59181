
export default class EventEmitter<T> {
    private readonly _handlers: ((data: T) => void)[];
    constructor() {
        this._handlers = [];
    }

    addEventListener(handler: (data: T) => void): () => void {
        this._handlers.push(handler);
        return () => {
            const index = this._handlers.indexOf(handler);
            if (index >= 0) {
                this._handlers.splice(index, 1);
            }
        };
    }
    dispatchEvent(data?: T) {
        for (const handler of this._handlers) {
            try { handler(data); } catch (ex) { console.log(ex); /* ignore */ }
        }
    }
}
