import { AxiosResponse } from "axios"
import { NotAvailable } from "./numberHelper";
import { FormatTypeEnum } from "@/constants";
import dayjs from "dayjs";
import isoWeek from 'dayjs/plugin/isoWeek'
import numeral from "numeral";

dayjs.extend(isoWeek)

export const getFileNameFromHeader = (response: AxiosResponse, defaultName = 'downloadFile') => {
    const contentDispositionItem = response.headers['content-disposition'].split(';').find(x => x.indexOf("filename=") >= 0)
    return contentDispositionItem && contentDispositionItem.replace(/^\s*filename="?/i, '').replace(/"\s*$/i, '') || defaultName;
}

export function isNullOrEmpty(str: string | null | undefined): boolean {
    return str === undefined || str === null || (str + '').trim() === '';
}

export const parseToString = (value: any, trim = true) => {
    if (typeof value === 'number') {
        return '' + value
    } else if (typeof value === 'string' && trim) {
        return value.trim()
    } else {
        return value
    }
}

export const convertToNumeralFormat = (excelFormatString: string) => {
    if (!excelFormatString) return excelFormatString
    let result: any = excelFormatString.split(';')
    result = result[result.length - 1]
    return result.replace(/#,/g, '0,')
        .replace(/##/g, '')
        .replace(/\[RED\]/gi, '')
        .replace(/E\+0+/g, 'e+0');
}

export const convertToDayjsFormat = (excelFormatString: string) => {
    if (!excelFormatString) return excelFormatString
    let result = excelFormatString
        .replace(/y{2,4}/g, x => x.toUpperCase()) //replace year
        .replace(/m{1,4}/g, x => x.toUpperCase()) //replace month
        .replace(/(:M+)|(M+:)/g, x => x.toLowerCase()) //replace minute back
        .replace(/d{1,4}/g, x => x.toUpperCase()) //replace day
    if (result.includes('AM/PM')) {
        //keep hh for 12 hours
        result = result.replace('AM/PM', 'A')
    } else {
        //replace hh to HH for 24 hours
        result = result.replace(/h{1,2}/g, x => x.toUpperCase()) //replace hours
    }
    return result
}

export const getFormatedValue = (value: any, dataFormatType: string, dataFormatCode: string) => {
    try {
        if (value === "" || value === null || value === undefined) {
            return '';
        } else if (value === NotAvailable) {
            return NotAvailable
        } else {
            if (dataFormatType === FormatTypeEnum.IsDateTime) {
                const jsDate = dayjs(value)
                return jsDate.isValid() ? jsDate.format(dataFormatCode) : value
            } else if (dataFormatType === FormatTypeEnum.IsNumeric && !isNaN(Number(value))) {
                const val = numeral(value)
                return isNaN(val.value()) ? value : val.format(dataFormatCode)
            } else {
                return value;
            }
        }
    }
    catch (error) {
        return NotAvailable;
    }
}


export default {
    getFileNameFromHeader,
    isNullOrEmpty,
    parseToString,
    convertToNumeralFormat,
    convertToDayjsFormat,
}
