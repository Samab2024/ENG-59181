const valueOfType = <T>(value: T): T => value;
export default valueOfType;