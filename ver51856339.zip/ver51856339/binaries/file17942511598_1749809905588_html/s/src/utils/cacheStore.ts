
const TOKEN = "t"
const PORTAL_TOKEN = 'currentToken'
const RETURN_URL = 'returnURL'

export const getToken = () => localStorage.getItem(TOKEN) || ''

export const hasToken = () => !!getToken()

export const setToken = (token: string) => localStorage.setItem(TOKEN, token)

export const clearToken = () => localStorage.removeItem(TOKEN)

export const getPortalToken = () => localStorage.getItem(PORTAL_TOKEN) || ''

export const clearAll = () => localStorage.clear()

export const popReturnURL = () => {
    const result = sessionStorage.getItem(RETURN_URL)
    sessionStorage.removeItem(RETURN_URL)
    return result
}

export const setReturnURL = (url: string) => sessionStorage.setItem(RETURN_URL, url)

export default {
    getToken: getToken,
    hasToken: hasToken,
    setToken: setToken,
    clearToken: clearToken,
    getPortalToken: getPortalToken,
    popReturnURL: popReturnURL,
    setReturnURL: setReturnURL,
    clearAll: clearAll,
}