import { createBrowserHistory } from 'history'
import { Modal } from 'antd'

const history = createBrowserHistory()

// const unblock = history.block(t => {
//     Modal.confirm({
//         title: '',
//         okText: 'Stay on the page',
//         cancelText: 'Leave without saving',
//         onOk() {
//             unblock()
//             t.retry()
//         },
//     })
// })

export default history
