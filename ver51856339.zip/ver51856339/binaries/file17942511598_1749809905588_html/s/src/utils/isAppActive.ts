
let activeFlag = true;
export function getAppIsActive() {
    return activeFlag;
}

let timeout: ReturnType<typeof setTimeout>;
function handleActiveEvent() {
    activeFlag = true;
    if (timeout) {
        clearTimeout(timeout);
    }
    timeout = setTimeout(() => activeFlag = false, 1800_000);
}
window.addEventListener('mousemove', handleActiveEvent);
window.addEventListener('keydown', handleActiveEvent);
window.addEventListener('click', handleActiveEvent);
