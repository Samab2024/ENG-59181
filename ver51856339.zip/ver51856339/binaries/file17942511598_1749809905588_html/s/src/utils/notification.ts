import React from 'react';
import type { ArgsProps } from 'antd/es/notification/interface';
import { NotificationEventEmitter } from '@/GlobalMessage';

const defaultConfig: Partial<ArgsProps> = {
    placement: 'bottomRight',
    duration: 3,
}

type OtherArgs = Omit<ArgsProps, 'message'>;
const notification = {
    info: (message: React.ReactNode, args: OtherArgs = {}) => {
        NotificationEventEmitter.dispatchEvent({
            type: 'info',
            props: { message, ...defaultConfig, ...args }
        })
        return true;
    },
    error: (message: React.ReactNode, args: OtherArgs = {}) => {
        NotificationEventEmitter.dispatchEvent({
            type: 'error',
            props: { message, ...defaultConfig, ...args }
        })
        return false;
    },
    success: (message: React.ReactNode, args: OtherArgs = {}) => {
        NotificationEventEmitter.dispatchEvent({
            type: 'success',
            props: { message, ...defaultConfig, ...args }
        })
        return true;
    },
    warning: (message: React.ReactNode, args: OtherArgs = {}) => {
        NotificationEventEmitter.dispatchEvent({
            type: 'warning',
            props: { message, ...defaultConfig, ...args }
        })
        return true;
    },

};

export default notification;
