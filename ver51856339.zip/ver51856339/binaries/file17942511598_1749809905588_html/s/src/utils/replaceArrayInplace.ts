
export default function replaceArrayInplace<T>(array: T[], newValue: T[]) {
    const result = array.splice(0, array.length);
    for (const value of newValue) {
        array.push(value);
    }
    return result;
}
