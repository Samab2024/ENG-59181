
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc'
import timezone from 'dayjs/plugin/timezone'

dayjs.extend(utc)
dayjs.extend(timezone)

/**
 * Default timezone for server time or API data exchange time
 * Reference: https://momentjs.com/timezone/docs/#/using-timezones/
 * Reference: https://day.js.org/docs/en/display/format
 */
export const TIME_ZONE = 'America/New_York'

export const FORMATS = {
    /** MMM D, YYYY HH:mm z */
    lll: 'MMM D, YYYY HH:mm z',
    /** MMM D, YYYY */
    ll: 'MMM D, YYYY',
    /** MM/DD/YYYY */
    L: 'MM/DD/YYYY',
    /** MM/DD/YYYY HH:mm z */
    LLL: 'MM/DD/YYYY HH:mm',
    /** YYYY-MM-DD */
    JSONDate: 'YYYY-MM-DD',
    /** YYYY-MM-DDTHH:mm:ss */
    JSONDateTime: 'YYYY-MM-DDTHH:mm:ss',
}

//TODO refactoring
export const parse = (value: API.DateInput, timezone = TIME_ZONE) => dayjs(value).tz(timezone)

export const parseUTC = (value: API.DateInput) => dayjs.utc(value)

export const format = (value: API.DateInput, format = FORMATS.LLL, timezone = TIME_ZONE) => parse(value, timezone).format(format)

export const formatUTC = (value: API.DateInput, format = FORMATS.LLL) => parseUTC(value).format(format)

export const dateTimeFormatter = (value: API.DateInput) => dayjs(value).format('MMM D, YYYY HH:mm')

export const parseEast = (value: API.DateInput, timezone = TIME_ZONE) => dayjs.utc(value).tz(timezone).format()

export const parseEast_noformat = (value: API.DateInput, timezone = TIME_ZONE) => dayjs.utc(value).tz(timezone)

export const formatEast = (value: API.DateInput, format = FORMATS.LLL, timezone = TIME_ZONE) => dayjs.utc(value).tz(timezone).format(format)

export default {
    TIME_ZONE,
    FORMATS,
    parse,
    parseUTC,
    format,
    formatUTC,
    dateTimeFormatter,
    parseEast,
    formatEast,
    parseEast_noformat
}