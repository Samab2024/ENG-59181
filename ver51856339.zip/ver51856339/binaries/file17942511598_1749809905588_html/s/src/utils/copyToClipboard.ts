/**
 * Copy text to clicpboard
 * @param text
 * @returns
 */
function copyToClipboard(text: string) {
  return navigator.clipboard.writeText(text)
}

export default copyToClipboard