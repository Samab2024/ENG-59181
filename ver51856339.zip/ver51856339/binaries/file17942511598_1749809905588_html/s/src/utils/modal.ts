import { ModalFuncProps } from "antd";
import { ModalEventEmitter } from '@/GlobalMessage';

const modal = {
    confirm: (args: ModalFuncProps = {}) => {
        // goto PopupProvider to see where these events are sending
        ModalEventEmitter.dispatchEvent({
            type: 'confirm',
            props: args
        })
        return true;
    },
    error: (args: ModalFuncProps = {}) => {
        ModalEventEmitter.dispatchEvent({
            type: 'error',
            props: args
        })
        return false;
    },
    info: (args: ModalFuncProps = {}) => {
        ModalEventEmitter.dispatchEvent({
            type: 'info',
            props: args
        })
        return true;
    },
    success: (args: ModalFuncProps = {}) => {
        ModalEventEmitter.dispatchEvent({
            type: 'success',
            props: args
        })
        return true;
    },
    warning: (args: ModalFuncProps = {}) => {
        ModalEventEmitter.dispatchEvent({
            type: 'warning',
            props: args
        })
        return true;
    },

};

export default modal;
