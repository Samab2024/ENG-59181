
const DEFAULT_TITLE = document.title

function set(title: string) {
    document.title = `${title} - ${DEFAULT_TITLE}`
}

function reset() {
    document.title = DEFAULT_TITLE
}

export const PageTitle = {
    set,
    reset
}