import { all, create } from 'mathjs';
import numeral from 'numeral';

export const NotAvailable = 'N/A';
export const Blank = '';

function validateValue(value) {
    if (value === undefined || value === null || value === "") {
        return true
    }
    if (Number.isNaN(value) || value === Number.POSITIVE_INFINITY || value === Number.NEGATIVE_INFINITY) {
        return true
    }
    if (Number.isNaN(Number.parseFloat(value)) && typeof value === 'string') {
        return true
    }
    return false
}

function roundTo(num, digits) {
    if (typeof digits !== 'number') {
        return num
    }

    let negative = false

    if (num < 0) {
        negative = true
        num = num * -1
    }

    const factor = Math.pow(10, digits)
    num = parseFloat((num * factor).toFixed(11))
    num = (Math.round(num) / factor).toFixed(digits)
    if (negative) {
        num = (num * -1).toFixed(digits)
    }

    return num
}

export function decimalFormatter(value, fixed?: number) {
    const isInvalid = validateValue(value)
    if (isInvalid) {
        return NotAvailable
    }

    let result = `${roundTo(value, fixed)}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    const index = result.indexOf(".")
    if (index >= 0) {
        result = result.substring(0, index) + result.substring(index).replace(/,/g, "")
    }
    return result
}

export const decimalParser = (value) => value.replace(/,/g, "")


export function percentFormatter(value, fixed?: number) {
    const isInvalid = validateValue(value)
    if (isInvalid) {
        return NotAvailable
    }

    const num = Number.parseFloat(value) * 100

    if (fixed || fixed === 0) {
        return `${roundTo(num, fixed)}%`
    }

    return `${num}%`
}

export const percentParser = (value) => {
    const num = value.replace(/%.*/, "")
    //16.7/100 -> 0.16699999999999998
    //return num / 100
    const index = value.indexOf(".")
    if (index >= 0) {
        return (num / 100).toFixed(2 + num.length - index - 1)
    } else {
        return (num / 100).toFixed(2)
    }
}

export const percentValidator = (precision) => (value) => {
    return (
        (value && new RegExp(`^\\d{1,}(\\.\\d{0,${precision}})?%?$`).test(value)) ||
        !value
    )
}

export const math = create(all);
export const calculateFormula = (formula: string, dataFormatCode?: string) => {
    try {
        if (!formula) return null
        if (!dataFormatCode) return math.evaluate(formula)

        const isPercentage = dataFormatCode.includes('%')
        const evaluatedResult = math.evaluate(isPercentage ? `(${formula})/100` : formula);
        const formattedString = numeral(evaluatedResult).format(dataFormatCode)
        return numeral(formattedString).value() //Apply format and convert the value back
    } catch (error) {
        return NaN
    }
}

export const roundPercentage = (value: any) => {
    if (isNaN(Number(value))) return NaN
    return math.number(math.multiply(math.bignumber(value as any), 100))
}

export const percentageToNumber = (value: any) => {
    return math.number(math.divide(math.bignumber(value as any), 100))
}

export default {
    math,
    decimalFormatter,
    decimalParser,
    percentFormatter,
    percentParser,
    percentValidator,
    calculateFormula,
    roundPercentage,
    percentageToNumber,
}