type PartialRecord<K extends keyof any, T> = Partial<Record<K, T>>
export default PartialRecord