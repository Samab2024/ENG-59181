const nameOfData = <T>(name: keyof T) => name;
export default nameOfData;