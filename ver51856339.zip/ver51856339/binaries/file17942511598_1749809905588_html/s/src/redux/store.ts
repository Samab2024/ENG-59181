import { IS_DEBUG } from '@/config';
import { combineReducers, configureStore, PreloadedState } from '@reduxjs/toolkit';
import { Middleware } from "redux";
import userReducer from './userSlice';

let logger: Middleware
if (IS_DEBUG) {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { createLogger } = require(`redux-logger`);
  logger = createLogger({ collapsed: true });
}

const rootReducer = combineReducers({
  user: userReducer
})

export function setupStore(preloadedState?: PreloadedState<RootState>) {
  return configureStore({
    reducer: rootReducer,
    preloadedState,
    middleware: getDefaultMiddleware =>
      getDefaultMiddleware()
        .prepend(IS_DEBUG ? [logger] : [])
  })
}
export type RootState = ReturnType<typeof rootReducer>
export type AppStore = ReturnType<typeof setupStore>
export type AppDispatch = AppStore['dispatch']