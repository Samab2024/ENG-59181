import { ThemeConfig, theme } from "antd";

const seedToken: Partial<typeof theme.defaultSeed> = {
    colorPrimary: "#FD5108",
    colorSuccess: "#22992e",
    colorWarning: "#ffbf1f",
    colorError: "#c52a1a",
    colorTextBase: "#404041",
}

const mapToken = theme.defaultAlgorithm({
    ...theme.defaultSeed,
    ...seedToken
})

const themeConfig: ThemeConfig = {
    algorithm: [
        theme.defaultAlgorithm,
        // theme.compactAlgorithm
    ],
    token: {
        ...seedToken,
        borderRadius: 4,
        wireframe: true,
        fontFamily: "'PwC Helvetica Neue', Arial",
        colorBgLayout: '#F3F3F5',
        colorLink: mapToken.colorPrimaryText,
        colorLinkHover: mapToken.colorPrimaryTextHover,
        colorLinkActive: mapToken.colorPrimaryTextActive,
        fontSize: 12,
        colorText: 'rgba(64, 64, 65)',
        colorTextDisabled: 'rgba(64, 64, 65, 0.6)',
    },
    components: {
        Layout: {
            controlHeight: 25,
            headerBg: '#FFF',
        },
        Modal: {
            colorSplit: 'transparent'
        },
        Table: {
            paddingXS: 4,
            rowHoverBg: "#FFE6A2",
        },
        Descriptions: {
            padding: 4
        },
        Tabs: {
            horizontalMargin: "0 0 0px 0",
            horizontalItemPaddingSM: "4px 0px"
        },
        Notification: {
            marginXS: 0
        },
        Form: {
            itemMarginBottom: 12,
            verticalLabelPadding: "0"
        },
    }
}

export default themeConfig