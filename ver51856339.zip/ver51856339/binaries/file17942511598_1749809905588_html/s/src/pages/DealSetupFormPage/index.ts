import { Dayjs } from 'dayjs'

export type IDealSetupForm = Omit<API.IDealSetup, 'cutOffDate'> & {
    cutOffDate: Dayjs
}

export { default } from './DealSetupFormPage'