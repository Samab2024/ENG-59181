import { Drawer, Spin } from "antd";
import { useForm } from "antd/lib/form/Form";
import dayjs from "dayjs";
import { FIClose } from "functional-icons/lib/Outline";
import { FC, useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import { IDealSetupForm } from ".";
import DealSetupForm from "./DealSetupForm";
import DealAPI from '@/services/api/DealAPI'
import { DealListPageContext } from "./../DealListPage/DealListPage";
import { DealPageContext } from "./../DealPage";
import notification from '@/utils/notification'
import { isNullOrEmpty } from "@/utils/stringHelper";
import { FORMATS } from "@/utils/dateHelper";

const DealSetupFormPage: FC<{
    isNew: boolean
    open: boolean
    onClose: () => void
}> = ({ isNew, open, onClose }) => {
    const { id } = useParams()
    const [form] = useForm<IDealSetupForm>()
    const [loading, setLoading] = useState(false)
    const { refreshDeals } = useContext(DealListPageContext);
    const { refreshData } = useContext(DealPageContext);

    useEffect(() => {
        if (!isNew && Number(id) > 0 && open) {
            setLoading(true)
            DealAPI.getDealById(Number(id)).then(deal => {
                form.setFieldsValue({
                    ...deal,
                    cutOffDate: deal.cutOffDate == null ? null : dayjs(deal.cutOffDate),
                    dealAdminArr: deal.dealAdmin?.split(','),
                    dealContactArr: isNullOrEmpty(deal.dealContact) ? undefined : deal.dealContact?.split(','),
                })
            })
                .catch(e => notification.error((e as API.IException).message))
                .finally(() => setLoading(false))
        }
    }, [open])

    const handleSave = (formData: IDealSetupForm) => {
        setLoading(true)
        if (isNew) {
            formData.dealAdmin = formData.dealAdminArr ? formData.dealAdminArr.join(',') : "";
            formData.dealContact = formData.dealContactArr ? formData.dealContactArr.join(',') : "";
            DealAPI.createDeal({
                ...formData,
                cutOffDate: formData.cutOffDate && formData.cutOffDate.format(FORMATS.JSONDate)
            })
                .then(() => {
                    notification.success("Create deal successfully.")
                    onClose();
                    refreshDeals();
                })
                .catch(e =>
                    notification.error((e as API.IException).message)
                )
                .finally(() => setLoading(false))
        } else {
            formData.dealId = Number(id);
            formData.dealAdmin = formData.dealAdminArr ? formData.dealAdminArr.join(',') : "";
            formData.dealContact = formData.dealContactArr ? formData.dealContactArr.join(',') : "";
            DealAPI.updateDeal({
                ...formData,
                cutOffDate: formData.cutOffDate && formData.cutOffDate.format(FORMATS.JSONDate)
            })
                .then(() => {
                    notification.success("Update deal successfully.")
                    onClose();
                    refreshData('deal')
                    refreshData('loan')
                })
                .catch(e =>
                    notification.error((e as API.IException).message)
                )
                .finally(() => setLoading(false))
        }
    }

    return (
        <Drawer open={open} closeIcon={<FIClose />} onClose={onClose} title={`${isNew ? 'Add New' : 'Edit'} Deal`} width={400} className="request-form-page">
            <Spin spinning={loading}>
                <DealSetupForm form={form} onCancel={onClose} onSave={handleSave} isNew={isNew} />
            </Spin>
        </Drawer>
    )
}

export default DealSetupFormPage