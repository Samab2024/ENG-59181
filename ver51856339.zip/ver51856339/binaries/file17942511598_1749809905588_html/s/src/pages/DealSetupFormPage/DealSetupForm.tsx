
import * as controlStyles from '@/styles/control.module.css'
import nameOfData from "@/utils/nameOfData"
import { Button, Checkbox, DatePicker, Form, FormInstance, Input, InputRef, Select, Space } from "antd"
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { FC, useEffect, useRef, useState } from "react"
import { IDealSetupForm } from "."
import { selectCurrentUser } from '../../redux/userSlice'
import { useAppSelector } from '@/hooks/reduxHook'
import AuthAPI from '@/services/api/AuthAPI'
import notification from '@/utils/notification'
import InfoPop from '@/components/InfoPop';
import { FORMATS } from '@/utils/dateHelper';

const DealSetupForm: FC<{
    form: FormInstance<IDealSetupForm>
    onSave: (data: IDealSetupForm) => void
    onCancel: () => void
    isNew: boolean
}> = ({ form, onCancel, onSave, isNew }) => {
    const inputRef = useRef<InputRef>()
    const currentUser = useAppSelector(selectCurrentUser)
    const [users, setUsers] = useState([])

    useEffect(() => {
        setTimeout(() => {
            inputRef.current?.focus()
        });
    }, [])

    useEffect(() => {
        AuthAPI.getAllUsers()
            .then(users => {
                setUsers(users)
            })
            .catch(e => notification.error((e as API.IException).message))
    }, [])

    const filterOption = (input: string, option: any) => {
        return option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0;
    }
    const initialData = isNew ? { dealName: "", assetType: "CMBS", dealStatus: "Not Started", levelOfReview: 3, levelOfReviewForCalculation: 0, dealAdmin: currentUser?.email, docSections: ["Legal Terms", "Third Parties"] } : form

    const validateSelectedValues = ({ getFieldsValue }) => ({
        validator() {
            const { dealAdminArr, dealContactArr } = getFieldsValue();

            if (dealAdminArr && dealContactArr) {
                const commonValues = dealAdminArr.filter(value => dealContactArr.includes(value));

                if (commonValues.length > 0) {
                    return Promise.reject('User can only be the deal admin or deal contact.');
                }
            }

            return Promise.resolve();
        }
    });

    return (
        <Form form={form} layout="vertical" name="RequestForm" onFinish={data => onSave({
            ...form.getFieldsValue(true),
            ...data
        })} initialValues={initialData}>
            <Form.Item rules={[{ required: true, message: 'Please input deal name' }]} label="Deal Name" name={nameOfData<IDealSetupForm>("dealName")}>
                <Input />
            </Form.Item>
            {isNew && (
                <Form.Item rules={[{ required: true, message: 'Please select asset type' }]} label="Asset Type" name={nameOfData<IDealSetupForm>("assetType")}>
                    <Select className={controlStyles.fullWidth} options={[
                        { label: 'CMBS', value: 'CMBS' },
                        { label: 'ABS', value: 'ABS' },
                        { label: 'CLO', value: 'CLO' },
                        { label: 'SFR', value: 'SFR' },
                    ]} />
                </Form.Item>
            )}
            <Form.Item label="Key Column" name={nameOfData<IDealSetupForm>("keyColumn")}>
                <Input maxLength={100} />
            </Form.Item>
            <Form.Item label="Loan Number Display Column" name={nameOfData<IDealSetupForm>("loanNumberDisplayColumn")}>
                <Input maxLength={100} />
            </Form.Item>
            <Form.Item label="Cut Off Date" name={nameOfData<IDealSetupForm>("cutOffDate")}>
                <DatePicker className={controlStyles.fullWidth} format={[FORMATS.L, FORMATS.JSONDate]} />
            </Form.Item>
            {isNew && (
                <Form.Item rules={[{ required: true, message: 'Please select level of review' }]} label="Level of Review" name={nameOfData<IDealSetupForm>("levelOfReview")}>
                    <Select className={controlStyles.fullWidth} options={[
                        { label: 1, value: 1 },
                        { label: 2, value: 2 },
                        { label: 3, value: 3 },
                    ]} />
                </Form.Item>
            )}
            <Form.Item rules={[{ required: true, message: 'Please select level of review for calculation' }]} label="Level of Review for Calculation" tooltip="The minimal review level from which the calculator will retrieve data." name={nameOfData<IDealSetupForm>("levelOfReviewForCalculation")}>
                <Select className={controlStyles.fullWidth} options={[
                    { label: 'Client Value', value: 0 },
                    { label: 1, value: 1 },
                    { label: 2, value: 2 },
                    { label: 3, value: 3 },
                ]} />
            </Form.Item>
            <Form.Item label="Client Name" name={nameOfData<IDealSetupForm>("clientName")}>
                <Input maxLength={500} />
            </Form.Item>
            <Form.Item rules={[{ required: true, message: 'Please select deal status' }]} label="Deal Status" name={nameOfData<IDealSetupForm>("dealStatus")}>
                <Select className={controlStyles.fullWidth} options={[
                    { label: 'Not Started', value: 'Not Started' },
                    { label: 'In Progress', value: 'In Progress' },
                    { label: 'Completed', value: 'Completed' },
                ]} />
            </Form.Item>
            <Form.Item valuePropName="checked" name={nameOfData<IDealSetupForm>("isBlindReview")}>
                <Checkbox>Is Blind Review</Checkbox>
            </Form.Item>
            <Form.Item valuePropName="checked" name={nameOfData<IDealSetupForm>("isExRptIncludePwCComments")}>
                <Checkbox>
                    Exception Report Consider PwC Comment
                    <InfoPop textInline content="Exception report will include tied values when there is a PwC comment present." placement="top" />
                </Checkbox>
            </Form.Item>
            <Form.Item rules={[{ required: true, message: 'Please select deal admin' }, validateSelectedValues]} label="Deal Admin" name={nameOfData<IDealSetupForm>("dealAdminArr")} initialValue={[currentUser?.email]}>
                <Select mode="multiple" className={controlStyles.fullWidth}
                    filterOption={filterOption}
                    options={users ? users.map((user, index) => ({ key: index, label: user.email, value: user.email })) : []} />
            </Form.Item>
            <Form.Item label="Deal Contact" name={nameOfData<IDealSetupForm>("dealContactArr")} rules={[validateSelectedValues]}>
                <Select mode="multiple" className={controlStyles.fullWidth}
                    filterOption={filterOption}
                    options={users ? users.map((user, index) => ({ key: index, label: user.email, value: user.email })) : []} />
            </Form.Item>
            <Form.Item label="Description" name={nameOfData<IDealSetupForm>('dealDesc')}>
                <Input.TextArea maxLength={500} />
            </Form.Item>

            {isNew && <Form.List
                name="docSections"
                rules={[
                    {
                        validator: async (_, docSections) => {
                            if (docSections.length !== new Set(docSections).size) {
                                return Promise.reject(new Error('Duplicated section names'));
                            }
                        },
                    },
                ]}
            >
                {(fields, { add, remove }, { errors }) => (
                    <>
                        {fields.map((field, index) => (
                            <Form.Item style={{ marginBottom: 12 }} label={index === 0 ? 'Sections' : ''} required={false} key={field.key}>
                                <Form.Item {...field} validateTrigger={['onChange', 'onBlur']} noStyle
                                    rules={[
                                        {
                                            required: true,
                                            whitespace: true,
                                            message: "Please input section name or delete this field.",
                                        },
                                    ]}>
                                    <Input placeholder="section name" style={{ width: '94%' }} />
                                </Form.Item>
                                <MinusCircleOutlined style={{ marginLeft: 6 }} className="dynamic-delete-button" onClick={() => remove(field.name)} />
                            </Form.Item>
                        ))}
                        <Form.Item>
                            <Button type="dashed" onClick={() => add()} style={{ width: '100%' }} icon={<PlusOutlined />}>Add Section</Button>
                            <Form.ErrorList errors={errors} />
                        </Form.Item>
                    </>
                )}
            </Form.List>}

            <Form.Item>
                <Space>
                    <Button type="primary" htmlType="submit">
                        Submit
                    </Button>
                    <Button onClick={onCancel}>Cancel</Button>
                </Space>
            </Form.Item>
        </Form>
    )
}

export default DealSetupForm