import createStyle from "@/hooks/createStyle";
import { css } from "@emotion/react";

export default createStyle(token => ({
    root: css`
        .functional-icons {
            display: flex;
            flex-wrap: wrap;

            .icon-card {
                padding: 0.25rem;
                display: inline-block;
                width: 10%;
                text-align: center;
                min-height: 80px;

                span {
                    display: block;
                    font-size: 1rem;
                    line-height: 16px;
                    word-break: break-all;
                }

                &:hover {
                    background-color: #EEE;
                }
            }
        }
        .no-label .functional-icons {
            .icon-card {
                width: auto;
                min-height: auto;
                span {
                    display: none;
                }
            }
        }
`
}))