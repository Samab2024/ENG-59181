import Text from "@/components/Text";
import FunctionalIcons, { IconType } from "functional-icons/lib/FunctionalIcons";
import { FC, FunctionComponent, useState } from "react";
// import './Demo.less'
import { Button, Card, Checkbox, Col, DatePicker, Form, Input, InputNumber, Radio, Row, Select, Space, Switch, Tabs, Tooltip } from "antd";
import { FILightbulb, FIPlus } from "functional-icons/lib/Outline";
import useStyle from './styles';

const IconDemo: FunctionComponent = () => {
    const [iconType, updateIconType] = useState(IconType.Outline)
    const [showLabel, updateShowLabel] = useState(false)
    const [fontSize, updateFontSize] = useState(24)
    const [fontColor, updateFontColor] = useState('#000000')
    return (
        <Card title="PwC Functional Icons V3" className={showLabel ? "" : "no-label"}>
            <Radio.Group size="small" value={iconType} onChange={(e) => updateIconType(e.target.value)}>
                <Radio.Button value={IconType.Outline}>Outline</Radio.Button>
                <Radio.Button value={IconType.Fill}>Filled</Radio.Button>
            </Radio.Group>
            <Checkbox checked={showLabel} onChange={e => updateShowLabel(e.target.checked)} style={{ margin: '0 8px' }} >Show Label</Checkbox>
            <label>Font Size: </label>
            <InputNumber size="small" value={fontSize} onChange={value => updateFontSize(value)}></InputNumber>
            <Select style={{ marginLeft: '8px' }} value={fontColor} onSelect={value => updateFontColor(value)} size="small" popupMatchSelectWidth={false}>
                <Select.Option value="#000000">Black Color</Select.Option>
                <Select.Option value="#D04A02">Primary Color</Select.Option>
                <Select.Option value="#EB8C00">Secondery Color</Select.Option>
                <Select.Option value="#C52A1A">Red Color</Select.Option>
                <Select.Option value="#FFBF1F">Yellow Color</Select.Option>
                <Select.Option value="#22992E">Green Color</Select.Option>
            </Select>
            <FunctionalIcons type={iconType} fontSize={fontSize} fontColor={fontColor} />
        </Card>
    )
}

const Demo: FC = () => {
    const { root } = useStyle()

    return (
        <div css={root} style={{ width: '100%', minHeight: '100vh', background: "#FBFBFB", padding: '2rem' }}>
            <h1>Style Guide</h1>
            <Space direction="vertical" size="middle">
                <Card bordered={false} style={{ width: '50%' }}>
                    <Text.Header1>Header - h1</Text.Header1>
                    <Text.Header2 >Header - h2</Text.Header2>
                    <Text.ParagraphTitle>Paragraph Title</Text.ParagraphTitle>
                    <p>Neque iste voluptas reiciendis. Reprehenderit ab iusto fuga est quis nostrum maiores rerum. Quia sunt nihil vel consequuntur ut id aut voluptatem qui. Libero aut omnis modi provident dignissimos qui dolor qui. Ullam dolor nostrum. Quia est ad.</p>
                    <p><strong>Distinctio dicta id soluta id aliquid dolores voluptas et. Suscipit cumque aut dolor quae. Laudantium eius qui eius fuga.</strong></p>
                    <p><i>Id ipsum maiores maiores. Mollitia eum voluptas delectus dolorum. Ipsum ex ipsam aliquam consectetur non ut maxime qui.</i></p>
                    <span style={{ fontWeight: 400 }}>Regular text</span><br />
                    <span style={{ fontWeight: 500 }}>Medium text</span><br />
                    <span style={{ fontWeight: 700 }}>Bold text</span><br />
                    <span style={{ fontWeight: 300 }}>Light text</span><br />
                    <a href="#">Text Link</a>
                </Card>
                <IconDemo />
                <Card title="Section Title">
                    <p>This is a page section example</p>
                </Card>
                <Card title="Buttons">
                    <Space>
                        <Button type="primary">Primary</Button>
                        <Button>Default</Button>
                        <Button type="primary" ghost>Border</Button>
                        <Button type="link">Link</Button>
                        <Button type="link">
                            <FIPlus />
                            Add with Custom Icon
                        </Button>
                    </Space>
                    <Space className="empty-line-top">
                        <Button type="primary" disabled>Primary</Button>
                        <Button disabled>Default</Button>
                        <Button type="primary" ghost disabled>Border</Button>
                        <Button type="link" disabled>Link</Button>
                        <Button type="link" disabled>
                            <FIPlus />
                            Add with Custom Icon
                        </Button>
                    </Space>
                </Card>
                <Card title="Form Control" style={{ width: '40%' }}>
                    <Form layout="vertical">
                        <Form.Item label="Field A" required>
                            <Input placeholder="Input" />
                        </Form.Item>
                        <Form.Item label={<span className="required">Field A1</span>}>
                            <Input placeholder="Input" />
                        </Form.Item>
                        <Form.Item label={<span>Field B<Tooltip title="A Simple tooltip" placement="left">
                            <FILightbulb className="color-orange" style={{ marginLeft: '4px' }} />
                        </Tooltip></span>} >
                            <Select placeholder="Select">
                                <Select.Option value="1">Option 1</Select.Option>
                                <Select.Option value="2">Option 2</Select.Option>
                                <Select.Option value="3">Option 3</Select.Option>
                            </Select>
                        </Form.Item>
                        <Form.Item label="Select with Right Alignment">
                            <Select placeholder="Select" className="align-right" allowClear>
                                <Select.Option value="1">Option 1</Select.Option>
                                <Select.Option value="2">Option 2</Select.Option>
                                <Select.Option value="3">Option 3</Select.Option>
                            </Select>
                        </Form.Item>
                        <Row gutter={8}>
                            <Col span={12}>
                                <Form.Item label="Field C" required>
                                    <DatePicker className="fullwidth"></DatePicker>
                                </Form.Item>
                            </Col>
                            <Col span={12}>
                                <Form.Item label="Field D">
                                    <Input placeholder="Input" />
                                </Form.Item>
                            </Col>
                        </Row>
                        <Form.Item>
                            <Checkbox>
                                I have read the <a href="">agreement</a>
                            </Checkbox>
                        </Form.Item>
                        <Form.Item>
                            <Switch></Switch>
                        </Form.Item>
                        <Form.Item>
                            <Radio.Group defaultValue="1">
                                <Radio.Button value="1">Radio 1</Radio.Button>
                                <Radio.Button value="2">Radio 2</Radio.Button>
                                <Radio.Button value="3">Radio 3</Radio.Button>
                            </Radio.Group>
                        </Form.Item>
                        <Form.Item>
                            <Button.Group>
                                <Button>Button 1</Button>
                                <Button>Button 2</Button>
                                <Button>Button 3</Button>
                            </Button.Group>
                        </Form.Item>
                        <Form.Item >
                            <div>
                                <Button type="primary">Submit</Button>
                            </div>
                        </Form.Item>
                    </Form>
                </Card>
                <Card title="Tabs">
                    <Tabs defaultActiveKey="1">
                        <Tabs.TabPane tab="Tab1" key="1"></Tabs.TabPane>
                        <Tabs.TabPane tab="Tab2" key="2"></Tabs.TabPane>
                        <Tabs.TabPane tab="Tab3" key="3"></Tabs.TabPane>
                        <Tabs.TabPane tab="Tab4" key="4" disabled></Tabs.TabPane>
                    </Tabs>
                </Card>
                <Card title="Card">
                    <Card title="Default size card" style={{ width: 300 }}>
                        <p>Card content</p>
                        <p>Card content</p>
                        <p>Card content</p>
                    </Card>
                </Card>
            </Space>
        </div>
    )
}

export default Demo
