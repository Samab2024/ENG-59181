import createStyle from "@/hooks/createStyle"
import { css } from "@emotion/react"
import { CustomInnerHeaderProps } from "ag-grid-react";
import { Popover, Space } from "antd"
import { FILightbulb } from "functional-icons/lib/Outline"

export const LoanStatusTooltip = (props: CustomInnerHeaderProps) => {
    const styles = useStyle()
    return <div css={styles.wrapper}>
        {props.displayName}
        <Popover content={<div css={styles.loanRview}>
            <Space size={"middle"}>
                <span className="loan-review-color" title={"NotStart"}>Not Started</span>
                <span className="loan-review-color" title={"InReview"}>In Review</span>
                <span className="loan-review-color" title={"Exception"}>Exception</span>
                <span className="loan-review-color" title={"Completed"}>Completed</span>
            </Space>
        </div>}>
            <FILightbulb className="icon" />
        </Popover>
    </div>;
};

const useStyle = createStyle((token) => ({
    loanRview: css`
        .loan-review-color {
            &::before {
                display: inline-block;
                margin-right: 4px;
                margin-bottom: -3px;
                content: ' ';
                width: 1rem;
                height: 1rem;
                background-color: ${token.colorText};
                border: solid 1px ${token.colorBorder};
            }
            &[title="NotStart"] {
                &::before {
                    background-color: ${token.colorWhite};
                }
            }
            &[title="InReview"] {
                &::before {
                    background-color: ${token.colorWarning}99;
                }
            }
            &[title="Exception"] {
                &::before {
                    background-color: ${token.colorError}66;
                }
            }
            &[title="Completed"] {
                &::before {
                    background-color: ${token.colorSuccess}99;
                }
            }
        }
    `,
    wrapper: css({
        '.icon': {
            color: token.colorPrimary,
            fontSize: '0.75rem',
            marginLeft: '4px'
        }
    })
}))