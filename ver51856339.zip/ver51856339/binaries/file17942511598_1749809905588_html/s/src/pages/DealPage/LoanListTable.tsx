import Grid, { getDefaultColumn } from "@/components/Grid";
import selectCellEditor, { ISelectCellEditorProps, suppressSelectKeyboardEvent } from "@/components/Grid/selectCellEditor";
import SelectCellRender, { ISelectCellRenderProps } from "@/components/Grid/selectCellRender";
import dropdownFilter, { DropdownFilterParams } from "@/components/Grid/dropdownFilter";
import { ReviewStatus, ReviewStatusEnum } from "@/constants";
import ReviewerAPI from "@/services/api/ReviewerAPI";
import notification from '@/utils/notification';
import { CellValueChangedEvent, ColDef, ICellRendererParams } from "ag-grid-community";
import { Spin } from "antd";
import { FC, useContext, useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { DealPageContext, FilterCache } from ".";
import useGridStyle from './grid.style';
import _ from 'lodash';
import { LoanStatusTooltip } from "./LoanStatusTooltip";

type IRowData = API.IReviewer

const defaultColumn = getDefaultColumn({
    resizable: true,
})

let filterCache: FilterCache

//FilterCache defined after filterCache, use timeout to make it work properly
setTimeout(() => {
    filterCache = new FilterCache()
});

function getLoanReviewClass(loanReviewStatus: string): string {
    switch (loanReviewStatus) {
        case 'InReview':
            return 'ag-loan-review-inreview';
        case 'Exception':
            return 'ag-loan-review-exception';
        case 'Completed':
            return 'ag-loan-review-completed';
        default:
            return '';
    }
}

const createColDefs = (levelOfReview: number, reviewers: API.UserInfo[], currentSectionId: number, loanReviewers: API.IReviewer[], isReadonly: boolean): ColDef<IRowData>[] => {
    const reviewerOptions = reviewers.map(x => ({ value: x.email, label: x.email }))
    const statusOptions = ReviewStatus.map(x => ({ value: x, label: x }))
    return [
        {
            colId: 'number',
            field: 'displayOrder',
            headerName: '#',
            width: 40,
            sortable: true,
            resizable: true,
        },
        {
            field: 'loanNumber',
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((loanReviewers?.map(x => ({
                    value: x.loanNumber,
                    label: x.loanNumber
                }))), JSON.stringify),
            } as DropdownFilterParams,
            cellRenderer: ({ data, value }: ICellRendererParams<IRowData>) => <NavLink to={`/${data.dealId}/loan/${data.loanId}/section/${currentSectionId}`}>{value}</NavLink>
        },
        {
            field: 'propertyName',
            headerComponentParams: {
                innerHeaderComponent: LoanStatusTooltip,
            },
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((loanReviewers?.map(x => ({
                    value: x.propertyName,
                    label: x.propertyName
                }))), JSON.stringify),
            } as DropdownFilterParams,
            cellClass: ({ data }) => getLoanReviewClass(data.loanReviewStatus)
        },
        {
            field: 'sellerName',
            hide: _.uniqBy((loanReviewers?.map(x => x.sellerName)), JSON.stringify).length <= 1,
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((loanReviewers?.map(x => ({
                    value: x.sellerName,
                    label: x.sellerName
                }))), JSON.stringify),
            } as DropdownFilterParams,
        },
        {
            field: 'reviewer1',
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((loanReviewers?.map(x => ({
                    value: x.reviewer1,
                    label: x.reviewer1
                }))), JSON.stringify),
            } as DropdownFilterParams,
            editable: !isReadonly,
            cellEditor: selectCellEditor,
            cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            cellRenderer: SelectCellRender,
            cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
        },
        {
            field: 'reviewerStatus1',
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((loanReviewers?.map(x => ({
                    value: x.reviewerStatus1,
                    label: x.reviewerStatus1
                }))), JSON.stringify),
            } as DropdownFilterParams,
            editable: !isReadonly,
            cellEditor: selectCellEditor,
            cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
        },
        ...([
            {
                field: 'reviewer2',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((loanReviewers?.map(x => ({
                        value: x.reviewer2,
                        label: x.reviewer2
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                editable: ({ data }) => data.reviewerStatus1 !== ReviewStatusEnum.NotStarted && !isReadonly,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: SelectCellRender,
                cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
            },
            {
                field: 'reviewerStatus2',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((loanReviewers?.map(x => ({
                        value: x.reviewerStatus2,
                        label: x.reviewerStatus2
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                editable: ({ data }) => data.reviewerStatus1 !== ReviewStatusEnum.NotStarted && !isReadonly,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
            },
            {
                field: 'reviewer3',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((loanReviewers?.map(x => ({
                        value: x.reviewer3,
                        label: x.reviewer3
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                editable: ({ data }) => data.reviewerStatus2 !== ReviewStatusEnum.NotStarted && !isReadonly,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: SelectCellRender,
                cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
            },
            {
                field: 'reviewerStatus3',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((loanReviewers?.map(x => ({
                        value: x.reviewerStatus3,
                        label: x.reviewerStatus3
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                editable: ({ data }) => data.reviewerStatus2 !== ReviewStatusEnum.NotStarted && !isReadonly,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
            },
        ] as ColDef<IRowData>[]).slice(0, (levelOfReview - 1) * 2)
    ]
}

const LoanListTable: FC = () => {
    const navigate = useNavigate()
    const { loanReviewers, reviewers, deal, currentSectionId, loading, refreshData } = useContext(DealPageContext);

    const [columnDefs, setColumnDefs] = useState<ColDef[]>([])
    const [saveLoading, setSaveLoading] = useState(false)

    const gridStyle = useGridStyle()

    useEffect(() => {
        setColumnDefs(createColDefs(deal.levelOfReview, reviewers, currentSectionId, loanReviewers, deal?.isReadOnly))
    }, [deal.levelOfReview, loanReviewers])

    //NOTICE: all logic here should reflect to HeaderListTable, LoanReviewerStatus, HeaderReviewerStatus
    const handleTableChange = ({ value, colDef, node, oldValue }: CellValueChangedEvent<IRowData>) => {
        let shouldRefreshSummay = false
        if (colDef.field.includes('Status')) {
            //Not allow to clear status
            if (!value) {
                node.setData({
                    ...node.data,
                    [colDef.field]: oldValue
                })
                return
            }
            shouldRefreshSummay = true
        } else {
            //Editing reviewer by default
            if (value && [1, 2, 3].find(x => colDef.field !== ('reviewer' + x) && node.data['reviewer' + x] === value)) {
                //Found duplicate reviewer
                node.setData({
                    ...node.data,
                    [colDef.field]: oldValue
                })
                return
            }
            const statusField = colDef.field.replace('reviewer', 'reviewerStatus')
            if (value && node.data[statusField] === ReviewStatusEnum.NotStarted) {
                node.setData({
                    ...node.data,
                    [statusField]: ReviewStatusEnum.InProgress
                })
                shouldRefreshSummay = true
            } else if (!value && node.data[statusField] !== ReviewStatusEnum.NotStarted) {
                node.setData({
                    ...node.data,
                    [statusField]: ReviewStatusEnum.NotStarted
                })
                shouldRefreshSummay = true
            }
        }

        setSaveLoading(true)
        ReviewerAPI.updateLoanReviewer({
            ...node.data, //using data from node will always be the newest
            [colDef.field]: value
        })
            .then(() => {
                if (shouldRefreshSummay) {
                    refreshData('summary')
                }
            })
            .catch(ex => notification.error(ex.message))
            .finally(() => setSaveLoading(false))

    }

    return (
        <Spin spinning={loading.loan || saveLoading}>
            <Grid<IRowData>
                height="50vh"
                css={gridStyle}
                rowData={loanReviewers}
                defaultColDef={defaultColumn}
                columnDefs={columnDefs}
                getRowId={p => p.data.loanId + ''}
                onFirstDataRendered={({ api }) => {
                    //using timeout to avoid antd animation issue
                    setTimeout(() => {
                        api.sizeColumnsToFit()
                        const filterModel = filterCache.get(deal.dealId)
                        if (filterModel) {
                            api.setFilterModel(filterModel)
                        }
                    });
                }}
                onFilterChanged={e => filterCache.set(deal.dealId, e.api.getFilterModel())}
                onRowDoubleClicked={(e) => {
                    navigate(`/${e.data.dealId}/loan/${e.data.loanId}/section/${currentSectionId}`)
                }}
                onCellValueChanged={handleTableChange}
                suppressMovableColumns={true}
            />
        </Spin>
    )
}
export default LoanListTable
