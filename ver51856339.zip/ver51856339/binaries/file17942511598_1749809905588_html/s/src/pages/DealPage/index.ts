import { createContext } from 'react';
export { default } from './DealPage'

export const DealPageContext = createContext<{
    deal: API.IDealSetup
    reviewers: API.UserInfo[]
    loading: {
        deal?: boolean
        loan?: boolean
        header?: boolean
    }

    reviewStatus: API.IReviewStatus

    sections: API.ISection[]
    currentSectionId: number
    loanReviewers: API.IReviewer[]

    headerReviewers: API.IHeader[]

    sellers: API.ISeller[]

    selectSection: (sectionId: number) => void
    refreshData: (type: 'deal' | 'loan' | 'header' | 'summary' | 'loansummary' | 'headersummary') => void

}>({
    deal: null,
    reviewers: [],
    loading: {},
    reviewStatus: null,
    sections: [],
    currentSectionId: 0,
    loanReviewers: [],
    headerReviewers: [],
    sellers: [],
    selectSection: () => { },
    refreshData: () => { },
});

type FilterModel = { [key: string]: any; }

export class FilterCache {
    private _id: number
    private _modal: FilterModel

    constructor() {
        this._id = null
        this._modal = null
    }

    public get(id: number): FilterModel {
        return id == this._id ? this._modal : null
    }

    public set(id: number, modal: FilterModel) {
        this._id = id
        this._modal = modal
    }

    public clear() {
        this._id = null
        this._modal = null
    }
}