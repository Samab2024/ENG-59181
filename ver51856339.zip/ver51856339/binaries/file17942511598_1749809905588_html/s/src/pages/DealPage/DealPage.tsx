import IconButton from "@/components/IconButton";
import Wrapper, { HeadRow } from "@/components/Wrapper";
import createStyle from "@/hooks/createStyle";
import LoanAPI from '@/services/api/LoanAPI';
import notification from '@/utils/notification';
import { percentFormatter } from '@/utils/numberHelper';
import { css } from "@emotion/react";
import { Button, Card, Col, Dropdown, InputNumber, Popover, Radio, Row, Space, Spin, Tabs, Tooltip, theme } from "antd";
import { FIArchive, FIHome, FIHub, FIMenu, FINetworkPort } from "functional-icons/lib/Outline";
import { FC, useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { DealPageContext } from ".";
import { DealPageProvider } from "./DealPageProvider";
import DealSetup from "./DealSetup";
import HeaderListTable from "./HeaderListTable";
import ImportLoanModal from "./ImportLoanModal";
import LoanListTable from "./LoanListTable";
import ReportModal from "./ReportModal";
import useLoanManagementModal from "./useLoanManagementModal";
import LoanDependencyModal from "./LoanDependencyModal";

const RandomInputContent: FC<{
    minCount: number
    onCancel: () => void
    onOK: (count: number) => void
    loading: boolean
}> = ({ minCount, onCancel, onOK, loading }) => {
    const [countValue, setCountValue] = useState(minCount)
    return (
        <Space direction="vertical">
            <div>Random count:</div>
            <div>
                <InputNumber style={{ width: "100%" }}
                    min={minCount}
                    value={countValue}
                    onChange={(value: number) => setCountValue(value)} />
            </div>
            <div css={css({ display: 'flex', justifyContent: 'flex-end' })}>
                <Space>
                    <Tooltip title="Reset ramdom count and view all loans.">
                        <Button onClick={() => onOK(0)}>Reset</Button>
                    </Tooltip>
                    {/* <Button onClick={onCancel}>Cancel</Button> */}
                    <Button type="primary" onClick={() => onOK(countValue)} loading={loading}>OK</Button>
                </Space>
            </div>
        </Space>
    )
}

const DealPage: FC = () => {
    const navigate = useNavigate()
    const { id } = useParams()
    const dealId = Number(id)

    const { deal, loading, currentSectionId, headerReviewers, reviewStatus, sections, selectSection, refreshData } = useContext(DealPageContext)
    const [loanManagementModal, openLoanManagementModal] = useLoanManagementModal()
    const [loanDependencyModalOpen, setLoanDependencyModalOpen] = useState(false)

    const [open, setOpen] = useState(false)
    const { token } = theme.useToken()

    const [randomCountOpen, setRandomCountOpen] = useState(false);
    const [confirmLoading, setConfirmLoading] = useState(false);
    const [reportOpen, setReportOpen] = useState(false);
    const [currentTab, setCurrentTab] = useState(currentSectionId === -1 ? 'header' : 'loan');

    const styles = useStyle();

    //TODO move all ramdom related functionality together
    const handleRandomlyGenerateOk = (count: number) => {
        setConfirmLoading(true);
        LoanAPI.generateRandomlyLoan({ dealId, randomNumber: count })
            .then(() => refreshData('loan'))
            .catch(e => notification.error((e as API.IException).message))
            .finally(() => setConfirmLoading(false))
    };

    const handleRandomlyGenerateCancel = () => {
        setRandomCountOpen(false);
    }

    const handleTabClick = (key: string) => {
        setCurrentTab(key);
        if (currentSectionId === -1 && key === 'loan') {
            //Back from DealHeaderPage, switch to loan, unknow currentSectionId
            selectSection(0)
        } else {
            //Default switch between tab, known currentSectionId, only refresh summary
            key == 'loan' ? refreshData('loansummary') : refreshData('headersummary');
        }
    }
    //TODO layout adjustment for one table or two table

    return (
        <Wrapper.PageContainer>
            <Spin spinning={loading.deal}>
                <HeadRow
                    icon={<IconButton icon={FIHome} onClick={() => navigate('/')} />}
                    title={deal?.dealName}
                >
                    <Space>
                        {deal?.isDealAdmin && !deal?.isReadOnly && (
                            <Dropdown placement="bottomRight" menu={{
                                items: [{
                                    label: 'Loan Management',
                                    key: 'Loan Management'
                                }, {
                                    label: 'Loan Dependency',
                                    key: 'Loan Dependency'
                                }],
                                onClick: ({ key }) => {
                                    switch (key) {
                                        case 'Loan Management':
                                            openLoanManagementModal()
                                            break;

                                        case 'Loan Dependency':
                                            setLoanDependencyModalOpen(true)
                                            break;

                                        default:
                                            break;
                                    }
                                }
                            }}>
                                <Button type="text" icon={<FIMenu />} />
                            </Dropdown>
                        )}
                        <Button type="link" onClick={() => navigate(`/${id}/map`)}>Header Map</Button>
                        <Button type="primary" onClick={() => setReportOpen(true)}>Report</Button>
                        {deal?.isDealAdmin && !deal?.isReadOnly && (
                            <Button type="primary" onClick={() => setOpen(true)}>Import Tape</Button>
                        )}
                    </Space>
                </HeadRow>
                <Space direction="vertical" size="small" style={{ width: '100%' }}>
                    <Row gutter={token.marginXS}>
                        <Col span={18}>
                            <DealSetup />
                        </Col>
                        <Col span={6}>
                            <Card bordered={false} style={{ height: '100%' }} bodyStyle={{ height: '100%' }} >
                                <Row css={styles.CardStatus}>
                                    <Col span={16}>Completed</Col>
                                    <Col span={4}>{reviewStatus?.completedCount}</Col>
                                    <Col span={4}>{percentFormatter(reviewStatus?.completedPercentage, 2)}</Col>
                                </Row>
                                <Row css={styles.CardStatus}>
                                    <Col span={16}>Ready for Final Review (or In Progress)</Col>
                                    <Col span={4}>{reviewStatus?.readyForFinalReviewCount}</Col>
                                    <Col span={4}>{percentFormatter(reviewStatus?.readyForFinalReviewPercentage, 2)}</Col>
                                </Row>
                                <Row css={styles.CardStatus}>
                                    <Col span={16}>Ready for 2nd Review (or In Progress)</Col>
                                    <Col span={4}>{reviewStatus?.readyFor2ndReviewCount}</Col>
                                    <Col span={4}>{percentFormatter(reviewStatus?.readyFor2ndReviewPercentage, 2)}</Col>
                                </Row>
                                <Row css={styles.CardStatus}>
                                    <Col span={16}>1st Review (Not Started or In Progress)</Col>
                                    <Col span={4}>{reviewStatus?.readyFor1stReviewCount}</Col>
                                    <Col span={4}>{percentFormatter(reviewStatus?.readyFor1stReviewPercentage, 2)}</Col>
                                </Row>
                                <Row>
                                    <Col span={24}><hr /></Col>
                                </Row>
                                <Row css={styles.CardStatus}>
                                    <Col span={16}>Total</Col>
                                    <Col span={4}>{reviewStatus?.totalCount}</Col>
                                    <Col span={4}>{percentFormatter(reviewStatus?.totalPercentage, 2)}</Col>
                                </Row>
                            </Card>
                        </Col>
                    </Row >
                    {sections.length > 0 &&
                        <Card bordered={false} bodyStyle={{ paddingTop: 0 }} loading={loading.deal} >
                            <div css={styles.CardHeader}>
                                <div style={{ width: headerReviewers.length > 0 ? 150 : 65 }}>
                                    <Tabs tabBarGutter={10} items={[
                                        { key: 'loan', label: 'Loan List' },
                                        headerReviewers.length > 0 && { key: 'header', label: 'Header List' },
                                    ]} size="small" activeKey={currentTab} onChange={handleTabClick}></Tabs>
                                </div>
                                {currentTab == 'loan' && <div css={styles.SectionRadio} >
                                    <Radio.Group value={currentSectionId} onChange={e => selectSection(e.target.value)}>
                                        {sections.map(x => (
                                            <Radio.Button key={x.sectionId} value={x.sectionId}>{x.name}</Radio.Button>
                                        ))}
                                    </Radio.Group>
                                </div>}
                                <div>
                                    <Popover open={randomCountOpen} placement="left" onOpenChange={v => setRandomCountOpen(v)} content={(
                                        <RandomInputContent
                                            minCount={0}
                                            loading={confirmLoading}
                                            onOK={handleRandomlyGenerateOk}
                                            onCancel={handleRandomlyGenerateCancel}
                                        />
                                    )}>
                                        {deal.isAllowRandomReview && !deal?.isReadOnly && <Button onClick={() => setRandomCountOpen(true)} >Random Loan</Button>}
                                    </Popover>
                                </div>
                            </div>
                            {currentTab == 'loan' ? <LoanListTable /> : <HeaderListTable />}
                        </Card>
                    }
                </Space >

                {deal?.isDealAdmin && (
                    <ImportLoanModal open={open} onClose={() => setOpen(false)} />
                )}
                <ReportModal open={reportOpen} onClose={() => setReportOpen(false)} />
                {loanManagementModal}
                <LoanDependencyModal open={loanDependencyModalOpen} onClose={() => {
                    setLoanDependencyModalOpen(false);
                    refreshData('loan')
                }} />
            </Spin>
        </Wrapper.PageContainer >
    )
}

const useStyle = createStyle(token => ({
    CardStatus: css`
        line-height: 22px;
        text-align: center;
        div:nth-child(1){
            text-align: right
        }`,
    CardHeader: css({
        padding: '4px 0',
        marginBottom: -4,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: 8,
    }),
    SectionRadio: css({
        flex: 1
    }),
}))

const DealPageWrapper = () => (
    <DealPageProvider>
        <DealPage />
    </DealPageProvider>
)

export default DealPageWrapper