import useAPICall from "@/hooks/useAPICall";
import AuthAPI from "@/services/api/AuthAPI";
import DealAPI from "@/services/api/DealAPI";
import LoanReviewAPI from "@/services/api/LoanReviewAPI";
import ReviewerAPI from "@/services/api/ReviewerAPI";
import SectionAPI from "@/services/api/SectionAPI";
import SellerAPI from "@/services/api/SellerAPI";
import { FC, PropsWithChildren, useEffect, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { DealPageContext } from ".";
import notification from "@/utils/notification";
import HeaderReviewAPI from "@/services/api/HeaderReviewAPI";

export const DealPageProvider: FC<PropsWithChildren> = ({ children }) => {
    const { id } = useParams()
    const [searchParams, setSearchParams] = useSearchParams()
    const dealId = Number(id)
    const defaultSectionId = Number(searchParams.get('s')) || 0

    const [deal, setDeal] = useState<API.IDealSetup>()
    const [reviewers, setReviewers] = useState<API.UserInfo[]>()
    const [reviewStatus, setReviewStatus] = useState<API.IReviewStatus>()
    const [sections, setSections] = useState<API.ISection[]>([])
    const [currentSectionId, setCurrentSectionId] = useState(defaultSectionId)
    const [loanReviewers, setLoanReviewers] = useState<API.IReviewer[]>([])
    const [headerReviewers, setHeaderReviewers] = useState<API.IHeader[]>([])
    const [sellers, setSellers] = useState<API.ISeller[]>([])

    const [loading, setLoading] = useState(true)
    const [loanLoading, getLoanReviewers] = useAPICall(ReviewerAPI.getLoanReviewers)
    const [headerLoading, getAttributeReviewers] = useAPICall(ReviewerAPI.getAttributeReviewers)

    useEffect(() => {
        //clear possible default section id
        setSearchParams('')
        Promise.all([
            DealAPI.getDealById(dealId),
            SectionAPI.getSections(dealId),
            AuthAPI.getReviewers(dealId),
            ReviewerAPI.getAttributeReviewers(dealId),
            SellerAPI.getSellers(dealId)
        ])
            .then(([deal, sections, reviewers, headerReviewers, sellers]) => {
                setDeal(deal)
                setSections(sections)
                setReviewers(reviewers)
                setHeaderReviewers(headerReviewers)
                setSellers(sellers)
                //Set default section id only when navigate from deal list page or section not found
                if (currentSectionId == 0
                    || currentSectionId !== -1
                    && !sections.find(x => x.sectionId == currentSectionId)) {
                    setCurrentSectionId(sections?.[0]?.sectionId ?? 0)
                }
            })
            .catch(ex => notification.error((ex as API.IException).message))
            .finally(() => setLoading(false))
    }, [])

    useEffect(() => {
        if (currentSectionId === -1) {
            //Back from DealHeaderPage, refresh summay
            HeaderReviewAPI.getHeaderStatusById(dealId).then(data => calReviewStatusPercentage(data))
        } else if (currentSectionId === 0) {
            //Back from DealHeaderPage and switch to loan, select default section
            setCurrentSectionId(sections?.[0]?.sectionId ?? 0)
        } else if (currentSectionId > 0) {
            //Loan with selected section, get reviewer data
            getLoanReviewers(dealId, currentSectionId).then(data => setLoanReviewers(data))
            LoanReviewAPI.getLoanReviewStatus(dealId, currentSectionId).then(data => calReviewStatusPercentage(data))
        }
    }, [currentSectionId])

    const calReviewStatusPercentage = (reviewStatus: API.IReviewStatus) => {
        reviewStatus.totalCount = reviewStatus.readyFor1stReviewCount + reviewStatus.readyFor2ndReviewCount + reviewStatus.readyForFinalReviewCount + reviewStatus.completedCount;
        if (reviewStatus.totalCount > 0) {
            reviewStatus.readyFor1stReviewPercentage = reviewStatus.readyFor1stReviewCount / reviewStatus.totalCount
            reviewStatus.readyFor2ndReviewPercentage = reviewStatus.readyFor2ndReviewCount / reviewStatus.totalCount
            reviewStatus.readyForFinalReviewPercentage = reviewStatus.readyForFinalReviewCount / reviewStatus.totalCount
            reviewStatus.completedPercentage = reviewStatus.completedCount / reviewStatus.totalCount
            reviewStatus.totalPercentage = reviewStatus.totalCount / reviewStatus.totalCount
        } else {
            reviewStatus.readyFor1stReviewPercentage = 0;
            reviewStatus.readyFor2ndReviewPercentage = 0;
            reviewStatus.readyForFinalReviewPercentage = 0;
            reviewStatus.completedPercentage = 0;
            reviewStatus.totalPercentage = 0;
        }
        setReviewStatus(reviewStatus)
    }

    const refreshData = (type: 'deal' | 'loan' | 'header' | 'summary' | 'loansummary' | 'headersummary') => {
        if (type === 'deal') {
            setLoading(true)
            Promise.all([
                DealAPI.getDealById(dealId),
                AuthAPI.getReviewers(dealId),
                SectionAPI.getSections(dealId),
            ])
                .then(([deal, reviewers, sections]) => {
                    setDeal(deal)
                    setReviewers(reviewers)
                    setSections(sections)
                    setCurrentSectionId(sections?.[0]?.sectionId ?? 0)
                })
                .catch(ex => notification.error((ex as API.IException).message))
                .finally(() => setLoading(false))
        } else if (type === 'loan') {
            getLoanReviewers(dealId, currentSectionId).then(data => setLoanReviewers(data))
        } else if (type === 'header') {
            getAttributeReviewers(dealId).then(data => setHeaderReviewers(data))
        } else if (type === 'summary' || type == 'loansummary') {
            LoanReviewAPI.getLoanReviewStatus(dealId, currentSectionId).then(data => calReviewStatusPercentage(data))
        } else if (type === 'headersummary') {
            HeaderReviewAPI.getHeaderStatusById(dealId).then(data => calReviewStatusPercentage(data))
        }
    }

    return (
        <DealPageContext.Provider value={{
            deal,
            reviewers,
            reviewStatus,
            sections,
            currentSectionId,
            loanReviewers,
            headerReviewers,
            sellers,
            loading: {
                deal: loading,
                header: headerLoading,
                loan: loanLoading
            },

            refreshData,
            selectSection: setCurrentSectionId
        }}>
            {children}
        </DealPageContext.Provider>
    )
}
