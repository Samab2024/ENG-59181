import { css } from '@emotion/react';
import createStyle from '@/hooks/createStyle';
const useStyle = createStyle(token => css`

    div.notice {
        margin-top: 8px;

        a {
            color: #2295f2;
            font-size: 14px;
        }
    }

    .seller-wrapper {
        &:first-child {
            flex: 1 1 auto;
        }
        &:last-child {
            flex: 0 0 auto;
        }
    }

    div.progress {
        margin-top: 28px;
    }
    div.error-message {
        margin-top: 20px;

        pre {
            white-space: pre-wrap;
            width: 95%;
        }
    }
`)

export default useStyle