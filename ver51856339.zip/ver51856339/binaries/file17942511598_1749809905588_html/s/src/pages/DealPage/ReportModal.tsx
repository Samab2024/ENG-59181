import InfoPop from '@/components/InfoPop';
import ReportAPI from "@/services/api/ReportAPI";
import nameOfData from '@/utils/nameOfData';
import notification from '@/utils/notification';
import { Button, Checkbox, Form, Modal, Select, Space } from 'antd';
import { FC, useContext, useState } from 'react';
import { DealPageContext } from '.';
import useStyle from './ReportModal.style';
import { FIImage } from 'functional-icons/lib/Outline';

type FormData = {
    reportType: number,
    levelOfReview: number
    reportOrder: number
    includeCalculationException: boolean
    includePwcHeaderFields: boolean
    includePwcComments: boolean
    sellerIds: number[]
}

const ReportModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {
    const { deal, sellers } = useContext(DealPageContext);
    const [downloadLoading, setDownloadLoading] = useState(false)

    const [form] = Form.useForm<FormData>()
    const reportType = Form.useWatch(nameOfData<FormData>("reportType"), form);

    const style = useStyle()

    const handleCancel = () => {
        form.resetFields()
        onClose();
    }

    const handleReportClick = () => {
        setDownloadLoading(true)
        form.validateFields().then(data => {
            ReportAPI.downloadReport({
                dealId: deal.dealId,
                ...data
            })
                .catch(e => notification.error((e as API.IException).message))
                .finally(() => {
                    setDownloadLoading(false)
                    handleCancel()
                })
        })
    }
    return (
        <Modal
            css={style}
            open={open}
            title={"Download Report"}
            maskClosable={false}
            onCancel={handleCancel}
            footer={<div className="text-align-right">
                <Button onClick={handleCancel}>Cancel</Button>
                <Button loading={downloadLoading} disabled={!reportType} type="primary" onClick={() => handleReportClick()}>Download</Button>
            </div>}>
            <Form labelCol={{ span: 8 }} wrapperCol={{ span: 16 }} form={form} layout="horizontal">
                <Form.Item label="Report Type" name={nameOfData<FormData>("reportType")}>
                    <Select style={{ width: 200 }} options={[
                        { label: 'Exception Report', value: 2 },
                        { label: 'PwC Tape Report', value: 3 },
                        { label: 'Loan Status Report', value: 5 },
                        { label: 'Feedback Report', value: 4 },
                        { label: 'Master Tape Report', value: 1 },
                    ]} />
                </Form.Item>
                {reportType !== 4 && reportType !== 5 && (
                    <Form.Item
                        label="Level of Review"
                        tooltip={{ title: 'The minimal review level from which the report will retrieve data.', icon: <FIImage /> }}
                        name={nameOfData<FormData>("levelOfReview")} initialValue={2}>
                        <Select style={{ width: 200 }} options={[
                            { label: 1, value: 1 },
                            { label: 2, value: 2 },
                            { label: 3, value: 3 },
                        ]} />
                    </Form.Item>
                )}
                {reportType !== 3 && (
                    <Form.Item label="Report Order" name={nameOfData<FormData>("reportOrder")} initialValue={1}>
                        <Select style={{ width: 200 }} options={[
                            { label: 'By Loan', value: 1 },
                            { label: 'By Attribute', value: 2 },
                        ]} />
                    </Form.Item>
                )}
                <Form.Item
                    label="Seller"
                    name={nameOfData<FormData>("sellerIds")}
                    initialValue={sellers?.map(x => x.sellerId)}
                >
                    <Select style={{ width: 200 }} mode="multiple" options={sellers?.map(x => ({ value: x.sellerId, label: x.name }))} />
                </Form.Item>
                {reportType == 2 && (<>
                    <Form.Item wrapperCol={{ span: 16, offset: 8 }} name={nameOfData<FormData>("includeCalculationException")} initialValue={true} valuePropName="checked">
                        <Checkbox>
                            Include Calculation Exception
                        </Checkbox>
                    </Form.Item>
                    <Form.Item wrapperCol={{ span: 16, offset: 8 }}>
                        <Checkbox checked={deal?.isExRptIncludePwCComments} disabled>
                            Exception Report Consider PwC Comment
                            <InfoPop textInline content="Exception report will include tied values when there is a PwC comment present." placement="top" />
                        </Checkbox>
                    </Form.Item>
                </>)}
                {reportType == 3 && (<>
                    <Form.Item wrapperCol={{ span: 16, offset: 8 }} name={nameOfData<FormData>("includePwcHeaderFields")} initialValue={true} valuePropName="checked">
                        <Checkbox>
                            Include PwC Header Fields
                        </Checkbox>
                    </Form.Item>

                    <Form.Item wrapperCol={{ span: 16, offset: 8 }} name={nameOfData<FormData>("includePwcComments")} initialValue={false} valuePropName="checked">
                        <Checkbox>
                            Include PwC Comments
                        </Checkbox>
                    </Form.Item>

                    <Form.Item wrapperCol={{ span: 16, offset: 8 }}>
                        <Space size={"middle"} className='review-section'>
                            <span className="review-color" title={"1st Review"}>1st Review</span>
                            <span className="review-color" title={"2nd Review"}>2nd Review</span>
                            <span className="review-color" title={"3rd Review"}>3rd Review</span>
                        </Space>
                    </Form.Item>
                </>)}
            </Form>
        </Modal>
    )
}

export default ReportModal