import Grid from "@/components/Grid";
import createStyle from "@/hooks/createStyle";
import { MoveToFn, useDragTreeData } from "@/hooks/useDragTreeData";
import LoanAPI from "@/services/api/LoanAPI";
import notification from "@/utils/notification";
import { css } from "@emotion/react";
import { ColDef, GridApi, ICellRendererParams, IRowNode } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Button, Checkbox, Modal, Spin } from "antd";
import { FC, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";

type IDataRow = API.ILoanDependency

const useGridStyle = createStyle(token => css`
    --ag-row-group-indent-size: 20px;
    .section-row {
        background-color: #EEE;
        font-weight: bold;
    }
`)

const findParent = (node: IRowNode<IDataRow>, api: GridApi<IDataRow>) => {
    let tempParent: IDataRow = null
    let result: IDataRow = null
    api.forEachNode(x => {
        if (x.data.loanId === node.data.loanId) {
            result = tempParent
        }
        if (!x.data.parentId) {
            tempParent = x.data
        }
    })
    return result
}

const moveLoans: MoveToFn<IDataRow> = (rowData, source, target) => {
    if (source === target) {
        return rowData; //invalid move - no-op
    }

    //keep seller name consist
    if (source.sellerName !== target?.sellerName) {
        return rowData //invalid move - seller name should be same
    }

    let splitIndex: number;
    if (target) {
        splitIndex = rowData.findIndex(x => x.loanId === target.loanId);
        if (splitIndex > rowData.findIndex(x => x.loanId === source.loanId)) {
            ++splitIndex; // If we are moving to the top, we move after the target
        }
    } else {
        splitIndex = rowData.length; // we move at the end
    }

    if (source.parentId) {
        //child loan
        if (splitIndex === 0) {
            return rowData //invalid move - child can not be the first item
        }
        return [
            ...rowData.slice(0, splitIndex).filter(x => x.loanId !== source.loanId),
            { ...source, parentId: rowData[splitIndex - 1].parentId ?? rowData[splitIndex - 1].loanId },
            ...rowData.slice(splitIndex).filter(x => x.loanId !== source.loanId)
        ]
    } else {
        //parent loan
        if (target?.parentId == source.loanId) {
            return rowData //invalid move - parent can only move in top level
        }
        return [
            ...rowData.slice(0, splitIndex).filter(x => x.loanId !== source.loanId && x.parentId !== source.loanId),
            ...rowData.filter(x => x.loanId === source.loanId || x.parentId === source.loanId),
            ...rowData.slice(splitIndex).filter(x => x.loanId !== source.loanId && x.parentId !== source.loanId)
        ]
    }
}

const LoanDependencyModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {
    const gridRef = useRef<AgGridReact<IDataRow>>();
    const [columnDefs] = useState<ColDef<IDataRow>[]>([
        {
            field: 'propertyName',
            flex: 1,
            sortable: false,
        },
        {
            field: 'sellerName',
            flex: 1,
            sortable: false,
        },
        {
            colId: 'action',
            sortable: false,
            width: 40,
            cellRenderer: ({ data, node, api }: ICellRendererParams<IDataRow>) => {
                return <Checkbox checked={!data.parentId} onChange={e => {
                    if (!e.target.checked) {
                        if (node.allChildrenCount > 0) {
                            notification.error("The loan have child loans.")
                            return
                        } else if (node.rowIndex === 0) {
                            notification.error("First loan can not be a child loan.")
                            return
                        }
                        const parent = findParent(node, api)
                        if (parent.sellerId !== data.sellerId) {
                            notification.error("Not able to assign loan with different seller.")
                            return
                        }
                        api.applyTransaction({
                            update: [{ ...node.data, parentId: parent.loanId }]
                        })
                    } else {
                        api.applyTransaction({
                            remove: [node.data],
                            add: [{ ...node.data, parentId: null }],
                            addIndex: node.parent.rowIndex + 1
                        })
                    }
                }} />
            }
        }
    ])
    const { id } = useParams()
    const dealId = Number(id)
    const [loading, setLoading] = useState(false);
    const gridStyle = useGridStyle()
    const dndHandlers = useDragTreeData(gridRef, moveLoans)

    const handleGridReady = () => {
        setLoading(true)
        LoanAPI.getLoanDependency(dealId)
            .then(data => {
                gridRef.current.api.setGridOption('rowData', data)
                gridRef.current.api.sizeColumnsToFit()
            })
            .catch(ex => notification.error(ex.message))
            .finally(() => setLoading(false))
    }

    const handleSave = () => {
        const data: IDataRow[] = []
        gridRef.current.api.forEachNode((x, i) => data.push({ ...x.data, displayOrder: i + 1 }))
        setLoading(true)
        LoanAPI.updateLoanDependency(dealId, data)
            .then(() => {
                notification.success("Save loan dependency successfully.")
                onClose()
            })
            .catch(ex => notification.error(ex.message))
            .finally(() => setLoading(false))
    }

    const autoGroupColumnDef = useMemo<ColDef<IDataRow>>(() => {
        return {
            headerName: "Loan Number",
            flex: 1,
            cellRendererParams: {
                suppressCount: true,
                innerRenderer: ({ node }: ICellRendererParams<IDataRow>) => node.data.loanNumber,
            },
            rowDrag: true,
            sortable: false,
            rowDragText: (params) => params.rowNode.data.loanNumber,
        };
    }, []);

    const handleAutoClick = () => {
        let parentId = null
        let loanNumber = null
        gridRef.current?.api.forEachNode((node) => {
            if (loanNumber && new RegExp(`^${loanNumber}\\.\\d+$`).test(node.data.loanNumber)) {
                node.setData({ ...node.data, parentId })
            } else {
                parentId = node.data.loanId
                loanNumber = node.data.loanNumber.split('.')[0]
            }
        })
    }

    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Loan Dependency"
            width={800}
            destroyOnClose={true}
            footer={<div>
                <Button onClick={onClose}>Cancel</Button>
                <Button type="primary" onClick={handleSave}>SAVE</Button>
            </div>}>
            <div css={css({ position: 'absolute', top: 15, right: 50 })}>
                <Button type="primary" ghost onClick={handleAutoClick}>Identify Parent Nodes</Button>
            </div>
            <Spin spinning={loading}>
                <Grid<IDataRow>
                    ref={gridRef}
                    css={gridStyle}
                    suppressDragLeaveHidesColumns={true}
                    animateRows={true}
                    rowClassRules={{
                        'section-row': ({ data }) => !data.parentId
                    }}
                    groupDefaultExpanded={1}
                    treeData={true}
                    getDataPath={x => (x.parentId ? [x.parentId, x.loanId] : [x.loanId]).map(x => x + '')}
                    autoGroupColumnDef={autoGroupColumnDef}
                    getRowId={({ data }) => data.loanId + ''}
                    columnDefs={columnDefs}
                    onGridReady={handleGridReady}
                    {...dndHandlers}
                />
            </Spin>
        </Modal>
    )
}

export default LoanDependencyModal