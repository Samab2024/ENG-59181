import { FORMATS } from "@/utils/dateHelper";
import { css } from "@emotion/react";
import { Card, Descriptions, Dropdown, Flex, List, Popover, Tooltip, Typography } from "antd";
import dayjs from "dayjs";
import { FC, PropsWithChildren, useContext, useState } from "react";
import { DealPageContext } from ".";
import DealSetupFormPage from "../DealSetupFormPage";
import SectionModal from "./SectionModal";

const MaxDisplayedLength = 100;

const DetailWrapper: FC<PropsWithChildren> = ({ children }) => {
    return (
        <Popover open={children?.toString().length > 20 ? undefined : false} placement="bottomLeft" arrow={false} trigger="hover" content={<div css={css({ maxWidth: '300px' })}>{children}</div>}>
            <Typography.Text>{children}</Typography.Text>
        </Popover>
    )
}

const ContactWrapper: FC<PropsWithChildren> = ({ children }) => {
    return (
        <Popover open={children?.toString().includes(',') ? undefined : false} placement="bottomLeft" arrow={false} trigger="hover" content={<div css={css({ margin: '-12px -16px' })}>
            <List css={css({ maxHeight: '300px', overflowY: 'scroll' })} dataSource={children?.toString().split(',')} renderItem={item => <List.Item>{item}</List.Item>} bordered={false} />
        </div>}>
            <Typography.Text>{children}</Typography.Text>
        </Popover>
    )
}

const DealSetup: FC = () => {
    const [open, setOpen] = useState(false)
    const [sectionOpen, setSectionOpen] = useState(false)
    const { deal, refreshData } = useContext(DealPageContext);

    const formatDisplayedNames = (names: string) => {
        const nameArr = names?.split(',')
        return nameArr?.length > 5 ? <Tooltip title={deal?.dealAdmin}>{`${nameArr.slice(0, 5).join(",")}....`}</Tooltip> : names;
    }

    return (
        <Card bordered={false}>
            <Flex justify="end" style={{ height: "14px" }}>
                <div>
                    {deal?.isEditable && (
                        <Dropdown.Button menu={{
                            items: [{ key: 'section', label: 'Edit Section' }],
                            onClick: () => setSectionOpen(true)
                        }} type="link" onClick={() => setOpen(true)} style={{ fontWeight: 'bold' }}>Edit</Dropdown.Button>
                    )}
                </div>
            </Flex>

            <Descriptions layout="vertical" column={8} css={css({
                "&.ant-descriptions .ant-descriptions-item-container .ant-descriptions-item-content": {
                    display: 'block',
                    whiteSpace: 'nowrap',
                    textOverflow: 'ellipsis',
                    overflow: 'hidden',
                }
            })}>
                <Descriptions.Item label="Asset Type">{deal?.assetType}</Descriptions.Item>
                <Descriptions.Item label="Cut Off Date">{deal?.cutOffDate == null ? null : dayjs(deal?.cutOffDate).format(FORMATS.L)}</Descriptions.Item>
                <Descriptions.Item label="Level of Review">{deal?.levelOfReview}</Descriptions.Item>
                <Descriptions.Item label="Client Name">{deal?.clientName}</Descriptions.Item>
                <Descriptions.Item label="Deal Status">{deal?.dealStatus}</Descriptions.Item>
                <Descriptions.Item label="Is Blind Review">{deal?.isBlindReview ? "Yes" : "No"}</Descriptions.Item>
                <Descriptions.Item label="Key Column"><DetailWrapper>{deal?.keyColumn}</DetailWrapper></Descriptions.Item>
                <Descriptions.Item label="Display Column"><DetailWrapper>{deal?.loanNumberDisplayColumn}</DetailWrapper></Descriptions.Item>

                {/* <Descriptions.Item label="Description" span={2} style={{ paddingRight: 8 }}>{deal?.dealDesc?.length > MaxDisplayedLength ? <Tooltip title={deal?.dealDesc}>{`${deal?.dealDesc.slice(0, MaxDisplayedLength)}...`}</Tooltip> : deal?.dealDesc}</Descriptions.Item> */}
                <Descriptions.Item label="Description" span={2} style={{ paddingRight: 8 }}><DetailWrapper>{deal?.dealDesc}</DetailWrapper></Descriptions.Item>
                <Descriptions.Item label="Deal Admin" span={3} style={{ paddingRight: 8 }}><ContactWrapper>{deal?.dealAdmin}</ContactWrapper></Descriptions.Item>
                <Descriptions.Item label="Deal Contact" span={3}><ContactWrapper>{deal?.dealContact}</ContactWrapper></Descriptions.Item>

            </Descriptions>

            <DealSetupFormPage isNew={false} open={open} onClose={() => setOpen(false)} />
            <SectionModal open={sectionOpen} onClose={() => setSectionOpen(false)} />
        </Card>
    )
}

export default DealSetup
