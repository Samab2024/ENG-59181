import createStyle from "@/hooks/createStyle"
import { css } from "@emotion/react"

const useStyle = createStyle(token => css`
    margin-top: 4px;

    .ag-reviewer-status {
        &::before {
            display: inline-block;
            margin-right: 4px;
            margin-bottom: 2px;
            content: ' ';
            border-radius: 50%;
            width: 6px;
            height: 6px;
            background-color: ${token.colorText};
        }
        &[title="Not Started"] {
            color: ${token.colorError};
            &::before {
                background-color: ${token.colorError};
            }
        }
        &[title="In Progress"] {
            color: ${token.colorWarning};
            &::before {
                background-color: ${token.colorWarning};
            }
        }
        &[title="Completed"] {
            color: ${token.colorSuccess};
            &::before {
                background-color: ${token.colorSuccess};
            }
        }
    }

    .ag-loan-review-completed {
        background-color: ${token.colorSuccess}99;
    }
    .ag-loan-review-exception {
        background-color: ${token.colorError}66;
    }
    .ag-loan-review-inreview {
        background-color: ${token.colorWarning}99;
    }
`)

export default useStyle