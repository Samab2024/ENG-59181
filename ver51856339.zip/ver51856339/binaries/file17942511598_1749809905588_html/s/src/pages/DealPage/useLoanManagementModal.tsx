import Grid, { getDefaultColumn } from "@/components/Grid";
import notification from '@/utils/notification';
import { ColDef, GridApi, ICellRendererParams } from "ag-grid-community";
import { Modal, Spin } from "antd";
import { FIRevert } from "functional-icons/lib/Outline";
import { FC, ReactNode, useContext, useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";

import DateCellRender from "@/components/Grid/dateCellRender";
import IconButton from "@/components/IconButton";
import LoanAPI from "@/services/api/LoanAPI";
import { DealPageContext } from ".";

type RowDataType = API.ILoan

const defaultColumnDef = getDefaultColumn({ sortable: true, resizable: true })

const LoanManagementModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {

    const [modal, modalContext] = Modal.useModal()
    const [gridApi, setGridApi] = useState<GridApi<RowDataType>>()
    const { id } = useParams()
    const dealId = Number(id)
    const [loading, setLoading] = useState(false);

    const fetchData = async () => {
        try {
            setLoading(true);
            const data = await LoanAPI.getLoans(dealId, false)
            gridApi.applyTransaction({
                add: data
            })
        } catch (error) {
            notification.error((error as API.IException).message)
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        if (open && gridApi) {
            fetchData()
        }
    }, [open, gridApi])


    const [columnDefs] = useState<ColDef<RowDataType>[]>([
        {
            colId: 'loanNumber',
            field: "loanNumber",
        },
        {
            colId: 'propertyName',
            field: "propertyName",
        },
        {
            colId: 'createdBy',
            field: "createdBy",
        },
        {
            colId: 'createdTime',
            field: "createdTime",
            cellRenderer: DateCellRender
        },
        {
            colId: 'lastUpdatedBy',
            field: "lastUpdatedBy",
        },
        {
            colId: 'lastUpdatedTime',
            field: "lastUpdatedTime",
            cellRenderer: DateCellRender
        },
        {
            colId: 'action',
            width: 50,
            headerName: '',
            suppressAutoSize: true,
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: ({ api, data }: ICellRendererParams<RowDataType>) => <IconButton size="small" icon={FIRevert} title="Restore" onClick={() => modal.confirm({
                title: 'Are you sure to restore this loan?',
                onOk: () => {
                    setLoading(true)
                    LoanAPI.updateLoan({
                        ...data,
                        isActive: true
                    })
                        .then(() => {
                            notification.success("Restore loan successfully.")
                            api.applyTransaction({ remove: [data] })
                        })
                        .catch(ex => {
                            notification.error(ex.message)
                        })
                        .finally(() => setLoading(false))
                }
            })} />
        }
    ])

    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Loan Management"
            width={800}
            destroyOnClose={true}
            footer={null}>
            <Spin spinning={loading}>
                <Grid<RowDataType>
                    animateRows={true}
                    defaultColDef={defaultColumnDef}
                    onGridReady={e => setGridApi(e.api)}
                    getRowId={({ data }) => data.loanId + ''}
                    columnDefs={columnDefs}
                    onFirstDataRendered={({ api }) => api.sizeColumnsToFit()}
                />
            </Spin>
            {modalContext}
        </Modal>
    )
}

const useLoanManagementModal = (): [ReactNode, () => void] => {
    const [open, setOpen] = useState(false)
    const { refreshData } = useContext(DealPageContext)
    const ele = useMemo(() => (
        <LoanManagementModal
            open={open}
            onClose={() => {
                setOpen(false)
                refreshData('loan')
            }}
        />
    ), [open, refreshData])
    const openFn = () => setOpen(true)
    return [ele, openFn]
}

export default useLoanManagementModal