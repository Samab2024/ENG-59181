import createStyle from "@/hooks/createStyle"
import { css } from "@emotion/react"

const useStyle = createStyle(token => css`

    .review-section{
        margin-top: 10px;

        .review-color {
            &::before {
                display: inline-block;
                margin-right: 4px;
                margin-bottom: -3px;
                content: ' ';
                width: 1rem;
                height: 1rem;
                background-color: ${token.colorText};
            }
            &[title="1st Review"] {
                &::before {
                    background-color: #FFCC66;
                }
            }
            &[title="2nd Review"] {
                &::before {
                    background-color: #CCFFCC;
                }
            }
            &[title="3rd Review"] {
                &::before {
                    background-color: #8CE43C;
                }
            }
        }
    }
`)

export default useStyle