import IconButton from "@/components/IconButton";
import Wrapper from "@/components/Wrapper";
import { AssetType } from "@/constants";
import ImportAPI from "@/services/api/ImportAPI";
import SellerAPI from "@/services/api/SellerAPI";
import { ImportRunTypeEnum } from "@/services/api/enums";
import nameOfData from "@/utils/nameOfData";
import notification from '@/utils/notification';
import { Button, Col, Flex, Form, Input, List, Modal, Radio, Row, Select, Space, Spin, Tooltip, Typography, Upload } from 'antd';
import { ResultStatusType } from 'antd/lib/result';
import { UploadFile } from 'antd/lib/upload/interface';
import { FIDownloadSimple, FIEdit, FIImage } from "functional-icons/lib/Outline";
import { FC, ReactNode, forwardRef, useContext, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { useParams } from "react-router-dom";
import { DealPageContext } from ".";
import useStyle from './ImportLoanModal.style';
import SellerModal from "./SellerModal";
import { NotAvailable } from "@/utils/numberHelper";
import { FORMATS } from "@/utils/dateHelper";
import dayjs from "dayjs";
import { css } from "@emotion/react";
import modal from "@/utils/modal";
import InfoPop from "@/components/InfoPop";

enum ImportType {
    ClientData,
    ReviewData
}

interface IUploadForm {
    importType: ImportType
    sheetName: string,
    files: UploadFile[],
    sellerIds: number[]
    levelOfReview: number
}

export enum UploadStage {
    Input,
    Loading,
    Confirm,
    Result
}

export interface IUploadResult {
    status: ResultStatusType
    message: string
    error?: string
}


const ImportLoanModal: FC<{
    //button: (onClick: MouseEventHandler) => ReactNode,
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {
    const [stage, updateStage] = useState<UploadStage>(UploadStage.Input)
    const [form] = Form.useForm<IUploadForm>()
    const [sheetNames, updateSheetNames] = useState<string[]>()
    const [fileName, updateFileName] = useState<string>()
    const [showSellerModal, updateShowSellerModal] = useState<boolean>(false)
    const [sellerSource, updateSellerSource] = useState<API.ISeller[]>([])
    const { id } = useParams()
    const style = useStyle()
    const { deal, sellers, refreshData } = useContext(DealPageContext);
    const [confirmInfo, setConfirmInfo] = useState<API.IImportDataResponse>()
    const confirmRef = useRef<ConfirmRef>()
    const [lastInfo, setLastInfo] = useState<API.ILastImportInfo>()

    const importType = Form.useWatch<ImportType>(nameOfData<IUploadForm>("importType"), form)

    //when using sellerIds, the form will not aviliable so need to store last aviliable value
    const sellerIds = Form.useWatch<number[]>(nameOfData<IUploadForm>("sellerIds"), form)
    const [selectedSellers, setSelectedSellers] = useState(sellerIds)
    useEffect(() => {
        if (sellerIds) {
            setSelectedSellers(sellerIds)
        }
    }, [sellerIds])

    useEffect(() => {
        updateSellerSource(sellers);
    }, [sellers])

    useEffect(() => {
        ImportAPI.getLastImportInfo(Number(id)).then(x => setLastInfo(x))
    }, [])

    const handleCancel = () => {
        form.resetFields();
        updateSheetNames([]);
        updateFileName("");
        setConfirmInfo(null)
        updateStage(UploadStage.Input)
        onClose();
    }

    const handleBack = () => {
        form.resetFields()
        updateSheetNames([]);
        updateFileName("");
        setConfirmInfo(null)
        updateStage(UploadStage.Input)
    }

    const handleLoadSheetNames = () => {
        form.validateFields()
            .then(value => {
                updateStage(UploadStage.Loading);
                ImportAPI.loadSheets(value.files[0].originFileObj)
                    .then(x => {
                        updateSheetNames(x);
                        updateStage(UploadStage.Input);
                    })
                    .catch(e => notification.error((e as API.IException).message))
                    .finally(() =>
                        updateStage(UploadStage.Input)
                    );
            })
            .catch((errorInfo) => {
                console.log('Validation error:', errorInfo);
            });
    }

    const handleImportLoanData = () => {
        (stage !== UploadStage.Input ? Promise.resolve<IUploadForm>(form.getFieldsValue(true)) :
            form.validateFields())
            .then(value => {
                updateStage(UploadStage.Loading);
                let importRunType: ImportRunTypeEnum
                if (stage === UploadStage.Input) {
                    if (value.importType === ImportType.ReviewData) {
                        importRunType = ImportRunTypeEnum.ValidateReviewData
                    } else {
                        importRunType = ImportRunTypeEnum.ValidateClientData
                    }
                } else {
                    if (value.importType === ImportType.ReviewData) {
                        importRunType = ImportRunTypeEnum.ImportReviewData
                    } else {
                        importRunType = ImportRunTypeEnum.ImportClientData
                    }
                }
                const [loanMaps, headerMaps] = confirmRef.current?.getMapping() || [[], []]
                ImportAPI.importData({
                    DealId: Number(id),
                    SheetName: value.sheetName,
                    SellerIds: value.sellerIds,
                    ImportRunType: importRunType,
                    ReviewLevel: value.levelOfReview,
                    LoanMaps: loanMaps,
                    HeaderMaps: headerMaps
                }, value.files[0].originFileObj)
                    .then(res => {
                        if (typeof res?.statusMsg !== 'string') {
                            setConfirmInfo(res)
                            updateStage(UploadStage.Confirm)
                        } else {
                            if (deal.assetType !== AssetType.CLO) {
                                refreshData('loan');
                            } else {
                                refreshData('header');
                            }

                            if (res.warningMsg) {
                                modal.warning({
                                    title: res.statusMsg,
                                    content: res.warningMsg
                                })
                            } else {
                                notification.success(res.statusMsg)
                            }
                            updateStage(UploadStage.Input)
                            handleCancel();
                        }
                    })
                    .catch(e => {
                        updateStage(UploadStage.Input)
                        notification.error((e as API.IException).message, { duration: 5 })
                    })
            }).catch((errorInfo) => {
                console.log('Validation error:', errorInfo);
            });
    }

    const normFile = (e: any) => {
        form.setFieldValue(nameOfData<IUploadForm>("sheetName"), null)
        updateSheetNames([]);

        updateFileName(e.fileList[0].name)
        if (Array.isArray(e)) {
            return e;
        }
        return e && e.fileList;
    }

    const handleCloseSellerModal = () => {
        updateShowSellerModal(false);
        SellerAPI.getSellers(Number(id))
            .then((data) => {
                updateSellerSource(data);
            });
    }

    let footer: ReactNode = null
    if (stage === UploadStage.Input) {
        footer = (
            <Flex justify="space-between">
                <div>
                    {lastInfo && <LastInfo lastInfo={lastInfo} />}
                </div>
                <div>
                    <Button onClick={handleCancel}>Cancel</Button>
                    <Button type="primary" disabled={!(sheetNames && sheetNames.length > 0)} onClick={() => handleImportLoanData()}>Import Tape</Button>
                </div>
            </Flex>
        )
    } else if (stage === UploadStage.Confirm) {
        footer = (
            <div>
                <Button onClick={handleCancel}>Cancel</Button>
                <Button type="primary" onClick={() => handleImportLoanData()}>Import Tape</Button>
            </div>
        )
    }

    return (
        <Modal
            css={style}
            open={open}
            title={"Import Tape"}
            maskClosable={false}
            onCancel={handleCancel}
            footer={footer}>
            {stage === UploadStage.Input && (
                <Form layout="horizontal" labelCol={{ span: 6 }} wrapperCol={{ span: 18 }} form={form}>

                    {deal?.isDealAdmin && (
                        <Form.Item label="Import Type" name={nameOfData<IUploadForm>("importType")} initialValue={ImportType.ClientData}>
                            <Radio.Group>
                                <Radio value={ImportType.ClientData}>Client data</Radio>
                                <Radio value={ImportType.ReviewData}>Review data</Radio>
                            </Radio.Group>
                        </Form.Item>
                    )}

                    <Form.Item label="Upload File">
                        <Flex gap="small">
                            <Input placeholder='.xlsx file' value={fileName} disabled />
                            <Form.Item rules={[{ required: true, message: 'Please select a file' }]} valuePropName="fileList" name={nameOfData<IUploadForm>("files")} getValueFromEvent={normFile} noStyle >
                                <Upload onChange={handleLoadSheetNames} showUploadList={false} accept='.xlsx' beforeUpload={() => false} multiple={false} maxCount={1}>
                                    <Button>BROWSE</Button>
                                </Upload>
                            </Form.Item>
                        </Flex>
                    </Form.Item>

                    <Form.Item
                        label="Sheet"
                        rules={[{ required: !(sheetNames === undefined || sheetNames.length === 0), message: 'Please select one sheet' }]}
                        name={nameOfData<IUploadForm>("sheetName")}
                    >
                        <Select disabled={sheetNames === undefined || sheetNames.length === 0} options={sheetNames?.map(x => ({ value: x, label: x }))} />
                    </Form.Item>

                    <Form.Item
                        label="Seller"
                        tooltip={{ title: 'Use different sellers when data from multiple banks.', icon: <FIImage /> }}
                    >
                        <Flex gap="small" className="seller-wrapper">
                            <Form.Item
                                noStyle
                                name={nameOfData<IUploadForm>("sellerIds")}
                                initialValue={sellerSource && sellerSource.length > 0 ? [sellerSource[0].sellerId] : null}
                            >
                                <Select mode="multiple" options={sellerSource?.map(x => ({ value: x.sellerId, label: x.name }))} />
                            </Form.Item>
                            {deal?.isDealAdmin && (
                                <Button type="link" onClick={() => updateShowSellerModal(true)}>Update Seller</Button>
                            )}
                        </Flex>
                    </Form.Item>

                    {importType === ImportType.ReviewData && (
                        <Form.Item
                            label="Level of Review"
                            name={nameOfData<IUploadForm>("levelOfReview")} initialValue={2}>
                            <Select options={[
                                { label: 1, value: 1 },
                                { label: 2, value: 2 },
                                { label: 3, value: 3 },
                            ]} />
                        </Form.Item>
                    )}

                </Form>
            )}

            {stage === UploadStage.Confirm && (
                <UploadConfirm ref={confirmRef} confirmInfo={confirmInfo} selectedSellers={selectedSellers} />
            )}

            {stage === UploadStage.Loading && <Spin spinning={true} tip={sheetNames && sheetNames.length > 0 ? "Uploading..." : "Loading Sheets..."} ><div style={{ height: '140px' }}></div></Spin>}

            <SellerModal open={showSellerModal} onClose={handleCloseSellerModal} />
        </Modal>
    )
}

type ConfirmRef = {
    getMapping: () => [API.IImportLoanMap[], API.IImportHeaderMap[]]
}
const confirmStyle = css`
    .ant-list .ant-list-item .ant-list-item-action {
        margin-inline-start: 8px
    }
`
const UploadConfirm = forwardRef<ConfirmRef, { confirmInfo: API.IImportDataResponse, selectedSellers: number[] }>(function UploadConfirmImp({ confirmInfo, selectedSellers }, ref) {
    const [editLoan, setEditLoan] = useState(false)
    const [editHeader, setEditHeader] = useState(false)
    const [loanMapping, setLoanMapping] = useState<API.IImportLoanMap[]>([])
    const [headerMapping, setHeaderMapping] = useState<API.IImportHeaderMap[]>([])
    useImperativeHandle(ref, () => ({
        getMapping: () => [loanMapping, headerMapping]
    }))
    console.log(selectedSellers)
    return (
        <Space direction="vertical" style={{ width: '100%' }} css={confirmStyle}>
            <Typography.Text type="secondary">Data has below updates to fields and loans. Please click Import to load new data.</Typography.Text>
            <Wrapper.ListContainer height={300} noStyle={false}>
                <List>
                    {confirmInfo.missingFields?.length > 0 && (
                        <List.Item actions={confirmInfo.newFields?.length > 0 && [<IconButton size="small" key={0} icon={FIEdit} title="Remap Fields" onClick={() => setEditHeader(!editHeader)} />]}>
                            <List.Item.Meta title="Missing Fields" description={
                                editHeader ? confirmInfo.missingFields.map(missingField => {
                                    const matchItem = headerMapping.find(m => m.OrgHeaderId === missingField.headerId)
                                    return (
                                        <Row key={missingField.headerId} style={{ marginBottom: 8 }}>
                                            <Col span={10}>
                                                <Typography.Text>{missingField.headerName}</Typography.Text>
                                            </Col>
                                            <Col span={14}>
                                                <Select
                                                    style={{ width: '100%' }}
                                                    allowClear
                                                    options={
                                                        //filter out options not used or select by current header
                                                        confirmInfo.newFields
                                                            .filter(option => !headerMapping.some(mapItem => mapItem.NewHeaderId === option.headerId) || matchItem?.NewHeaderId === option.headerId)
                                                            .map(option => ({
                                                                value: option.headerId,
                                                                label: option.headerName
                                                            }))
                                                    }
                                                    value={matchItem?.NewHeaderId}
                                                    filterOption={true}
                                                    onSelect={value => {
                                                        if (matchItem) {
                                                            setHeaderMapping(mapping => mapping.map(x => x.OrgHeaderId === matchItem.OrgHeaderId ? ({
                                                                NewHeaderId: value,
                                                                OrgHeaderId: missingField.headerId
                                                            }) : x))
                                                        } else {
                                                            setHeaderMapping(x => [...x, { NewHeaderId: value, OrgHeaderId: missingField.headerId }])
                                                        }
                                                    }}
                                                    onClear={() => {
                                                        setHeaderMapping(mapping => mapping.filter(x => x.OrgHeaderId !== missingField.headerId))
                                                    }}
                                                />
                                            </Col>
                                        </Row>
                                    )
                                }) :
                                    confirmInfo.missingFields.map(x => {
                                        const matchItem = headerMapping.find(m => m.OrgHeaderId === x.headerId)
                                        if (matchItem) {
                                            return `${x.headerName} -> ${confirmInfo.newFields.find(n => n.headerId === matchItem.NewHeaderId).headerName}`
                                        } else {
                                            return x.headerName
                                        }
                                    }).join('; ')
                            } />
                        </List.Item>
                    )}

                    {confirmInfo.newFields?.length > 0 && (
                        <List.Item>
                            <List.Item.Meta title="New Fields" description={confirmInfo.newFields.filter(n => !headerMapping.find(x => x.NewHeaderId === n.headerId)).map(x => x.headerName).join('; ') || NotAvailable} />
                        </List.Item>
                    )}

                    {confirmInfo.missingLoans?.length > 0 && (
                        <List.Item actions={confirmInfo.newLoans?.length > 0 && [<IconButton size="small" key={0} icon={FIEdit} title="Remap Loans" onClick={() => setEditLoan(!editLoan)} />]}>
                            <List.Item.Meta title="Missing Loans" description={
                                editLoan ? confirmInfo.missingLoans.map(missingLoan => {
                                    const matchItem = loanMapping.find(m => m.OrgLoanId === missingLoan.loanId)
                                    return (
                                        <Row key={missingLoan.loanId} style={{ marginBottom: 8 }}>
                                            <Col span={10}>
                                                <Typography.Text>{missingLoan.loanNumber}</Typography.Text>
                                            </Col>
                                            <Col span={14}>
                                                <Select
                                                    style={{ width: '100%' }}
                                                    allowClear
                                                    options={
                                                        //filter out options not used or select by current loan
                                                        confirmInfo.newLoans
                                                            .filter(option => option.isAllowRemap && !loanMapping.some(mapItem => mapItem.NewLoanId === option.loanId) || matchItem?.NewLoanId === option.loanId)
                                                            .map(option => ({
                                                                value: option.loanId,
                                                                label: option.loanNumber
                                                            }))
                                                    }
                                                    value={matchItem?.NewLoanId}
                                                    filterOption={true}
                                                    onSelect={value => {
                                                        if (matchItem) {
                                                            setLoanMapping(mapping => mapping.map(x => x.OrgLoanId === matchItem.OrgLoanId ? ({
                                                                NewLoanId: value,
                                                                OrgLoanId: missingLoan.loanId
                                                            }) : x))
                                                        } else {
                                                            setLoanMapping(x => [...x, { NewLoanId: value, OrgLoanId: missingLoan.loanId }])
                                                        }
                                                    }}
                                                    onClear={() => {
                                                        setLoanMapping(mapping => mapping.filter(x => x.OrgLoanId !== missingLoan.loanId))
                                                    }}
                                                />
                                            </Col>
                                        </Row>
                                    )
                                }) :
                                    confirmInfo.missingLoans.map(x => {
                                        const matchItem = loanMapping.find(m => m.OrgLoanId === x.loanId)
                                        if (matchItem) {
                                            return `${x.loanNumber} -> ${confirmInfo.newLoans.find(n => n.loanId === matchItem.NewLoanId).loanNumber}`
                                        } else {
                                            return x.loanNumber
                                        }
                                    }).join('; ')
                            } />
                        </List.Item>
                    )}

                    {confirmInfo.newLoans?.filter(x => x.isAllowRemap).length > 0 && (
                        <List.Item>
                            <List.Item.Meta title={selectedSellers?.length > 1 ? <>New Loans<InfoPop buttonStyle={{ marginLeft: 4 }} textInline content="Not mapped new loans will be skipped from processing." /></> : <>New Loans</>} description={confirmInfo.newLoans.filter(n => !loanMapping.find(x => x.NewLoanId === n.loanId) && n.isAllowRemap).map(x => x.loanNumber).join('; ') || NotAvailable} />
                        </List.Item>
                    )}

                    {confirmInfo.newLoans?.filter(x => !x.isAllowRemap).length > 0 && (
                        <List.Item>
                            <List.Item.Meta title={<>Skip Loans<InfoPop buttonStyle={{ marginLeft: 4 }} textInline content="Loans will be skipped when processing since used by other sellers." /></>} description={confirmInfo.newLoans.filter(n => !loanMapping.find(x => x.NewLoanId === n.loanId) && !n.isAllowRemap).map(x => x.loanNumber).join('; ') || NotAvailable} />
                        </List.Item>
                    )}

                    {confirmInfo.updateFields?.length > 0 && (
                        <List.Item>
                            <List.Item.Meta title="Update Fields" description={confirmInfo.updateFields.join('; ')} />
                        </List.Item>
                    )}
                    {confirmInfo.updateLoans?.length > 0 && (
                        <List.Item>
                            <List.Item.Meta title="Update Loans" description={confirmInfo.updateLoans.join('; ')} />
                        </List.Item>
                    )}
                </List>
            </Wrapper.ListContainer>
        </Space >
    )
})

const LastInfo: FC<{ lastInfo: API.ILastImportInfo }> = ({ lastInfo }) => {
    const [loading, setLoading] = useState(false)
    const { id } = useParams()
    const download = () => {
        setLoading(true)
        ImportAPI.downloadLastImportFile(Number(id))
            .catch(ex => notification.error(ex.message))
            .finally(() => setLoading(false))
    }
    return (
        <Flex gap={8}>
            <Tooltip title={`Download ${lastInfo.fileName}`}>
                <IconButton size="small" icon={FIDownloadSimple} loading={loading} onClick={download} />
            </Tooltip>
            <Typography.Text type="secondary" style={{ fontSize: 10, textAlign: 'left', lineHeight: '1.2em' }}>
                {`Last uploaded at ${dayjs(lastInfo.importTime).format(FORMATS.LLL)} `}<br />
                {`by `}<strong>{lastInfo.importBy}</strong>
            </Typography.Text>
        </Flex>
    )
}

export default ImportLoanModal
