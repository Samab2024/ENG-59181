import Grid, { getDefaultColumn } from "@/components/Grid";
import selectCellEditor, { ISelectCellEditorProps, suppressSelectKeyboardEvent } from "@/components/Grid/selectCellEditor";
import SelectCellRender, { ISelectCellRenderProps } from "@/components/Grid/selectCellRender";
import dropdownFilter, { DropdownFilterParams } from "@/components/Grid/dropdownFilter";
import { ReviewStatus, ReviewStatusEnum } from "@/constants";
import ReviewerAPI from "@/services/api/ReviewerAPI";
import notification from '@/utils/notification';
import { CellValueChangedEvent, ColDef, ICellRendererParams } from "ag-grid-community";
import { Spin } from "antd";
import { FC, useContext, useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { DealPageContext, FilterCache } from ".";
import useGridStyle from './grid.style';
import _ from 'lodash';

type IRowData = API.IHeader

let filterCache: FilterCache

const defaultColumn = getDefaultColumn({
    resizable: true,
})

//FilterCache defined after filterCache, use timeout to make it work properly
setTimeout(() => {
    filterCache = new FilterCache()
});


const createColDefs = (levelOfReview: number, reviewers: API.UserInfo[], headerReviewers: API.IHeader[], isReadonly: boolean): ColDef<IRowData>[] => {
    const reviewerOptions = reviewers.map(x => ({ value: x.email, label: x.email }))
    const statusOptions = ReviewStatus.map(x => ({ value: x, label: x }))
    return [
        {
            colId: 'number',
            headerName: '#',
            field: 'displayOrder',
            sortable: true,
            width: 40,
            resizable: true,
        },
        {
            field: 'clientHeader',
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((headerReviewers?.map(x => ({
                    value: x.clientHeader,
                    label: x.clientHeader
                }))), JSON.stringify),
            } as DropdownFilterParams,
            cellRenderer: ({ data, value }: ICellRendererParams<IRowData>) => <NavLink to={`/${data.dealId}/header/${data.headerMapId}`}>{value}</NavLink>
        },
        {
            headerName: 'PwC Header',
            field: 'pwCHeader',
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((headerReviewers?.map(x => ({
                    value: x.pwCHeader,
                    label: x.pwCHeader
                }))), JSON.stringify),
            } as DropdownFilterParams,
            cellRenderer: ({ data, value }: ICellRendererParams<IRowData>) => <NavLink to={`/${data.dealId}/header/${data.headerMapId}`}>{value}</NavLink>
        },
        {
            field: 'reviewer1',
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((headerReviewers?.map(x => ({
                    value: x.reviewer1,
                    label: x.reviewer1
                }))), JSON.stringify),
            } as DropdownFilterParams,
            editable: !isReadonly,
            cellEditor: selectCellEditor,
            cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            cellRenderer: SelectCellRender,
            cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
        },
        {
            field: 'reviewerStatus1',
            sortable: true,
            filter: dropdownFilter,
            filterParams: {
                options: _.uniqBy((headerReviewers?.map(x => ({
                    value: x.reviewerStatus1,
                    label: x.reviewerStatus1
                }))), JSON.stringify),
            } as DropdownFilterParams,
            editable: !isReadonly,
            cellEditor: selectCellEditor,
            cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
        },
        ...([
            {
                field: 'reviewer2',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((headerReviewers?.map(x => ({
                        value: x.reviewer2,
                        label: x.reviewer2
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                editable: ({ data }) => data.reviewerStatus1 !== ReviewStatusEnum.NotStarted && !isReadonly,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: SelectCellRender,
                cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
            },
            {
                field: 'reviewerStatus2',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((headerReviewers?.map(x => ({
                        value: x.reviewerStatus2,
                        label: x.reviewerStatus2
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                editable: ({ data }) => data.reviewerStatus1 !== ReviewStatusEnum.NotStarted && !isReadonly,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
            },
            {
                field: 'reviewer3',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((headerReviewers?.map(x => ({
                        value: x.reviewer3,
                        label: x.reviewer3
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                editable: ({ data }) => data.reviewerStatus2 !== ReviewStatusEnum.NotStarted && !isReadonly,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: SelectCellRender,
                cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
            },
            {
                field: 'reviewerStatus3',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((headerReviewers?.map(x => ({
                        value: x.reviewerStatus3,
                        label: x.reviewerStatus3
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                editable: ({ data }) => data.reviewerStatus2 !== ReviewStatusEnum.NotStarted && !isReadonly,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
            },
        ] as ColDef<IRowData>[]).slice(0, (levelOfReview - 1) * 2)
    ]
}

const HeaderListTable: FC = () => {
    const { headerReviewers, reviewers, deal, loading, refreshData } = useContext(DealPageContext);

    const [columnDefs, setColumnDefs] = useState<ColDef[]>([])
    const [saveLoading, setSaveLoading] = useState(false)

    const gridStyle = useGridStyle()

    useEffect(() => {
        setColumnDefs(createColDefs(deal.levelOfReview, reviewers, headerReviewers, deal?.isReadOnly))
    }, [deal.levelOfReview, headerReviewers])

    //NOTICE: all logic here should reflect to LoanListTable, LoanReviewerStatus, HeaderReviewerStatus
    const handleTableChange = ({ value, colDef, node, oldValue }: CellValueChangedEvent<IRowData>) => {
        let shouldRefreshSummay = false
        if (colDef.field.includes('Status')) {
            //Not allow to clear status
            if (!value) {
                node.setData({
                    ...node.data,
                    [colDef.field]: oldValue
                })
                return
            }
            shouldRefreshSummay = true
        } else {
            //Editing reviewer by default
            if (value && [1, 2, 3].find(x => colDef.field !== ('reviewer' + x) && node.data['reviewer' + x] === value)) {
                //Found duplicate reviewer
                node.setData({
                    ...node.data,
                    [colDef.field]: oldValue
                })
                return
            }
            const statusField = colDef.field.replace('reviewer', 'reviewerStatus')
            if (value && node.data[statusField] === ReviewStatusEnum.NotStarted) {
                node.setData({
                    ...node.data,
                    [statusField]: ReviewStatusEnum.InProgress
                })
                shouldRefreshSummay = true
            } else if (!value && node.data[statusField] !== ReviewStatusEnum.NotStarted) {
                node.setData({
                    ...node.data,
                    [statusField]: ReviewStatusEnum.NotStarted
                })
                shouldRefreshSummay = true
            }
        }

        setSaveLoading(true)
        ReviewerAPI.updateAttributeReviewer({
            ...node.data, //using data from node will always be the newest
            [colDef.field]: value
        })
            .then(() => {
                if (shouldRefreshSummay) {
                    refreshData('summary')
                }
            })
            .catch(ex => notification.error(ex.message))
            .finally(() => setSaveLoading(false))

    }

    return (
        <Spin spinning={loading.header || saveLoading}>
            <Grid<IRowData>
                height="50vh"
                css={gridStyle}
                rowData={headerReviewers}
                defaultColDef={defaultColumn}
                columnDefs={columnDefs}
                getRowId={p => p.data.headerMapId + ''}
                onCellValueChanged={handleTableChange}
                onFirstDataRendered={({ api }) => {
                    //using timeout to avoid antd animation issue
                    setTimeout(() => {
                        api.sizeColumnsToFit()
                        const filterModel = filterCache.get(deal.dealId)
                        if (filterModel) {
                            api.setFilterModel(filterModel)
                        }
                    });
                }}
                onFilterChanged={e => filterCache.set(deal.dealId, e.api.getFilterModel())}
                suppressMovableColumns={true}
            />
        </Spin>
    )
}
export default HeaderListTable
