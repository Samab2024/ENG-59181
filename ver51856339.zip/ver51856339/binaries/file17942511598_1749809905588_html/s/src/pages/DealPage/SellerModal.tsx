import { FC, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Button, Col, Modal, Row, Spin } from "antd";
import notification from '@/utils/notification';
import { FIDelete, FIPlus } from "functional-icons/lib/Outline";
import Grid from "@/components/Grid";
import EditableCellRender from "@/components/Grid/editableCellRender";
import { ColDef, GridApi, ICellRendererParams } from "ag-grid-community";

import SellerAPI from "@/services/api/SellerAPI";

const SellerModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {

    const [modal, modalContext] = Modal.useModal()
    const [gridApi, setGridApi] = useState<GridApi<API.ISeller>>()
    const { id } = useParams()
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (open && gridApi) {
            setLoading(true);
            SellerAPI.getSellers(Number(id))
                .then((data) => {
                    gridApi.applyTransaction({
                        add: data.sort((a, b) => a.displayOrder - b.displayOrder)
                    })
                    gridApi.sizeColumnsToFit()
                })
                .finally(() => {
                    setLoading(false);
                });
        }

    }, [open, gridApi])


    const [columnDefs] = useState<ColDef<API.ISeller>[]>([
        {
            colId: 'displayOrder',
            field: "displayOrder",
            headerName: 'Order',
            width: 80,
            editable: true,
            rowDrag: true
        },
        {
            colId: 'name',
            field: "name",
            headerName: 'Name',
            editable: true,
            cellRenderer: EditableCellRender,
        },
        {
            colId: 'action',
            width: 20,
            headerName: '',
            suppressAutoSize: true,
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: ({ api, data }: ICellRendererParams<API.ISeller>) => data.isDeleteable && <Button type="text" icon={<FIDelete />} title="Delete" onClick={() => modal.confirm({
                title: 'Are you sure to delete this item?',
                onOk: () => {
                    const updatedRows: API.ISeller[] = []
                    api.forEachNode(node => {
                        if (node.data.sellerId !== data.sellerId) {
                            updatedRows.push(node.data)
                        }
                    })
                    updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                    api.applyTransaction({ remove: [data], update: updatedRows })
                }
            })} /> || null
        }
    ])

    const handleSaveSeller = () => {
        const data: API.ISeller[] = []
        gridApi.forEachNode(node => {
            data.push({
                ...node.data,
                sellerId: node.data.sellerId < 0 ? 0 : node.data.sellerId
            })
        })
        if (data.find(x => !x.name)) {
            notification.error("Name column is required, either fill in name or remove empty item.")
            return
        }
        if ([...new Set(data.map(x => x.name))].length !== data.length) {
            notification.error("Duplicated name found.")
            return
        }
        setLoading(true);
        SellerAPI.updateSellers(Number(id), data)
            .then(() => {
                notification.success("Save sellers successfully.")
                onClose()
            })
            .catch(e => notification.error((e as API.IException).message))
            .finally(() => setLoading(false));
    }
    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Seller"
            width={800}
            destroyOnClose={true}
            footer={<div>
                <Button onClick={onClose}>Cancel</Button>
                <Button type="primary" onClick={handleSaveSeller}>SAVE</Button>
            </div>}>
            <Row justify="end">
                <Col>
                    <Button type="link" icon={<FIPlus />} onClick={() => {
                        const displayOrders: number[] = []
                        const sellerIds: number[] = []
                        gridApi.forEachNode(node => {
                            displayOrders.push(node.data.displayOrder)
                            if (node.data.sellerId < 0) {
                                sellerIds.push(node.data.sellerId)
                            }
                        })
                        gridApi.applyTransaction({
                            add: [{
                                sellerId: (sellerIds.length > 0 ? Math.min(...sellerIds) : 0) - 1,
                                isDeleteable: true,
                                displayOrder: (Math.max(...displayOrders) || 0) + 1,
                                dealId: Number(id)
                            } as Partial<API.ISeller>] as any
                        })
                    }}>Add new</Button>
                </Col>
            </Row>
            <Spin spinning={loading}>
                <Grid<API.ISeller>
                    rowDragManaged={true}
                    onRowDragEnd={({ api }) => api.forEachNode((node, index) => node.setData({ ...node.data, displayOrder: index + 1 }))}
                    animateRows={true}
                    onGridReady={e => setGridApi(e.api)}
                    getRowId={({ data }) => data.sellerId + ''}
                    columnDefs={columnDefs}
                />
            </Spin>
            {modalContext}
        </Modal>
    )
}

export default SellerModal