import Grid from "@/components/Grid";
import EditableCellRender from "@/components/Grid/editableCellRender";
import notification from '@/utils/notification';
import { ColDef, GridApi, ICellRendererParams } from "ag-grid-community";
import { Button, Col, Modal, Row, Spin } from "antd";
import { FIDelete, FIPlus } from "functional-icons/lib/Outline";
import { FC, useContext, useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import SectionAPI from "@/services/api/SectionAPI";
import { DealPageContext } from ".";

type IRowData = API.ISection

const SectionModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {

    const [modal, modalContext] = Modal.useModal()
    const [gridApi, setGridApi] = useState<GridApi<IRowData>>()
    const { id } = useParams()
    const [loading, setLoading] = useState(false);
    const dealId = Number(id)
    const { refreshData } = useContext(DealPageContext)

    useEffect(() => {
        if (open && gridApi) {
            setLoading(true);
            SectionAPI.getSections(dealId)
                .then((data) => {
                    gridApi.applyTransaction({
                        add: data.sort((a, b) => a.displayOrder - b.displayOrder)
                    })
                    gridApi.sizeColumnsToFit()
                })
                .finally(() => {
                    setLoading(false);
                });
        }

    }, [open, gridApi])


    const [columnDefs] = useState<ColDef<IRowData>[]>([
        {
            colId: 'displayOrder',
            field: "displayOrder",
            headerName: 'Order',
            width: 80,
            editable: true,
            rowDrag: true
        },
        {
            colId: 'name',
            field: "name",
            headerName: 'Name',
            editable: true,
            cellRenderer: EditableCellRender,
        },
        {
            colId: 'action',
            width: 20,
            headerName: '',
            suppressAutoSize: true,
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: ({ api, data }: ICellRendererParams<IRowData>) => data.isDeleteable && <Button type="text" icon={<FIDelete />} title="Delete" onClick={() => modal.confirm({
                title: 'Are you sure to delete this item?',
                onOk: () => {
                    const updatedRows: IRowData[] = []
                    api.forEachNode(node => {
                        if (node.data.sectionId !== data.sectionId) {
                            updatedRows.push(node.data)
                        }
                    })
                    updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                    api.applyTransaction({ remove: [data], update: updatedRows })
                }
            })} /> || null
        }
    ])

    const handleSave = () => {
        const data: IRowData[] = []
        gridApi.forEachNode(node => {
            data.push({
                ...node.data,
                sectionId: node.data.sectionId < 0 ? 0 : node.data.sectionId
            })
        })
        if (data.find(x => !x.name)) {
            notification.error("Name column is required, either fill in name or remove empty item.")
            return
        }
        if ([...new Set(data.map(x => x.name))].length !== data.length) {
            notification.error("Duplicated name found.")
            return
        }
        setLoading(true);
        SectionAPI.updateSection(dealId, data)
            .then(() => {
                notification.success("Save sections successfully.")
                refreshData('deal')
                setLoading(false);
                onClose()
            })
            .catch(e => notification.error((e as API.IException).message))
            .finally(() => setLoading(false));
    }
    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Section"
            width={800}
            destroyOnClose={true}
            footer={<div>
                <Button onClick={onClose}>Cancel</Button>
                <Button type="primary" onClick={handleSave}>SAVE</Button>
            </div>}>
            <Row justify="end">
                <Col>
                    <Button type="link" icon={<FIPlus />} onClick={() => {
                        const displayOrders: number[] = []
                        const sectionIds: number[] = []
                        gridApi.forEachNode(node => {
                            displayOrders.push(node.data.displayOrder)
                            if (node.data.sectionId < 0) {
                                sectionIds.push(node.data.sectionId)
                            }
                        })
                        gridApi.applyTransaction({
                            add: [{
                                sectionId: (sectionIds.length > 0 ? Math.min(...sectionIds) : 0) - 1,
                                isDeleteable: true,
                                displayOrder: (Math.max(...displayOrders) || 0) + 1,
                                dealId: Number(id)
                            } as Partial<IRowData>] as any
                        })
                    }}>Add new</Button>
                </Col>
            </Row>
            <Spin spinning={loading}>
                <Grid<IRowData>
                    rowDragManaged={true}
                    onRowDragEnd={({ api }) => api.forEachNode((node, index) => node.setData({ ...node.data, displayOrder: index + 1 }))}
                    animateRows={true}
                    onGridReady={e => setGridApi(e.api)}
                    getRowId={({ data }) => data.sectionId + ''}
                    columnDefs={columnDefs}
                />
            </Spin>
            {modalContext}
        </Modal>
    )
}

export default SectionModal