import CalculatorAPI from '@/services/api/CalculatorAPI';
import modal from '@/utils/modal';
import notification from '@/utils/notification';
import { css } from '@emotion/react';
import { ColDef } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { Button, Card, Checkbox, Empty, List, Modal, Spin } from 'antd';
import { FIExpand, FIMinimize, FIPlay, FIRevert, FISave, FIHelpQuestion } from 'functional-icons/lib/Outline';
import { FC, useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import CodeEditor, { CodeEditorRef, CompletionItem } from '../../components/CodeEditor';
import Grid from '../../components/Grid/Grid';
import useGridStyle from '../DealLoanPage/ReviewDataGrid.style';
import { useAppSelector } from '@/hooks/reduxHook';
import { selectCurrentUser } from '@/redux/userSlice';
import { getAppIsActive } from '@/utils/isAppActive';
import { USER_HELP_GUIDE_LINK } from "@/constants"
import Wrapper from '@/components/Wrapper';

const RESULT_INDEX = 2

const CodeEditModal: FC<{
    headerMap: API.IHeaderMap
    headerMapItems?: API.IHeaderMap[]
    dealFields?: string[]
    open: boolean
    value: string
    onCancel: () => void
    onSave: (value: string) => void
}> = (props) => {
    const editor = useRef<CodeEditorRef>()
    const gridRef = useRef<AgGridReact>()
    const rawResult = useRef<API.ICalculatorField[]>([])
    const autoSaveTimer = useRef<NodeJS.Timeout>()

    const [loading, setLoading] = useState(false)
    const [columnDefs, setColumnDefs] = useState<ColDef[]>([])
    const [rowData, setRowData] = useState<any[]>([])
    const [errors, setErrors] = useState<string[]>([])
    const [isExpanded, setIsExpanded] = useState(false)
    const [isCalculateAllReferenceFormulas, setIsCalculateAllReferenceFormulas] = useState(false)
    const [cacheContent, setCacheContent] = useState<string>(null)

    const { id } = useParams()
    const currentUser = useAppSelector(selectCurrentUser)
    const dealId = Number(id)
    const gridStyle = useGridStyle()
    const CACHE_KEY = `AutoSave_${id}_${props.headerMap.headerMapId}_${currentUser.guid}`

    const handleSaveClick = async () => {
        try {
            setLoading(true)
            const scriptContent = editor.current?.getValue()
            await CalculatorAPI.saveFormula({
                dealId,
                headerMapId: props.headerMap.headerMapId,
                script: scriptContent,
                calculatedResult: rawResult.current,
            })
            notification.success('Saved.')
            localStorage.removeItem(CACHE_KEY)
            props.onSave(scriptContent)
        } catch (error) {
            notification.error((error as API.IException).message)
        } finally {
            setLoading(false)
        }
    }

    const popupError = (errs = errors) => {
        modal.error({ title: "Calculation Failed", width: 500, content: <Wrapper.ListContainer noStyle height={300}><List dataSource={errs} bordered={false} renderItem={item => <List.Item><code>{item}</code></List.Item>} /></Wrapper.ListContainer> })
    }

    const handleTestClick = async () => {
        if (!editor.current?.getValue()) return

        try {
            setLoading(true)
            const { errors, results: result } = await CalculatorAPI.testFormula({
                dealId,
                headerMapId: props.headerMap.headerMapId,
                script: editor.current?.getValue(),
                isCalculateAllReferenceFormulas,
            })
            const columns: ColDef[] = [...new Set(result.map(x => x.field))].map<ColDef>((x, i) => ({
                colId: x,
                field: x,
                headerName: x,
                cellStyle: { fontWeight: i == RESULT_INDEX ? 'bold' : 'normal' },
                cellClass: ({ data }) => i == RESULT_INDEX ? (data.isTie ? 'ag-cell-match' : 'ag-cell-different') : null
            }))
            setColumnDefs(columns)
            const data = Object.values(result.reduce((rows, cell, i) => {
                rows[cell.loanId] = {
                    loanId: cell.loanId,
                    ...rows[cell.loanId],
                    [cell.field]: cell.displayValue || cell.value,
                    isTie: cell.isTie || rows[cell.loanId]?.isTie
                }
                return rows
            }, {}))
            rawResult.current = result
            setRowData(data)
            setErrors(errors)

            if (errors.length > 0) {
                popupError(errors)
            }
        } catch (error) {
            setRowData([])
            rawResult.current = []
            notification.error((error as API.IException).message)
        } finally {
            setLoading(false)
        }
    }

    const handleHelpClick = () => {
        window.open(USER_HELP_GUIDE_LINK, '_blank');
    }

    const handleApplyCacheClick = () => {
        modal.confirm({
            title: "Are you sure to override with previously cached content?",
            onOk: () => {
                editor.current?.setValue(cacheContent)
                setCacheContent(null)
                localStorage.removeItem(CACHE_KEY)
            }
        })
    }

    const handleCancel = () => {
        const content = editor.current?.getValue() || ''
        if (content !== (props.value ?? '')) {
            modal.confirm({
                title: 'You have unsaved content, are you sure to continue?',
                onOk: props.onCancel
            })
        } else {
            props.onCancel()
        }
    }

    useEffect(() => {
        if (props.open) {
            editor.current?.setValue(props.value ?? "")
            setRowData([])
            rawResult.current = []

            const cache = localStorage.getItem(CACHE_KEY)
            if (cache) {
                setCacheContent(cache)
            }

            autoSaveTimer.current = setInterval(() => {
                const content = editor.current?.getValue() || ''
                if (getAppIsActive() && content !== (props.value ?? '')) {
                    localStorage.setItem(CACHE_KEY, content)
                }
            }, 30_000);
        }
        return () => {
            if (props.open) { //open changed from true to false
                setCacheContent(null)//clear state anyway
                localStorage.removeItem(CACHE_KEY)
                autoSaveTimer.current && clearInterval(autoSaveTimer.current)
            }
        }
    }, [props.open])

    return (
        <Modal
            title={`Formula Editor - ${props.headerMap.pwCHeader || props.headerMap.clientHeader}`}
            open={props.open}
            onCancel={handleCancel}
            footer={null}
            destroyOnClose={true}
            width={1200}
        >
            <div css={css({ position: 'absolute', top: 15, right: 50 })}>
                <Button size="small" type="text" title="Help" icon={<FIHelpQuestion style={{ fontSize: '16px', marginTop: '2px' }} />} onClick={handleHelpClick} />
            </div>
            <Card className="action-bar" bordered={false}>
                <div css={css({ display: 'flex', justifyContent: 'flex-start', alignItems: 'center', gap: 8 })}>
                    <Button icon={<FISave />} type="primary" onClick={handleSaveClick} disabled={rowData.length === 0 || errors.length > 0}>Save</Button>
                    <Button icon={<FIPlay />} type="text" onClick={handleTestClick} >Test</Button>
                    <Checkbox checked={isCalculateAllReferenceFormulas} onChange={e => setIsCalculateAllReferenceFormulas(e.target.checked)}>Recalculate all referenced fields</Checkbox>
                    {errors.length > 0 && <Button type="link" onClick={() => popupError()}>View Errors</Button>}
                    <div css={css({ flex: 1 })} />
                    {!!cacheContent && <Button size="small" type="text" icon={<FIRevert />} title="Restore to auto saved content" onClick={handleApplyCacheClick} />}
                    <Button size="small" type="text" icon={isExpanded ? <FIMinimize /> : <FIExpand />} onClick={() => setIsExpanded(!isExpanded)} />
                </div>
            </Card>
            <Card style={{ marginTop: '8px' }} bordered={true} bodyStyle={{ height: isExpanded ? '462px' : '136px' }}>
                <CodeEditor ref={editor} value={props.value} completionItems={props.headerMapItems.map<CompletionItem>(x => ({
                    item: x.calculatorHeader,
                    label: x.clientHeader,
                    level: 'loan'
                })).concat(props.dealFields.map<CompletionItem>(x => ({
                    item: `deal.${x}`,
                    label: x,
                    level: 'deal'
                }))).concat(props.headerMapItems.map<CompletionItem>(x => ({
                    item: `loans.${x.calculatorHeader}`,
                    label: x.clientHeader,
                    level: 'deal'
                })))} />
            </Card>
            <Card style={{ marginTop: '8px', display: isExpanded ? 'none' : 'block' }} bordered={true}>
                <Spin spinning={loading}>
                    <Grid
                        css={gridStyle}
                        ref={gridRef}
                        animateRows={true}
                        height="300px"
                        columnDefs={columnDefs}
                        rowData={rowData}
                        onFirstDataRendered={e => e.api.sizeColumnsToFit()}
                        noRowsOverlayComponent={() => <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
                    />
                </Spin>
            </Card>
        </Modal>
    )
}

export default CodeEditModal