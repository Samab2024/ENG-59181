import { FC, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Button, Col, Modal, Row, Spin } from "antd";
import notification from '@/utils/notification';
import { FIDelete, FIPlus } from "functional-icons/lib/Outline";
import Grid from "@/components/Grid";
import EditableCellRender from "@/components/Grid/editableCellRender";
import { ColDef, GridApi, ICellRendererParams } from "ag-grid-community";

import HeaderMapAPI from "@/services/api/HeaderMapAPI";

const SourceModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {

    const [modal, modalContext] = Modal.useModal()
    const [gridApi, setGridApi] = useState<GridApi<API.ISource>>()
    const { id } = useParams()
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (open && gridApi) {
            setLoading(true);
            HeaderMapAPI.getSources(Number(id))
                .then((data) => {
                    gridApi.applyTransaction({
                        add: data.sort((a, b) => a.displayOrder - b.displayOrder)
                    })
                    gridApi.sizeColumnsToFit()
                })
                .finally(() => {
                    setLoading(false);
                });
        }

    }, [open, gridApi])


    const [columnDefs] = useState<ColDef<API.ISource>[]>([
        {
            colId: 'displayOrder',
            field: "displayOrder",
            headerName: 'Order',
            width: 80,
            editable: true,
            rowDrag: true
        },
        {
            colId: 'name',
            field: "name",
            headerName: 'Name',
            editable: true,
            cellRenderer: EditableCellRender,
        },
        {
            colId: 'action',
            width: 20,
            headerName: '',
            suppressAutoSize: true,
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: ({ api, data }: ICellRendererParams<API.ISource>) => data.isDeleteable && <Button type="text" icon={<FIDelete />} title="Delete" onClick={() => modal.confirm({
                title: 'Are you sure to delete this item?',
                onOk: () => {
                    const updatedRows: API.ISource[] = []
                    api.forEachNode(node => {
                        if (node.data.sourceId !== data.sourceId) {
                            updatedRows.push(node.data)
                        }
                    })
                    updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                    api.applyTransaction({ remove: [data], update: updatedRows })
                }
            })} /> || null
        }
    ])

    const handleSaveSource = () => {
        const data: API.ISource[] = []
        gridApi.forEachNode(node => {
            data.push({
                ...node.data,
                sourceId: node.data.sourceId < 0 ? 0 : node.data.sourceId
            })
        })
        if (data.find(x => !x.name)) {
            notification.error("Name column is required, either fill in name or remove empty item.")
            return
        }
        if ([...new Set(data.map(x => x.name))].length !== data.length) {
            notification.error("Duplicated name found.")
            return
        }
        setLoading(true);
        HeaderMapAPI.updateSources(Number(id), data)
            .then(() => {
                notification.success("Save source successfully.")
                onClose()
            })
            .catch(e => notification.error((e as API.IException).message))
            .finally(() => setLoading(false));
    }
    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Source"
            width={800}
            destroyOnClose={true}
            footer={<div>
                <Button onClick={onClose}>Cancel</Button>
                <Button type="primary" onClick={handleSaveSource}>SAVE</Button>
            </div>}>
            <Row justify="end">
                <Col>
                    <Button type="link" icon={<FIPlus />} onClick={() => {
                        const displayOrders: number[] = []
                        const sourceIds: number[] = []
                        gridApi.forEachNode(node => {
                            displayOrders.push(node.data.displayOrder)
                            if (node.data.sourceId < 0) {
                                sourceIds.push(node.data.sourceId)
                            }
                        })
                        gridApi.applyTransaction({
                            add: [{
                                sourceId: (sourceIds.length > 0 ? Math.min(...sourceIds) : 0) - 1,
                                isDeleteable: true,
                                displayOrder: (Math.max(...displayOrders) || 0) + 1,
                                dealId: Number(id)
                            } as Partial<API.ISource>] as any
                        })
                    }}>Add new</Button>
                </Col>
            </Row>
            <Spin spinning={loading}>
                <Grid<API.ISource>
                    rowDragManaged={true}
                    onRowDragEnd={({ api }) => api.forEachNode((node, index) => node.setData({ ...node.data, displayOrder: index + 1 }))}
                    animateRows={true}
                    onGridReady={e => setGridApi(e.api)}
                    getRowId={({ data }) => data.sourceId + ''}
                    columnDefs={columnDefs}
                />
            </Spin>
            {modalContext}
        </Modal>
    )
}

export default SourceModal