import Grid from "@/components/Grid";
import EditableCellRender from "@/components/Grid/editableCellRender";
import createStyle from "@/hooks/createStyle";
import HeaderMapAPI from "@/services/api/HeaderMapAPI";
import { flexJustifyEnd } from '@/styles/display.module.css';
import notification from '@/utils/notification';
import { css } from "@emotion/react";
import { ColDef, GridApi, ICellRendererParams, IRowNode, RowClickedEvent, RowDragEvent } from "ag-grid-community";
import { Button, Col, Empty, Modal, Row, Spin } from "antd";
import { FIDelete, FIPlus } from "functional-icons/lib/Outline";
import { FC, useEffect, useState } from "react";
import { useParams } from "react-router-dom";

type IDataRow = API.IDropdownCategory & { isSelected?: boolean }
type IDataRow2 = API.IDropdownCategoryOption

const useGridStyle = createStyle((token) => css`
    .selected-row {
        background-color: ${token.controlItemBgActive};
        font-weight: bold;
    }
`)

const DropdownCategoryModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {

    const { id } = useParams()
    const dealId = Number(id)
    const gridStyle = useGridStyle()

    const [modal, modalContext] = Modal.useModal()
    const [gridApi, setGridApi] = useState<GridApi<IDataRow>>()
    const [gridApi2, setGridApi2] = useState<GridApi<IDataRow2>>()

    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (open && gridApi) {
            setLoading(true);
            HeaderMapAPI.getDropdownCategory(dealId)
                .then((data) => {
                    if (data.length) {
                        const sortedData = data.sort((a, b) => a.displayOrder - b.displayOrder)
                        gridApi.applyTransaction({
                            add: sortedData.map((x, i) => ({
                                ...x,
                                isSelected: i === 0 //Default select first record
                            }))
                        })

                        gridApi2.applyTransaction({
                            add: sortedData[0].dropdownCategoryOptions.sort((a, b) => a.displayOrder - b.displayOrder)
                        })
                    } else {
                        gridApi.showNoRowsOverlay()
                        gridApi2.showNoRowsOverlay()
                    }

                })
                .finally(() => {
                    setLoading(false);
                });
        }

    }, [open, gridApi])


    const [columnDefs] = useState<ColDef<IDataRow>[]>([
        {
            colId: 'displayOrder',
            field: "displayOrder",
            headerName: 'Order',
            width: 50,
            rowDrag: true
        },
        {
            colId: 'categoryName',
            field: "categoryName",
            headerName: 'Name',
            editable: true,
            cellRenderer: EditableCellRender,
        },
        {
            colId: 'action',
            width: 25,
            headerName: '',
            suppressAutoSize: true,
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: ({ api, data, context }: ICellRendererParams<IDataRow>) => data.isDeleteable && <Button type="text" icon={<FIDelete />} title="Delete" onClick={(e) => (e.preventDefault(), modal.confirm({
                title: 'Are you sure to delete this item?',
                onOk: () => {
                    const updatedRows: IDataRow[] = []
                    api.forEachNode(node => {
                        if (node.data.categoryId !== data.categoryId) {
                            updatedRows.push(node.data)
                        }
                    })
                    updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                    api.applyTransaction({ remove: [data], update: updatedRows })

                    //clear grid2 if current row selected
                    if (data.isSelected) {
                        const removeRows = []
                        context.gridApi2.forEachNode(row => removeRows.push(row.data))
                        context.gridApi2.applyTransaction({ remove: removeRows })
                    }
                }
            }))} /> || null
        }
    ])

    const [columnDefs2] = useState<ColDef<IDataRow2>[]>([
        {
            colId: 'displayOrder',
            field: "displayOrder",
            headerName: 'Order',
            width: 50,
            rowDrag: true
        },
        {
            colId: 'optionName',
            field: "optionName",
            headerName: 'Name',
            editable: true,
            cellRenderer: EditableCellRender,
        },
        {
            colId: 'action',
            width: 25,
            headerName: '',
            suppressAutoSize: true,
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: ({ api, data }: ICellRendererParams<IDataRow2>) => <Button type="text" icon={<FIDelete />} onClick={(e) => modal.confirm({
                title: 'Are you sure to delete this item?',
                onOk: () => {
                    const updatedRows: IDataRow2[] = []
                    api.forEachNode(node => {
                        if (node.data.categoryOptionId !== data.categoryOptionId) {
                            updatedRows.push(node.data)
                        }
                    })
                    updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                    api.applyTransaction({ remove: [data], update: updatedRows })
                }
            })} />
        }
    ])

    const handleSave = () => {
        //get all data from grid2
        const options: API.IDropdownCategoryOption[] = []
        gridApi2.forEachNode(row => options.push({
            ...row.data,
            categoryOptionId: row.data.categoryOptionId > 0 ? row.data.categoryOptionId : 0
        }))

        //find out current selected row
        const data: API.IDropdownCategory[] = []
        gridApi.forEachNode((row => {
            const rowData: IDataRow = { ...row.data, categoryId: row.data.categoryId > 0 ? row.data.categoryId : 0 }
            delete rowData.isSelected
            if (row.data.isSelected) {
                data.push({
                    ...rowData,
                    dropdownCategoryOptions: options,
                })
            } else {
                data.push({
                    ...rowData,
                    dropdownCategoryOptions: rowData.dropdownCategoryOptions.map(x => ({
                        ...x,
                        categoryOptionId: x.categoryOptionId > 0 ? x.categoryOptionId : 0
                    }))
                })
            }
        }))

        if (data.find(x => !x.categoryName || x.dropdownCategoryOptions.find(o => !o.optionName))) {
            notification.error("Name column is required, either fill in name or remove empty item.")
            return
        }
        if ([...new Set(data.map(x => x.categoryName))].length !== data.length) {
            notification.error("Duplicated name found.")
            return
        }
        setLoading(true);
        HeaderMapAPI.updateDropdownCategory(dealId, data)
            .then(() => {
                notification.success("Save lookup category successfully.")
                setLoading(false);
                onClose()
            })
            .catch(e => notification.error((e as API.IException).message))
            .finally(() => setLoading(false));
    }

    const handleRowDragEnd = (e: RowDragEvent) => {
        // If move to first item, move down one position(first item should always be a section)
        if (e.overIndex === 0) {
            e.api.applyTransaction({
                remove: [e.node.data],
                add: [e.node.data],
                addIndex: 1
            })
        }

        e.api.forEachNode((node, index) => {
            node.setData({
                ...node.data,
                displayOrder: index + 1
            })
            index++
        })
    }

    const handleRowSelect = (e: RowClickedEvent<IDataRow, any>) => {
        //prevent click event on delete button
        if (e.event.defaultPrevented) return

        //find out current selected row
        let currentRowNode: IRowNode<IDataRow>
        e.api.forEachNode((row => {
            if (row.data.isSelected) {
                currentRowNode = row
            }
        }))

        //get all data from grid2
        const options: IDataRow2[] = []
        gridApi2.forEachNode(row => options.push(row.data))

        //update existing row
        if (currentRowNode) {
            currentRowNode.setData({
                ...currentRowNode.data,
                isSelected: false,
                dropdownCategoryOptions: options
            })
        }

        //select current row
        e.node.setData({
            ...e.data,
            isSelected: true
        })

        //and override grid2
        gridApi2.applyTransaction({
            remove: options,
            add: e.data.dropdownCategoryOptions.sort((a, b) => a.displayOrder - b.displayOrder)
        })
    }

    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Lookup Management"
            width={800}
            destroyOnClose={true}
            footer={<div>
                <Button onClick={onClose}>Cancel</Button>
                <Button type="primary" onClick={handleSave}>SAVE</Button>
            </div>}>
            <Row gutter={16}>
                <Col span={12} className={flexJustifyEnd}>
                    <Button type="link" icon={<FIPlus />} onClick={() => {
                        const displayOrders: number[] = []
                        const ids: number[] = []
                        gridApi.forEachNode(node => {
                            displayOrders.push(node.data.displayOrder)
                            if (node.data.categoryId < 0) {
                                ids.push(node.data.categoryId)
                            }
                        })
                        gridApi.applyTransaction({
                            add: [{
                                categoryId: (ids.length > 0 ? Math.min(...ids) : 0) - 1,
                                isDeleteable: true,
                                isSelected: displayOrders.length === 0,
                                displayOrder: (displayOrders.length && Math.max(...displayOrders) || 0) + 1,
                                dropdownCategoryOptions: []
                            } as Partial<IDataRow>] as any
                        })
                    }}>Add Category</Button>
                </Col>
                <Col span={12} className={flexJustifyEnd}>
                    <Button type="link" icon={<FIPlus />} onClick={() => {
                        const displayOrders: number[] = []
                        const ids: number[] = []
                        gridApi2.forEachNode(node => {
                            displayOrders.push(node.data.displayOrder)
                            if (node.data.categoryOptionId < 0) {
                                ids.push(node.data.categoryOptionId)
                            }
                        })
                        gridApi2.applyTransaction({
                            add: [{
                                categoryOptionId: (ids.length > 0 ? Math.min(...ids) : 0) - 1,
                                displayOrder: (displayOrders.length && Math.max(...displayOrders) || 0) + 1,
                            } as Partial<IDataRow2>] as any
                        })
                    }}>Add Option</Button>
                </Col>
            </Row>
            <Row gutter={16}>
                <Col span={12}>
                    <Spin spinning={loading}>
                        <Grid<IDataRow>
                            css={gridStyle}
                            rowDragManaged={true}
                            onRowDragEnd={handleRowDragEnd}
                            onRowClicked={handleRowSelect}
                            suppressDragLeaveHidesColumns={true}
                            animateRows={true}
                            rowClassRules={{
                                'selected-row': ({ data, node }) => data.isSelected
                            }}
                            onGridReady={e => setGridApi(e.api)}
                            onFirstDataRendered={({ api }) => api.sizeColumnsToFit()}
                            getRowId={({ data }) => data.categoryId + ''}
                            columnDefs={columnDefs}
                            context={{ gridApi2 }}
                            noRowsOverlayComponent={() => <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
                        />
                    </Spin>
                </Col>
                <Col span={12}>
                    <Spin spinning={loading}>
                        <Grid<IDataRow2>
                            css={gridStyle}
                            rowDragManaged={true}
                            onRowDragEnd={handleRowDragEnd}
                            suppressDragLeaveHidesColumns={true}
                            animateRows={true}
                            onGridReady={e => setGridApi2(e.api)}
                            onFirstDataRendered={({ api }) => api.sizeColumnsToFit()}
                            getRowId={({ data }) => data.categoryOptionId + ''}
                            columnDefs={columnDefs2}
                            noRowsOverlayComponent={() => <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
                        />
                    </Spin>
                </Col>
            </Row>
            {modalContext}
        </Modal>
    )
}

export default DropdownCategoryModal