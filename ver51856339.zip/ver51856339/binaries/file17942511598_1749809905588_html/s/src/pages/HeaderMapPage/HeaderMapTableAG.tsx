import Grid, { getDefaultColumn } from "@/components/Grid"
import HeaderMapAPI from "@/services/api/HeaderMapAPI"
import notification from "@/utils/notification"
import { Empty, Space, Upload, Modal, Checkbox } from "antd"
import { ForwardRefRenderFunction, forwardRef, useCallback, useContext, useEffect, useImperativeHandle, useMemo, useState } from "react"
// import useStyle from "../DealLoanPage/style";
import dropdownFilter, { DropdownFilterParams } from "@/components/Grid/dropdownFilter"
import EditableCellRender from "@/components/Grid/editableCellRender"
import inputFilter from "@/components/Grid/inputFilter"
import SelectCellEditor, { ISelectCellEditorProps, suppressSelectKeyboardEvent } from "@/components/Grid/selectCellEditor"
import SelectCellRender, { ISelectCellRenderProps } from "@/components/Grid/selectCellRender"
import nameOfData from "@/utils/nameOfData"
import { CloseOutlined, CloudUploadOutlined, DeleteOutlined, EyeOutlined } from "@ant-design/icons"
import { CellValueChangedEvent, ColDef, GridApi, ICellRendererParams, ILargeTextEditorParams } from "ag-grid-community"
import { useParams } from "react-router-dom"
import { HeaderMapContext } from "./HeaderMapPage"
import __ from "lodash";
import { FormatTypeEnum, PROCESS_TYPES } from "@/constants"
import NumericCellRender, { INumericCellRenderProps } from "@/components/Grid/numericCellRender"
import numericCellEditor, { INumericCellEditorProps } from "@/components/Grid/numericCellEditor"
import CodeCellRender from "./CodeCellRender"

export interface IHeaderMapTableComp {
    getValues: () => API.IHeaderMap[]
    getChangedValues: () => API.IHeaderMap[]
}

const TEXT_FORMAT_ID = 1
const regexPattern = /^[a-zA-Z_][a-zA-Z0-9_]*$/;

const DatGrid = Grid<API.IHeaderMap>
const defaultColumn = getDefaultColumn({
    resizable: true,
    // suppressSizeToFit: true,
    sortable: true,
    // wrapText: true
})

const isSpecificProcessType = (processType: string) => [
    PROCESS_TYPES.Provided,
    PROCESS_TYPES.PassThrough,
    PROCESS_TYPES.Calculation
].includes(processType)

const createColumnDefs = ({
    handleUploadScreenShot,
    sourceDocSections,
    dataFormats,
    processTypes,
    sources,
    modal,
    onRowDelete,
    levelOfReviews,
    isEditable,
    dropdownCategories
}: {
    handleUploadScreenShot,
    sourceDocSections: API.ISourceDocSection[],
    dataFormats: API.IDataFormat[],
    processTypes: string[],
    sources: API.ISource[],
    modal,
    onRowDelete: (row: API.IHeaderMap) => void,
    levelOfReviews: number[],
    isEditable: boolean,
    dropdownCategories: API.IDropdownCategory[]
}): ColDef<API.IHeaderMap>[] => [
        {
            colId: 'displayOrder',
            field: nameOfData<API.IHeaderMap>("displayOrder"),
            headerName: '#',
            width: 70,
            rowDrag: isEditable,
            editable: isEditable
        },
        {
            colId: "clientHeader",
            field: nameOfData<API.IHeaderMap>("clientHeader"),
            headerName: 'Client Header',
            cellClass: 'ag-text-allow-select',
            filter: inputFilter
        },
        {
            colId: "pwCHeader",
            field: nameOfData<API.IHeaderMap>("pwCHeader"),
            headerName: 'PwC Header',
            editable: isEditable,
            cellEditor: 'agLargeTextCellEditor',
            cellEditorParams: {
                maxLength: 200,
                rows: 5,
                cols: 30,
            } as ILargeTextEditorParams,
            cellEditorPopup: isEditable,
            cellRenderer: EditableCellRender,
            filter: inputFilter
        },
        {
            colId: "calculatorHeader",
            field: "calculatorHeader",
            headerName: 'Calculator Header',
            editable: isEditable,
            cellEditor: 'agLargeTextCellEditor',
            cellEditorParams: {
                maxLength: 200,
                rows: 5,
                cols: 30,
            } as ILargeTextEditorParams,
            valueSetter: ({ newValue, node }) => {
                if (!newValue || regexPattern.test(newValue)) {
                    node.data.calculatorHeader = newValue
                    return true
                } else {
                    notification.error("The Calculator Header is invalid.")
                    return false
                }
            },
            cellEditorPopup: isEditable,
            cellRenderer: EditableCellRender,
            filter: inputFilter
        },
        {
            colId: "processType",
            field: nameOfData<API.IHeaderMap>("processType"),
            headerName: 'Process Type',
            editable: isEditable,
            cellRenderer: SelectCellRender,
            cellRendererParams: {
                options: processTypes?.map(x => ({
                    value: x,
                    label: x
                })) || []
            } as ISelectCellRenderProps,
            cellEditor: SelectCellEditor,
            cellEditorParams: {
                options: processTypes?.map(x => ({
                    value: x,
                    label: x
                })) || [],
                allowClear: false
            } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            filter: dropdownFilter,
            filterParams: {
                options: processTypes?.map(x => ({
                    value: x,
                    label: x
                })) || []
            } as DropdownFilterParams,
            colSpan: ({ data }) => data.processType == PROCESS_TYPES.Calculation ? 1 : 2
        },
        {
            colId: 'calculatorFormula',
            field: 'calculatorFormula',
            headerName: '',
            width: 20,
            suppressSizeToFit: true,
            resizable: false,
            editable: false,
            hide: !isEditable,
            cellRenderer: CodeCellRender,
            cellEditorPopup: true,
        },
        {
            colId: "sourceDocSectionId",
            field: nameOfData<API.IHeaderMap>("sourceDocSectionId"),
            headerName: 'Source Doc Section',
            editable: ({ data }) => isEditable && !isSpecificProcessType(data.processType),
            cellRenderer: SelectCellRender,
            cellRendererParams: {
                options: sourceDocSections?.map(x => ({
                    value: x.sourceDocSectionId,
                    label: x.name
                })) || []
            } as ISelectCellRenderProps,
            cellEditor: SelectCellEditor,
            cellEditorParams: {
                options: sourceDocSections?.map(x => ({
                    value: x.sourceDocSectionId,
                    label: x.name
                })),
                allowClear: false
            } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            filter: dropdownFilter,
            filterParams: {
                options: sourceDocSections?.map(x => ({
                    value: x.sourceDocSectionId,
                    label: x.name
                })),
            } as DropdownFilterParams,
            cellClassRules: {
                'hidden': ({ data }) => isSpecificProcessType(data.processType)
            },
        },
        {
            colId: "source",
            field: nameOfData<API.IHeaderMap>("sourceId"),
            headerName: 'Source',
            editable: ({ data }) => isEditable && !isSpecificProcessType(data.processType),
            cellRenderer: SelectCellRender,
            cellRendererParams: {
                options: sources?.map(x => ({
                    value: x.sourceId,
                    label: x.name
                })) || []
            } as ISelectCellRenderProps,
            cellEditor: SelectCellEditor,
            cellEditorParams: {
                options: sources?.map(x => ({
                    value: x.sourceId,
                    label: x.name
                })),
                allowClear: false
            } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            filter: dropdownFilter,
            filterParams: {
                options: sources?.map(x => ({
                    value: x.sourceId,
                    label: x.name
                })),
            } as DropdownFilterParams,
            cellClassRules: {
                'hidden': ({ data }) => isSpecificProcessType(data.processType)
            },
        },
        {
            colId: "dataFormatId",
            field: nameOfData<API.IHeaderMap>("dataFormatId"),
            headerName: 'Format',
            editable: isEditable,
            width: 150,
            cellRenderer: SelectCellRender,
            cellRendererParams: {
                options: dataFormats?.map(x => ({
                    value: x.dataFormatId,
                    label: x.name
                })) || []
            } as ISelectCellRenderProps,
            cellEditor: SelectCellEditor,
            cellEditorParams: {
                options: dataFormats?.map(x => ({
                    value: x.dataFormatId,
                    label: x.name
                })),
                allowClear: false
            } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            filter: dropdownFilter,
            filterParams: {
                options: dataFormats?.map(x => ({
                    value: x.dataFormatId,
                    label: x.name
                })),
            } as DropdownFilterParams,
        },
        {
            colId: "threadhold",
            field: nameOfData<API.IHeaderMap>("threadhold"),
            headerName: 'Threshold',
            editable: ({ data }) => {
                const format = dataFormats?.find(x => x.dataFormatId == data.dataFormatId)
                return isEditable && format?.type !== FormatTypeEnum.IsString
            },
            width: 150,
            cellRendererSelector: ({ data }) => {
                const format = dataFormats?.find(x => x.dataFormatId == data.dataFormatId)
                if (format?.type == FormatTypeEnum.IsString) {
                    return {
                        component: () => null
                    }
                }
                return {
                    component: NumericCellRender,
                    params: {
                        isPercentage: format?.code.includes('%'),
                        suffix: format?.type === FormatTypeEnum.IsDateTime ? ' days' : ''
                    } as INumericCellRenderProps,
                }
            },
            cellEditorSelector: ({ data }) => {
                const format = dataFormats?.find(x => x.dataFormatId == data.dataFormatId)
                return {
                    component: numericCellEditor,
                    params: {
                        isPercentage: format?.code.includes('%'),
                        isNegativeAllowed: false,
                        isIntegerOnly: format?.type === FormatTypeEnum.IsDateTime,
                        suffix: format?.type === FormatTypeEnum.IsDateTime ? 'days' : ''
                    } as INumericCellEditorProps,
                }
            }
        },
        {
            colId: 'dropdownCategoryId',
            field: 'dropdownCategoryId',
            headerName: 'Lookup Category',
            width: 150,
            editable: ({ data }) => isEditable && data.dataFormatId === TEXT_FORMAT_ID,
            cellRenderer: SelectCellRender,
            cellRendererParams: {
                options: dropdownCategories?.map(x => ({ value: x.categoryId, label: x.categoryName }))
            } as ISelectCellRenderProps,
            cellEditor: SelectCellEditor,
            cellEditorParams: {
                options: dropdownCategories?.map(x => ({ value: x.categoryId, label: x.categoryName }))
            } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            filter: dropdownFilter,
            filterParams: {
                options: dropdownCategories?.map(x => ({
                    value: x.categoryId,
                    label: x.categoryName
                })),
            } as DropdownFilterParams,
        },
        {
            colId: "fieldGuide",
            field: nameOfData<API.IHeaderMap>("fieldGuide"),
            headerName: 'Field Guide',
            editable: isEditable,
            cellEditor: 'agLargeTextCellEditor',
            cellEditorParams: {
                maxLength: 2000,
                rows: 5,
                cols: 30,
            } as ILargeTextEditorParams,
            cellEditorPopup: isEditable,
            cellRenderer: EditableCellRender,
            filter: inputFilter
        },
        {
            colId: "levelOfReview",
            field: nameOfData<API.IHeaderMap>("levelOfReview"),
            width: 120,
            headerName: 'Level Of Review',
            editable: isEditable,
            cellRenderer: SelectCellRender,
            cellRendererParams: {
                options: levelOfReviews?.map(x => ({
                    value: x,
                    label: x
                })) || []
            } as ISelectCellRenderProps,
            cellEditor: SelectCellEditor,
            cellEditorParams: {
                options: levelOfReviews?.map(x => ({
                    value: x,
                    label: x
                })),
            } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            filter: dropdownFilter,
            filterParams: {
                options: levelOfReviews?.map(x => ({
                    value: x,
                    label: x.toString()
                })),
            } as DropdownFilterParams
        },
        {
            colId: 'isBlindReview',
            field: nameOfData<API.IHeaderMap>("isBlindReview"),
            width: 100,
            headerName: 'Blind Review',
            suppressAutoSize: true,
            cellRenderer: ({ node, data, value }: ICellRendererParams<API.IHeaderMap>) => <Checkbox disabled={!isEditable} checked={value} onChange={e => node.setData({ ...data, isBlindReview: e.target.checked })} />
        },
        {
            colId: 'isExcludedInReport',
            field: nameOfData<API.IHeaderMap>("isExcludedInReport"),
            width: 120,
            headerName: 'Exclude in Exception Report',
            suppressAutoSize: true,
            cellRenderer: ({ node, data, value }: ICellRendererParams<API.IHeaderMap>) => <Checkbox disabled={!isEditable} checked={value} onChange={e => node.setData({ ...data, isExcludedInReport: e.target.checked })} />
        },
        {
            colId: "screenShotId",
            field: nameOfData<API.IHeaderMap>("screenShotId"),
            headerName: '',
            width: 50,
            cellRenderer: ({ node, value, api }: ICellRendererParams<API.IHeaderMap>) => value ? (
                <Space>
                    <EyeOutlined onClick={() => {
                        HeaderMapAPI.downloadScreenShot(value)
                    }} title="View screen shot" />
                    {isEditable && <CloseOutlined onClick={() => {
                        node.setData({
                            ...node.data,
                            screenShotId: null
                        })
                    }} title="Remove screen shot" />}
                </Space>
            ) : isEditable && (
                <Upload accept="image/*" onChange={(info) => handleUploadScreenShot(info, node)} beforeUpload={() => false} multiple={false}>
                    <CloudUploadOutlined title="Add screen shot" onClick={() => { }} />
                </Upload>
            )
        },
        {
            colId: "action",
            headerName: '',
            width: 50,
            cellRenderer: ({ node, data, api }: ICellRendererParams<API.IHeaderMap>) => !data.clientHeader ? (
                <Space>
                    <DeleteOutlined title="Remove item" onClick={() => modal.confirm({
                        title: 'Are you sure to delete this item?',
                        onOk: () => {
                            onRowDelete(node.data);
                            // reorder rows
                            const updatedRows: API.IHeaderMap[] = []
                            api.forEachNode(node => {
                                if (node.data.headerMapId !== data.headerMapId) {
                                    updatedRows.push(node.data)
                                }
                            })
                            updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                            // remove row from AG
                            api.applyTransaction({ remove: [data], update: updatedRows })
                        }
                    })} />
                </Space>
            ) : null
        }
    ]

const HeaderMapTable: ForwardRefRenderFunction<IHeaderMapTableComp> = (_, ref) => {
    const { id } = useParams()
    const { headerMaps, sourceDocSections, dataFormats, processTypes, sources, levelOfReviews, isEditable, dropdownCategories } = useContext(HeaderMapContext);
    const [gridApi, setGridApi] = useState<GridApi<API.IHeaderMap>>()
    const [columnDefs, setColumnDefs] = useState<ColDef<API.IHeaderMap>[]>([])
    const initialHeaderMaps = useMemo(() => __.cloneDeep(headerMaps), [headerMaps])
    const [modal, modalContext] = Modal.useModal()
    const [deleteRows, setDeleteRows] = useState<API.IHeaderMap[]>([])
    useEffect(() => {
        if (gridApi) {
            setColumnDefs(createColumnDefs({
                handleUploadScreenShot,
                sourceDocSections,
                dataFormats,
                processTypes,
                sources,
                modal,
                onRowDelete: (row) => setDeleteRows([...deleteRows, row]),
                levelOfReviews,
                isEditable,
                dropdownCategories
            }))
        }
    }, [sourceDocSections, dataFormats, sources, processTypes, gridApi, modal, deleteRows, levelOfReviews, isEditable, dropdownCategories])

    useEffect(() => {
        //clear deleted rows when data refreshed
        setDeleteRows([])
    }, [headerMaps])

    const handleUploadScreenShot = (info, node) => {
        HeaderMapAPI.uploadScreenShot(Number(id), info.fileList[0].originFileObj)
            .then((data) => {
                node.setData({
                    ...node.data,
                    screenShotId: data
                })
                notification.success("Upload screen shot successfully.");
            })
            .catch(e => notification.error((e as API.IException).message))
    }

    const handleCellValueChange = ({ colDef, value, node, api }: CellValueChangedEvent<API.IHeaderMap>) => {
        if (colDef.field === 'dataFormatId') {
            if (value !== TEXT_FORMAT_ID) {
                node.setData({
                    ...node.data,
                    dropdownCategoryId: null,
                    threadhold: 0,
                })
            } else {
                node.setData({
                    ...node.data,
                    threadhold: 0,
                })
            }
        } else if (colDef.field == 'processType') {
            api.redrawRows({ rowNodes: [node] })
        }
    }

    const getChangedValues = useCallback(() => {
        const result: API.IHeaderMap[] = []
        const fields: (keyof API.IHeaderMap)[] = ['displayOrder', 'pwCHeader', 'processType', 'sourceDocSectionId', 'sourceId', 'dataFormatId', 'fieldGuide', 'levelOfReview', 'screenShotId', 'isActive', 'isBlindReview', 'isExcludedInReport', 'dropdownCategoryId', 'threadhold', 'calculatorHeader']
        gridApi.forEachNode(node => {
            if (fields.find(field => node.data[field] !== initialHeaderMaps.find(x => x.headerMapId === node.data.headerMapId)[field])) {
                result.push(node.data)
            }
        })
        //add delete row if existing
        return result.concat(deleteRows.map(d => ({ ...d, isActive: false })));
    }, [initialHeaderMaps, deleteRows, gridApi])

    useImperativeHandle<IHeaderMapTableComp, IHeaderMapTableComp>(ref, () => {
        return {
            // the final value to send to the grid, on completion of editing
            getValues() {
                const result: API.IHeaderMap[] = []
                gridApi.forEachNode(node => {
                    result.push(node.data)
                })
                return result;
            },
            getChangedValues,
        };
    });

    return (
        <>
            <DatGrid
                rowDragManaged={true}
                onRowDragEnd={({ api }) => api.forEachNode((node, index) => node.setData({ ...node.data, displayOrder: index + 1 }))}
                animateRows={true}
                onGridReady={e => setGridApi(e.api)}
                defaultColDef={defaultColumn}
                rowData={headerMaps}
                context={{ getChangedValues }}
                height="calc(100vh - 40px - 50px - 56px)" //footer + header + title
                columnDefs={columnDefs}
                onFirstDataRendered={e => e.api.sizeColumnsToFit()}
                onCellValueChanged={handleCellValueChange}
                getRowId={({ data }) => data.headerMapId + ''}
                noRowsOverlayComponent={() => <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
            />
            {modalContext}
        </>

    )
}

export default forwardRef(HeaderMapTable)
