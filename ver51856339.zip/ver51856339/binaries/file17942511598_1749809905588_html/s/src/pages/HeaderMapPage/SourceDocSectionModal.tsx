import Grid from "@/components/Grid";
import EditableCellRender from "@/components/Grid/editableCellRender";
import createStyle from "@/hooks/createStyle";
import HeaderMapAPI from "@/services/api/HeaderMapAPI";
import SectionAPI from "@/services/api/SectionAPI";
import notification from '@/utils/notification';
import { css } from "@emotion/react";
import customHeaderToolTip, { ICustomHeaderParams } from "@/components/Grid/customHeaderToolTip";
import { ColDef, EditableCallbackParams, GridApi, ICellRendererParams, RowDragEndEvent, RowDragEvent } from "ag-grid-community";
import { Button, Checkbox, Col, Modal, Row, Spin } from "antd";
import { FIDelete, FIPlus } from "functional-icons/lib/Outline";
import _ from "lodash";
import { FC, useCallback, useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { MoveToFn, useDragTreeData } from "@/hooks/useDragTreeData";
import { AgGridReact } from "ag-grid-react";

interface IDataRow {
    sectionId: number
    sourceDocSectionId?: number
    name?: string
    displayOrder?: number
    isAllowCopy?: boolean
    isEditable?: boolean
    isDeleteable?: boolean
    isSection: boolean
}

const useGridStyle = createStyle(token => css`
    .section-row {
        background-color: #EEE;
        font-weight: bold;
    }
`)

const moveSections: MoveToFn<IDataRow> = (rowData, source, target) => {
    if (source === target) {
        return rowData; //invalid move - no-op
    }

    let splitIndex: number;
    if (target) {
        splitIndex = rowData.findIndex(x => target.isSection ? (x.isSection && x.sectionId === target.sectionId) : x.sourceDocSectionId === target.sourceDocSectionId);
        if (splitIndex > rowData.findIndex(x => source.isSection ? (x.isSection && x.sectionId === source.sectionId) : x.sourceDocSectionId === source.sourceDocSectionId)) {
            ++splitIndex; // If we are moving to the top, we move after the target
        }
    } else {
        splitIndex = rowData.length; // we move at the end
    }

    if (splitIndex === 0) {
        return rowData //invalid move - child can not be the first item
    }
    return [
        ...rowData.slice(0, splitIndex).filter(x => x.sourceDocSectionId !== source.sourceDocSectionId),
        { ...source, sectionId: rowData[splitIndex - 1].sectionId },
        ...rowData.slice(splitIndex).filter(x => x.sourceDocSectionId !== source.sourceDocSectionId)
    ]

}

const SourceDocSectionModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {
    const [modal, modalContext] = Modal.useModal()
    const [columnDefs] = useState<ColDef<IDataRow>[]>([
        {
            colId: 'displayOrder',
            field: "displayOrder",
            headerName: 'Order',
            width: 80,
            editable: ({ data }) => !data.isSection,
            sortable: false,
        },
        {
            colId: 'name',
            field: "name",
            headerName: 'Name',
            editable: ({ data }: EditableCallbackParams<IDataRow>) => data.isEditable,
            cellRenderer: EditableCellRender,
            sortable: false,
        },
        {
            colId: 'isAllowCopy',
            field: "isAllowCopy",
            width: 50,
            headerComponent: customHeaderToolTip,
            headerComponentParams: {
                displayName: 'Allow Copy',
                tooltipText: 'Allow users to copy the entire section when doing the review.'
            } as ICustomHeaderParams,
            suppressAutoSize: true,
            cellRenderer: ({ node, data, value }: ICellRendererParams<IDataRow>) => !data.isSection && <Checkbox checked={value} onChange={e => node.setData({ ...data, isAllowCopy: e.target.checked })} />,
            sortable: false,
        },
        {
            colId: 'action',
            width: 20,
            headerName: '',
            suppressAutoSize: true,
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: ({ api, data }: ICellRendererParams<IDataRow>) => data.isEditable && data.isDeleteable && <Button type="text" icon={<FIDelete />} title="Delete" onClick={() => modal.confirm({
                title: 'Are you sure to delete this item?',
                onOk: () => {
                    const updatedRows: IDataRow[] = []
                    api.forEachNode(node => {
                        //Reorder source doc section in same section
                        if (node.data.sourceDocSectionId !== data.sourceDocSectionId && node.data.sectionId === data.sectionId && !node.data.isSection) {
                            updatedRows.push(node.data)
                        }
                    })
                    updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                    api.applyTransaction({ remove: [data], update: updatedRows })
                }
            })} /> || null,
            sortable: false,
        }
    ])
    const [gridApi, setGridApi] = useState<GridApi<IDataRow>>()
    const gridRef = useRef<AgGridReact<IDataRow>>()
    const { id } = useParams()
    const dealId = Number(id)
    const [loading, setLoading] = useState(false);
    const gridStyle = useGridStyle()
    const dndHandlers = useDragTreeData(gridRef, moveSections)

    useEffect(() => {
        if (open && gridApi) {
            setLoading(true);
            Promise.all([
                SectionAPI.getSections(dealId),
                HeaderMapAPI.getSourceDocSections(dealId)
            ])
                .then(([sections, sourceDocSections]) => {
                    //group by sectionid, if no sectionid, assign to first section
                    const docSectionGroup = _.groupBy(sourceDocSections, x => x.sectionId || sections[0].sectionId)
                    gridApi.applyTransaction({
                        add: sections.reduce<IDataRow[]>((p, c, i) => {
                            //add section
                            p.push({
                                isSection: true,
                                sectionId: c.sectionId,
                                sourceDocSectionId: 0,
                                name: c.name,
                                isEditable: false
                            })
                            //add source doc sections
                            p.push(...(docSectionGroup[c.sectionId] ?? []).sort((a, b) => a.displayOrder - b.displayOrder).map<IDataRow>(x => ({
                                isSection: false,
                                sectionId: x.sectionId,
                                sourceDocSectionId: x.sourceDocSectionId,
                                name: x.name,
                                displayOrder: x.displayOrder,
                                isAllowCopy: x.isAllowCopy,
                                isEditable: true,
                                isDeleteable: x.isDeleteable,
                            })))
                            return p
                        }, [])
                    })
                    gridApi.sizeColumnsToFit()
                })
                .finally(() => {
                    setLoading(false);
                });
        }

    }, [open, gridApi])


    const handleSaveSourceDocSection = () => {
        const data: API.ISourceDocSection[] = []
        gridApi.forEachNode(node => {
            if (!node.data.isSection) {
                data.push({
                    sectionId: node.data.sectionId,
                    name: node.data.name,
                    displayOrder: node.data.displayOrder,
                    isAllowCopy: node.data.isAllowCopy,
                    isDeleteable: node.data.isDeleteable,
                    sourceDocSectionId: node.data.sourceDocSectionId < 0 ? 0 : node.data.sourceDocSectionId
                })
            }
        })
        if (data.find(x => !x.name)) {
            notification.error("Name column is required, either fill in name or remove empty item.")
            return
        }
        if ([...new Set(data.map(x => x.name))].length !== data.length) {
            notification.error("Duplicated name found.")
            return
        }
        setLoading(true);
        HeaderMapAPI.updateSourceDocSection(dealId, data)
            .then(() => {
                notification.success("Save soure doc section successfully.")
                onClose()
            })
            .catch(e => notification.error((e as API.IException).message))
            .finally(() => setLoading(false));
    }

    const handleRowDragEnd = (e: RowDragEvent<IDataRow>) => {
        dndHandlers.onRowDragEnd(e)
        let index = 0
        e.api.forEachNode(node => {
            if (node.data.isSection) {
                index = 0 //reset count
            } else {
                node.setData({
                    ...node.data,
                    displayOrder: index + 1
                })
                index++
            }
        })
    }

    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Source Doc Section"
            width={800}
            destroyOnClose={true}
            footer={<div>
                <Button onClick={onClose}>Cancel</Button>
                <Button type="primary" onClick={handleSaveSourceDocSection}>SAVE</Button>
            </div>}>
            <Row justify="end">
                <Col>
                    <Button type="link" icon={<FIPlus />} onClick={() => {
                        let sectionId = 0
                        let maxOrder = 0
                        let minId = 0
                        gridApi.forEachNode(node => {
                            if (node.data.isSection) {
                                //use last section
                                sectionId = node.data.sectionId
                                maxOrder = 0
                            } else {
                                maxOrder = Math.max(maxOrder, node.data.displayOrder)
                                if (node.data.sourceDocSectionId < 0) {
                                    minId = Math.min(minId, node.data.sourceDocSectionId)
                                }
                            }
                        })
                        gridApi.applyTransaction({
                            add: [{
                                sectionId,
                                sourceDocSectionId: minId - 1,
                                isEditable: true,
                                isDeleteable: true,
                                displayOrder: maxOrder + 1,
                                dealId
                            } as Partial<API.ISourceDocSection>] as any
                        })
                    }}>Add new</Button>
                </Col>
            </Row>
            <Spin spinning={loading}>
                <Grid<IDataRow>
                    ref={gridRef}
                    css={gridStyle}
                    suppressDragLeaveHidesColumns={true}
                    animateRows={true}
                    rowClassRules={{
                        'section-row': ({ data }) => data.isSection
                    }}
                    onGridReady={e => setGridApi(e.api)}
                    getRowId={({ data }) => data.isSection ? ('s' + data.sectionId) : ('' + data.sourceDocSectionId)}
                    treeData={true}
                    groupDefaultExpanded={-1}
                    autoGroupColumnDef={{
                        width: 30,
                        resizable: false,
                        headerName: '',
                        cellRenderer: () => '',
                        sortable: false,
                        rowDrag: ({ data }) => !data.isSection,
                        rowDragText: (params) => params.rowNode.data.name,
                    }}
                    getDataPath={x => x.isSection ? [x.sectionId + ''] : [x.sectionId + '', x.sourceDocSectionId + '']}
                    columnDefs={columnDefs}
                    {...dndHandlers}
                    onRowDragEnd={handleRowDragEnd}
                />
            </Spin>
            {modalContext}
        </Modal>
    )
}

export default SourceDocSectionModal