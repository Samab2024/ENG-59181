import { Checkbox, Modal, Select, Spin, Button, Tooltip } from "antd";
import { FC, useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import InfoPop from "@/components/InfoPop";
import DealAPI from '@/services/api/DealAPI';
import useStyle from './CopyHeaderMapFromOtherDealModal.style';
import notification from '@/utils/notification';
import HeaderMapAPI from "@/services/api/HeaderMapAPI";
import { HeaderMapContext } from "./HeaderMapPage";

const CopyHeaderMapFromOtherDealModal: FC<{
    open: boolean
    onCloes: () => void
}> = ({ open, onCloes }) => {
    const style = useStyle()
    const { id } = useParams()
    const { getHeaderMapById, getSourceDocSection } = useContext(HeaderMapContext);
    const [loading, setLoading] = useState(false);
    const [dealList, setDealList] = useState<API.IDealSetup[]>([]);
    const [isOverride, setIsOverride] = useState(false);
    const [copiedDealId, setCopiedDealId] = useState(undefined);

    useEffect(() => {
        if (open) {
            setLoading(true);
            DealAPI.getAll()
                .then((data) => {
                    setDealList(data.filter(d => d.dealId !== Number(id)));
                })
                .finally(() => {
                    setLoading(false);
                });
        }

    }, [open])


    const handleCopyHeaderMap = () => {
        if (copiedDealId == undefined) {
            notification.error("Please select a deal for coping the header map first.");
            return;
        }

        setLoading(true);
        HeaderMapAPI.copyHeaderMap(Number(id), { dealIdRef: copiedDealId, isOverride: isOverride } as API.ICopyHeaderMapConfig)
            .then(() => {
                notification.success("Copy header map successfully.")
                getSourceDocSection();
                getHeaderMapById();
                setLoading(false);
                onCloes();
            })
            .catch(e => notification.error((e as API.IException).message))
            .finally(() => setLoading(false));
    }

    const onCancel = () => {
        setIsOverride(false);
        setCopiedDealId(undefined);
        onCloes();
    }

    return (
        <Modal
            css={style}
            open={open}
            onCancel={onCancel}
            title="Copy Header Map"
            width={410}
            maskClosable={false}
            footer={<div>
                <Button onClick={onCancel}>Cancel</Button>
                <Button type="primary" onClick={handleCopyHeaderMap}>COPY</Button>
            </div>}>
            <Spin spinning={loading}>
                <div>
                    <span className="select-deal">
                        <label>Deal: </label>
                        <Select onChange={(v) => setCopiedDealId(v)} value={copiedDealId}>
                            {dealList && dealList.map(x => (
                                <Select.Option key={x.dealId} value={x.dealId}>{x.dealName}</Select.Option>
                            ))}
                        </Select>
                    </span>
                </div>
                <div className="is-override">
                    <Checkbox onChange={e => setIsOverride(e.target.checked)}>Is Override?</Checkbox>
                    <InfoPop textInline={true} content="When the 'Is Override' option is unchecked, only the headers that do not have a PwC Header assigned will be replaced by the header map settings of the referenced Deal. When checked, all the headers will be replaced by the header map settings of the referenced Deal." />
                </div>
            </Spin>
        </Modal>
    )
}

export default CopyHeaderMapFromOtherDealModal
