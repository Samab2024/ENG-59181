import { css } from '@emotion/react';
import createStyle from '@/hooks/createStyle';
const useStyle = createStyle(token => css`
    span.select-deal{
        margin-right: 25px;
        div.ant-select {
            width: 300px;
        }
    }

    div.is-override{
        margin-top: 10px;
    }
`)

export default useStyle