
import { ICellRendererParams } from 'ag-grid-community';
import { FICalculator } from 'functional-icons/lib/Outline';
import { useContext, useState } from 'react';
import CodeEditModal from './CodeEditModal';
import notification from '@/utils/notification';
import { HeaderMapContext } from './HeaderMapPage';

const CodeCellRender = (props: ICellRendererParams<API.IHeaderMap>) => {
    const formula = props.value

    const { context } = props
    const [modalOpen, setModalOpen] = useState(false)
    const [items, setItems] = useState<API.IHeaderMap[]>([])
    const { dealCalcFields } = useContext(HeaderMapContext)

    return (
        <>
            <div className="ag-formula-cell-render" onClick={(e) => {
                e.stopPropagation()
                if (context?.getChangedValues().length) {
                    notification.error("Please save before edit formula.")
                } else {
                    const result = []
                    props.api.forEachNode(x => {
                        if (x.data.calculatorHeader) {
                            result.push(x.data)
                        }
                    })
                    setItems(result)
                    setModalOpen(true)
                }
            }}>
                <FICalculator className="icon" />
            </div>
            <CodeEditModal
                headerMap={props.data}
                headerMapItems={items}
                dealFields={dealCalcFields || []}
                open={modalOpen}
                value={formula}
                onCancel={() => setModalOpen(false)}
                onSave={(value) => {
                    setModalOpen(false)
                    props.node.setDataValue(props.colDef.field, value)
                }}
            />
        </>

    )
}

export default CodeCellRender