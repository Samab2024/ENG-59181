import Grid from "@/components/Grid";
import dateCellEditor, { IDateCellEditorProps } from "@/components/Grid/dateCellEditor";
import numericCellEditor, { INumericCellEditorProps } from "@/components/Grid/numericCellEditor";
import selectCellEditor, { ISelectCellEditorProps, suppressSelectKeyboardEvent } from "@/components/Grid/selectCellEditor";
import SelectCellRender, { ISelectCellRenderProps } from "@/components/Grid/selectCellRender";
import TextCellEditor, { ITextCellEditorProps } from "@/components/Grid/TextCellEditor";
import { FormatTypeEnum } from "@/constants";
import CalculatorAPI from "@/services/api/CalculatorAPI";
import { FORMATS } from "@/utils/dateHelper";
import notification from "@/utils/notification";
import { CellEditorSelectorFunc, CellValueChangedEvent, ColDef, ICellEditorParams, ICellRendererParams, ITextCellEditorParams, KeyCode, SuppressKeyboardEventParams, ValueParserParams, ValueSetterParams } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { Button, Checkbox, Col, Modal, Row, Spin } from "antd";
import { FIDelete, FIPlus } from "functional-icons/lib/Outline";
import { FC, useCallback, useContext, useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import ReviewValueRender from "../DealLoanPage/ReviewValueRender";
import { HeaderMapContext } from "./HeaderMapPage";
import EditableCellRender from "@/components/Grid/editableCellRender";
import { NotAvailable } from "@/utils/numberHelper";
import { HookAPI } from "antd/es/modal/useModal";

type IRowData = API.ICalculatorGlobalField & {
    dataFormatType?: string
    dataFormatCode?: string
}

const regexPattern = /^[a-zA-Z_][a-zA-Z0-9_]*$/;

const valueCellEditorSelector: CellEditorSelectorFunc<IRowData, ICellEditorParams> = ({ data, colDef }) => {
    if (data.dataFormatType === FormatTypeEnum.IsDateTime) {
        return {
            component: dateCellEditor,
            params: { format: [data.dataFormatCode, FORMATS.L, FORMATS.JSONDate] } as IDateCellEditorProps
        }
    } else if (data.dataFormatType === FormatTypeEnum.IsNumeric) {
        // "0.00" => ".00" => fixed=2; "0" => null
        const fixed = /\.0+/.exec(data.dataFormatCode)
        return {
            component: numericCellEditor,
            params: {
                fixed: fixed && (fixed[0].length - 1) || 0,
                isPercentage: data.dataFormatCode.includes('%'),
                isNegativeAllowed: true,
                maxLength: 200,
            } as INumericCellEditorProps
        }
    } else {
        return {
            component: TextCellEditor,
            popup: true,
            params: {
                maxLength: 200
            } as ITextCellEditorProps
        }
    }
}

const suppressKeyboardEvent = (params: SuppressKeyboardEventParams<IRowData>) => {
    // return true (to suppress) if editing and user hit up/down keys
    const key = params.event.key
    const gridShouldDoNothing = [FormatTypeEnum.IsDateTime].includes(params.data.dataFormatType as FormatTypeEnum) && params.editing && (key === KeyCode.ENTER)
    return gridShouldDoNothing
}

const createColumnDefs = ({ dataFormats, modal }: {
    dataFormats: API.IDataFormat[],
    modal: HookAPI
}): ColDef[] => [
        {
            colId: 'displayOrder',
            field: "displayOrder",
            headerName: 'Order',
            width: 80,
            editable: true,
            rowDrag: true
        },
        {
            colId: 'field',
            field: "fieldName",
            headerName: 'Field Name',
            editable: true,
            cellRenderer: EditableCellRender,
            cellEditorParams: { maxLength: 200 } as ITextCellEditorParams,
            valueSetter: ({ newValue, node }) => {
                if (!newValue || regexPattern.test(newValue)) {
                    node.data.fieldName = newValue
                    return true
                } else {
                    notification.error("The Field Name is invalid.")
                    return false
                }
            },
        },
        {
            colId: "dataFormatId",
            field: "dataFormatId",
            headerName: 'Format',
            editable: true,
            width: 150,
            cellRenderer: SelectCellRender,
            cellRendererParams: {
                options: dataFormats?.map(x => ({
                    value: x.dataFormatId,
                    label: x.name
                })) || []
            } as ISelectCellRenderProps,
            cellEditor: selectCellEditor,
            cellEditorParams: {
                options: dataFormats?.map(x => ({
                    value: x.dataFormatId,
                    label: x.name
                })),
                allowClear: false
            } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
        },
        {
            colId: 'value',
            field: "fieldValue",
            headerName: 'Field Value',
            editable: true,
            cellRenderer: ReviewValueRender,
            cellEditorSelector: valueCellEditorSelector,
            cellDataType: false,
            suppressKeyboardEvent,
            valueParser: ({ newValue }: ValueParserParams<IRowData>) => newValue && newValue !== NotAvailable ? ('' + newValue) : newValue
        },
        {
            colId: 'active',
            width: 50,
            headerName: 'Active',
            suppressAutoSize: true,
            cellClass: 'ag-center-aligned-cell',
            cellRenderer: ({ api, node, column, data }: ICellRendererParams<IRowData>) => <Button type="text" icon={<FIDelete />} title="Delete" onClick={() => modal.confirm({
                title: 'Are you sure to delete this item?',
                onOk: () => {
                    const updatedRows: IRowData[] = []
                    api.forEachNode(node => {
                        if (node.data.calculatorGlobalFieldId !== data.calculatorGlobalFieldId) {
                            updatedRows.push(node.data)
                        }
                    })
                    updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                    api.applyTransaction({ remove: [data], update: updatedRows })
                }
            })} />
        }
    ]

export const GlobalFieldsModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {

    const [modal, modalContext] = Modal.useModal()
    const gridRef = useRef<AgGridReact<IRowData>>()
    const { id } = useParams()
    const dealId = Number(id)
    const [loading, setLoading] = useState(false);
    const [rowData, setRowData] = useState<IRowData[]>([])

    const [columnDefs, setColumnDefs] = useState<ColDef<IRowData>[]>()
    const { dataFormats } = useContext(HeaderMapContext)

    const handleSave = () => {
        const data: API.ICalculatorGlobalField[] = []
        gridRef.current?.api.forEachNode(node => {
            data.push({
                ...node.data,
                calculatorGlobalFieldId: node.data.calculatorGlobalFieldId < 0 ? 0 : node.data.calculatorGlobalFieldId,
            })
        })

        //do some validation
        if (data.some(x => !x.fieldName)) {
            notification.error("Please input field name.")
            return
        }
        if (data.some(x => !x.dataFormatId)) {
            notification.error("Please select format.")
            return
        }
        if (data.some(x => !x.fieldValue)) {
            notification.error("Please input value.")
            return
        }

        if ([...new Set(data.map(x => x.fieldName))].length !== data.length) {
            notification.error("Field name should not duplicate.")
            return
        }

        setLoading(true)
        CalculatorAPI.updateCalculatorGlobalField(dealId, data)
            .then(() => {
                notification.success('Saved.')
                onClose()
            })
            .catch(ex => {
                notification.error((ex as API.IException).message)
            })
            .finally(() => setLoading(false))
    }

    const handleCellValueChanged = useCallback(({ node, colDef }: CellValueChangedEvent<IRowData>) => {
        if (colDef.field === 'dataFormatId') {
            node.setData({
                ...node.data,
                fieldValue: '',
                dataFormatCode: dataFormats.find(x => x.dataFormatId === node.data.dataFormatId).code,
                dataFormatType: dataFormats.find(x => x.dataFormatId === node.data.dataFormatId).type
            })
        }
    }, [dataFormats])

    useEffect(() => {
        if (open) {
            setLoading(true)
            CalculatorAPI.getCalculatorGlobalField(dealId)
                .then(data => {
                    setRowData(data.map<IRowData>(x => ({
                        ...x,
                        dataFormatCode: dataFormats.find(f => f.dataFormatId === x.dataFormatId).code,
                        dataFormatType: dataFormats.find(f => f.dataFormatId === x.dataFormatId).type,
                    })))
                    setColumnDefs(createColumnDefs({ dataFormats, modal }))
                })
                .catch(ex => {
                    notification.error((ex as API.IException).message)
                })
                .finally(() => setLoading(false))
        }
    }, [open])

    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Calculator Global Fields"
            width={800}
            destroyOnClose={true}
            footer={<div>
                <Button onClick={onClose}>Cancel</Button>
                <Button type="primary" onClick={handleSave}>SAVE</Button>
            </div>}>
            <Spin spinning={loading}>
                <Row justify="end">
                    <Col>
                        <Button type="link" icon={<FIPlus />} onClick={() => {
                            const displayOrders: number[] = []
                            const ids: number[] = []
                            gridRef.current?.api.forEachNode(node => {
                                displayOrders.push(node.data.displayOrder)
                                if (node.data.calculatorGlobalFieldId < 0) {
                                    ids.push(node.data.calculatorGlobalFieldId)
                                }
                            })
                            gridRef.current?.api.applyTransaction({
                                add: [{
                                    calculatorGlobalFieldId: (ids.length > 0 ? Math.min(...ids) : 0) - 1,
                                    displayOrder: (displayOrders.length > 0 ? Math.max(...displayOrders) : 0) + 1,
                                    dealId,
                                    isActive: true,
                                } as IRowData]
                            })
                        }}>Add new</Button>
                    </Col>
                </Row>
                <Grid<IRowData>
                    ref={gridRef}
                    rowData={rowData}
                    rowDragManaged={true}
                    onRowDragEnd={({ api }) => api.forEachNode((node, index) => node.setData({ ...node.data, displayOrder: index + 1 }))}
                    animateRows={true}
                    onGridReady={({ api }) => api.sizeColumnsToFit()}
                    getRowId={({ data }) => data.calculatorGlobalFieldId + ''}
                    onCellValueChanged={handleCellValueChanged}
                    columnDefs={columnDefs}
                />
            </Spin>
            {modalContext}
        </Modal>
    )
}

export default GlobalFieldsModal