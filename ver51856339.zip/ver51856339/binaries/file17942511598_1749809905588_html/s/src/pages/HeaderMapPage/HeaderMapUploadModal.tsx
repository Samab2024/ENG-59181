import HeaderMapAPI from "@/services/api/HeaderMapAPI"
import ImportAPI from "@/services/api/ImportAPI"
import nameOfData from "@/utils/nameOfData"
import notification from "@/utils/notification"
import { Button, Flex, Form, Input, Modal, Select, Spin, Upload, UploadFile, Result } from "antd"
import { FIDocumentAlert } from "functional-icons/lib/Outline"
import { FC, ReactNode, useState } from "react"
import { useParams } from "react-router-dom"

interface IUploadForm {
    sheetName: string,
    files: UploadFile[],
    sellerId: number
    levelOfReview: number
}

enum UploadStage {
    Input,
    Loading,
    Result
}

const HeaderMapUploadModal: FC<{
    open: boolean
    onClose?: () => void
}> = ({ open, onClose }) => {
    const [stage, setStage] = useState<UploadStage>(UploadStage.Input)
    const [form] = Form.useForm<IUploadForm>()
    const [sheetNames, setSheetNames] = useState<string[]>()
    const [fileName, setFileName] = useState<string>()
    const [url, setURL] = useState('')

    const { id } = useParams()
    const dealId = Number(id)

    const handleCancel = () => {
        form.resetFields();
        setSheetNames([]);
        setFileName("");
        setURL('')
        setStage(UploadStage.Input)
        onClose();
    }

    const handleLoadSheetNames = () => {
        form.validateFields()
            .then(value => {
                setStage(UploadStage.Loading);
                ImportAPI.loadSheets(value.files[0].originFileObj)
                    .then(x => {
                        setSheetNames(x);
                    })
                    .catch(e => notification.error((e as API.IException).message))
                    .finally(() =>
                        setStage(UploadStage.Input)
                    );
            })
            .catch((errorInfo) => {
                console.log('Validation error:', errorInfo);
            });
    }

    const handleImportLoanData = () => {
        form.validateFields()
            .then(value => {
                setStage(UploadStage.Loading);
                HeaderMapAPI.importHeaderMap({
                    dealId,
                    sheetName: value.sheetName,
                }, value.files[0].originFileObj)
                    .then(res => {
                        if (res.statusMsg) {
                            notification.success(res.statusMsg)
                            setStage(UploadStage.Input)
                            handleCancel()

                        } else {
                            setURL(res.exceptionFile)
                            setStage(UploadStage.Result)
                        }
                    })
                    .catch(e => {
                        setStage(UploadStage.Input)
                        notification.error((e as API.IException).message, { duration: 5 })
                    })
            }).catch((errorInfo) => {
                console.log('Validation error:', errorInfo);
            });
    }

    const handleDownload = () => {
        HeaderMapAPI.downloadHeaderMapException({ fileName: url })
    }

    const normFile = (e: any) => {
        form.setFieldValue(nameOfData<IUploadForm>("sheetName"), null)
        setSheetNames([]);

        setFileName(e.fileList[0].name)
        if (Array.isArray(e)) {
            return e;
        }
        return e && e.fileList;
    }

    let footer: ReactNode = null
    if (stage === UploadStage.Input) {
        footer = (
            <Flex justify="flex-end">
                <div>
                    <Button onClick={handleCancel}>Cancel</Button>
                    <Button type="primary" disabled={!(sheetNames && sheetNames.length > 0)} onClick={() => handleImportLoanData()}>Import</Button>
                </div>
            </Flex>
        )
    }

    return (
        <Modal
            open={open}
            title={"Import Header Map"}
            maskClosable={false}
            onCancel={handleCancel}
            footer={footer}>
            {stage === UploadStage.Input && (
                <Form layout="horizontal" labelCol={{ span: 6 }} wrapperCol={{ span: 18 }} form={form}>

                    <Form.Item label="Upload File">
                        <Flex gap="small">
                            <Input placeholder='.xlsx file' value={fileName} disabled />
                            <Form.Item rules={[{ required: true, message: 'Please select a file' }]} valuePropName="fileList" name={nameOfData<IUploadForm>("files")} getValueFromEvent={normFile} noStyle >
                                <Upload onChange={handleLoadSheetNames} showUploadList={false} accept='.xlsx' beforeUpload={() => false} multiple={false} maxCount={1}>
                                    <Button>BROWSE</Button>
                                </Upload>
                            </Form.Item>
                        </Flex>
                    </Form.Item>

                    <Form.Item
                        label="Sheet"
                        rules={[{ required: !(sheetNames === undefined || sheetNames.length === 0), message: 'Please select one sheet' }]}
                        name={nameOfData<IUploadForm>("sheetName")}
                    >
                        <Select disabled={sheetNames === undefined || sheetNames.length === 0} options={sheetNames?.map(x => ({ value: x, label: x }))} />
                    </Form.Item>

                </Form>
            )}

            {stage === UploadStage.Loading && <Spin spinning={true} tip={sheetNames && sheetNames.length > 0 ? "Uploading..." : "Loading Sheets..."} ><div style={{ height: '140px' }}></div></Spin>}

            {stage === UploadStage.Result && (
                <Result
                    status="success"
                    title="Import partially complete."
                    subTitle="Please download the log file for more detailed information."
                    extra={<Button type="link" key="download" onClick={handleDownload} icon={<FIDocumentAlert />}>
                        Download Log
                    </Button>}
                />
            )}

        </Modal>
    )
}

export default HeaderMapUploadModal