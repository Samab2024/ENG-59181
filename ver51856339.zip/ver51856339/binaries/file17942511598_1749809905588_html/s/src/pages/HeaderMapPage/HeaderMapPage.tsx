import IconButton from "@/components/IconButton";
import Wrapper, { HeadRow } from "@/components/Wrapper";
import HeaderMapAPI from "@/services/api/HeaderMapAPI";
import { Button, Dropdown, Space, Spin, Tooltip } from "antd";
import { FIArrowLeft, FIDownloadBox, FIMenu } from "functional-icons/lib/Outline";
import { FC, useEffect, useState, useCallback, createContext, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import HeaderMapTable, { IHeaderMapTableComp } from "./HeaderMapTableAG";
import SourceDocSectionModal from "./SourceDocSectionModal";
import SourceModal from "./SourceModal";
import CopyHeaderMapFromOtherDealModal from "./CopyHeaderMapFromOtherDealModal";
import notification from '@/utils/notification';
import modal from '@/utils/modal'
import HeaderMapFormPage from "../HeaderMapFormPage"
import DropdownCategoryModal from "./DropdownCategoryModal";
import GlobalFieldsModal from "./GlobalFieldsModal";
import HeaderMapUploadModal from "./HeaderMapUploadModal";
import CalculatorAPI from "@/services/api/CalculatorAPI";
import { PROCESS_TYPES } from "@/constants";

export const HeaderMapContext = createContext<{
    headerMaps: API.IHeaderMap[] | null;
    sourceDocSections: API.ISourceDocSection[] | null;
    sources: API.ISource[] | null;
    dataFormats: API.IDataFormat[] | null;
    dropdownCategories: API.IDropdownCategory[]
    dealCalcFields: string[]
    processTypes: string[] | null;
    isEditable: boolean;
    levelOfReviews: number[] | null;
    getHeaderMapById: () => void;
    getSourceDocSection: () => void;
}>({
    headerMaps: null,
    sourceDocSections: null,
    sources: null,
    dataFormats: null,
    dropdownCategories: null,
    dealCalcFields: null,
    processTypes: null,
    isEditable: false,
    levelOfReviews: null,
    getHeaderMapById: () => { },
    getSourceDocSection: () => { },
});

const HeaderMapPage: FC = () => {
    const navigate = useNavigate()
    const { id } = useParams()
    const dealId = Number(id)

    const [dealHeaderMap, setDealHeaderMap] = useState<API.IDealHeaderMap>()
    const [headerMaps, setHeaderMaps] = useState<API.IHeaderMap[]>()
    const [sourceDocSections, setSourceDocSections] = useState<API.ISourceDocSection[]>()
    const [sources, setSources] = useState<API.ISource[]>()
    const [dataFormats, setDataFormats] = useState<API.IDataFormat[]>()
    const [dropdownCategories, setDropdownCategories] = useState<API.IDropdownCategory[]>()
    const [dealCalcFields, setDealCalcFields] = useState<string[]>()
    const [processTypes, setProcessTypes] = useState<string[]>()
    const [modalOpen, setModalOpen] = useState(false)
    const [modalSourceOpen, setModalSourceOpen] = useState(false)
    const [loading, setLoading] = useState(false)
    const [copyDealModalOpen, setCopyDealModalOpen] = useState(false)
    const headerTableRef = useRef<IHeaderMapTableComp>()
    const [addHeaderModalOpen, setAddHeaderModalOpen] = useState(false)
    const [modalDropdownOpen, setModalDropdownOpen] = useState(false)
    const [globalFieldModalOpen, setGlobalFieldModalOpen] = useState(false)
    const [isEditable, setIsEditable] = useState(false)
    const [levelOfReviews, setLevelOfReviews] = useState<number[]>()
    const [importModalOpen, setImportModalOpen] = useState(false)

    const [downloadHeaderMap] = useDownloadHeaderMap()

    useEffect(() => {
        refreshData()
    }, [])

    const refreshData = () => {
        setLoading(true);
        Promise.all([
            getHeaderMapById(),
            getSourceDocSection(),
            getSources(),
            getDataFormats(),
            getProcessTypes(),
            getDropdownCategories(),
            getDealCalcFields(),
        ]).then(() => { setLoading(false); })
    }

    const refreshHeaderMap = () => {
        setLoading(true)
        getHeaderMapById().finally(() => setLoading(false))
    }

    const getHeaderMapById = () => {
        return HeaderMapAPI.getHeaderMapsById(dealId)
            .then((dealHeaderMap) => {
                setDealHeaderMap(dealHeaderMap);
                setHeaderMaps(dealHeaderMap.headerMap);
                setIsEditable(dealHeaderMap?.isEditable);
                const levels = Array.from({ length: dealHeaderMap.levelOfReview }, (_, index) => index + 1);
                setLevelOfReviews(levels);
            })
    }

    const getSourceDocSection = useCallback(() => {
        return HeaderMapAPI.getSourceDocSections(dealId)
            .then((sourceDocSections) => {
                setSourceDocSections(sourceDocSections);
            })
    }, []);

    const getSources = useCallback(() => {
        return HeaderMapAPI.getSources(dealId)
            .then((sources) => {
                setSources(sources);
            })
    }, []);

    const getDataFormats = useCallback(() => {
        return HeaderMapAPI.getDataFormats()
            .then((dataFormats) => {
                setDataFormats(dataFormats);
            })
    }, []);

    const getDropdownCategories = useCallback(() => {
        return HeaderMapAPI.getDropdownCategory(dealId)
            .then((data) => {
                setDropdownCategories(data);
            })
    }, []);

    const getProcessTypes = useCallback(() => {
        return HeaderMapAPI.getProcessTypes()
            .then((processTypes) => {
                setProcessTypes(processTypes);
            })
    }, []);

    const getDealCalcFields = useCallback(() => {
        return CalculatorAPI.getCalculatorGlobalField(dealId)
            .then(data => {
                setDealCalcFields(data.map(x => x.fieldName))
            })
    }, [])

    const handleSaveHeaderMap = () => {
        //updatedData.map(data => { [...headerMaps, data] })
        const updatedData = headerTableRef.current.getChangedValues()

        //validate data
        if (updatedData.find(x => x.processType === PROCESS_TYPES.Calculation && !x.calculatorHeader)) {
            notification.error('Calculator Header is required if select "Calculation" as process type.')
            return
        }

        setLoading(true);
        HeaderMapAPI.updateDealHeaderMap(dealId, updatedData)
            .then(() => {
                setLoading(false);
                getHeaderMapById();
                notification.success("Saved header map successfully.");
            })
            .catch(e => notification.error(e.message))
            .finally(() => setLoading(false))
    }

    const handleRevert = () => {
        modal.confirm({
            title: 'Warning',
            content: `Are you sure you want to revert all the contents?`,
            okText: 'CONFIRM',
            cancelText: 'CANCEL',
            onOk: () => {
                setHeaderMaps([]);
                refreshData();
            }
        })
    }

    const handleCloseSourceDocSectionModal = () => {
        getSourceDocSection();
        setModalOpen(false);
    }
    const handleCloseSourceModal = () => {
        getSources();
        setModalSourceOpen(false);
    }

    const navigateBack = () => {
        const updatedData = headerTableRef.current.getChangedValues()
        if (updatedData.length > 0) {
            modal.confirm({
                title: 'Warning',
                content: `Are you sure you want to navigate back without saving changes?`,
                okText: 'CONFIRM',
                cancelText: 'CANCEL',
                onOk: () => {
                    navigate(`/${id}`);
                }
            })
        }
        else {
            navigate(`/${id}`);
        }
    }

    return (
        <HeaderMapContext.Provider value={{
            headerMaps,
            sourceDocSections,
            sources,
            dataFormats,
            dealCalcFields,
            processTypes,
            isEditable,
            levelOfReviews,
            getSourceDocSection,
            getHeaderMapById,
            dropdownCategories
        }}>
            <Wrapper.PageContainer>
                <HeadRow
                    icon={<IconButton icon={FIArrowLeft} onClick={navigateBack} />}
                    title={dealHeaderMap && `Header Map - ${dealHeaderMap?.dealName}`}
                >
                    {dealHeaderMap?.isEditable ?
                        <Space>
                            <Dropdown placement="bottomRight" menu={{
                                items: [{
                                    label: 'Source Doc Section',
                                    key: 'Source Doc Section'
                                }, {
                                    label: 'Source',
                                    key: 'Source'
                                }, {
                                    label: 'Lookup Management',
                                    key: 'Lookup Management'
                                }, {
                                    label: 'Calculator Global Fields',
                                    key: 'Calculator Global Fields'
                                }, {
                                    label: 'Copy Header Map',
                                    key: 'Copy Header Map'
                                }, {
                                    label: 'Import Header Map',
                                    key: 'Import Header Map'
                                }, {
                                    label: 'Download Header Map',
                                    key: 'Download Header Map'
                                }],
                                onClick: ({ key }) => {
                                    switch (key) {
                                        case 'Source Doc Section':
                                            setModalOpen(true)
                                            break;

                                        case 'Source':
                                            setModalSourceOpen(true)
                                            break;

                                        case 'Lookup Management':
                                            setModalDropdownOpen(true)
                                            break;

                                        case 'Calculator Global Fields':
                                            setGlobalFieldModalOpen(true)
                                            break;

                                        case 'Copy Header Map':
                                            setCopyDealModalOpen(true)
                                            break;

                                        case 'Import Header Map':
                                            setImportModalOpen(true)
                                            break;

                                        case 'Download Header Map':
                                            downloadHeaderMap()
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }}>
                                <Button type="text" icon={<FIMenu />} />
                            </Dropdown>
                            <Button type="link" onClick={() => setAddHeaderModalOpen(true)}>Add New</Button>
                            {/* <Tooltip title="Source Doc Section" >
                                <Button type="text" icon={<BookOutlined />} onClick={() => setModalOpen(true)} />
                            </Tooltip>
                            <Tooltip title="Source">
                                <Button type="text" icon={<ContainerOutlined />} onClick={() => setModalSourceOpen(true)} />
                            </Tooltip>
                            <Tooltip title="Lookup Management">
                                <Button type="text" icon={<FIDocumentFile />} onClick={() => setModalDropdownOpen(true)} />
                            </Tooltip>
                            <Tooltip title="Copy Header Map" >
                                <Button type="text" icon={<CopyOutlined />} onClick={() => setCopyDealModalOpen(true)} />
                            </Tooltip>
                            <DownloadHeaderMap /> */}

                            <Button onClick={handleRevert}>Revert</Button>
                            <Button type="primary" onClick={handleSaveHeaderMap}>Save</Button>
                        </Space> :
                        <Space>
                            <DownloadHeaderMap />
                        </Space>
                    }
                </HeadRow>
                <Spin spinning={loading}>
                    <HeaderMapTable ref={headerTableRef} />
                </Spin>
                <SourceDocSectionModal open={modalOpen} onClose={handleCloseSourceDocSectionModal} />
                <SourceModal open={modalSourceOpen} onClose={handleCloseSourceModal} />
                <CopyHeaderMapFromOtherDealModal open={copyDealModalOpen} onCloes={() => {
                    getSourceDocSection();
                    getSources()
                    getDropdownCategories()
                    setCopyDealModalOpen(false)
                }} />
                <HeaderMapFormPage open={addHeaderModalOpen} onClose={() => setAddHeaderModalOpen(false)} />
                <DropdownCategoryModal open={modalDropdownOpen} onClose={() => {
                    getDropdownCategories()
                    setModalDropdownOpen(false)
                }} />
                <GlobalFieldsModal open={globalFieldModalOpen} onClose={() => {
                    setGlobalFieldModalOpen(false)
                    getDealCalcFields()
                    refreshHeaderMap()
                }} />
                <HeaderMapUploadModal open={importModalOpen} onClose={() => {
                    setImportModalOpen(false)
                    refreshHeaderMap()
                }} />
            </Wrapper.PageContainer>
        </HeaderMapContext.Provider>
    )
}

const useDownloadHeaderMap = (): [() => void, boolean] => {
    const [loading, setLoading] = useState(false)
    const { id } = useParams()
    const download = () => {
        setLoading(true)
        HeaderMapAPI.downloadHeaderMap(Number(id))
            .catch(ex => notification.error(ex.message))
            .finally(() => setLoading(false))
    }
    return [download, loading]
}

const DownloadHeaderMap = () => {
    const [download, loading] = useDownloadHeaderMap()
    return (
        <Tooltip title="Download Header Map" >
            <Button type="text" icon={<FIDownloadBox />} onClick={download} loading={loading} />
        </Tooltip>
    )
}
export default HeaderMapPage