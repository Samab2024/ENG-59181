import nameOfData from "@/utils/nameOfData";
import { useParams } from "react-router-dom";
import { Table, Select, Input, Upload, Tooltip } from "antd";
import { FC, useEffect, useState, useContext, } from "react";
import * as controlStyles from '@/styles/control.module.css'
import { CloudUploadOutlined, CloudDownloadOutlined } from '@ant-design/icons';
import useStyle from "../DealLoanPage/style";
import { HeaderMapContext } from "./HeaderMapPage";
import HeaderMapAPI from "@/services/api/HeaderMapAPI";
import notification from '@/utils/notification';
import { isNullOrEmpty } from "@/utils/stringHelper";


const HeaderMapTable: FC<{
    updateDealHeaderMap: (headerMaps: API.IHeaderMap[]) => void;
}> = ({ updateDealHeaderMap }) => {
    const { id } = useParams()
    const [data, setData] = useState<API.IHeaderMap[]>([])
    const [formats, setFormats] = useState([])
    const [sourceDocSection, setSourceDocSection] = useState([])
    const { displayArea, inputArea, selectArea } = useStyle()
    const { headerMaps, sourceDocSections, sources, dataFormats, processTypes } = useContext(HeaderMapContext);

    let updatedData: Array<API.IHeaderMap> = [];

    useEffect(() => {

        setData(headerMaps)

        setSourceDocSection(sourceDocSections != undefined && sourceDocSections.map(x => ({
            value: x.sourceDocSectionId,
            label: x.name
        })))

        setFormats(dataFormats != undefined && dataFormats.map(x => ({
            value: x.dataFormatId,
            label: x.name
        })))
    }, [headerMaps, sourceDocSections, dataFormats])

    const handleTableChange = (value: any, rowData: API.IHeaderMap, propsName: string) => {
        rowData[propsName] = value;
        // setData([...data, rowData])
        // updateDealHeaderMap(data);

        if (updatedData.find(d => d.headerMapId === rowData.headerMapId) !== undefined) {
            [...updatedData, rowData]
        }
        else {
            updatedData = [...updatedData, rowData]
        }

        updateDealHeaderMap(updatedData);

    }

    const handleUploadScreenShot = (info) => {
        HeaderMapAPI.uploadScreenShot(Number(id), info.file)
            .then(() => { notification.success("Upload screen shot successfully."); })
            .catch(e => notification.error((e as API.IException).message))

    }

    return (
        <Table<API.IHeaderMap> rowKey="HeaderID" pagination={false} bordered={false} dataSource={data} scroll={{ y: 'calc(100vh - 180px)' }} columns={[
            {
                dataIndex: nameOfData<API.IHeaderMap>("clientHeader"),
                title: 'Client Header',
                render: v => <div css={displayArea}>{v}</div>
            },
            {
                dataIndex: nameOfData<API.IHeaderMap>("pwCHeader"),
                title: 'PwC Header',
                render: (v, r) => (
                    <Input.TextArea css={inputArea} bordered={false} placeholder="Type something" defaultValue={v} onChange={(e) => handleTableChange(e.target.value, r, "pwCHeader")} />
                )
            },
            {
                dataIndex: nameOfData<API.IHeaderMap>("processType"),
                title: 'Process Type',
                render: (v, r) => (
                    <Select css={selectArea} className={controlStyles.fullWidth} placeholder="Select..." bordered={false} defaultValue={v}
                        options={processTypes && processTypes.map(x => ({ value: x, label: x }))}
                        onChange={(v) => handleTableChange(v, r, "processType")} />
                )
            },
            {
                dataIndex: nameOfData<API.IHeaderMap>("sourceDocSectionId"),
                title: 'Source Doc Section',
                render: (v, r) => (
                    <Select css={selectArea} className={controlStyles.fullWidth} placeholder="Select..." bordered={false}
                        defaultValue={v} options={sourceDocSection}
                        onChange={(v) => handleTableChange(v, r, "sourceDocSectionId")} />
                )
            },
            {
                dataIndex: nameOfData<API.IHeaderMap>("sourceId"),
                title: 'Source',
                render: (v, r) => (
                    <Select css={selectArea} className={controlStyles.fullWidth} placeholder="Select..." bordered={false} defaultValue={v}
                        options={sources && sources.map(x => ({ value: x.sourceId, label: x.name }))}
                        onChange={(v) => handleTableChange(v, r, "sourceId")} />
                )
            },
            {
                dataIndex: nameOfData<API.IHeaderMap>("dataFormatId"),
                title: 'Format',
                render: (v, r) => (
                    <Select css={selectArea} className={controlStyles.fullWidth} placeholder="Select..." bordered={false} defaultValue={v} options={formats} onChange={(v) => handleTableChange(v, r, "dataFormatId")} />
                )
            },
            {
                dataIndex: nameOfData<API.IHeaderMap>("fieldGuide"),
                title: 'Field Guide',
                width: '20%',
                render: (v, r) => (
                    <Input.TextArea css={inputArea} bordered={false} placeholder="Type something" defaultValue={v} onChange={(e) => handleTableChange(e.target.value, r, "fieldGuide")} />
                )
            },
            {
                dataIndex: nameOfData<API.IHeaderMap>("screenShotId"),
                title: '',
                width: 50,
                render: v => (
                    <Upload onChange={handleUploadScreenShot}>
                        <Tooltip title="Add Screen Shot">
                                <CloudUploadOutlined />
                        </Tooltip>
                    </Upload>
                )
            },

        ]} />
    )
}

export default HeaderMapTable