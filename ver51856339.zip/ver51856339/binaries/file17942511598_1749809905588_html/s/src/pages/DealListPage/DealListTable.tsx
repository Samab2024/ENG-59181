import Grid, { getDefaultColumn } from "@/components/Grid";
import dropdownFilter, { DropdownFilterParams } from "@/components/Grid/dropdownFilter";
import { FORMATS } from "@/utils/dateHelper";
import modal from "@/utils/modal";
import { DeleteOutlined } from '@ant-design/icons';
import { ColDef, ICellRendererParams } from "ag-grid-community";
import { Space, Spin, Tooltip } from "antd";
import dayjs from "dayjs";
import { FIArchive, FIRevert } from "functional-icons/lib/Outline";
import _ from 'lodash';
import { FC, useContext, useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { DealListPageContext } from "./DealListPage";
import useGridStyle from './DealListTable.style';

type IRowData = API.IDealSetup

const defaultColumn = getDefaultColumn({
    resizable: true,
})

const DealListTable: FC<{
    onDealActionClick: (dealId: number, action: 'archive' | 'reactive' | 'remove' | 'delete') => void;
}> = ({ onDealActionClick }) => {
    const gridStyle = useGridStyle();

    const { dealList, loading, currentTab } = useContext(DealListPageContext);

    const handleDeleteDeal = (dealId: number, dealName: string) => {
        modal.confirm({
            title: 'Warning',
            content: `Are you sure you want to delete the deal "${dealName}"${currentTab == 'Deleted' ? ' permanently' : ''}?`,
            okText: 'CONFIRM',
            cancelText: 'CANCEL',
            onOk: () => {
                onDealActionClick(dealId, currentTab == 'Deleted' ? 'delete' : 'remove');
            }
        })
    }

    const handleArchiveDeal = (dealId: number, dealName: string) => {
        modal.confirm({
            title: 'Warning',
            content: `Are you sure you want to archive the deal "${dealName}"?`,
            okText: 'CONFIRM',
            cancelText: 'CANCEL',
            onOk: () => {
                onDealActionClick(dealId, 'archive');
            }
        })

    }

    const handleReactiveDeal = (dealId: number, dealName: string) => {
        modal.confirm({
            title: 'Warning',
            content: `Are you sure you want to reactive the deal "${dealName}"?`,
            okText: 'CONFIRM',
            cancelText: 'CANCEL',
            onOk: () => {
                onDealActionClick(dealId, 'reactive');
            }
        })

    }

    const [columnDefs, setColumnDefs] = useState<ColDef[]>([])

    const createColDefs = (): ColDef<IRowData>[] => {
        return [
            {
                colId: 'number',
                field: 'dealId',
                headerName: 'Deal ID',
                suppressSizeToFit: true,
                width: 70,
                sortable: true,
                resizable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((dealList?.map(x => ({
                        value: x.dealId,
                        label: x.dealId
                    }))), JSON.stringify).sort((a, b) => a.value - b.value),
                } as DropdownFilterParams,
            },
            {
                field: 'dealName',
                width: 200,
                suppressSizeToFit: true,
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((dealList?.map(x => ({
                        value: x.dealName,
                        label: x.dealName
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                cellRenderer: ({ data, value }: ICellRendererParams<IRowData>) => <NavLink to={`/${data.dealId}`}>{value}</NavLink>
            },
            {
                field: 'assetType',
                width: 100,
                suppressSizeToFit: true,
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((dealList?.map(x => ({
                        value: x.assetType,
                        label: x.assetType
                    }))), JSON.stringify),
                } as DropdownFilterParams,
            },
            {
                field: 'cutOffDate',
                width: 100,
                suppressSizeToFit: true,
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((dealList?.map(x => ({
                        value: x.cutOffDate,
                        label: x.cutOffDate && dayjs(x.cutOffDate).format(FORMATS.L)
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                cellRenderer: ({ data, value }: ICellRendererParams<IRowData>) => value && dayjs(value).format(FORMATS.L)
            },
            {
                field: 'levelOfReview',
                width: 120,
                suppressSizeToFit: true,
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((dealList?.map(x => ({
                        value: x.levelOfReview,
                        label: x.levelOfReview
                    }))), JSON.stringify).sort((a, b) => a.value - b.value),
                } as DropdownFilterParams,
            },
            {
                field: 'dealDesc',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((dealList?.map(x => ({
                        value: x.dealDesc,
                        label: x.dealDesc
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                cellRenderer: ({ value, data }: ICellRendererParams<IRowData>) => <Tooltip title={value}>{value}</Tooltip>
            },
            {
                field: 'dealAdmin',
                sortable: true,
                filter: dropdownFilter,
                filterParams: {
                    options: _.uniqBy((dealList?.map(x => ({
                        value: x.dealAdmin,
                        label: x.dealAdmin
                    }))), JSON.stringify),
                } as DropdownFilterParams,
                cellRenderer: ({ value, data }: ICellRendererParams<IRowData>) => <Tooltip title={value}>{value}</Tooltip>
            },
            {
                colId: 'action',
                //width: 30,
                maxWidth: 50,
                headerName: '',
                suppressAutoSize: true,
                cellClass: 'ag-right-aligned-cell',
                cellRenderer: ({ api, data }: ICellRendererParams<IRowData>) => (currentTab !== 'Active' || data.isEditable) && <Space size="small">
                    {currentTab == 'Active' && <FIArchive title="Archive" onClick={() => handleArchiveDeal(data.dealId, data.dealName)} />}
                    {currentTab != 'Active' && <FIRevert title="Reactive" onClick={() => handleReactiveDeal(data.dealId, data.dealName)} />}
                    <DeleteOutlined title="Delete" onClick={() => handleDeleteDeal(data.dealId, data.dealName)} />
                </Space>
            }
        ]
    }

    useEffect(() => {
        setColumnDefs(createColDefs)
    }, [dealList])

    return (
        <Spin spinning={loading}>
            <Grid<IRowData>
                css={gridStyle}
                height={dealList?.length === 0 ? '50vh' : `calc(100vh - 135px)`}
                rowData={dealList}
                defaultColDef={defaultColumn}
                columnDefs={columnDefs}
                getRowId={p => p.data.dealId + ''}
                onFirstDataRendered={({ api }) => {
                    //using timeout to avoid antd animation issue
                    setTimeout(() => {
                        api.sizeColumnsToFit()
                    });
                }}
                suppressMovableColumns={true}
            />
        </Spin>

    )
}

export default DealListTable