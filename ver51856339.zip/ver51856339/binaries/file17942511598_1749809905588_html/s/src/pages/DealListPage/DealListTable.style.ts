import createStyle from "@/hooks/createStyle"
import { css } from "@emotion/react"

const useStyle = createStyle(token => css`
    margin-top: 4px;

    .ag-header-row, .ag-header-viewport {
        /* background-color: #fbfbfb; */
    }

`)

export default useStyle