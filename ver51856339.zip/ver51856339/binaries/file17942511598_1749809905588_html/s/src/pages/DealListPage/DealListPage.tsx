import Wrapper, { HeadRow } from "@/components/Wrapper"
import { Button, Radio, Space } from "antd"
import { FC, useState, createContext, useEffect, useCallback } from "react"
import DealSetupFormPage from "../DealSetupFormPage"
import DealListTable from "./DealListTable"
import DealAPI from '@/services/api/DealAPI'
import notification from "@/utils/notification";
import { useAppSelector } from "@/hooks/reduxHook"
import { selectCurrentUser } from "@/redux/userSlice"
import FormatMangementModal from "@/components/Modal/FormatMangementModal"
import FileCompareModal from "@/components/Modal/FileCompareModal"
import { DealState } from "@/services/api/enums"
import createStyle from "@/hooks/createStyle"
import { css } from "@emotion/react"
import valueOfType from "@/utils/valueOfType"

export const DealListPageContext = createContext<{
    dealList: API.IDealSetup[] | [];
    loading: boolean;
    refreshDeals: () => void;
    currentTab: DealState
}>({
    dealList: [],
    loading: false,
    refreshDeals: () => { },
    currentTab: 'Active'
});

const DealListPage: FC = () => {
    const styles = useDealListPageStyle()
    const [open, setOpen] = useState(false)
    const [dealList, setDealList] = useState<API.IDealSetup[]>([]);
    const [loading, setLoading] = useState(false)
    const [formatModalOpen, setFormatModalOpen] = useState(false)
    const [fileCompareModalOpen, setFileCompareModalOpen] = useState(false)
    const currentUser = useAppSelector(selectCurrentUser)
    const [currentTab, setCurrentTab] = useState<DealState>('Active')

    useEffect(() => {
        refreshDeals();
    }, [])

    const refreshDeals = useCallback((tab = currentTab) => {
        setLoading(true);
        DealAPI.getAll(tab)
            .then((data) => {
                setDealList(data);
            })
            .finally(() => {
                setLoading(false);
            });
    }, [currentTab]);

    const handleDealAction = (dealId: number, action: 'archive' | 'reactive' | 'remove' | 'delete') => {
        setLoading(true);
        if (action == 'delete') {
            DealAPI.deleteDealById(dealId)
                .then(() => {
                    notification.success("Delete deal successfully.");
                    refreshDeals();
                }).catch(e => notification.error(e.message))
                .finally(() => { setLoading(false); });
        } else {
            const ac: DealState = action == 'archive' ? 'Archived' : action == 'reactive' ? 'Active' : 'Deleted'
            DealAPI.updateDealState(dealId, ac)
                .then(() => {
                    notification.success(`${ac.replace(/d$/, '')} deal successfully.`);
                    refreshDeals();
                }).catch(e => notification.error(e.message))
                .finally(() => { setLoading(false); });
        }
    }

    return (
        <DealListPageContext.Provider value={{
            dealList,
            refreshDeals,
            currentTab,
            loading
        }}>

            <Wrapper.PageContainer>
                <HeadRow
                    title="Deals"
                    expandContent={true}
                >
                    <div css={styles.header}>
                        <div>
                            <Radio.Group value={currentTab} onChange={e => (setCurrentTab(e.target.value), refreshDeals(e.target.value))} buttonStyle="outline">
                                <Radio.Button value={valueOfType<DealState>("Active")}>Active</Radio.Button>
                                <Radio.Button value={valueOfType<DealState>("Archived")}>Archive</Radio.Button>
                                {currentUser?.isAdmin && (
                                    <Radio.Button value={valueOfType<DealState>("Deleted")}>Recycle Bin</Radio.Button>
                                )}
                            </Radio.Group>
                        </div>
                        <Space>
                            {currentUser?.isAdmin && (
                                <Button onClick={() => setFormatModalOpen(true)} >Manage Format</Button>
                            )}
                            <Button onClick={() => setFileCompareModalOpen(true)} >Compare File</Button>
                            <Button type="primary" onClick={() => setOpen(true)}>Create new deal</Button>
                        </Space>
                    </div>
                </HeadRow>
                <DealListTable onDealActionClick={handleDealAction} />
                <DealSetupFormPage isNew={true} open={open} onClose={() => setOpen(false)} />
            </Wrapper.PageContainer >
            {currentUser?.isAdmin && (
                <FormatMangementModal open={formatModalOpen} onClose={() => setFormatModalOpen(false)} />
            )}
            <FileCompareModal open={fileCompareModalOpen} onClose={() => setFileCompareModalOpen(false)} />
        </DealListPageContext.Provider>
    )
}

const useDealListPageStyle = createStyle(() => ({
    header: css({
        display: 'flex',
        justifyContent: 'space-between',
        marginLeft: 8,
    }),
}))

export default DealListPage