import { isNullOrEmpty } from "@/utils/stringHelper";
import { CopyOutlined } from "@ant-design/icons";
import { Button, Collapse, Empty } from "antd";
import { FC, RefObject, createRef, useEffect, useState } from "react";
import ReviewDataGrid, { IDealLoanInputTableComp, InputColumnName } from "./ReviewDataGrid";
import { selectCurrentUser } from "@/redux/userSlice";
import { useAppSelector } from "@/hooks/reduxHook";
import modal from '@/utils/modal'

type SectionRefMap = { [key: number]: RefObject<IDealLoanInputTableComp> }

const DealLoanInputTable: FC<{
    isReadonly: boolean
    loanReview: API.ILoanReview
    reviewer: API.IReviewer
    onSectionValueCopy: (loanReviewSections: API.ILoanReviewSection) => void
    onReviewDataChange: (data: API.ILoanReviewCell) => void
}> = ({ loanReview, reviewer, onSectionValueCopy, onReviewDataChange, isReadonly }) => {
    const { isBlindReview, levelOfReview, reviewSection } = loanReview ?? {}
    const [gridRefs, setGridRefs] = useState<SectionRefMap>({})
    const currentUser = useAppSelector(selectCurrentUser);

    useEffect(() => {
        if (reviewSection && reviewSection) {
            setGridRefs(reviewSection.reduce<SectionRefMap>((p, c, i) => {
                p[c.sourceDocSectionId] = createRef<IDealLoanInputTableComp>()
                return p
            }, {}))
        }
    }, [reviewSection])

    const handleDuplicateValue = (e: any, section: API.ILoanReviewSection) => {
        e.stopPropagation();

        // Some tricky logic here, eg.
        // secondReviewValue => [thirdReviewValue]
        // firstReviewValue => [secondReviewValue, thirdReviewValue]
        // clientValue => [firstReviewValue, secondReviewValue, thirdReviewValue]
        const propNames: InputColumnName[] = []
        let originKey: InputColumnName
        let message = ''
        if (reviewer.reviewer3 === currentUser.email) {
            propNames.push('thirdReviewValue')
            originKey = 'secondReviewValue'
            message = '2nd review'
        }
        if (reviewer.reviewer2 === currentUser.email) {
            propNames.push('secondReviewValue')
            originKey = 'firstReviewValue'
            message = '1st review'
        }
        if (reviewer.reviewer1 === currentUser.email) {
            propNames.push('firstReviewValue')
            originKey = 'clientValue'
            message = 'client'
        }

        modal.confirm({
            title: 'Warning',
            content: `Are you sure you want to copy values from ${message} value?`,
            onOk: () => {

                gridRefs[section.sourceDocSectionId].current.copyValue(propNames, originKey)
                onSectionValueCopy({
                    ...section,
                    reviewData: gridRefs[section.sourceDocSectionId].current.getValues()
                })
            }
        })
    }

    if (reviewSection && reviewSection.length === 0) {
        return (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
        )
    }

    const isSectionAllowCopy = (section: API.ILoanReviewSection) => !isReadonly && section.isAllowCopy
        && (!isBlindReview || isBlindReview && [reviewer.reviewer2, reviewer.reviewer3].includes(currentUser.email))
        && !isNullOrEmpty(section.permission)
        && [reviewer.reviewer1, reviewer.reviewer2, reviewer.reviewer3].includes(currentUser.email)

    return reviewSection && (
        <Collapse bordered={false} defaultActiveKey={reviewSection.map((_, i) => i)} items={reviewSection.map((section, i) => ({
            key: i,
            label: <strong>{section.sourceDocSectionName}</strong>,
            extra: isSectionAllowCopy(section) && (
                <Button type="text" icon={<CopyOutlined />} onClick={(e) => handleDuplicateValue(e, section)} title="Duplicate values" />
            ),
            children: (
                <ReviewDataGrid
                    ref={gridRefs[section.sourceDocSectionId]}
                    isReadonly={isReadonly}
                    data={section.reviewData}
                    sectionId={section.sectionId}
                    levelOfReview={levelOfReview}
                    permission={section.permission}
                    isBlindReview={isBlindReview}
                    onChange={onReviewDataChange}
                />
            )
        }))} />
    )
}

export default DealLoanInputTable