import Grid, { getDefaultColumn } from "@/components/Grid";
import selectCellEditor, { ISelectCellEditorProps, suppressSelectKeyboardEvent } from "@/components/Grid/selectCellEditor";
import SelectCellRender, { ISelectCellRenderProps } from "@/components/Grid/selectCellRender";
import { ADMIN_PERMISSION, ReviewStatus, ReviewStatusEnum } from "@/constants";
import { useAppSelector } from '@/hooks/reduxHook';
import LoanAPI from '@/services/api/LoanAPI';
import ReviewerAPI from "@/services/api/ReviewerAPI";
import * as control from '@/styles/control.module.css';
import notification from '@/utils/notification';
import { css } from "@emotion/react";
import { CellValueChangedEvent, ColDef, ICellRendererParams } from "ag-grid-community";
import { Card, Input, Space } from "antd";
import { FC, useEffect, useState } from "react";
import { selectCurrentUser } from '../../redux/userSlice';
import useGridStyle from '../DealPage/grid.style';

type IRowData = API.IReviewer

const defaultColumn = getDefaultColumn({
    resizable: true,
})

const customStyle = css`
display:flex;
.ant-space-item:nth-child(2) {
    flex: 1;
}
`

const createColDefs = (levelOfReview: number, reviewers: API.UserInfo[], isReadonly: boolean): ColDef<IRowData>[] => {
    const reviewerOptions = reviewers.map(x => ({ value: x.email, label: x.email }))
    const statusOptions = ReviewStatus.map(x => ({ value: x, label: x }))
    return [
        {
            field: 'reviewer1',
            editable: !isReadonly,
            width: 200,
            cellEditor: selectCellEditor,
            cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            cellRenderer: SelectCellRender,
            cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
        },
        {
            field: 'reviewerStatus1',
            editable: !isReadonly,
            width: 200,
            cellEditor: selectCellEditor,
            cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
            cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
        },
        ...([
            {
                field: 'reviewer2',
                editable: ({ data }) => data.reviewerStatus1 !== ReviewStatusEnum.NotStarted && !isReadonly,
                width: 200,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: SelectCellRender,
                cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
            },
            {
                field: 'reviewerStatus2',
                editable: ({ data }) => data.reviewerStatus1 !== ReviewStatusEnum.NotStarted && !isReadonly,
                width: 200,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
            },
            {
                field: 'reviewer3',
                editable: ({ data }) => data.reviewerStatus2 !== ReviewStatusEnum.NotStarted && !isReadonly,
                width: 200,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: reviewerOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: SelectCellRender,
                cellRendererParams: { options: reviewerOptions } as ISelectCellRenderProps
            },
            {
                field: 'reviewerStatus3',
                editable: ({ data }) => data.reviewerStatus2 !== ReviewStatusEnum.NotStarted && !isReadonly,
                width: 200,
                cellEditor: selectCellEditor,
                cellEditorParams: { options: statusOptions } as ISelectCellEditorProps,
                suppressKeyboardEvent: suppressSelectKeyboardEvent,
                cellRenderer: ({ value }: ICellRendererParams<IRowData>) => <span className="ag-reviewer-status" title={value}>{value}</span>
            },
        ] as ColDef<IRowData>[]).slice(0, (levelOfReview - 1) * 2)
    ]
}

const LoanReviewerStatus: FC<{
    isReadonly: boolean
    loanReview: API.ILoanReview
    reviewer: API.IReviewer
    reviewerList: API.UserInfo[]
    onReviewerChange: (permission: string) => void
    onMissingDocChange: (value: string) => void
}> = ({ loanReview, reviewer, reviewerList, onReviewerChange: handleReviewerChange, onMissingDocChange: handleMissingDocChange, isReadonly }) => {
    const currentUser = useAppSelector(selectCurrentUser);

    const [columnDefs, setColumnDefs] = useState<ColDef<IRowData>[]>([])
    const [missingDoc, setMissingDoc] = useState<string>()

    const gridStyle = useGridStyle()

    useEffect(() => {
        if (reviewerList && loanReview) {
            setColumnDefs(createColDefs(loanReview.levelOfReview, reviewerList, isReadonly))
            setMissingDoc(loanReview.missingDoc)
        }
    }, [loanReview, reviewerList])

    //NOTICE: all logic here should reflect to LoanListTable, HeaderListTable, LoanReviewerStatus, HeaderReviewerStatus
    const handleTableChange = ({ value, colDef, node, oldValue }: CellValueChangedEvent<IRowData>) => {
        if (colDef.field.includes('Status')) {
            //Not allow to clear status
            if (!value) {
                node.setData({
                    ...node.data,
                    [colDef.field]: oldValue
                })
                return
            }
        } else {
            //Editing reviewer by default
            if (value && [1, 2, 3].find(x => colDef.field !== ('reviewer' + x) && node.data['reviewer' + x] === value)) {
                //Found duplicate reviewer
                node.setData({
                    ...node.data,
                    [colDef.field]: oldValue
                })
                return
            }
            const statusField = colDef.field.replace('reviewer', 'reviewerStatus')
            if (value && node.data[statusField] === ReviewStatusEnum.NotStarted) {
                node.setData({
                    ...node.data,
                    [statusField]: ReviewStatusEnum.InProgress
                })
            } else if (!value && node.data[statusField] !== ReviewStatusEnum.NotStarted) {
                node.setData({
                    ...node.data,
                    [statusField]: ReviewStatusEnum.NotStarted
                })
            }
        }

        ReviewerAPI.updateLoanReviewer({
            ...node.data, //using data from node will always be the newest
            [colDef.field]: value
        })
            .then(() => {
                if (loanReview.isDealAdmin) {
                    handleReviewerChange(ADMIN_PERMISSION)
                } else {
                    const permissions = [];
                    [...new Array(3)].forEach((_, level) => {
                        if (node.data['reviewer' + (level + 1)] === currentUser?.email &&
                            (level === 0 || node.data['reviewerStatus' + level] !== ReviewStatusEnum.NotStarted)) {
                            permissions.push(level + 1);
                        }
                    })
                    handleReviewerChange(permissions.join(', '))
                }
            })
            .catch(ex => notification.error(ex.message))

    }

    const handleMissingDecSave = () => {
        LoanAPI.updateLoan({
            loanId: loanReview.loanId,
            missingDoc
        })
            .then(() => handleMissingDocChange(missingDoc))
            .catch(ex => notification.error(ex.message))
    }

    return (
        <Card style={{ marginRight: 10, marginBottom: 6 }}>
            <Space direction="vertical" className={control.fullWidth}>
                <Grid<IRowData>
                    height="60px"
                    css={gridStyle}
                    rowData={reviewer ? [reviewer] : []}
                    defaultColDef={defaultColumn}
                    columnDefs={columnDefs}
                    getRowId={p => p.data.loanId + ''}
                    onCellValueChanged={handleTableChange}
                    suppressMovableColumns={true}
                    // onFirstDataRendered={({ api }) => {
                    //     //using timeout to avoid antd animation issue
                    //     setTimeout(() => {
                    //         api.sizeColumnsToFit()
                    //     });
                    // }}
                />

                <Space css={customStyle}>
                    <label>Missing Doc:</label>
                    <Input.TextArea maxLength={2000} value={missingDoc} onChange={e => setMissingDoc(e.target.value)} onBlur={handleMissingDecSave} disabled={isReadonly} />
                </Space>
            </Space>
        </Card>
    )
}

export default LoanReviewerStatus
