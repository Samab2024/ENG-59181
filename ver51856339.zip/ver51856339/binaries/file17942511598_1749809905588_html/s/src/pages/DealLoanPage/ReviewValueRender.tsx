import { NotAvailable } from "@/utils/numberHelper"
import { CopyOutlined } from "@ant-design/icons"
import { css } from "@emotion/react"
import { ICellRendererParams } from "ag-grid-community"
import { Button } from "antd"
import { IDataRow } from "./ReviewDataGrid"
import { getFormatedValue, isNullOrEmpty } from "@/utils/stringHelper"
import { FIChevronDown } from "functional-icons/lib/Outline"
import { useCallback, useEffect, useMemo } from "react"

type AllowCopyFn<T> = (props: { data: T }) => boolean
export interface IReviewValueRenderParams<T> {
    // allowCopy: boolean | AllowCopyFn<T>,
    // getCopyValue: (props: {
    //     data: T
    // }) => any
    dataFormatType?: string
    dataFormatCode?: string
}

const renderStyle = css`
    display: flex;
    justify-content: space-between;
    word-break: break-all;

    .value {
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .action {
        display :none;
    }
    &:hover .action {
        display: block
    }
    &:hover .action + .arrow {
        display: none;
    }
`

const ReviewValueRender = ({ value, data, column, node, colDef, api, dataFormatCode, dataFormatType }: ICellRendererParams<IDataRow> & IReviewValueRenderParams<IDataRow>) => {
    const editable = column.isCellEditable(node)

    const formatedValue = useMemo(() => getFormatedValue(value, dataFormatType || data.dataFormatType, dataFormatCode || data.dataFormatCode), [value])

    const trancateCount = Math.round((column.getActualWidth() - 12) / 6 * 5)

    const displayValue = useMemo(() => formatedValue.length > trancateCount ? `${formatedValue.slice(0, trancateCount)}...` : formatedValue, [formatedValue, trancateCount])

    const isEmptyValue = isNullOrEmpty(value)

    const handleWidthChanged = useCallback(() => {
        api.refreshCells({ rowNodes: [node], columns: [column], force: true })
    }, [])

    useEffect(() => {
        column.addEventListener('widthChanged', handleWidthChanged)
        return () => {
            column.removeEventListener('widthChanged', handleWidthChanged)
        }
    }, [])
    return (
        <div css={renderStyle} title={formatedValue}>
            <div className="value">
                {isEmptyValue && editable ? <span className="placeholder-text">Please input...</span> : displayValue}</div>
            {editable && data.dropdownCategoryId && (
                <FIChevronDown className="arrow" />
            )}
        </div>
    )
}

export default ReviewValueRender