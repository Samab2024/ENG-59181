import createStyle from "@/hooks/createStyle";
import { css } from "@emotion/react";
import { CSSProperties } from "@emotion/serialize";

const useStyle = createStyle(token => ({
    cellColor: (r: API.ILoanReviewData, f: keyof Pick<API.ILoanReviewData, 'firstReviewValue' | 'secondReviewValue' | 'thirdReviewValue'>, dv: string, hasPermission: boolean): CSSProperties => ({
        backgroundColor: hasPermission
            ? (!r[f] ? token.colorWarningBg : dv !== r.clientDisplayValue ? token.colorErrorBg : token.colorSuccessBg)
            : (!r[f] ? null : (dv !== r.clientDisplayValue ? token.colorErrorBg : token.colorSuccessBg))
    }),
    displayArea: css`
        white-space: pre-line;
        height: 46px;
        overflow-y: auto;
        padding: 0 0.5rem;
    `,
    inputArea: css`
        &.ant-input {
            height: 46px!important;
            resize: none;
            font-size: 12px;
        }
        &:focus {
            transition: none;
            border: 1px solid ${token.colorPrimary};
        }
    `,
    selectArea: css`
        &.ant-select {
            height: 46px;
            font-size: 12px;
        }
        .ant-select-selector {
            height: 46px!important;
            font-size: 12px;
        }
        .ant-select-selection-item {
            white-space: normal;
        }
    `,

    datePickerArea: css`
        &.ant-picker{
            padding: 0px 7px 0px;
        }
        &.ant-picker-focused.ant-picker{
            box-shadow: 0 0 0 0px rgba(255, 135, 5, 0.1);
        }

        .ant-picker-input {
            height: 46px!important;
            width: 175px!important;
            position: absolute;
            background: transparent;
            font-size: 12px;

            input{
                //margin-top: -20px;
            }
        }
    `,

    reviewTable: css`
        .ant-picker{
            border: none;
        }
    `,

    customSwitch: css`
        &[aria-checked="false"] {
            background-color: ${token.colorPrimary};
        }
      `,

    settingTable: css`
        div.ant-card-head{
            min-height: 24px;
        }
        div.ant-select{
            width: 100px;
        }

        textarea.ant-input{
            width: 1250px;
            margin-left: 4px;
        }
    `,
}))

export default useStyle