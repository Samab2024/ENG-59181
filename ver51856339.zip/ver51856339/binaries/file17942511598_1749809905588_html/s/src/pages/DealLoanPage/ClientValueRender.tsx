import { ICellRendererParams } from "ag-grid-community"
import { useCallback, useEffect, useMemo } from "react"
import { IDataRow } from "./ReviewDataGrid"

const ClientValueRender = ({ value, column, node, api }: ICellRendererParams<IDataRow>) => {

    const trancateCount = Math.round((column.getActualWidth() - 20) / 6 * 5)

    const displayValue = useMemo(() => value?.length > trancateCount ? `${value.slice(0, trancateCount)}...` : value, [value, trancateCount])

    const handleWidthChanged = useCallback(() => {
        api.refreshCells({ rowNodes: [node], columns: [column], force: true })
    }, [])

    useEffect(() => {
        column.addEventListener('widthChanged', handleWidthChanged)
        return () => {
            column.removeEventListener('widthChanged', handleWidthChanged)
        }
    }, [])

    if (node.data.isBlindReview) {
        return <span />
    } else {
        return (
            <span style={{ wordBreak: 'break-all' }} title={value}>{displayValue}</span>
        )
    }
}

export default ClientValueRender