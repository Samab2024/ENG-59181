import IconButton from "@/components/IconButton";
import Wrapper, { HeadRow } from "@/components/Wrapper";
import AuthAPI from '@/services/api/AuthAPI';
import LoanReviewAPI from '@/services/api/LoanReviewAPI';
import ReviewerAPI from '@/services/api/ReviewerAPI';
import SectionAPI from "@/services/api/SectionAPI";
import notification from "@/utils/notification";
import { Col, Radio, Row, Space, Spin } from "antd";
import { FIArrowLeft, FIChevronLeft, FIChevronRight, FIRefresh } from "functional-icons/lib/Outline";
import { FC, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import DealLoanInputTable from "./DealLoanInputTable";
import LoanReviewerStatus from "./LoanReviewerStatus";
import DealAPI from "@/services/api/DealAPI";
import { PageTitle } from "@/utils/pageTitle";

const DealLoanPage: FC = () => {
    const { id, lid, sid } = useParams()

    const dealId = Number(id)
    const loanId = Number(lid)
    const sectionId = Number(sid)

    const navigate = useNavigate()
    const [loading, setLoading] = useState(false)

    const [sections, setSections] = useState<API.ISection[]>([])
    const [loanReview, setLoanReview] = useState<API.ILoanReview>()
    const [reviewer, setReviewer] = useState<API.IReviewer>()
    const [reviewerList, setReviewerList] = useState<API.UserInfo[]>()
    const [isReadonly, setIsReadonly] = useState(false)

    useEffect(() => {
        //fetch meta info
        Promise.all([
            SectionAPI.getSections(dealId),
            AuthAPI.getReviewers(dealId),
            DealAPI.getDealById(dealId),
        ])
            .then(([sections, reviewerList, deal]) => {
                setSections(sections)
                setReviewerList(reviewerList)
                setIsReadonly(deal.isReadOnly)
            })
        return () => {
            PageTitle.reset()
        }
    }, [])

    useEffect(() => {
        fetchData()
    }, [sectionId, loanId])

    const fetchData = () => {
        //fetch section data
        setLoading(true);
        Promise.all([
            LoanReviewAPI.getLoanReviewBySection(dealId, loanId, sectionId),
            ReviewerAPI.getLoanReviewer(loanId, sectionId),
        ])
            .then(([loanReview, reviewer]) => {
                setLoanReview(loanReview)
                setReviewer(reviewer)
                PageTitle.set(`${loanReview?.loanNumber} - ${loanReview?.propertyName}`)
            })
            .finally(() => setLoading(false))
    }

    const handleSectionValueCopy = (loanReviewSection: API.ILoanReviewSection) => {
        LoanReviewAPI.updateLoanReview(dealId, loanId, loanReviewSection)
            .then(() => {
                const review = { ...loanReview };
                const index = review.reviewSection.findIndex(rs => rs.sourceDocSectionId == loanReviewSection.sourceDocSectionId);
                review.reviewSection[index] = loanReviewSection;
                setLoanReview(review);
            })
            .catch(e => notification.error(e.message))
    }

    const handleReviewDataChange = (data: API.ILoanReviewCell) => {
        LoanReviewAPI.updateLoanReviewCell(dealId, loanId, data)
            .catch(e => notification.error(e.message))
    }

    const handleReviewerChange = (permission: string) => {
        //fetch with newest reviewer data and set them together
        ReviewerAPI.getLoanReviewer(loanId, sectionId).then(reviewer => {
            setReviewer(reviewer)
            setLoanReview({
                ...loanReview,
                reviewSection: loanReview.reviewSection.map(x => ({
                    ...x,
                    permission
                }))
            })
        })
    }

    const handleMissingDocChange = (missingDoc: string) => {
        setLoanReview({ ...loanReview, missingDoc })
    }

    const gotoLoan = (loanId: number) => {
        navigate(`/${dealId}/loan/${loanId}/section/${sectionId}`)
    }

    return (
        <Wrapper.PageContainer>
            <HeadRow
                icon={<IconButton icon={FIArrowLeft} onClick={() => navigate(`/${id}?s=${sectionId}`)} />}
                title={!loanReview ? '' : `#${loanReview?.displayOrder} - ${loanReview?.dealName} - ${loanReview?.loanNumber} - ${loanReview?.propertyName}`}
                expandContent={true}
            >
                <Row justify="space-between">
                    <Col style={{ paddingLeft: '8px' }}>
                        <Radio.Group value={sectionId} onChange={e => navigate(`/${dealId}/loan/${loanId}/section/${e.target.value}`)} disabled={loading}>
                            {sections.map(x => (
                                <Radio.Button key={x.sectionId} value={x.sectionId}>{x.name}</Radio.Button>
                            ))}
                        </Radio.Group>
                    </Col>
                    <Col>
                        <Space>
                            <IconButton icon={FIChevronLeft} onClick={() => gotoLoan(loanReview?.prvLoanId)} disabled={!loanReview?.prvLoanId} title={loanReview?.prvLoanNumber && `Previous loan: ${loanReview?.prvLoanNumber}`} />
                            <IconButton icon={FIChevronRight} onClick={() => gotoLoan(loanReview?.nextLoanId)} disabled={!loanReview?.nextLoanId} title={loanReview?.nextLoanNumber && `Next loan: ${loanReview?.nextLoanNumber}`} />
                            <IconButton icon={FIRefresh} onClick={fetchData} />
                        </Space>
                    </Col>
                </Row>
            </HeadRow>
            <Spin spinning={loading}>
                <LoanReviewerStatus
                    isReadonly={isReadonly}
                    loanReview={loanReview}
                    reviewer={reviewer}
                    reviewerList={reviewerList}
                    onReviewerChange={handleReviewerChange}
                    onMissingDocChange={handleMissingDocChange}
                />
                <DealLoanInputTable
                    isReadonly={isReadonly}
                    loanReview={loanReview}
                    reviewer={reviewer}
                    onSectionValueCopy={handleSectionValueCopy}
                    onReviewDataChange={handleReviewDataChange}
                />
            </Spin>
        </Wrapper.PageContainer>
    )
}

export default DealLoanPage
