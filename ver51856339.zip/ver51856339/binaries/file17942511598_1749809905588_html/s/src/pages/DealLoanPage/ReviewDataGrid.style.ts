import createStyle from "@/hooks/createStyle";
import { css } from "@emotion/react";

const useGridStyle = createStyle(token => css`
    .ag-cell-different {
        background-color: ${token.colorErrorBg}CC;
    }
    .ag-cell-match {
        background-color: ${token.colorSuccessBg}66;
    }
    .ag-cell-empty {
        background-color: ${token.colorWarningBg}99;
    }
`)

export default useGridStyle