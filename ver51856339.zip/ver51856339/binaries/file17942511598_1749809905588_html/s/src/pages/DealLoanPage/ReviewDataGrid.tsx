import Grid from "@/components/Grid";
import FormulaCellEditor from "@/components/Grid/FormulaCellEditor";
import FormulaCellRender from "@/components/Grid/FormulaCellRender";
import TextCellRender from "@/components/Grid/textCellRender";
import { calculateFormula } from "@/utils/numberHelper";
import { LoanContextType, cellClassFn, checkIsFinalReviewValueTie, colSpanFn, createContextMenuFn, defaultColumn, getReviewFields, handleGridKeyDown, suppressKeyboardEvent, valueCellEditorSelector, valueParser } from "@/utils/reviewHelper";
import { parseToString } from "@/utils/stringHelper";
import { CellClassFunc, CellEditorSelectorFunc, CellValueChangedEvent, ColDef, GetDataPath, GridApi, ICellRendererParams, ILargeTextEditorParams } from "ag-grid-community";
import { Empty } from "antd";
import { ForwardRefRenderFunction, forwardRef, useEffect, useImperativeHandle, useMemo, useState } from "react";
import ClientValueRender from "./ClientValueRender";
import CommentValueRender from "./CommentValueRender";
import useGridStyle from "./ReviewDataGrid.style";
import ReviewValueRender from "./ReviewValueRender";

export type IDataRow = API.ILoanReviewData

export type InputColumnName = keyof Pick<IDataRow, 'clientValue' | 'firstReviewValue' | 'secondReviewValue' | 'thirdReviewValue'>

export interface IDealLoanInputTableComp {
    getValues: () => IDataRow[]
    // getChangedValues: () => IDataRow[]
    copyValue: (target: InputColumnName[], origin: InputColumnName) => void
}

const createColumnDefs = ({ isBlindReview, permission, levelOfReview, isTreeData, isReadonly }): ColDef<IDataRow>[] => [
    {
        colId: 'clientHeader',
        headerName: 'Inputs / Tape Header',
        cellRenderer: ({ data }: ICellRendererParams<IDataRow>) => <span title={data.pwCHeader || data.clientHeader} style={{ whiteSpace: 'nowrap' }}>{data.pwCHeader || data.clientHeader}</span>
    },
    {
        colId: 'fieldGuide',
        field: 'fieldGuide',
        headerName: 'Field Guide',
        cellRenderer: TextCellRender,
        cellStyle: () => ({ whiteSpace: 'nowrap' })
    },
    {
        colId: 'clientDisplayValue',
        field: 'clientDisplayValue',
        headerName: 'Client Value',
        cellClass: 'ag-text-allow-select',
        hide: isBlindReview,
        autoHeight: true,
        cellRenderer: ClientValueRender
    },
    {
        colId: 'firstReviewValue',
        field: 'firstReviewValue',
        headerName: '1st Review',
        cellRenderer: ReviewValueRender,
        editable: (params) => params.node.data.levelOfReview >= 1 && permission.includes("1") && !params.node.data.parentId && !isReadonly,
        cellEditorSelector: valueCellEditorSelector as CellEditorSelectorFunc<IDataRow>,
        cellEditorParams: {
            maxLength: 2000,
        },
        cellDataType: false,
        valueParser: valueParser<IDataRow>,
        suppressKeyboardEvent: suppressKeyboardEvent<IDataRow>,
        cellClass: cellClassFn as CellClassFunc<IDataRow>,
        colSpan: colSpanFn,
        contextMenuItems: createContextMenuFn<IDataRow>('firstReviewValue'),
        autoHeight: true,
    },
    {
        colId: 'firstReviewFormula',
        field: 'firstReviewFormula',
        headerName: '',
        width: 20,
        suppressSizeToFit: true,
        resizable: false,
        editable: (params) => params.node.data.levelOfReview >= 1 && permission.includes("1") && !params.node.data.parentId && !isReadonly,
        cellRenderer: FormulaCellRender,
        cellEditor: FormulaCellEditor,
        cellEditorPopup: true,
        cellClass: cellClassFn as CellClassFunc<IDataRow>,
        cellStyle: () => ({ display: 'flex', alignItems: 'center' }),
    },
    ...([
        {
            colId: 'secondReviewValue',
            field: 'secondReviewValue',
            headerName: '2nd Review',
            cellRenderer: ReviewValueRender,
            editable: (params) => params.node.data.levelOfReview >= 2 && permission.includes("2") && !params.node.data.parentId && !isReadonly,
            cellEditorSelector: valueCellEditorSelector,
            cellEditorParams: {
                maxLength: 2000,
            },
            cellDataType: false,
            valueParser,
            suppressKeyboardEvent,
            cellClass: cellClassFn,
            colSpan: colSpanFn,
            contextMenuItems: createContextMenuFn<IDataRow>('secondReviewValue'),
            autoHeight: true,
        },
        {
            colId: 'secondReviewFormula',
            field: 'secondReviewFormula',
            headerName: '',
            width: 20,
            suppressSizeToFit: true,
            resizable: false,
            editable: (params) => params.node.data.levelOfReview >= 2 && permission.includes("2") && !params.node.data.parentId && !isReadonly,
            cellRenderer: FormulaCellRender,
            cellEditor: FormulaCellEditor,
            cellEditorPopup: true,
            cellClass: cellClassFn,
            cellStyle: () => ({ display: 'flex', alignItems: 'center' }),
        },
        {
            colId: 'thirdReviewValue',
            field: 'thirdReviewValue',
            headerName: '3rd Review',
            cellRenderer: ReviewValueRender,
            editable: (params) => params.node.data.levelOfReview == 3 && permission.includes("3") && !params.node.data.parentId && !isReadonly,
            cellEditorSelector: valueCellEditorSelector,
            cellEditorParams: {
                maxLength: 2000,
            },
            cellDataType: false,
            valueParser,
            suppressKeyboardEvent,
            cellClass: cellClassFn,
            colSpan: colSpanFn,
            contextMenuItems: createContextMenuFn<IDataRow>('thirdReviewValue'),
            autoHeight: true,
        },
        {
            colId: 'thirdReviewFormula',
            field: 'thirdReviewFormula',
            headerName: '',
            width: 20,
            suppressSizeToFit: true,
            resizable: false,
            editable: (params) => params.node.data.levelOfReview == 3 && permission.includes("3") && !params.node.data.parentId && !isReadonly,
            cellRenderer: FormulaCellRender,
            cellEditor: FormulaCellEditor,
            cellEditorPopup: true,
            cellClass: cellClassFn,
            cellStyle: () => ({ display: 'flex', alignItems: 'center' }),
        },
    ] as ColDef<IDataRow>[]).slice(0, (levelOfReview - 1) * 2),
    {
        colId: 'pwCComments',
        field: 'pwCComments',
        headerName: 'PwC Comment',
        editable: ({ node }) => !node.data.parentId && !isReadonly,
        cellEditor: 'agLargeTextCellEditor',
        cellEditorParams: {
            rows: 5,
            cols: 30,
            maxLength: 5000,
        } as ILargeTextEditorParams,
        cellEditorPopup: true,
        cellRenderer: CommentValueRender,
    },
    {
        colId: 'internalComments',
        field: 'internalComments',
        headerName: 'Internal Comment',
        editable: ({ node }) => !node.data.parentId && !isReadonly,
        cellEditor: 'agLargeTextCellEditor',
        cellEditorParams: {
            rows: 5,
            cols: 30,
            maxLength: 5000,
        } as ILargeTextEditorParams,
        cellEditorPopup: true,
        cellRenderer: CommentValueRender,
    },
    { field: 'isFirstReviewed', hide: true },
    { field: 'isSecondReviewed', hide: true },
    { field: 'isThirdReviewed', hide: true },
].filter((_, i) => isTreeData ? i !== 0 : true) as any

const getDataPath: GetDataPath<IDataRow> = x => {
    if (x.parentId) {
        return [x.headerMapId + '', x.loanNumber]
    } else {
        return [x.headerMapId + '']
    }
}

const DataGrid: ForwardRefRenderFunction<IDealLoanInputTableComp, {
    isReadonly: boolean
    data: IDataRow[]
    levelOfReview: number
    permission: string,
    isBlindReview: boolean,
    sectionId: number,
    onChange: (record: API.ILoanReviewCell) => void
}> = ({ data, levelOfReview, permission, isBlindReview, onChange, sectionId, isReadonly }, ref) => {
    const gridStyle = useGridStyle()
    const [gridApi, setGridApi] = useState<GridApi<IDataRow>>()
    const [columnDefs, setColumnDefs] = useState<ColDef<IDataRow>[]>([])

    const isTreeData = useMemo(() => data.some(x => x.parentId), [data])

    useEffect(() => {
        if (gridApi) {
            setColumnDefs(createColumnDefs({
                isBlindReview,
                permission,
                levelOfReview,
                isTreeData,
                isReadonly
            }))
            gridApi.sizeColumnsToFit();
        }
    }, [gridApi, isBlindReview, permission, levelOfReview, isTreeData])

    useEffect(() => {
        if (gridApi) {
            gridApi.sizeColumnsToFit();
        }
    }, [columnDefs])

    const handleCellValueChanged = ({ oldValue, newValue, node, colDef, api }: CellValueChangedEvent<IDataRow>) => {
        const { reviewLevel, formulaField, reviewField, valueField } = getReviewFields<IDataRow>(colDef.field as keyof IDataRow)

        let oldReviewValue: string, newReviewValue: string, formula: string, isReviewed: boolean
        if (colDef.field.includes('Formula')) {
            const calculateValue = calculateFormula(newValue, node.data.dataFormatCode)
            oldReviewValue = parseToString(node.data[valueField], false)
            newReviewValue = parseToString(calculateValue)
            formula = parseToString(newValue)
            isReviewed = !!newReviewValue
            node.setData({
                ...node.data,
                [valueField]: calculateValue,
                [reviewField]: isReviewed,
            })
        } else if (colDef.field.includes('Value')) {
            oldReviewValue = parseToString(oldValue, false)
            newReviewValue = parseToString(newValue)
            formula = ''
            isReviewed = !!newReviewValue
            if (typeof newValue === 'string') {
                node.setData({
                    ...node.data,
                    [colDef.field]: newReviewValue,
                    [formulaField]: formula, //Reset previous formula
                    [reviewField]: isReviewed,
                })
            } else {
                node.setData({
                    ...node.data,
                    [formulaField]: formula, //Reset previous formula
                    [reviewField]: isReviewed,
                })
            }
        } else if (colDef.field.includes('Reviewed')) {
            oldReviewValue = newReviewValue = parseToString(node.data[valueField], false)
            formula = parseToString(node.data[formulaField])
            isReviewed = newValue
            api.refreshCells({ columns: [valueField], rowNodes: [node], force: true }) //refresh color
        }
        onChange({
            headerMapId: node.data.headerMapId,
            sectionId,
            reviewLevel,
            oldReviewValue,
            newReviewValue,
            isReviewed,
            formula,
            pwCComments: node.data.pwCComments,
            internalComments: node.data.internalComments,
            isTie: checkIsFinalReviewValueTie<IDataRow>(node.data, levelOfReview)
        })
    }

    useImperativeHandle<IDealLoanInputTableComp, IDealLoanInputTableComp>(ref, () => {
        return {
            copyValue(targetKeys, originKey) {
                gridApi.forEachNode(node => {
                    node.setData({
                        ...node.data,
                        ...targetKeys.reduce((p, key, i) => {
                            const levelOfReview = key === 'thirdReviewValue' ? 3 : key === 'secondReviewValue' ? 2 : 1
                            const { reviewField } = getReviewFields(key)
                            if (node.data.isBlindReview && originKey === 'clientValue') {
                                //skip this row if the header is blind
                            } else if (levelOfReview > node.data.levelOfReview) {
                                //skip this row if the header review level less than current target
                            } else {
                                p[key] = node.data[originKey]
                                p[reviewField] = !!node.data[originKey]
                            }
                            return p
                        }, {})
                    })
                })
            },
            getValues() {
                const result: IDataRow[] = []
                gridApi.forEachNode(node => {
                    result.push({
                        ...node.data,
                        isTie: checkIsFinalReviewValueTie<IDataRow>(node.data, levelOfReview)
                    })
                })
                return result
            },
        }
    })

    const autoGroupColumnDef = useMemo<ColDef<IDataRow>>(() => {
        return {
            headerName: "Inputs / Tape Header",
            flex: 1,
            cellRendererParams: {
                suppressCount: true,
                innerRenderer: ({ node }: ICellRendererParams<IDataRow>) => node.data.parentId
                    ? <span style={{ whiteSpace: 'nowrap' }}>{node.data.propertyName} ({node.data.loanNumber})</span>
                    : <span title={node.data.pwCHeader || node.data.clientHeader} style={{ whiteSpace: 'nowrap' }}>{node.data.pwCHeader || node.data.clientHeader}</span>,
            }
        };
    }, []);

    return (
        <Grid<IDataRow>
            css={gridStyle}
            animateRows={true}
            onGridReady={e => setGridApi(e.api)}
            defaultColDef={defaultColumn}
            rowData={data}
            context={{ isBlindReview } as LoanContextType}
            height={Math.min(data.length * 28 + 64, 600)} //footer + header + title
            columnDefs={columnDefs}
            onCellValueChanged={handleCellValueChanged}
            // suppressClickEdit={true}
            getRowId={({ data }) => data?.loanNumber + data?.headerMapId + ''}
            noRowsOverlayComponent={() => <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
            undoRedoCellEditing={true}
            allowContextMenuWithControlKey={true}
            onCellKeyDown={handleGridKeyDown}
            getContextMenuItems={({ column, node }) => {
                const isEditable = column?.isCellEditable(node)
                return isEditable ? ['copy', 'paste'] : ['copy']
            }}
            treeData={isTreeData}
            getDataPath={getDataPath}
            autoGroupColumnDef={autoGroupColumnDef}
        />
    )
}

// [clientheader]
// [clientheader, loannumber1]
// [clientheader, loannumber2]
// [clientheader2]
// [clienthdaer2, loannumber1]
// [clienthdaer2, loannumber2]

export default forwardRef(DataGrid)
