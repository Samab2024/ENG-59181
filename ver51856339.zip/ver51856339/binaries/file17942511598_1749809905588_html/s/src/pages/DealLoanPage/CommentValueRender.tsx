import { ICellRendererParams } from "ag-grid-community"
import { IDataRow } from "./ReviewDataGrid"

const CommentValueRender = ({ value, api, node, column }: ICellRendererParams<IDataRow>) => {
    const isEditable = column?.isCellEditable(node)
    let displayValue = value
    if (!value && isEditable) {
        displayValue = <span className="placeholder-text">Add comment...</span>
    }
    return (
        <div className="ag-cell-value" onClick={() => api.startEditingCell({
            rowIndex: node.rowIndex,
            colKey: column.getId(),
        })} title={value}>{displayValue}</div>
    )
}

export default CommentValueRender