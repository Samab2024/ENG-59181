import * as controlStyles from '@/styles/control.module.css'
import nameOfData from "@/utils/nameOfData"
import { Button, Form, FormInstance, Input, Select, Space, Checkbox } from "antd"
import { FC, useContext, useState, } from "react";
import { IHeaderMapFrom } from "."
import { HeaderMapContext } from "../HeaderMapPage/HeaderMapPage";
import { PROCESS_TYPES } from '@/constants';

const isSpecificProcessType = (processType: string) => [
    PROCESS_TYPES.Provided,
    PROCESS_TYPES.PassThrough,
    PROCESS_TYPES.Calculation
].includes(processType)

const HeaderMapForm: FC<{
    form: FormInstance<IHeaderMapFrom>
    onSave: (data: IHeaderMapFrom) => void
    onCancel: () => void
}> = ({ form, onCancel, onSave }) => {

    const { processTypes, sourceDocSections, sources, dataFormats, dropdownCategories } = useContext(HeaderMapContext);

    const [showDropdownCategory, setShowDropdownCategory] = useState(true)

    //initial default value
    const sourceDocSectionDefaultValue = sourceDocSections.find(s => s.name === "LEGAL TERMS")?.sourceDocSectionId;
    const textOptionId = dataFormats.find(f => f.name === "Text")?.dataFormatId;
    const initialData = { processType: "Review", sourceDocSectionId: sourceDocSectionDefaultValue, dataFormatId: textOptionId }

    const processType = Form.useWatch<string>(nameOfData<IHeaderMapFrom>("processType"), form);
    const isSpecificProcessTypeValue = isSpecificProcessType(processType)

    return (
        <Form form={form} layout="vertical" name="RequestForm" onFinish={onSave} initialValues={initialData}>
            <Form.Item label="PwC Header" name={nameOfData<IHeaderMapFrom>("pwCHeader")} rules={[{ required: true }]}>
                <Input />
            </Form.Item>
            <Form.Item label="Process Type" name={nameOfData<IHeaderMapFrom>("processType")} rules={[{ required: true }]}>
                <Select className={controlStyles.fullWidth} options={processTypes && processTypes.map(x => ({ value: x, label: x }))} />
            </Form.Item>
            <Form.Item label="Source Doc Section" name={nameOfData<IHeaderMapFrom>("sourceDocSectionId")} rules={[{ required: !isSpecificProcessTypeValue }]}>
                <Select className={controlStyles.fullWidth} options={sourceDocSections && sourceDocSections.map(x => ({ value: x.sourceDocSectionId, label: x.name }))} disabled={isSpecificProcessTypeValue} />
            </Form.Item>
            <Form.Item label="Source" name={nameOfData<IHeaderMapFrom>("sourceId")} rules={[{ required: !isSpecificProcessTypeValue }]}>
                <Select className={controlStyles.fullWidth} options={sources && sources.map(x => ({ value: x.sourceId, label: x.name }))} disabled={isSpecificProcessTypeValue} />
            </Form.Item>
            <Form.Item label="Format" name={nameOfData<IHeaderMapFrom>("dataFormatId")} rules={[{ required: true }]}>
                <Select className={controlStyles.fullWidth} options={dataFormats && dataFormats.map(x => ({ value: x.dataFormatId, label: x.name }))} onSelect={v => setShowDropdownCategory(v === textOptionId)} />
            </Form.Item>
            {showDropdownCategory &&
                <Form.Item label="Lookup Category" name={nameOfData<IHeaderMapFrom>("dropdownCategoryId")}>
                    <Select className={controlStyles.fullWidth} options={dropdownCategories.map(x => ({ value: x.categoryId, label: x.categoryName }))} allowClear />
                </Form.Item>
            }
            <Form.Item label="Field Guide" name={nameOfData<IHeaderMapFrom>('fieldGuide')}>
                <Input.TextArea />
            </Form.Item>
            <Form.Item>
                <Space>
                    <Button type="primary" htmlType="submit">
                        Submit
                    </Button>
                    <Button onClick={onCancel}>Cancel</Button>
                </Space>
            </Form.Item>
        </Form>
    )
}

export default HeaderMapForm