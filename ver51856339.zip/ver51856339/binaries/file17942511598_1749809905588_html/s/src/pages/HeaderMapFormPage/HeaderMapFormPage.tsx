import { Drawer, Spin } from "antd";
import { useForm } from "antd/lib/form/Form";
import { useParams } from "react-router-dom";
import { FIClose } from "functional-icons/lib/Outline";
import { FC, useState, useEffect, useContext } from "react";
import notification from '@/utils/notification'
import HeaderMapAPI from '@/services/api/HeaderMapAPI'
import { IHeaderMapFrom } from ".";
import HeaderMapForm from "./HeaderMapForm";
import { HeaderMapContext } from "../HeaderMapPage/HeaderMapPage";

const HeaderMapFormPage: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {
    const { id } = useParams()
    const [form] = useForm<IHeaderMapFrom>()
    const [loading, setLoading] = useState(false)
    const { getHeaderMapById } = useContext(HeaderMapContext)

    useEffect(() => {
        if (open) {
            form.resetFields()
        }
    }, [open])

    const handleSave = (formData: IHeaderMapFrom) => {
        setLoading(true)
        HeaderMapAPI.createHeaderMap(Number(id), formData)
            .then(() => {
                notification.success("Create header map successfully.")
                onClose();
                getHeaderMapById();
            })
            .catch(e =>
                notification.error((e as API.IException).message)
            )
            .finally(() => setLoading(false))
    }

    return (
        <Drawer open={open} closeIcon={<FIClose />} onClose={onClose} title='Add New Header' width={400} className="request-form-page" destroyOnClose={true}>
            <Spin spinning={loading}>
                <HeaderMapForm form={form} onCancel={onClose} onSave={handleSave} />
            </Spin>
        </Drawer>
    )
}

export default HeaderMapFormPage

