export type IHeaderMapFrom = API.IHeaderMap
export { default } from './HeaderMapFormPage'