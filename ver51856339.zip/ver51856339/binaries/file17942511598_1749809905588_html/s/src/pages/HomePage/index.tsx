import DefaultLayout from '@/components/DefaultLayout'
import { FC } from 'react'
import { Outlet, useNavigate } from 'react-router-dom'

const HomePage: FC = () => {
    const navigate = useNavigate()
    return (
        <div className="home-container">
            <DefaultLayout header={{ onTitleClick: () => navigate('/') }}>
                <Outlet />
            </DefaultLayout>
        </div>
    )
}

export default HomePage