import createStyle from "@/hooks/createStyle";
import { css } from "@emotion/react";

const useStyle = createStyle(token => ({
    settingTable: css`
        div.ant-card-head{
            min-height: 24px;
        }
        div.ant-select{
            width: 100px;
        }

        textarea.ant-input{
            width: 1250px;
            margin-left: 4px;
        }
    `,
}))

export default useStyle