import IconButton from "@/components/IconButton";
import Wrapper, { HeadRow } from "@/components/Wrapper";
import AuthAPI from '@/services/api/AuthAPI';
import HeaderReviewAPI from "@/services/api/HeaderReviewAPI";
import ReviewerAPI from "@/services/api/ReviewerAPI";
import notification from "@/utils/notification";
import { isNullOrEmpty } from "@/utils/stringHelper";
import { Space, Spin } from "antd";
import { FIArrowLeft, FIChevronLeft, FIChevronRight, FIRefresh } from "functional-icons/lib/Outline";
import { FC, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import DealHeaderInputTable from "./DealHeaderInputTable";
import HeaderReviewerStatus from "./HeaderReviewerStatus";
import DealAPI from "@/services/api/DealAPI";

const DealHeaderPage: FC = () => {
    const { id, hid } = useParams()

    const dealId = Number(id)
    const headerId = Number(hid)

    const navigate = useNavigate()
    const [loading, setLoading] = useState(false)

    const [headerReview, setHeaderReview] = useState<API.IHeaderReview>()
    const [header, setHeader] = useState<API.IHeader>()
    const [reviewerList, setReviewerList] = useState<API.UserInfo[]>()
    const [isReadonly, setIsReadonly] = useState(false)

    useEffect(() => {
        //fetch meta info
        Promise.all([
            DealAPI.getDealById(dealId),
            AuthAPI.getReviewers(dealId)
        ])
            .then(([deal, reviewerList]) => {
                setIsReadonly(deal.isReadOnly)
                setReviewerList(reviewerList)
            })
    }, [])

    useEffect(() => {
        fetchData()
    }, [headerId])

    const fetchData = () => {
    //fetch section data
        setLoading(true);
        Promise.all([
            HeaderReviewAPI.getHeaderReview(dealId, headerId),
            ReviewerAPI.getAttributeReviewerByHeaderMap(headerId),
        ])
            .then(([headerReview, header]) => {
                setHeaderReview(headerReview)
                setHeader(header)
            })
            .finally(() => setLoading(false))
    }

    const handleSectionValueCopy = (headerReviewSection: API.IHeaderReviewSection) => {
        HeaderReviewAPI.updateHeaderReview(dealId, headerId, headerReviewSection)
            .then(() => {
                const review = { ...headerReview };
                const index = review.reviewSection.findIndex(rs => rs.sourceDocSectionId == headerReviewSection.sourceDocSectionId);
                review.reviewSection[index] = headerReviewSection;
                setHeaderReview(review);
            })
            .catch(e => notification.error(e.message))
    }

    const handleReviewDataChange = (data: API.IHeaderReviewCell) => {
        HeaderReviewAPI.updateHeaderReviewCell(dealId, headerId, data)
            .catch(e => notification.error(e.message))
    }

    const handleReviewerChange = (permission: string) => {
        //fetch with newest reviewer data and set them together
        ReviewerAPI.getAttributeReviewerByHeaderMap(headerId).then(reviewer => {
            setHeader(reviewer)
            setHeaderReview({
                ...headerReview,
                reviewSection: headerReview.reviewSection.map(x => ({
                    ...x,
                    permission
                }))
            })
        })
    }
    const gotoHeader = (headerMapId: number) => {
        navigate(`/${dealId}/header/${headerMapId}`)
    }

    return (
        <Wrapper.PageContainer>
            <HeadRow
                icon={<IconButton icon={FIArrowLeft} onClick={() => navigate(`/${id}?s=-1`)} />}
                title={!headerReview ? '' : `${headerReview?.dealName} - ${isNullOrEmpty(headerReview?.clientHeader) ? headerReview?.pwCHeader : headerReview?.clientHeader}`}
            >
                <Space>
                    <IconButton icon={FIChevronLeft} onClick={() => gotoHeader(headerReview?.prvHeaderMapId)} disabled={!headerReview?.prvHeaderMapId} title={headerReview?.prvClientHeader && `Previous client header: ${headerReview?.prvClientHeader}`} />
                    <IconButton icon={FIChevronRight} onClick={() => gotoHeader(headerReview?.nextHeaderMapId)} disabled={!headerReview?.nextHeaderMapId} title={headerReview?.nextClientHeader && `Next client header: ${headerReview?.nextClientHeader}`} />
                    <IconButton icon={FIRefresh} onClick={fetchData} />
                </Space>
            </HeadRow>
            <Spin spinning={loading}>
                <HeaderReviewerStatus
                    isReadonly={isReadonly}
                    headerReview={headerReview}
                    header={header}
                    reviewerList={reviewerList}
                    onReviewerChange={handleReviewerChange}
                />
                <DealHeaderInputTable
                    isReadonly={isReadonly}
                    headerReview={headerReview}
                    header={header}
                    onSectionValueCopy={handleSectionValueCopy}
                    onReviewDataChange={handleReviewDataChange}
                />
            </Spin>
        </Wrapper.PageContainer>
    )
}

export default DealHeaderPage
