import Grid from "@/components/Grid";
import FormulaCellEditor from "@/components/Grid/FormulaCellEditor";
import FormulaCellRender from "@/components/Grid/FormulaCellRender";
import TextCellRender from "@/components/Grid/textCellRender";
import { calculateFormula } from "@/utils/numberHelper";
import { HeaderContextType, cellClassFn, checkIsFinalReviewValueTie, colSpanFn, createContextMenuFn, defaultColumn, getReviewFields, handleGridKeyDown, suppressKeyboardEvent, valueCellEditorSelector, valueParser } from "@/utils/reviewHelper";
import { isNullOrEmpty, parseToString } from "@/utils/stringHelper";
import { CellClassFunc, CellEditorSelectorFunc, CellValueChangedEvent, ColDef, GridApi, ILargeTextEditorParams } from "ag-grid-community";
import { Empty } from "antd";
import { ForwardRefRenderFunction, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import ClientValueRender from "../DealLoanPage/ClientValueRender";
import CommentValueRender from "../DealLoanPage/CommentValueRender";
import useGridStyle from "../DealLoanPage/ReviewDataGrid.style";
import ReviewValueRender, { IReviewValueRenderParams } from "../DealLoanPage/ReviewValueRender";

export type IDataRow = API.IHeaderReviewData

export type InputColumnName = keyof Pick<IDataRow, 'clientValue' | 'firstReviewValue' | 'secondReviewValue' | 'thirdReviewValue'>

export interface IDealHeaderInputTableComp {
    getValues: () => IDataRow[]
    // getChangedValues: () => IDataRow[]
    copyValue: (target: InputColumnName[], origin: InputColumnName) => void
}

const createColumnDefs = ({ headerReview, permission, isReadonly }): ColDef<IDataRow>[] => [
    {
        colId: 'loanNumber',
        field: 'loanNumber',
        headerName: 'Loan Number',
        cellRenderer: TextCellRender,
    },
    {
        colId: 'propertyName',
        field: 'propertyName',
        headerName: 'Property Name',
        cellRenderer: TextCellRender,
    },
    {
        colId: 'clientDisplayValue',
        field: 'clientDisplayValue',
        headerName: 'Client Value',
        cellClass: 'ag-text-allow-select',
        hide: headerReview.isBlindReview || isNullOrEmpty(headerReview.clientHeader),
        autoHeight: true,
        cellRenderer: ClientValueRender
    },
    {
        colId: 'firstReviewValue',
        field: 'firstReviewValue',
        headerName: '1st Review',
        cellRenderer: ReviewValueRender,
        cellRendererParams: {
            dataFormatCode: headerReview.dataFormatCode,
            dataFormatType: headerReview.dataFormatType,
        } as IReviewValueRenderParams<IDataRow>,
        editable: (params) => params.node.data.levelOfReview >= 1 && permission.includes("1") && !isReadonly,
        cellEditorSelector: valueCellEditorSelector as CellEditorSelectorFunc<IDataRow>,
        cellEditorParams: {
            maxLength: 2000,
        },
        cellDataType: false,
        valueParser: valueParser<IDataRow>,
        suppressKeyboardEvent: suppressKeyboardEvent<IDataRow>,
        cellClass: cellClassFn as CellClassFunc<IDataRow>,
        colSpan: colSpanFn,
        autoHeight: true,
        contextMenuItems: createContextMenuFn('firstReviewValue')
    },
    {
        colId: 'firstReviewFormula',
        field: 'firstReviewFormula',
        headerName: '',
        width: 20,
        suppressSizeToFit: true,
        resizable: false,
        editable: (params) => params.node.data.levelOfReview >= 1 && permission.includes("1") && !isReadonly,
        cellRenderer: FormulaCellRender,
        cellEditor: FormulaCellEditor,
        cellEditorPopup: true,
        cellClass: cellClassFn as CellClassFunc<IDataRow>,
        cellStyle: () => ({ display: 'flex', alignItems: 'center' }),
    },
    ...([
        {
            colId: 'secondReviewValue',
            field: 'secondReviewValue',
            headerName: '2nd Review',
            cellRenderer: ReviewValueRender,
            cellRendererParams: {
                dataFormatCode: headerReview.dataFormatCode,
                dataFormatType: headerReview.dataFormatType,
            } as IReviewValueRenderParams<IDataRow>,
            editable: (params) => params.node.data.levelOfReview >= 2 && permission.includes("2") && !isReadonly,
            cellEditorSelector: valueCellEditorSelector,
            cellEditorParams: {
                maxLength: 2000,
            },
            cellDataType: false,
            valueParser,
            suppressKeyboardEvent: suppressKeyboardEvent,
            cellClass: cellClassFn,
            colSpan: colSpanFn,
            autoHeight: true,
            contextMenuItems: createContextMenuFn('secondReviewValue')
        },
        {
            colId: 'secondReviewFormula',
            field: 'secondReviewFormula',
            headerName: '',
            width: 20,
            suppressSizeToFit: true,
            resizable: false,
            editable: (params) => params.node.data.levelOfReview >= 2 && permission.includes("2") && !isReadonly,
            cellRenderer: FormulaCellRender,
            cellEditor: FormulaCellEditor,
            cellEditorPopup: true,
            cellClass: cellClassFn,
            cellStyle: () => ({ display: 'flex', alignItems: 'center' }),
        },
        {
            colId: 'thirdReviewValue',
            field: 'thirdReviewValue',
            headerName: '3rd Review',
            cellRenderer: ReviewValueRender,
            cellRendererParams: {
                dataFormatCode: headerReview.dataFormatCode,
                dataFormatType: headerReview.dataFormatType,
            } as IReviewValueRenderParams<IDataRow>,
            editable: (params) => params.node.data.levelOfReview == 3 && permission.includes("3") && !isReadonly,
            cellEditorSelector: valueCellEditorSelector,
            cellEditorParams: {
                maxLength: 2000,
            },
            cellDataType: false,
            valueParser,
            suppressKeyboardEvent: suppressKeyboardEvent,
            cellClass: cellClassFn,
            colSpan: colSpanFn,
            autoHeight: true,
            contextMenuItems: createContextMenuFn('thirdReviewValue'),
        },
        {
            colId: 'thirdReviewFormula',
            field: 'thirdReviewFormula',
            headerName: '',
            width: 20,
            suppressSizeToFit: true,
            resizable: false,
            editable: (params) => params.node.data.levelOfReview == 3 && permission.includes("3") && !isReadonly,
            cellRenderer: FormulaCellRender,
            cellEditor: FormulaCellEditor,
            cellEditorPopup: true,
            cellClass: cellClassFn,
            cellStyle: () => ({ display: 'flex', alignItems: 'center' }),
        }
    ] as ColDef<IDataRow>[]).slice(0, (headerReview.levelOfReview - 1) * 2), // [2,3]<=3, [2]<=2
    {
        colId: 'pwCComments',
        field: 'pwCComments',
        headerName: 'PwC Comment',
        editable: !isReadonly,
        cellEditor: 'agLargeTextCellEditor',
        cellEditorParams: {
            rows: 5,
            cols: 30,
            maxLength: 5000,
        } as ILargeTextEditorParams,
        cellEditorPopup: true,
        cellRenderer: CommentValueRender,
    },
    {
        colId: 'internalComments',
        field: 'internalComments',
        headerName: 'Internal Comment',
        editable: !isReadonly,
        cellEditor: 'agLargeTextCellEditor',
        cellEditorParams: {
            rows: 5,
            cols: 30,
            maxLength: 5000,
        } as ILargeTextEditorParams,
        cellEditorPopup: true,
        cellRenderer: CommentValueRender,
    },
    { field: 'isFirstReviewed', hide: true },
    { field: 'isSecondReviewed', hide: true },
    { field: 'isThirdReviewed', hide: true },
]

const DataGrid: ForwardRefRenderFunction<IDealHeaderInputTableComp, {
    isReadonly: boolean
    data: IDataRow[]
    headerReview: API.IHeaderReview
    permission: string,
    onChange: (record: API.IHeaderReviewCell) => void
}> = ({ data, permission, onChange, headerReview, isReadonly }, ref) => {
    const gridStyle = useGridStyle()
    const [gridApi, setGridApi] = useState<GridApi<IDataRow>>()
    const [columnDefs, setColumnDefs] = useState<ColDef<IDataRow>[]>([])

    useEffect(() => {
        if (gridApi) {
            setColumnDefs(createColumnDefs({
                permission,
                headerReview,
                isReadonly
            }))
            gridApi.sizeColumnsToFit();
        }
    }, [gridApi, permission, headerReview])

    useEffect(() => {
        if (gridApi) {
            gridApi.sizeColumnsToFit();
        }
    }, [columnDefs])

    const handleCellValueChanged = ({ api, oldValue, newValue, node, colDef, context }: CellValueChangedEvent<IDataRow>) => {
        const { headerReview } = context as HeaderContextType
        const { reviewLevel, formulaField, reviewField, valueField } = getReviewFields<IDataRow>(colDef.field as keyof IDataRow)

        let oldReviewValue: string, newReviewValue: string, formula: string, isReviewed: boolean
        if (colDef.field.includes('Formula')) {
            const calculateValue = calculateFormula(newValue, headerReview.dataFormatCode)
            oldReviewValue = parseToString(node.data[valueField], false)
            newReviewValue = parseToString(calculateValue)
            formula = parseToString(newValue)
            isReviewed = !!newReviewValue
            node.setData({
                ...node.data,
                [valueField]: calculateValue,
                [reviewField]: isReviewed,
            })
        } else if (colDef.field.includes('Value')) {
            oldReviewValue = parseToString(oldValue, false)
            newReviewValue = parseToString(newValue)
            formula = ''
            isReviewed = !!newReviewValue
            if (typeof newValue === 'string') {
                node.setData({
                    ...node.data,
                    [colDef.field]: newReviewValue,
                    [formulaField]: formula, //Reset previous formula
                    [reviewField]: isReviewed,
                })
            } else {
                node.setData({
                    ...node.data,
                    [formulaField]: formula, //Reset previous formula
                    [reviewField]: isReviewed,
                })
            }
        } else if (colDef.field.includes('Reviewed')) {
            oldReviewValue = newReviewValue = parseToString(node.data[valueField], false)
            formula = parseToString(node.data[formulaField])
            isReviewed = newValue
            api.refreshCells({ columns: [valueField], rowNodes: [node], force: true }) //refresh color
        }
        //Exception is editng comments fields
        onChange({
            loanId: node.data.loanId,
            reviewLevel,
            oldReviewValue,
            newReviewValue,
            formula,
            isReviewed,
            pwCComments: node.data.pwCComments,
            internalComments: node.data.internalComments,
            isTie: checkIsFinalReviewValueTie<IDataRow>(node.data, headerReview.levelOfReview, headerReview)
        })

    }

    useImperativeHandle<IDealHeaderInputTableComp, IDealHeaderInputTableComp>(ref, () => {
        return {
            copyValue(targetKeys, originKey) {
                gridApi.forEachNode(node => {
                    node.setData({
                        ...node.data,
                        ...targetKeys.reduce((p, key, i) => {
                            const levelOfReview = key === 'thirdReviewValue' ? 3 : key === 'secondReviewValue' ? 2 : 1
                            const { reviewField } = getReviewFields(key)
                            if (levelOfReview > node.data.levelOfReview) {
                                //skip this row if the header review level less than current target
                            } else {
                                p[key] = node.data[originKey]
                                p[reviewField] = !!node.data[originKey]
                            }
                            return p
                        }, {})
                    })
                })
            },
            getValues() {
                const result: IDataRow[] = []
                gridApi.forEachNode(node => {
                    result.push({
                        ...node.data,
                        isTie: checkIsFinalReviewValueTie(node.data, headerReview.levelOfReview, headerReview)
                    })
                })
                return result
            },
        }
    })

    return (
        <Grid<IDataRow>
            css={gridStyle}
            animateRows={true}
            onGridReady={e => setGridApi(e.api)}
            defaultColDef={defaultColumn}
            rowData={data}
            height={Math.min(data.length * 28 + 64, 600)} //footer + header + title
            columnDefs={columnDefs}
            onCellValueChanged={handleCellValueChanged}
            context={{ headerReview } as HeaderContextType}
            // suppressClickEdit={true}
            getRowId={({ data }) => data.loanId + ''}
            noRowsOverlayComponent={() => <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
            undoRedoCellEditing={true}
            allowContextMenuWithControlKey={true}
            onCellKeyDown={handleGridKeyDown}
            getContextMenuItems={({ column, node }) => {
                const isEditable = column.isCellEditable(node)
                return isEditable ? ['copy', 'paste'] : ['copy']
            }}
        />
    )
}

export default forwardRef(DataGrid)
