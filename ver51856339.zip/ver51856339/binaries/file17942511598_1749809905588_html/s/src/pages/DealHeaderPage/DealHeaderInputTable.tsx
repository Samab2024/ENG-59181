import { isNullOrEmpty } from "@/utils/stringHelper";
import { CopyOutlined } from "@ant-design/icons";
import { Button, Collapse, Empty } from "antd";
import { FC, RefObject, createRef, useEffect, useState } from "react";
import ReviewDataGrid, { IDealHeaderInputTableComp, InputColumnName } from "./ReviewDataGrid";
import { useAppSelector } from "@/hooks/reduxHook";
import { selectCurrentUser } from "@/redux/userSlice";
import modal from '@/utils/modal'

type SectionRefMap = { [key: number]: RefObject<IDealHeaderInputTableComp> }

const DealHeaderInputTable: FC<{
    isReadonly: boolean
    headerReview: API.IHeaderReview
    header: API.IHeader
    onSectionValueCopy: (headerReviewSections: API.IHeaderReviewSection) => void
    onReviewDataChange: (data: API.IHeaderReviewCell) => void
}> = ({ headerReview, header, onSectionValueCopy, onReviewDataChange, isReadonly }) => {
    const { isBlindReview, reviewSection } = headerReview ?? {}
    const [gridRefs, setGridRefs] = useState<SectionRefMap>({})
    const currentUser = useAppSelector(selectCurrentUser);

    useEffect(() => {
        if (reviewSection && reviewSection) {
            setGridRefs(reviewSection.reduce<SectionRefMap>((p, c, i) => {
                p[c.sourceDocSectionId] = createRef<IDealHeaderInputTableComp>()
                return p
            }, {}))
        }
    }, [reviewSection])

    const handleDuplicateValue = (e: any, section: API.IHeaderReviewSection) => {
        e.stopPropagation();

        // Some tricky logic here, eg.
        // secondReviewValue => [thirdReviewValue]
        // firstReviewValue => [secondReviewValue, thirdReviewValue]
        // clientValue => [firstReviewValue, secondReviewValue, thirdReviewValue]
        const propNames: InputColumnName[] = []
        let originKey: InputColumnName
        let message = ''
        if (header.reviewer3 === currentUser.email) {
            propNames.push('thirdReviewValue')
            originKey = 'secondReviewValue'
            message = '2nd review'
        }
        if (header.reviewer2 === currentUser.email) {
            propNames.push('secondReviewValue')
            originKey = 'firstReviewValue'
            message = '1st review'
        }
        if (header.reviewer1 === currentUser.email) {
            propNames.push('firstReviewValue')
            originKey = 'clientValue'
            message = 'client'
        }

        modal.confirm({
            title: 'Warning',
            content: `Are you sure you want to copy values from ${message} value?`,
            onOk: () => {
                gridRefs[section.sourceDocSectionId].current.copyValue(propNames, originKey)
                onSectionValueCopy({
                    ...section,
                    reviewData: gridRefs[section.sourceDocSectionId].current.getValues()
                })
            }
        })

    }

    if (reviewSection && reviewSection.length === 0) {
        return (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
        )
    }

    const isSectionAllowCopy = (section: API.IHeaderReviewSection) => !isReadonly && section.isAllowCopy
        && (!isBlindReview || isBlindReview && [header.reviewer2, header.reviewer3].includes(currentUser.email))
        && !isNullOrEmpty(section.permission)
        && [header.reviewer1, header.reviewer2, header.reviewer3].includes(currentUser.email)

    return reviewSection && (
        <Collapse bordered={false} defaultActiveKey={reviewSection.map((_, i) => i)} items={reviewSection.map((section, i) => ({
            key: i,
            label: <strong>{section.sourceDocSectionName}</strong>,
            extra: isSectionAllowCopy(section) && (
                <Button type="text" icon={<CopyOutlined />} onClick={(e) => handleDuplicateValue(e, section)} title="Duplicate values" />
            ),
            children: (
                <ReviewDataGrid
                    ref={gridRefs[section.sourceDocSectionId]}
                    isReadonly={isReadonly}
                    headerReview={headerReview}
                    data={section.reviewData}
                    permission={section.permission}
                    onChange={onReviewDataChange}
                />
            )
        }))} />
    )
}

export default DealHeaderInputTable