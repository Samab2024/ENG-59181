import { setUser } from '@/redux/userSlice'
import { useAppDispatch } from '@/hooks/reduxHook'
import LoginLayout from '@/components/LoginLayout'
import cacheStore from '@/utils/cacheStore'
import { Button } from 'antd'
import { FunctionComponent, useEffect, useState } from 'react'
import { redirect, useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import { bindActionCreators } from 'redux'
import AuthAPI from '@/services/api/AuthAPI'
import { css } from '@emotion/react'
import notification from '@/utils/notification'

const LoginPage: FunctionComponent = () => {
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState('')

    const navigate = useNavigate();
    const location = useLocation();
    const dispatch = useAppDispatch()

    const setCurrentUser = bindActionCreators(setUser, dispatch)

    const from = location.state?.from?.pathname || "/";
    const [params] = useSearchParams(location.state?.from?.search)
    const urlToken = params.get('token')

    const handleLoginClick = () => {
        setError('')
        window.open(`${AUTH_URL}?CallbackURL=${window.location.origin}/${APPLICATION_NAME}?`, "_self");
    }

    useEffect(() => {
        if (cacheStore.hasToken()) {
            //user enter login page by mistake, move user back
            navigate(from, { replace: true })
        }
        if (urlToken) {
            //login process
            setLoading(true)
            AuthAPI.login(urlToken)
                .then(({ userInfo }) => {
                    notification.success('Login successfully.')
                    setCurrentUser(userInfo)
                    // Send them back to the page they tried to visit when they were
                    // redirected to the login page. Use { replace: true } so we don't create
                    // another entry in the history stack for the login page. This means that
                    // when they get to the protected page and click the back button, they
                    // won't end up back on the login page, which is also really nice for the
                    // user experience.
                    // Since a redirect action, the url will alwasy stored in cache store
                    navigate(cacheStore.popReturnURL() || '/', { replace: true });
                })
                .catch(e => {
                    notification.error('Login failed.')
                    setError(e.message)
                })
                .finally(() => setLoading(false))
        } else {
            //store where user comes from
            cacheStore.setReturnURL(from)
        }
    }, [])

    return (
        <LoginLayout>
            <div>
                <Button type="primary" style={{ width: '200px', margin: '1rem auto' }} loading={loading} onClick={handleLoginClick}>PwC Identity Login</Button>
            </div>
            <div css={css`color:red;`}>
                {error}
            </div>
        </LoginLayout>
    )
}

export default LoginPage