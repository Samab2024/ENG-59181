import { GlobalToken, theme } from "antd"

const createStyle = <T>(callback: (token: GlobalToken) => T) => (): T => {
    const { token } = theme.useToken()
    return callback(token)
}

export default createStyle