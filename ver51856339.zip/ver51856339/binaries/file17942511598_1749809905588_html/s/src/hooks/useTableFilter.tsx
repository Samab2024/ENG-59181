import { Button, DatePicker, Input, InputRef, Space } from "antd";
import { ColumnType } from "antd/lib/table";
import { FilterDropdownProps } from "antd/lib/table/interface";
import React, { useMemo, useRef } from "react";

export const TextFilter = React.forwardRef<InputRef, FilterDropdownProps>(function TextFilter({ setSelectedKeys, selectedKeys, confirm, clearFilters }, ref) {
    return (
        <div style={{ padding: 8 }}>
            <Input
                ref={ref}
                placeholder={`Please input`}
                value={selectedKeys[0]}
                onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                onPressEnter={() => confirm && confirm()}
                style={{ marginBottom: 8, display: 'block' }}
            />
            <Space>
                <Button
                    type="primary"
                    onClick={() => confirm && confirm()}
                    size="small"
                    style={{ width: 100 }}
                >
                    Filter
                </Button>
                <Button onClick={() => {
                    clearFilters && clearFilters()
                    confirm && confirm()
                }} size="small" style={{ width: 80 }}>
                    Reset
                </Button>
            </Space>
        </div>
    )
})

type FilterPredicate<T> = (value: string | number | boolean, record: T) => boolean

/**
 * Create a set of text input filter options
 * @param predicate key of T, or a custom filter function to do the filter
 * @returns filter object, expand it in table column
 */
export default function <T>(predicate: keyof T | FilterPredicate<T>): Pick<ColumnType<T>, 'onFilter' | 'filterDropdown' | 'onFilterDropdownOpenChange'> {
    const filterPredicate: FilterPredicate<T> = typeof predicate === 'function' ? predicate :
        (value, record) =>
            record[predicate]
                ? (record[predicate] + '').toLowerCase().includes(('' + value).toLowerCase())
                : false
    const ref = useRef<InputRef>(null)
    return useMemo(() => ({
        filterDropdown: (props) => <TextFilter ref={ref} {...props} />,
        onFilter: filterPredicate,
        onFilterDropdownOpenChange: visible => {
            if (visible) {
                setTimeout(() => ref.current && ref.current.select(), 100);
            }
        },
    }), [predicate, ref])
}