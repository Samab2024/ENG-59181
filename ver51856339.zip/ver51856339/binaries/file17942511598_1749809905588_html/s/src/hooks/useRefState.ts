import { Dispatch, useRef, useState } from "react";

/**
 *  useState with an reference
 * @param initialState
 * @returns [ref, value, setValue]
 */
export function useRefState<S>(initialState: S): [React.MutableRefObject<S>, S, Dispatch<S>] {
    const ref = useRef<S>(initialState);
    const [value, setValue] = useState(initialState);
    const setValueAndRef = (value: S) => {
        ref.current = value;
        setValue(value);
    };
    return [ref, value, setValueAndRef];
}
