import { useCallback, useEffect, useRef } from 'react';
import { CustomFilterProps } from 'ag-grid-react';

export function useCustomGridFilter<T>(callback: (model: T) => void, props: CustomFilterProps<any, any, T>) {
    const updateModelRef = useRef(false);
    useEffect(() => {
        if (updateModelRef.current) {
            updateModelRef.current = false;
        } else {
            return callback(props.model);
        }
    }, [props.model]);
    const onModelChange = useCallback((model: T) => {
        updateModelRef.current = true;
        props.onModelChange(model);
    }, []);
    return { onModelChange };
}
