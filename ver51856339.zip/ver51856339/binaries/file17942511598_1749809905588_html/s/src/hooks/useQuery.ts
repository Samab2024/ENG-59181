import QueryString, { ParsedQs } from "qs";
import React from "react";
import { useLocation } from "react-router";

export default function useQuery<T extends ParsedQs = any>() {
    const { search } = useLocation();
    return React.useMemo(() => QueryString.parse(search.replace('?', '')) as T, [search]);
}