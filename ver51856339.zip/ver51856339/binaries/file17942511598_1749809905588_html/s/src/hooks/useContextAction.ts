import { Context, useContext, useEffect, useRef } from "react";

type Action<T, K extends keyof T> = T[K]

/**
 * Get a referenced context action which will not affect by closure.
 * @param context React Context
 * @param action Context Action need to reference
 * @returns Context Action
 */
const useContextAction: <T, K extends keyof T>(context: Context<T>, action: K) => Action<T, K> = <T>(context: Context<T>, action: keyof T): any => {
    const ctx = useContext(context)
    const fn = ctx[action] as any
    const ref = useRef(fn)
    useEffect(() => {
        ref.current = fn
    }, [fn])
    return (...args) => ref.current(...args)
}

export default useContextAction