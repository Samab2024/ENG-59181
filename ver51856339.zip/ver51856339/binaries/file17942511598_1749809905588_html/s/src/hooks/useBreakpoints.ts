import { useState } from "react"

export enum bps {
    xs = 0,
    sm,
    md,
    lg,
    xl
}

/**
 * breakpoint hook
 * @returns { breakpoint, updateBreakpoint, isLargerThan }
 */
export const useBreakpoints = () => {
    const [current, setCurrent] = useState<bps>(bps.xl)
    const updateBreakpoint = () => {
        const windowWidth = window.innerWidth
        if (windowWidth >= 1200) {
            setCurrent(bps.xl)
        } else if (windowWidth >= 992) {
            setCurrent(bps.lg)
        } else if (windowWidth >= 768) {
            setCurrent(bps.md)
        } else if (windowWidth >= 576) {
            setCurrent(bps.sm)
        } else {
            setCurrent(bps.xs)
        }
    }
    const isLargerThan = (bps: bps) => current > bps
    return {
        breakpoint: current,
        updateBreakpoint,
        isLargerThan
    }
}

export default useBreakpoints