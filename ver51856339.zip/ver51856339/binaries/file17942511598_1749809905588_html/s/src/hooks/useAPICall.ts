import notification from "@/utils/notification";
import { useCallback, useState } from "react"

/**
 * Wrapper function to simplify API call with loading state
 * WHEN TO USE: need to call a API separately, maybe triggered by user, maybe triggered by useEffect
 * WHEN NOT TO USE: call APIs by chain or call multiple APIs at the same time
 * @param fn Promise API call
 * @returns [loadingState, wrappedFunction]
 */
const useAPICall = <T extends (...args: any[]) => Promise<any>>(fn: T): [boolean, (...args: Parameters<T>) => ReturnType<T>] => {
    const [loading, setLoading] = useState(false)

    const caller = useCallback(async (...params: Parameters<T>) => {
        try {
            setLoading(true)
            const data = await fn(...params)
            return data
        } catch (ex) {
            notification.error((ex as API.IException).message)
        } finally {
            setLoading(false)
        }
    }, [])

    return [loading, caller as (...args: Parameters<T>) => ReturnType<T>]
}

export default useAPICall
