import { GridApi, RowDragEndEvent, RowDragMoveEvent } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { useCallback, useRef } from "react";

export type MoveToFn<T> = (rowData: T[], source: T, target: T) => T[]

function getRowData<T>(gridApi: GridApi<T>) {
    const result: T[] = []
    gridApi.forEachNode(node => result.push(node.data))
    return result
}

export function useDragTreeData<T>(gridRef: React.MutableRefObject<AgGridReact<T>>, moveData: MoveToFn<T>) {
    const originalRowData = useRef<T[]>()

    function rowDragOrDrop(event: RowDragMoveEvent<T> | RowDragEndEvent<T>) {
        const target = event.overNode?.data;
        const source = event.node.data;
        const rowData = getRowData(event.api);
        if (rowData && source && source !== target) {
            const newRowData = moveData(rowData, source, target);
            if (newRowData !== rowData) {
                event.api.setGridOption("rowData", newRowData);
            }
        }
    }

    const onRowDragEnter = useCallback(() => {
        originalRowData.current = getRowData(gridRef.current.api)
    }, [])
    const onRowDragMove = useCallback((event: RowDragMoveEvent<T>) => {
        rowDragOrDrop(event)
    }, []);
    const onRowDragEnd = useCallback((event: RowDragEndEvent<T>) => {
        rowDragOrDrop(event);
        event.api.clearFocusedCell();
        originalRowData.current = null
    }, []);
    const onRowDragCancel = useCallback(() => {
        if (originalRowData.current) {
            // Restore the original row data before the drag started
            gridRef.current.api.setGridOption("rowData", originalRowData.current);
            originalRowData.current = null;
        }
    }, []);

    return { onRowDragEnter, onRowDragMove, onRowDragEnd, onRowDragCancel }
}