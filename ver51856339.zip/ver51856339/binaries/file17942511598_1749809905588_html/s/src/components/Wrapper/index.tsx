import { css } from '@emotion/react'
import { Col, Divider, Row, Space, Typography, theme } from 'antd'
import React, { FC, PropsWithChildren, ReactNode } from 'react'
import useStyle from './style'

type T_div = React.PropsWithChildren<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>>

const isPropertyExist = (property: any) => property !== undefined && property !== false

export const Nav: FC<React.PropsWithChildren> = ({ children }) => {
    const { nav } = useStyle()
    return (
        <div css={nav} >
            {children}
        </div>
    )
}

export const HeadRow: FC<PropsWithChildren<{
    icon?: ReactNode
    title: ReactNode
    expandContent?: boolean
}>> = ({ children, icon, title, expandContent }) => {
    const { headRow } = useStyle()
    return (
        <Row justify="space-between" align="middle" css={headRow}>
            <Col>
                <Space>
                    {icon}
                    {icon && <Divider type="vertical" style={{ height: '28px', borderColor: '#CCC', margin: '0' }} />}
                    <Typography.Title level={4} style={{ margin: 0 }}>{title}</Typography.Title>
                </Space>
            </Col>
            <Col flex={expandContent ? 'auto' : 'none'}>
                {children}
            </Col>
        </Row>
    )
}

export const PageContainer: FC<React.PropsWithChildren> = ({ children }) => {
    const { pageContainer } = useStyle()
    return (
        <div css={pageContainer}>
            {children}
        </div>
    )
}

export const ListContainer: FC<{ height?: number, noStyle?: boolean } & T_div> = ({ height = '100', children, noStyle, ...props }) => {
    const { listContainer } = useStyle()
    const { token } = theme.useToken()
    const sty = isPropertyExist(height) ? { '--height': height + 'px' } as React.CSSProperties : undefined
    return (
        <div css={css(listContainer, {
            boxShadow: !noStyle && token.boxShadowTertiary,
            marginBottom: !noStyle && '1rem'
        })} style={sty} {...props}>
            {children}
        </div>
    )
}

export default {
    Nav,
    HeadRow,
    PageContainer,
    ListContainer,
}