import createStyle from "@/hooks/createStyle"
import { css } from "@emotion/react"

const useStyle = createStyle(token => ({
    nav: css({
        backgroundColor: token.colorBgContainer,
        padding: `0 ${token.padding}px`,
        zIndex: token.zIndexBase,
        boxShadow: token.boxShadow
    }),
    pageContainer: css({
        padding: `0 ${token.padding}px`,
        marginTop: token.margin,
    }),
    listContainer: css({
        '--height': '100px',
        maxHeight: 'var(--height)',
        overflowY: 'auto'
    }),
    headRow: css({
        // marginTop: token.margin,
        // marginBottom: token.margin,
        marginTop: '6px',
        marginBottom: '6px'
    })
}))

export default useStyle