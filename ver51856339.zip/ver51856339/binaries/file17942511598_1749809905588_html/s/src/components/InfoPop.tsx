import { css } from '@emotion/react'
import { Popover, theme } from 'antd'
import { TooltipPlacement } from 'antd/lib/tooltip'
import { FIImage } from 'functional-icons/lib/Outline'
import React, { FC, ReactNode } from 'react'
import IconButton from './IconButton'
import Text from './Text'

const InfoPop: FC<{
    title?: string
    content: ReactNode | string[]
    width?: number
    textInline?: boolean
    buttonStyle?: React.CSSProperties
    placement?: TooltipPlacement
}> = ({ title, content, width = 300, textInline, buttonStyle = { verticalAlign: "middle", color: 'white' }, placement = 'right' }) => {
    const { token } = theme.useToken()
    let text
    if (typeof content === 'string') {
        text = <p style={{ whiteSpace: "pre-line" }} css={css`
        :last-child{
            margin-bottom: 0;
        }`}>{content}</p>
    } else if (Array.isArray(content)) {
        text = content.map((x, i) => <p css={css`
        :last-child{
            margin-bottom: 0;
        }`} key={i}>{x}</p>)
    } else {
        text = content
    }
    return (
        <Popover overlayClassName="info-pop" trigger={textInline ? 'hover' : 'click'} content={
            <div style={{ maxWidth: width + 'px' }} className="info-pop-content">
                {title && <Text.Header1>{title}</Text.Header1>}
                {text}
            </div>
        } placement={placement}>
            {textInline ?
                <FIImage style={{ cursor: 'pointer', marginLeft: '4px' }} /> :
                <IconButton type="primary" shape="circle" size="small" icon={FIImage} style={buttonStyle} />
            }
        </Popover>
    )
}

export default InfoPop