import { css } from "@emotion/react";
import createStyle from "@/hooks/createStyle";
import logo from '@/assets/pwc_micro_logo.svg'

const useStyle = createStyle(token => ({
    appHeader: css`
        display: flex;
        z-index: ${token.zIndexPopupBase};
        box-shadow: ${token.boxShadowSecondary};
    `,
    logoContainer: css`
        flex: 0 0 auto;
        padding: 0;
        display: flex;
        align-items: center;
    `,
    pwcLogo: css`
        height: 50px;
        width: 50px;
        background-image: url("${logo}");
        background-repeat: no-repeat;
        background-size: 50px;
        background-origin: border-box;
        background-position-y: center;
    `,
    divider: css`
        height: 20px;
    `,
    title: css`
        font-weight: bold;
        vertical-align: middle;
        color: ${token.colorText};
    `,
    contentContainer: css`
        flex: 1;
        padding: 0 12px;
    `,
    settingContainer: css`
        flex: 0 0 auto;
        display: flex;
        padding: 0;
    `,
}))

export default useStyle