import * as controlStyles from '@/styles/control.module.css'
import * as displayStyles from '@/styles/display.module.css'
import SettingBox from '../SettingBox'
import { Divider, Layout, Space, Typography } from 'antd'
import React, { FunctionComponent } from 'react'
import useStyle from './style'

export const Header: FunctionComponent<React.PropsWithChildren<{
    onHeaderClick?: React.MouseEventHandler,
}>> = ({ onHeaderClick, children }) => {
    const styles = useStyle()
    return (
        <Layout.Header css={styles.appHeader}>
            <Space align="center">
                <div css={styles.pwcLogo}></div>
                <Divider css={styles.divider} type="vertical" />
                <div className={displayStyles.flex1}>
                    <Typography.Text role="link" css={styles.title} className={controlStyles.pointer} onClick={onHeaderClick}>Due Diligence</Typography.Text>
                </div>
            </Space>
            <div css={styles.contentContainer}>
                {children}
            </div>
            <div css={styles.settingContainer}>
                <SettingBox />
            </div>
        </Layout.Header >
    )
}

export default Header