import * as displayStyles from '@/styles/display.module.css'
import { css } from '@emotion/react'
import { Col, Layout, Row } from 'antd'
import React, { FC } from 'react'
import useStyle from './style'
import Footer from '../Footer'

const LoginLayout: FC<React.PropsWithChildren> = ({ children }) => {
    const { loginBg, pwcLogo, leftPanel, flexPanel } = useStyle()

    return (
        <Layout className={displayStyles.wholeScreen} >
            <Layout.Content>
                <Row>
                    <Col span={8} css={css`
                        ${flexPanel};
                        ${leftPanel};
                    `}>
                        <div>
                            <div css={pwcLogo} />
                        </div>
                        <h1>Login to Due Diligence</h1>
                        {children}
                    </Col>
                    <Col span={16} css={flexPanel}>
                        <div css={loginBg} />
                        <div className={displayStyles.flex0} >
                            <Footer />
                        </div>
                    </Col>
                </Row>
            </Layout.Content>
        </Layout>
    )
}

export default LoginLayout