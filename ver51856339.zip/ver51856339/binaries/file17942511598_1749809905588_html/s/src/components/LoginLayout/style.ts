import createStyle from "@/hooks/createStyle";
import { css } from "@emotion/react";
import logo from '@/assets/pwc_micro_logo.svg'
import bg from '@/assets/PwC_Repre_Illus_Iso_Data-Analysis-Research.png'

const useStyle = createStyle(token => ({
    pwcLogo: css`
        display: inline-block;
        height: 100px;
        width: 100px;
        background-image: url("${logo}");
        background-repeat: no-repeat;
        background-size: 100px;
        background-origin: border-box;
        background-position-y: center;
    `,
    loginBg: css`
        flex: 1;
        background-image: url('${bg}');
        background-repeat: no-repeat;
        background-size: 500px;
        background-origin: border-box;
        background-position-y: center;
        background-position-x: center;
    `,
    flexPanel: css`
        display: flex;
        flex-direction: column;
    `,
    leftPanel: css`
        background-color: ${token.colorBgContainer};
        min-height: 100vh;
        border-right: 1px solid ${token.colorBorder};
        text-align: center;
        justify-content: center;
    `,
}))

export default useStyle