import createStyle from "@/hooks/createStyle"
import { css } from "@emotion/react"
import { ForwardRefRenderFunction, forwardRef, useEffect, useImperativeHandle, useRef } from "react"
import * as monaco from 'monaco-editor/esm/vs/editor/editor.api'
import type * as Monaco from 'monaco-editor/esm/vs/editor/editor.api'

export type CompletionItem = {
    item: string
    label: string
    level: 'deal' | 'loan'
}

export type EditorProps = {
    value: string
    completionItems?: CompletionItem[]
    onChange?: (value: string) => void
}

export type CodeEditorRef = {
    getValue: () => string
    setValue: (value: string) => void
}

const useStyle = createStyle(() => ({
    container: css`
        min-height: 120px;
        height: 100%;
    `
}))

const CodeEditor: ForwardRefRenderFunction<CodeEditorRef, EditorProps> = (props, ref) => {
    const styles = useStyle()
    const containerRef = useRef<HTMLDivElement>()
    const editorRef = useRef<Monaco.editor.IStandaloneCodeEditor>()

    const handleChangeModelContent = (e: Monaco.editor.IModelContentChangedEvent) => {
        typeof props.onChange == 'function' && props.onChange(editorRef.current.getValue())
    }

    useImperativeHandle(ref, () => ({
        getValue: () => {
            return editorRef.current.getValue()
        },
        setValue: value => {
            editorRef.current.setValue(value)
        }
    }))

    useEffect(() => {

        const completionProvider = monaco.languages.registerCompletionItemProvider("python", {
            'provideCompletionItems': function (model, position) {
                const word = model.getWordUntilPosition(position);
                const range = {
                    startLineNumber: position.lineNumber,
                    endLineNumber: position.lineNumber,
                    startColumn: word.startColumn,
                    endColumn: word.endColumn,
                };
                const suggestions = [
                    ...props.completionItems.map<monaco.languages.CompletionItem>(x => ({
                        label: x.item,
                        detail: x.label,
                        kind: monaco.languages.CompletionItemKind.Variable,
                        insertText: x.level == 'deal' ? x.item : `loan[row].${x.item}`,
                        range,
                    })),
                    {
                        label: "IF",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "IF(${1:condition}, lambda: ${2:true}, lambda: ${3:false})",
                        detail: 'IF(logical_test, [value_if_true], [value_if_false])',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "OR",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "OR(${1:logical1}, ${2:logical2})",
                        detail: 'OR(logical1, [logical2], ...)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "SUM",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "SUM($1, $2)",
                        detail: 'SUM(number1, [number2], ...)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "CEILING",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "CEILING(${1:number}, ${2:significance})",
                        detail: 'CEILING(number, significance)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "FLOOR",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "FLOOR(${1:number}, ${2:significance})",
                        detail: 'FLOOR(number, significance)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "FV",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "FV(${1:rate}, ${2:nper}, ${3:pmt}, ${4:pv}, ${5:type})",
                        detail: 'FV(rate, nper, pmt, [pv], [type])',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "TEXT",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "TEXT(${1:value}, ${2:format_text})",
                        detail: 'TEXT(value, format_text)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "DIV",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "DIV($1, $2)",
                        detail: 'DIV(number1, number2)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "MAX",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "MAX($1, $2)",
                        detail: 'MAX(number1, [number2], ...)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "MIN",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "MIN($1, $2)",
                        detail: 'MIN(number1, [number2], ...)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "ROUND",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "ROUND(${1:number}, ${2:digits})",
                        detail: 'ROUND(number, num_digits)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "DATEDIF",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "DATEDIF(${1:start_date}, ${2:end_date}, ${3:unit})",
                        detail: 'DATEDIF(start_date, end_date, [unit])',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "DAYS360",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "DAYS360(${1:start_date}, ${2:end_date}, ${3:method})",
                        detail: 'DAYS360(start_date, end_date, [method])',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "AMORTSCHEDULE",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "AMORTSCHEDULE(${1:AmortizationTermRemain}, ${2:OriginalLoanAmount}, ${3:MaturityDate}, ${4:GrossInterestRate}, ${5:Seasoning}, ${6:IOPeriod}, ${7:CutoffDate})",
                        detail: 'AMORTSCHEDULE(AmortizationTermRemain, OriginalLoanAmount, MaturityDate, GrossInterestRate, Seasoning, IOPeriod, CutoffDate)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "SUMIF",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "SUMIF(${1:range}, ${2:criteria}, ${3:sum_range})",
                        detail: 'SUMIF(range, criteria, [sum_range])',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "AND",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "AND(${1:logical1}, ${2:logical2})",
                        detail: 'AND(logical1, [logical2], ...)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "MROUND",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "MROUND(${1:number}, ${2:multiple})",
                        detail: 'MROUND(number, multiple)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "PMT",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "PMT(${1:rate}, ${2:nper}, ${3:pv}, ${4:fv}, ${5:type})",
                        detail: 'PMT(rate, nper, pv, [fv], [type])',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "IFERROR",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "IFERROR(${1:value}, ${2:value_if_error})",
                        detail: 'IFERROR(value, value_if_error)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "YEAR",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "YEAR(${1:serial_number})",
                        detail: 'YEAR(serial_number)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "MONTH",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "MONTH(${1:serial_number})",
                        detail: 'MONTH(serial_number)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "DAY",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "DAY(${1:serial_number})",
                        detail: 'DAY(serial_number)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "SUMPARENTNODE",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "SUMPARENTNODE(${1:sum_range})",
                        detail: 'SUMPARENTNODE(sum_range)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "SUMCHILDNODES",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "SUMCHILDNODES(${1:sum_range})",
                        detail: 'SUMCHILDNODES(sum_range)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "STR",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "STR(${1:value})",
                        detail: 'STR(value)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                    {
                        label: "NUMBER",
                        kind: monaco.languages.CompletionItemKind.Function,
                        insertText: "NUMBER(${1:value})",
                        detail: 'NUMBER(value)',
                        insertTextRules:
                            monaco.languages.CompletionItemInsertTextRule
                                .InsertAsSnippet,
                        range: range,
                    },
                ] as monaco.languages.CompletionItem[];
                return { suggestions: suggestions };
            },
        });

        editorRef.current = monaco.editor.create(containerRef.current, {
            value: props.value,
            language: 'python',
            theme: 'vs',
            minimap: { enabled: false },
            wordWrap: "on",
            automaticLayout: true,
        });

        editorRef.current.onDidChangeModelContent(handleChangeModelContent)

        return () => {
            completionProvider.dispose()
            editorRef.current.dispose()
        }

    }, [])

    return (
        <div ref={containerRef} id="script-container" css={styles.container} />
    )
}

export default forwardRef(CodeEditor)