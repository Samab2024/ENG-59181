import { IS_DEBUG } from '@/config'
import createStyle from '@/hooks/createStyle'
import * as displayStyles from '@/styles/display.module.css'
import { css } from '@emotion/react'
import { Affix, Layout } from 'antd'
import { Footer } from 'antd/lib/layout/layout'
import React, { FunctionComponent, ReactNode } from 'react'
import FooterContent from '../Footer'
import Header from '../Header'
const { Sider, Content } = Layout

type T_RC = ReactNode

export interface HeaderProps {
    content?: T_RC
    onTitleClick?: React.MouseEventHandler
}

export interface LayoutProps {
    header?: HeaderProps,
    sider?: T_RC
}

const useStyle = createStyle(() => css({
    minHeight: 'calc(100vh - 130px)'
}))

export const DefaultLayout: FunctionComponent<React.PropsWithChildren<LayoutProps>> = ({ header, sider, children }) => {
    const contentStyle = useStyle()
    return (
        <Layout className={displayStyles.wholeScreen}>
            <Header onHeaderClick={header?.onTitleClick} >{header?.content}</Header>
            <Layout>
                {sider &&
                    <Sider width={315}>
                        <Affix>
                            {sider}
                        </Affix>
                        {!IS_DEBUG && <span style={{ position: "fixed", left: 0, bottom: 0, fontSize: 8, color: '#464646' }}>{BUILD_NO}</span>}
                    </Sider>
                }
                <Layout>
                    <Content css={contentStyle}>
                        {children}
                    </Content>
                    <Footer>
                        <FooterContent />
                    </Footer>
                </Layout>
            </Layout>
        </Layout>
    )
}

export default DefaultLayout