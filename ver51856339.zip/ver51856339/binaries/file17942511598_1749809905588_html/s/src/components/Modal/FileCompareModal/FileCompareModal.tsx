import ImportAPI from "@/services/api/ImportAPI"
import SellerAPI from "@/services/api/SellerAPI"
import nameOfData from "@/utils/nameOfData"
import { Button, Form, Input, Modal, Select, Spin, Upload, Typography } from 'antd'
const { Text } = Typography;
import { AssetType } from "@/constants"
import notification from '@/utils/notification'
import { ResultStatusType } from 'antd/lib/result'
import { UploadFile } from 'antd/lib/upload/interface'
import { FunctionComponent, useContext, useState, useEffect } from 'react'
import { useParams } from "react-router-dom";
import useStyle from './FileCompareModal.style';
import InfoPop from "@/components/InfoPop";
import { isNullOrEmpty } from "@/utils/stringHelper";

interface IUploadForm {
    clientFiles: UploadFile[],
    pwcFiles: UploadFile[],
}

export enum UploadStage {
    Input,
    Loading,
    Result
}

export interface IUploadResult {
    status: ResultStatusType
    message: string
    error?: string
}


const FileCompareModal: FunctionComponent<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {
    const [stage, updateStage] = useState<UploadStage>(UploadStage.Input)
    const [form] = Form.useForm<IUploadForm>()
    const [clientFileName, updateClientFileName] = useState<string>()
    const [pwcFileName, updatePwcileName] = useState<string>()
    const style = useStyle()


    const handleCancel = () => {
        form.resetFields();
        updateClientFileName("");
        updatePwcileName("");
        onClose();
    }

    const handleGenerateReport = () => {
        form.validateFields()
            .then(value => {
                updateStage(UploadStage.Loading);
                ImportAPI.compareFile(value.clientFiles[0].originFileObj, value.pwcFiles[0].originFileObj)
                    .then(x => {
                        notification.success("Generate exception report successfully.")
                        handleCancel();
                    })
                    .catch(e => notification.error((e as API.IException).message, { duration: 5 }))
                    .finally(() =>
                        updateStage(UploadStage.Input)
                    );
            }).catch((errorInfo) => {
                updateStage(UploadStage.Input)
                console.log('Validation error:', errorInfo);
            });
    }

    const clientNormFile = (e: any) => {
        updateClientFileName(e.fileList[0].name)
        if (Array.isArray(e)) {
            return e;
        }
        return e && e.fileList;
    }

    const pwcNormFile = (e: any) => {
        updatePwcileName(e.fileList[0].name)
        if (Array.isArray(e)) {
            return e;
        }
        return e && e.fileList;
    }

    return (
        <Modal
            css={style}
            open={open}
            title={"File Compare"}
            maskClosable={false}
            onCancel={handleCancel}
            footer={<div className="text-align-right">
                <Button onClick={handleCancel}>Cancel</Button>
                <Button type="primary" disabled={isNullOrEmpty(clientFileName) || isNullOrEmpty(pwcFileName)} onClick={handleGenerateReport}>Generate Exception Report</Button>
            </div>}>

            {stage === UploadStage.Input && <Form layout="vertical" className='upload-form' form={form}>
                <span className="select-client-file">
                    <label>Client: </label>
                    <Input placeholder='.xlsx file' value={clientFileName} disabled />
                    <Form.Item rules={[{ required: true, message: 'Please select a file' }]} valuePropName="fileList" name={nameOfData<IUploadForm>("clientFiles")} getValueFromEvent={clientNormFile} >
                        <Upload showUploadList={false} accept='.xlsx' beforeUpload={() => false} multiple={false} maxCount={1}>
                            <Button>BROWSE</Button>
                        </Upload>
                    </Form.Item>
                </span>

                <span className="select-pwc-file">
                    <label>PwC: </label>
                    <Input placeholder='.xlsx file' value={pwcFileName} disabled />
                    <Form.Item rules={[{ required: true, message: 'Please select a file' }]} valuePropName="fileList" name={nameOfData<IUploadForm>("pwcFiles")} getValueFromEvent={pwcNormFile} >
                        <Upload showUploadList={false} accept='.xlsx' beforeUpload={() => false} multiple={false} maxCount={1}>
                            <Button>BROWSE</Button>
                        </Upload>
                    </Form.Item>
                </span>
            </Form>}

            {stage === UploadStage.Loading && <Spin spinning={true} tip={"Generating..."} ><div style={{ height: '70px' }}></div></Spin>}

        </Modal>
    )
}

export default FileCompareModal
