import Grid from "@/components/Grid";
import EditableCellRender from "@/components/Grid/editableCellRender";
import selectCellEditor, { ISelectCellEditorProps, suppressSelectKeyboardEvent } from "@/components/Grid/selectCellEditor";
import SelectCellRender, { ISelectCellRenderProps } from "@/components/Grid/selectCellRender";
import { FORMAT_TYPE_OPTIONS, FormatTypeEnum } from "@/constants";
import HeaderMapAPI from "@/services/api/HeaderMapAPI";
import { flexJustifyEnd } from '@/styles/display.module.css';
import notification from '@/utils/notification';
import { convertToDayjsFormat, convertToNumeralFormat, getFormatedValue } from "@/utils/stringHelper";
import { CellValueChangedEvent, ColDef, GridApi, ICellRendererParams, IRowNode, RowClickedEvent, RowDragEvent } from "ag-grid-community";
import { Button, Card, Col, Empty, Input, Modal, Row, Spin, Typography } from "antd";
import { FIDelete, FIPlus } from "functional-icons/lib/Outline";
import { FC, forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { useModalStyle } from ".";
import CustomHeaderToolTip, { ICustomHeaderParams } from "@/components/Grid/customHeaderToolTip";

type IDataRow = API.IDataFormat & { isSelected?: boolean }
type TestCardRef = { set: (value: API.IDataFormat) => void }

const FormatMangementModal: FC<{
    open: boolean
    onClose: () => void
}> = ({ open, onClose }) => {

    const modalStyle = useModalStyle()

    const [modal, modalContext] = Modal.useModal()
    const [gridApi, setGridApi] = useState<GridApi<IDataRow>>()
    const testRef = useRef<TestCardRef>()

    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (open && gridApi) {
            setLoading(true);
            HeaderMapAPI.getDataFormats()
                .then((data) => {
                    if (data.length) {
                        const sortedData = data.sort((a, b) => a.displayOrder - b.displayOrder)
                        gridApi.applyTransaction({
                            add: sortedData.map((x, i) => ({
                                ...x,
                                isSelected: i === 0 //Default select first record
                            }))
                        })
                        testRef.current?.set(data[0])
                    } else {
                        gridApi.showNoRowsOverlay()
                    }
                })
                .finally(() => {
                    setLoading(false);
                });
        }

    }, [open, gridApi])


    const [columnDefs] = useState<ColDef<IDataRow>[]>([
        {
            colId: 'displayOrder',
            field: "displayOrder",
            headerName: 'Order',
            width: 50,
            rowDrag: true
        },
        {
            colId: 'name',
            field: "name",
            headerName: 'Format Name',
            editable: ({ data }) => data.isEditable,
            cellRenderer: EditableCellRender,
        },
        {
            colId: 'type',
            field: "type",
            headerName: 'Format Type',
            editable: ({ data }) => data.isEditable,
            cellRenderer: SelectCellRender,
            cellRendererParams: {
                options: FORMAT_TYPE_OPTIONS
            } as ISelectCellRenderProps,
            cellEditor: selectCellEditor,
            cellEditorParams: {
                options: FORMAT_TYPE_OPTIONS
            } as ISelectCellEditorProps,
            suppressKeyboardEvent: suppressSelectKeyboardEvent,
        },
        {
            colId: 'format',
            field: "format",
            headerComponent: CustomHeaderToolTip,
            headerComponentParams: {
                displayName: 'Format',
                tooltipText: 'Plase make sure the format works in Excel first.'
            } as ICustomHeaderParams,
            editable: ({ data }) => data.isEditable,
            cellRenderer: EditableCellRender,
        },
        {
            colId: 'action',
            width: 25,
            headerName: '',
            suppressAutoSize: true,
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: ({ api, data, context }: ICellRendererParams<IDataRow>) => data.isEditable && <Button type="text" icon={<FIDelete />} title="Delete" onClick={(e) => (e.preventDefault(), modal.confirm({
                title: 'Are you sure to delete this item?',
                onOk: () => {
                    const updatedRows: IDataRow[] = []
                    api.forEachNode(node => {
                        if (node.data.dataFormatId !== data.dataFormatId) {
                            updatedRows.push(node.data)
                        }
                    })
                    updatedRows.forEach((x, i) => x.displayOrder = i + 1)
                    api.applyTransaction({ remove: [data], update: updatedRows })

                    //clear selectedFormat if current row selected
                    if (data.isSelected) {
                        context.testRef.current?.set(null)
                    }
                }
            }))} /> || null
        }
    ])

    const handleSave = () => {
        //find out current selected row
        const data: API.IDataFormat[] = []
        gridApi.forEachNode((row => {
            const rowData: IDataRow = { ...row.data }
            delete rowData.isSelected
            data.push(rowData)
        }))

        if (data.find(x => !x.name)) {
            notification.error("Format Name column is required, either fill in name or remove empty item.")
            return
        }

        if (data.find(x => !x.type)) {
            notification.error("Format Type column is required, either fill in type or remove empty item.")
            return
        }

        if (data.find(x => !x.format)) {
            notification.error("Format column is required, either fill in format or remove empty item.")
            return
        }

        if ([...new Set(data.map(x => x.name))].length !== data.length) {
            notification.error("Duplicated name found.")
            return
        }
        setLoading(true);
        HeaderMapAPI.updateDateFormats(data)
            .then(() => {
                notification.success("Save format successfully.")
                setLoading(false);
                onClose()
            })
            .catch(e => notification.error((e as API.IException).message))
            .finally(() => setLoading(false));
    }

    const handleRowDragEnd = (e: RowDragEvent) => {
        // If move to first item, move down one position(first item should always be a section)
        if (e.overIndex === 0) {
            e.api.applyTransaction({
                remove: [e.node.data],
                add: [e.node.data],
                addIndex: 1
            })
        }

        e.api.forEachNode((node, index) => {
            node.setData({
                ...node.data,
                displayOrder: index + 1
            })
            index++
        })
    }

    const handleRowSelect = (e: RowClickedEvent<IDataRow, any>) => {
        //prevent click event on delete button
        if (e.event.defaultPrevented) return

        //find out current selected row
        let currentRowNode: IRowNode<IDataRow>
        e.api.forEachNode((row => {
            if (row.data.isSelected) {
                currentRowNode = row
            }
        }))

        //update existing row
        if (currentRowNode) {
            currentRowNode.setData({
                ...currentRowNode.data,
                isSelected: false,
            })
        }

        //select current row
        e.node.setData({
            ...e.data,
            isSelected: true
        })

        e.context.testRef.current?.set(e.data)

    }

    const handleCellValueChanged = ({ colDef, node, value, data, context }: CellValueChangedEvent<IDataRow>) => {
        if (colDef.field === 'format') {
            if (data.type === FormatTypeEnum.IsDateTime) {
                const formatCode = convertToDayjsFormat(value)
                node.setData({
                    ...node.data,
                    code: formatCode
                })
            } else if (data.type === FormatTypeEnum.IsNumeric) {
                const formatCode = convertToNumeralFormat(value)
                node.setData({
                    ...node.data,
                    code: formatCode
                })
            } else {
                node.setData({
                    ...node.data,
                    code: value
                })
            }
        }

        if (data.isSelected) {
            context.testRef.current?.set(node.data)
        }
    }

    const handleAddClick = () => {
        const displayOrders: number[] = []
        const ids: number[] = []
        gridApi.forEachNode(node => {
            displayOrders.push(node.data.displayOrder)
            if (node.data.dataFormatId < 0) {
                ids.push(node.data.dataFormatId)
            }
        })
        gridApi.applyTransaction({
            add: [{
                categoryOptionId: (ids.length > 0 ? Math.min(...ids) : 0) - 1,
                displayOrder: (displayOrders.length && Math.max(...displayOrders) || 0) + 1,
                isEditable: true,
            } as Partial<IDataRow>] as any
        })
    }

    return (
        <Modal
            open={open}
            onCancel={onClose}
            title="Format"
            style={{ top: 50 }}
            width={800}
            destroyOnClose={true}
            footer={<div>
                <Button onClick={onClose}>Cancel</Button>
                <Button type="primary" onClick={handleSave}>SAVE</Button>
            </div>}>
            <div css={modalStyle}>
                <div className={flexJustifyEnd}>
                    <Button type="link" icon={<FIPlus />} onClick={handleAddClick}>Add Format</Button>
                </div>
                <div style={{ marginBottom: 16 }}>
                    <Spin spinning={loading}>
                        <Grid<IDataRow>
                            height={300}
                            rowDragManaged={true}
                            onRowDragEnd={handleRowDragEnd}
                            onRowClicked={handleRowSelect}
                            suppressDragLeaveHidesColumns={true}
                            animateRows={true}
                            rowClassRules={{
                                'selected-row': ({ data, node }) => data.isSelected
                            }}
                            onCellValueChanged={handleCellValueChanged}
                            onGridReady={e => setGridApi(e.api)}
                            onFirstDataRendered={({ api }) => api.sizeColumnsToFit()}
                            getRowId={({ data }) => data.dataFormatId + ''}
                            columnDefs={columnDefs}
                            context={{ testRef }}
                            noRowsOverlayComponent={() => <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
                        />
                    </Spin>
                </div>
                    <TestCard ref={testRef} />
                </div>
                {modalContext}
            </Modal>
        )
    }

const TestCard = forwardRef<TestCardRef>(function TC(_, ref) {
    const [selectedFormat, setSelectedFormat] = useState<API.IDataFormat>()
    const [inputValue, setInputValue] = useState<string>()

    const formatResult = useMemo(() => {
        return getFormatedValue(inputValue, selectedFormat?.type, selectedFormat?.code)
    }, [inputValue, selectedFormat])

    useImperativeHandle(ref, () => ({
        set: (value) => {
            setSelectedFormat(value)
        }
    }))

    return (
        <Card>
            <Typography.Text>Test the format:</Typography.Text>
            <Row style={{ marginTop: 8 }}>
                <Col span={2}>
                    <Typography.Text type="secondary">Format:</Typography.Text>
                </Col>
                <Col>
                    <Typography.Text code>{selectedFormat?.format}</Typography.Text>
                    <Typography.Text code>{selectedFormat?.code}</Typography.Text>
                </Col>
            </Row>
            <Row style={{ marginTop: 8 }}>
                <Col span={2}>
                    <Typography.Text type="secondary">Input:</Typography.Text>
                </Col>
                <Col>
                    <Input style={{ display: 'inline-block', width: 200 }} placeholder="Type something to test the format" value={inputValue} onChange={e => setInputValue(e.target.value)} />
                </Col>
            </Row>
            <Row style={{ marginTop: 8 }}>
                <Col span={2}>
                    <Typography.Text type="secondary">Result:</Typography.Text>
                </Col>
                <Col>
                    <Typography.Text code>{formatResult}</Typography.Text>
                </Col>
            </Row>
        </Card>
    )
})

export default FormatMangementModal