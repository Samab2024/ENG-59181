import { css } from '@emotion/react';
import createStyle from '@/hooks/createStyle';
const useStyle = createStyle(token => css`
    div.ant-modal-body {
        padding-bottom: 8px;
        padding-left: 12px;
        padding-right: 12px;
        padding-top: 0px;

        div.ant-form-item{
            margin-bottom: 2px;
        }
    }

    div.ant-modal-header {
        padding: 8px 12px;
    }

    div.ant-modal-footer{
        padding-top: 8px;
    }

    span label{
        padding-right: 8px;
        padding-top: 2px;
    }
    span.select{
        display: flex;
        margin-top: 8px;
    }

    .upload-form{
        span.select-client-file, span.select-pwc-file{
            display: flex;

            .ant-row{
                margin-top: 1px;
            }

            div.ant-input {
                height: 24px;
                cursor: default;
                border: 1px solid #d9d9d9;
            }
            .ant-btn {
                margin-left: 12px;
            }
        }

        span.select-client-file{
            div.ant-input {
                width: 380px;
            }
        }

        span.select-pwc-file{
            display: flex;
            margin-top: 8px;

            input {
                width: 380px;
                margin-left: 6px;
            }
        }
    }


    div.notice {
        margin-top: 8px;

        a {
            color: #2295f2;
            font-size: 14px;
        }
    }

    .ant-checkbox-wrapper {
        margin-top: 16px;
    }
    div.progress {
        margin-top: 28px;
    }
    div.error-message {
        margin-top: 20px;

        pre {
            white-space: pre-wrap;
            width: 95%;
        }
    }
`)

export default useStyle