import createStyle from '@/hooks/createStyle'
import { css } from '@emotion/react'

export { default } from './FormatMangementModal'

export const useModalStyle = createStyle((token) => css`
    .selected-row {
        background-color: ${token.controlItemBgActive};
        font-weight: bold;
    }
`)
