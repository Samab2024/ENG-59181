import createStyle from "@/hooks/createStyle";
import { css } from "@emotion/react";
import { FC } from "react";

const useStyle = createStyle((token) => css`
    text-align: center;
    color: ${token.colorTextSecondary};
    font-size: 12px;
`)

const Footer: FC = () => {
    const style = useStyle()
    return (
        <div css={style}>
            &copy; {(new Date()).getFullYear()} PwC. All rights reserved. PwC refers to the US member firm of the PwC network or one of its subsidiaries or affiliates.
        </div>
    )
}

export default Footer