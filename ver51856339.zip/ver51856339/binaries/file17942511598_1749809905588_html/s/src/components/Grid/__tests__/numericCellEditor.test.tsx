import numericCellEditor, { INumericCellEditorProps } from "../numericCellEditor"
import { generateEditorTestSuite } from "./utils"

describe('numericCellEditor', () => {
    generateEditorTestSuite('default config', numericCellEditor, {}, [
        { input: '123456.789', expect: '123456.789' },
        { input: '-123456.789', expect: '123456.789' },
        { input: '$123,456.789', expect: '123456.789', method: 'paste' },
        { input: '-$123,456.789', expect: '', method: 'paste' },
        { input: 'foo', expect: '' },
        { input: 'foo', expect: '', method: 'paste' }
    ])

    generateEditorTestSuite('isIntegerOnly=true', numericCellEditor, { isIntegerOnly: true } as INumericCellEditorProps, [
        { input: '123456.789', expect: '123456' },
        { input: '-123456.789', expect: '123456' },
        { input: '$123,456.789', expect: '', method: 'paste' },
        { input: '-$123,456.789', expect: '', method: 'paste' },
        { input: 'foo', expect: '' },
        { input: 'foo', expect: '', method: 'paste' }
    ])

    generateEditorTestSuite('isNegativeAllowed=true', numericCellEditor, { isNegativeAllowed: true } as INumericCellEditorProps, [
        { input: '123456.789', expect: '123456' },
        { input: '-123456.789', expect: '-123456' },
        { input: '$123,456.789', expect: '123456.789', method: 'paste' },
        { input: '-$123,456.789', expect: '-123456.789', method: 'paste' },
        { input: 'foo', expect: '' },
        { input: 'foo', expect: '', method: 'paste' }
    ])

    generateEditorTestSuite('isPercentage=true', numericCellEditor, { isPercentage: true } as INumericCellEditorProps, [
        { input: '12.34', expect: '0.1234' },
        { input: '-12.34', expect: '0.1234' },
        { input: '12.34%', expect: '0.1234', method: 'paste' },
        { input: '-12.34%', expect: '', method: 'paste' },
        { input: 'foo', expect: '' },
        { input: 'foo', expect: '', method: 'paste' }
    ])

    generateEditorTestSuite('isPercentage+isNegativeAllowed', numericCellEditor, { isPercentage: true, isNegativeAllowed: true } as INumericCellEditorProps, [
        { input: '-12.34', expect: '-0.1234' },
        { input: '-12.34%', expect: '-0.1234', method: 'paste' },
    ])

    generateEditorTestSuite('isIntegerOnly+isNegativeAllowed', numericCellEditor, { isIntegerOnly: true, isNegativeAllowed: true } as INumericCellEditorProps, [
        { input: '-123456.789', expect: '-123456' },
        { input: '-123,456.789', expect: '', method: 'paste' },
        { input: '-123,456', expect: '-123456', method: 'paste' },
    ])

    generateEditorTestSuite('isTextAllowd=true', numericCellEditor, { isTextAllowd: true, isNegativeAllowed: true } as INumericCellEditorProps, [
        { input: '123456.789', expect: '123456.789' },
        { input: '-123456.789', expect: '-123456.789' },
        { input: '$123,456.789', expect: '123456.789', method: 'paste' },
        { input: '-$123,456.789', expect: '-123456.789', method: 'paste' },
        { input: '$123,456.789a', expect: '$123,456.789a', method: 'paste' },
        { input: 'foo', expect: 'foo' },
        { input: 'foo', expect: 'foo', method: 'paste' }
    ])


})