import { Tooltip } from "antd";
import { InfoCircleOutlined } from '@ant-design/icons';
import { IHeaderParams } from 'ag-grid-community';

export interface ICustomHeaderParams extends IHeaderParams {
  tooltipText: string;
}

const CustomHeaderToolTip = (header: ICustomHeaderParams) => (
  <div className="ag-custom-header-tool">
    <span className="title">{header.displayName}</span>
    <Tooltip className="icon" title={header.tooltipText}><InfoCircleOutlined /> </Tooltip>
  </div>
);

export default CustomHeaderToolTip;