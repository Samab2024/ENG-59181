
import { isNullOrEmpty } from '@/utils/stringHelper';
import { ICellRendererParams } from 'ag-grid-community';
import { BaseOptionType, DefaultOptionType } from 'antd/lib/select';

export interface ISelectCellRenderProps<OptionType extends BaseOptionType = DefaultOptionType> {
    options: OptionType[] | ((props: { data: any, context: any }) => OptionType[])
    placeholder?: string
}

const SelectCellRender = (props: ICellRendererParams & ISelectCellRenderProps) => {
    const cellValue = props.valueFormatted ? props.valueFormatted : props.value;
    if (!props.column.isCellEditable(props.node) && isNullOrEmpty(cellValue)) {
        return ''
    }
    if (cellValue === null || cellValue === undefined || cellValue === '') {
        return (<span className="placeholder-text">{props.placeholder || "Please select..."}</span>)
    }

    const options = (() => {
        if (typeof props.options === 'function') {
            return props.options({ data: props.data, context: props.context })
        } else {
            return props.options
        }
    })()

    return (
        <span>
            {options?.find(x => (x.value + '') === (cellValue + ''))?.label || cellValue}
        </span>
    )
}

export default SelectCellRender