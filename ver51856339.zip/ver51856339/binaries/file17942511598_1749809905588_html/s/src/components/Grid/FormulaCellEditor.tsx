import createStyle from '@/hooks/createStyle';
import notification from '@/utils/notification';
import { calculateFormula } from '@/utils/numberHelper';
import { css } from '@emotion/react';
import { ICellEditor, ICellEditorParams } from 'ag-grid-community';
import { CustomCellEditorProps, useGridCellEditor, useGridFilter } from 'ag-grid-react';
import { Input, InputRef } from 'antd';
import { TextAreaRef } from 'antd/es/input/TextArea';
import {
    forwardRef,
    useCallback,
    useEffect,
    useImperativeHandle,
    useRef,
    useState,
} from 'react';

const KEY_BACKSPACE = 'Backspace';
const KEY_DELETE = 'Delete';
const KEY_ENTER = 'Enter';
const KEY_TAB = 'Tab';

const FormulaCellEditor = (props: ICellEditorParams & CustomCellEditorProps, ref) => {

    const createInitialState = useCallback(() => {
        let startValue;

        if (props.eventKey === KEY_BACKSPACE || props.eventKey === KEY_DELETE) {
            // if backspace or delete pressed, we clear the cell
            startValue = '';
        } else if (props.eventKey) {
            // if a letter was pressed, we start with the letter
            startValue = props.eventKey;
        } else if (props.value === undefined) {
            startValue = ''
        } else if (props.value?.startsWith("'")) {
            startValue = ''
        } else {
            // otherwise we start with the current value
            startValue = props.value;
        }

        return {
            value: startValue,
        };
    }, [])

    const initialState = createInitialState();
    const [value, setValue] = useState(initialState.value);
    const refInput = useRef<TextAreaRef>(null);

    // focus on the input
    useEffect(() => {
        // get ref from React component
        window.setTimeout(() => {
            const eInput = refInput.current!;
            eInput.focus();
            const textareaDom = eInput?.resizableTextArea.textArea
            textareaDom.selectionStart = textareaDom.selectionEnd = textareaDom.value.length
            textareaDom.scrollTop = textareaDom.scrollHeight;
        });
    }, []);

    /* Utility Methods */
    const isLeftOrRight = (event: any) => {
        return ['ArrowLeft', 'ArrowRight'].indexOf(event.key) > -1;
    };

    const deleteOrBackspace = (event: any) => {
        return [KEY_DELETE, KEY_BACKSPACE].indexOf(event.key) > -1;
    };

    const onKeyDown = (event: any) => {
        if (isLeftOrRight(event) || deleteOrBackspace(event)) {
            event.stopPropagation();
            return;
        }
    };

    const updateValue = (value: any) => props.onValueChange(value);

    const handleValueChange = (value: string) => {
        updateValue(value);
        setValue(value)
    }

    /* Component Editor Lifecycle methods */
    useGridCellEditor({
        // Gets called once before editing starts, to give editor a chance to
        // cancel the editing before it even starts.
        isCancelBeforeStart() {
            // return cancelBeforeStart;
            return false;
        },

        // Gets called once when editing is finished (eg if Enter is pressed).
        // If you return true, then the result of the edit will be ignored.
        isCancelAfterEnd() {
            //not allow to clear the value
            if (value === "") return true

            const calValue = calculateFormula(value)
            const isInvalid = isNaN(calValue)
            if (isInvalid) {
                notification.error('Invalid formula.')
            }
            return isInvalid;
        },
    });

    return (
        <Input.TextArea
            style={{ width: 250 }}
            bordered={false}
            ref={refInput}
            className={'grid-input-editor popup-input'}
            value={value}
            onChange={e => handleValueChange(e.target.value)}
            onKeyDown={e => onKeyDown(e)}
            placeholder="Input formula and press Enter to calculate"
        />
    );
}

export default FormulaCellEditor;