import { useCustomGridFilter } from "@/hooks/useCustomGridFilter";
import { useRefState } from "@/hooks/useRefState";
import { IDoesFilterPassParams, IFilter, IFilterParams } from "ag-grid-community";
import { CustomFilterProps, useGridFilter } from "ag-grid-react";
import { Input, InputRef } from "antd";
import { useCallback, useRef } from "react";

const escapeRegex = (input: string) => {
    return input.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};

type Props = IFilter & IFilterParams & CustomFilterProps;
const InputFilter = (props: Readonly<Props>) => {

    const [textValueRef, textValue, setTextValue] = useRefState("")
    const inputRef = useRef<InputRef>()

    const doesFilterPass = useCallback((params: IDoesFilterPassParams) => {
        if (!textValueRef.current) return true
        return new RegExp(escapeRegex(textValueRef.current), 'i').test("" + params.data[props.colDef.field])
    }, [])

    const { onModelChange } = useCustomGridFilter((model: any) => {
        setTextValue(model || "")
    }, props)

    // expose AG Grid Filter Lifecycle callbacks
    useGridFilter({
        doesFilterPass,
        afterGuiAttached() {
            inputRef.current?.focus()
        }
    });

    function updateText(items: (string)) {
        setTextValue(items);
        updateModel();
    }

    function updateModel() {
        onModelChange(textValueRef.current || null);
    }

    return (
        <div className="ag-input-filter">
            <Input ref={inputRef} bordered={false} allowClear={true} value={textValue} onChange={e => updateText(e.target.value)} />
        </div>
    )
};

export default InputFilter;