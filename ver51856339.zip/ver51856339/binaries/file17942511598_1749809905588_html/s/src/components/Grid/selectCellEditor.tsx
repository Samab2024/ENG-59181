import { ICellEditorParams, KeyCode, SuppressKeyboardEventParams } from 'ag-grid-community';
import { CustomCellEditorProps, useGridCellEditor } from 'ag-grid-react';
import { RefSelectProps, Select } from 'antd';
import { BaseOptionType, DefaultOptionType } from 'antd/lib/select';
import {
    useEffect,
    useMemo,
    useRef,
    useState
} from 'react';
// import copyToClipboard from '@app/shared/utility/copyToClipboard';

const KEY_BACKSPACE = 'Backspace';
const KEY_DELETE = 'Delete';
const KEY_ENTER = 'Enter';
const KEY_TAB = 'Tab';

export interface ISelectCellEditorProps<OptionType extends BaseOptionType = DefaultOptionType> {
    options: OptionType[] | ((props: { data: any, context: any }) => OptionType[])
    allowClear?: boolean
}

export function suppressSelectKeyboardEvent({ event: { code }, editing }: SuppressKeyboardEventParams) {
    const keysToSuppress: string[] = [KeyCode.ENTER];
    return editing && keysToSuppress.includes(code);
}

const SelectCellEditor = (props: ICellEditorParams & ISelectCellEditorProps & CustomCellEditorProps) => {

    const createInitialState = () => {
        let startValue;

        if (props.eventKey) {
            // if a letter was pressed, we start with the letter
            startValue = props.eventKey;
        } else {
            // otherwise we start with the current value
            startValue = '';
        }

        return {
            value: startValue,
        };
    };

    const initialState = createInitialState();
    const [searchValue, setSearchValue] = useState(initialState.value)
    const [value, setValue] = useState(props.value);
    const refSelect = useRef<RefSelectProps>(null);

    // focus on the input
    useEffect(() => {
        // get ref from React component
        window.setTimeout(() => {
            const eSelect = refSelect.current;
            eSelect.focus();
        });
    }, []);


    const onKeyDown = (event: any) => {
        if (event.key === KEY_ENTER) {
            event.stopPropagation()
        }
    };

    /* Component Editor Lifecycle methods */
    useGridCellEditor({
            // Gets called once before editing starts, to give editor a chance to
            // cancel the editing before it even starts.
            isCancelBeforeStart() {
                return false;
            },

            // Gets called once when editing is finished (eg if Enter is pressed).
            // If you return true, then the result of the edit will be ignored.
            isCancelAfterEnd() {
                return false;
        },
    });

    const updateValue = (value) => props.onValueChange(value);

    const stopEdit = () => {
        setTimeout(() => {
            props.api.stopEditing()
        });
    }

    const options = useMemo(() => {
        if (typeof props.options === 'function') {
            return props.options({ data: props.data, context: props.context })
        } else {
            return props.options
        }
    }, [props.options, props.data, props.context])

    return (
        <Select
            ref={refSelect}
            open={true}
            onDropdownVisibleChange={stopEdit}
            showSearch={true}
            searchValue={searchValue}
            onSearch={v => setSearchValue(v)}
            bordered={false}
            allowClear={typeof props.allowClear === 'boolean' ? props.allowClear : true}
            className={'grid-select-editor'}
            value={value}
            onSelect={(value) => {
                updateValue(value)
                setValue(value)
                stopEdit()
            }}
            onClear={() => {
                updateValue(null)
                setValue(null)
                stopEdit()
            }}
            // onInputKeyDown={e => (e.ctrlKey || e.metaKey) && e.key === 'c' && copyToClipboard(value)}
            optionFilterProp="label"
            options={options}
            onKeyDown={e => onKeyDown(e)}

        />
    );
}

export default SelectCellEditor;