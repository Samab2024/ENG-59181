import { css } from '@emotion/react';
import createUseStyle from '@/hooks/createStyle';

const useStyle = createUseStyle(token => css`
    &.ag-theme-balham,
    &.ag-theme-balham-dark,
    /* ag-popup for popup editor */
    .ag-theme-balham.ag-popup {
        --ag-balham-active-color: ${token.colorPrimary};
        --ag-foreground-color: #000;
        --ag-background-color: #fff;
        --ag-header-background-color: #D8D7D7;
        --ag-subheader-background-color: #e2e9eb;
        --ag-control-panel-background-color: #f5f7f7;
        --ag-border-color: transparent;
        --ag-odd-row-background-color: #fafafa;
        --ag-row-hover-color: #FFE6A2;
        --ag-column-hover-color: #FFE6A2;
        --ag-input-border-color: #95a5a6;
        --ag-invalid-color: #e02525;
        --ag-input-disabled-background-color: #ebebeb;
        --ag-checkbox-unchecked-color: #7f8c8d;
        --ag-input-focus-border-color: ${token.colorPrimary};
        --ag-input-focus-box-shadow: 0 0 2px 1px var(--ag-input-focus-border-color);
        --ag-range-selection-border-color: var(--ag-balham-active-color);
        --ag-checkbox-checked-color: var(--ag-balham-active-color);
        --ag-checkbox-background-color: var(--ag-background-color);
        --ag-secondary-foreground-color: rgba(0, 0, 0, 0.54);
        --ag-disabled-foreground-color: rgba(0, 0, 0, 0.38);
        --ag-subheader-toolbar-background-color: rgba(226, 233, 235, 0.5);
        --ag-row-border-color: transparent;
        --ag-chip-background-color: rgba(0, 0, 0, 0.1);
        --ag-range-selection-background-color: rgba(0, 145, 234, 0.2);
        --ag-range-selection-background-color-2: rgba(0, 145, 234, 0.36);
        --ag-range-selection-background-color-3: rgba(0, 145, 234, 0.49);
        --ag-range-selection-background-color-4: rgba(0, 145, 234, 0.59);
        --ag-selected-row-background-color: rgba(0, 145, 234, 0.28);
        --ag-header-column-separator-color: rgba(189, 195, 199, 0.5);
        --ag-input-disabled-border-color: rgba(149, 165, 166, 0.3);
        --ag-header-column-separator-display: block;
        --ag-header-column-separator-height: 50%;
        --ag-grid-size: 4px;
        --ag-icon-size: 16px;
        --ag-row-height: calc(var(--ag-grid-size) * 7);
        --ag-header-height: calc(var(--ag-grid-size) * 7);
        --ag-list-item-height: calc(var(--ag-grid-size) * 6);
        --ag-row-group-indent-size: calc(var(--ag-grid-size) * 3 + var(--ag-icon-size));
        --ag-cell-horizontal-padding: calc(var(--ag-grid-size) * 1);
        --ag-input-height: calc(var(--ag-grid-size) * 4);
        --ag-font-family: ${token.fontFamily};
        --ag-font-size: 12px;
        --ag-icon-font-family: agGridBalham;
        --ag-border-radius: 2px;
        --ag-checkbox-border-radius: 3px;
        --ag-card-shadow: none;

        --ag-header-foreground-color: ${token.colorTextBase};
        --ag-data-color: rgba(64, 64, 65);

        /* //TODO: header height not correct */
    }

    .placeholder-text {
        color: ${token.colorTextPlaceholder};
    }

    .grid-input-editor {
        width: 100%;
        background-color: transparent;
        border-radius: 0;
        padding: 1px 2px;
        padding-left: var(--ag-grid-size);
    }

    .popup-input {
        background: #FFF;
    }

    .grid-select-editor {
        width: 100%;
    }

    .grid-date-editor {
        width: 100%;
    }

    .ag-center-aligned-cell {
        text-align: center;
    }

    .ag-dropdown-filter {
        padding-top: 4px;

        .ag-dropdown-filter-search {
            margin-bottom: 4px;
            padding: 0 8px;
        }

        .ag-dropdown-filter-group {
            margin-top: 4px;
            padding-bottom: 4px;
        }

        .ag-dropdown-filter-item {
            padding: 0 8px;
        }
    }

    .ag-date-filter {
        padding: 8px 0;

        .ant-picker {
            margin-left: 8px;
        }

        .ant-picker-range-arrow {
            display: none;
        }

        .ag-date-filter-picker {
            margin-top: 4px;
        }

        .ant-picker-panel-container {
            box-shadow: none;
        }

        .ant-picker-panel {
            border: none;
        }

        .ant-picker-dropdown {
            padding: 0;
        }
    }

    .ag-text-allow-select {
        user-select: text;
        cursor: text;
    }

    .ag-custom-header-tool{
        span.icon{
            margin-left: 2px;

            :hover{
                cursor: pointer;
            }
        }
    }
    .ag-formula-cell-render {
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
    }

`)
export default useStyle