import { useCustomGridFilter } from "@/hooks/useCustomGridFilter";
import { useRefState } from "@/hooks/useRefState";
import { IDoesFilterPassParams } from "ag-grid-community";
import { CustomFilterProps, useGridFilter } from "ag-grid-react";
import { Checkbox, Input } from "antd";
import { FISearch } from "functional-icons/lib/Outline";
import { useCallback, useEffect, useState } from "react";
import Wrapper from "../Wrapper";

export interface DropdownFilterParams {
    options?: FilterOption[]
}

interface FilterOption {
    value: string | number
    label: string
    [key: string]: any
}

type Props = CustomFilterProps & DropdownFilterParams;

const DropdownFilter = (props: Readonly<Props>) => {
    const [options, setOptions] = useState<FilterOption[]>(props.options || [])
    const [searchValue, setSearchValue] = useState("")
    const [selectedItemsRef, selectedItems, setSelectedItems] = useRefState(options.map(x => x.value));


    // expose AG Grid Filter Lifecycle callbacks
    // useImperativeHandle(ref, () => {
    //     return {
    //         doesFilterPass(params) {
    //             return checkedValues.includes(params.data[props.colDef.field])
    //         },

    //         isFilterActive() {
    //             return checkedValues.length !== options.length && options.length > 0
    //         },

    //         getModel() {
    //             return checkedValues.length > 0 ? checkedValues : null
    //         },

    //         setModel(modal) {
    //             setCheckedValues(modal || [])
    //         },
    //     }
    // });

    const doesFilterPass = useCallback((params: IDoesFilterPassParams) => {
        return selectedItemsRef.current?.includes(params.data[props.colDef.field])
    }, []);

    useGridFilter({
        doesFilterPass,
    });

    function updateSelectedItems(items: (string | number)[]) {
        setSelectedItems(items);
        updateModel();
    }

    function updateModel() {
        onModelChange(selectedItemsRef.current?.length > 0 ? selectedItems : null);
    }

    const { onModelChange } = useCustomGridFilter((model: any) => {
        console.log('useCustomGridFilter', model)
        setSelectedItems(model || [...options.map(x => x.value)])
    }, props);

    // console.log(props.model)

    useEffect(() => {
        if (!props.options) {
            const options = new Set<string>()
            props.api.forEachNode(row => {
                options.add(row.data[props.colDef.field])
            })
            setOptions([...options].map(x => ({ value: x, label: x })))
            setSelectedItems([...options])
        }
    }, [])

    return (
        <div className="ag-dropdown-filter">
            <div className="ag-dropdown-filter-search">
                <Input prefix={<FISearch />} value={searchValue} onChange={e => setSearchValue(e.target.value)} allowClear={true} />
            </div>
            <div className="ag-dropdown-filter-item">
                <Checkbox onChange={e => updateSelectedItems(e.target.checked ? options.map(x => x.value) : [])} checked={selectedItems.length === options.length} indeterminate={selectedItems.length !== options.length && selectedItems.length > 0}>All</Checkbox>
            </div>
            <Wrapper.ListContainer noStyle height={200} className="ag-dropdown-filter-group">
                <Checkbox.Group value={selectedItems} onChange={selectedItems => updateSelectedItems(selectedItems as string[])}>
                    <div>
                        {options.map((x, i) => (
                            <div className="ag-dropdown-filter-item" css={{ display: x.label?.toString().toLocaleLowerCase().includes(searchValue?.toLocaleLowerCase()) ? 'block' : 'none' }} key={i}>
                                <Checkbox value={x.value}>{x.label}</Checkbox>
                            </div>
                        ))}
                    </div>
                </Checkbox.Group>
            </Wrapper.ListContainer>
        </div>
    )
};

export default DropdownFilter;