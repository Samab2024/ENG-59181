import {
    forwardRef,
    useEffect,
    useImperativeHandle,
    useRef,
    useState,
} from 'react';
import { ICellEditor, ICellEditorParams, KeyCode } from 'ag-grid-community';
import { AutoComplete, Input, InputRef } from 'antd';
import { css } from '@emotion/react';
import { TextAreaRef } from 'antd/es/input/TextArea';
import { CustomCellEditorProps, useGridCellEditor } from 'ag-grid-react';
import { update } from 'lodash';

const KEY_BACKSPACE = 'Backspace';
const KEY_DELETE = 'Delete';
const KEY_ENTER = 'Enter';
const KEY_TAB = 'Tab';

export interface ITextCellEditorProps {
    options?: string[]
    maxLength?: number
}

const wrapperStyle = css`
    background-color: #FFF;
`

const TextCellEditor = (props: ICellEditorParams & ITextCellEditorProps & CustomCellEditorProps) => {

    const createInitialState = () => {
        let startValue;

        if (props.eventKey === KEY_BACKSPACE || props.eventKey === KEY_DELETE) {
            // if backspace or delete pressed, we clear the cell
            startValue = '';
        } else if (props.eventKey) {
            // if a letter was pressed, we start with the letter
            startValue = props.eventKey;
        } else if (props.value === undefined) {
            startValue = ''
        } else {
            // otherwise we start with the current value
            startValue = props.value;
        }

        return {
            value: startValue,
        };
    };

    const initialState = createInitialState();
    const [value, setValue] = useState(initialState.value);
    const refInput = useRef<TextAreaRef>(null);
    const optionRef = useRef<HTMLDivElement>(null);

    // focus on the input
    useEffect(() => {
        // get ref from React component
        window.setTimeout(() => {
            const eInput = refInput.current!;
            eInput?.focus();
            const textareaDom = eInput?.resizableTextArea.textArea
            textareaDom.selectionStart = textareaDom.selectionEnd = textareaDom.value.length
            textareaDom.scrollTop = textareaDom.scrollHeight;
        });
    }, []);

    /* Utility Methods */
    const handleValueChange = (value: string) => {
        setValue(value);
        updateValue(value);
    }

    const updateValue = (value) => props.onValueChange(props.parseValue(value));


    const insertAtCursorPosition = (text: string) => {
        const textareaDom = refInput.current?.resizableTextArea.textArea
        const positionStart = textareaDom.selectionStart
        setValue(value.slice(0, positionStart) + text + value.slice(textareaDom.selectionEnd))
        setTimeout(() => {
            textareaDom.selectionStart = textareaDom.selectionEnd = positionStart + 1 //reset cursor position
        });
    }

    /* Component Editor Lifecycle methods */
    useGridCellEditor({
            // Gets called once before editing starts, to give editor a chance to
            // cancel the editing before it even starts.
            isCancelBeforeStart() {
                // return cancelBeforeStart;
                return false;
            },

            // Gets called once when editing is finished (eg if Enter is pressed).
            // If you return true, then the result of the edit will be ignored.
            isCancelAfterEnd() {
                return false
        },
    });

    if (props.options?.length) {
        return (
            <div css={wrapperStyle} >
                <AutoComplete
                    popupClassName="wrap-text"
                    open={true}
                    options={props.options.map(x => ({ value: x, label: x }))}
                    filterOption={true}
                    dropdownStyle={{ maxWidth: 300 }}
                    onSelect={v => {
                        handleValueChange(v)
                        setTimeout(() => {
                            props.api.stopEditing()
                        });
                    }}
                    onInputKeyDown={e => {
                        e.code === KeyCode.ENTER && setTimeout(() => {
                            props.api.stopEditing()
                        });
                    }}
                    value={value}
                    onChange={value => handleValueChange(value)}
                    getPopupContainer={() => optionRef.current}
                >
                    <Input.TextArea
                        rows={3}
                        cols={30}
                        maxLength={props.maxLength}
                        ref={refInput}
                        className={'grid-input-editor'}
                        bordered={false}
                    />
                </AutoComplete>
                <div ref={optionRef} />
            </div>
        )
    } else {
        return (
            <div css={wrapperStyle} >
                <Input.TextArea
                    rows={3}
                    cols={30}
                    maxLength={props.maxLength}
                    ref={refInput}
                    className={'grid-input-editor'}
                    bordered={false}
                    value={value}
                    onKeyDown={e => {
                        if (e.altKey) {
                            if (e.key === ',') {
                                insertAtCursorPosition('≤')
                                e.preventDefault()
                            } else if (e.key === '.') {
                                insertAtCursorPosition('≥')
                                e.preventDefault()
                            }
                        }
                    }}
                    onChange={e => handleValueChange(e.target.value)}
                />
            </div>
        )
    }
}

export default TextCellEditor;