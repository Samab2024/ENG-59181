import { AgGridReact, AgGridReactProps } from "ag-grid-react";
import { ForwardedRef, forwardRef, useMemo } from "react";
import { getDefaultOption } from ".";
import useStyle from './Grid.style';

interface GridProps<TData> extends AgGridReactProps<TData> {
    width?: number | string
    height?: number | string
    style?: React.CSSProperties & { [key: string]: string }
}

const Grid = <T,>(props: GridProps<T>, ref: ForwardedRef<AgGridReact<T>>) => {
    const styles = useStyle()
    const { width, height, style, ...rest } = props
    const containerStyle = useMemo<React.CSSProperties>(() => ({
        width: width ?? '100%',
        height: height ?? '400px',
        ...style
    }), [height, width])
    return (
        <div css={styles} className="ag-theme-balham" style={containerStyle}>
            <AgGridReact ref={ref} gridOptions={getDefaultOption<T>()} {...rest} />
        </div>
    )
}

export default forwardRef(Grid) as <T>(
    props: GridProps<T> & { ref?: React.ForwardedRef<AgGridReact> }
) => ReturnType<typeof Grid>;