import { ICellRendererParams } from "ag-grid-community"

const TextCellRender = ({ value }: ICellRendererParams) => {
    return (
        <div className="ag-cell-value" title={value}>{value}</div>
    )
}

export default TextCellRender