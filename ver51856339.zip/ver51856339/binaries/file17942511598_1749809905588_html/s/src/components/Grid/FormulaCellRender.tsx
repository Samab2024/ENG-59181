
import { ICellRendererParams } from 'ag-grid-community';
import { Tooltip } from 'antd';
import { FICalculator, FIDuplicate } from 'functional-icons/lib/Outline';

const FormulaCellRender = (props: ICellRendererParams) => {
    const formula = props.value
    // if (formula && (formula as string).startsWith("'")) {
    //     const text = (formula as string).slice(1)
    //     formula = <>
    //         {text}
    //     </>
    // }

    const { column, node, api } = props
    const editable = column.isCellEditable(node)

    return (
        <div className="ag-formula-cell-render" onClick={() => {
            editable && api.startEditingCell({
                rowIndex: node.rowIndex,
                colKey: column.getId(),
            })
        }}>
            <Tooltip title={formula}>
                <FICalculator className="icon" />
            </Tooltip>
        </div>
    )
}

export default FormulaCellRender