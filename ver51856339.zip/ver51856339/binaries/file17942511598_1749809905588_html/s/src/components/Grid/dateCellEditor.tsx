import { FORMATS } from '@/utils/dateHelper';
import { NotAvailable } from '@/utils/numberHelper';
import { CustomCellEditorProps, useGridCellEditor } from 'ag-grid-react';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';
import {
    useCallback,
    useEffect,
    useRef
} from 'react';

const KEY_BACKSPACE = 'Backspace';
const KEY_DELETE = 'Delete';
const KEY_ENTER = 'Enter';
const KEY_TAB = 'Tab';

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface IDateCellEditorProps {
    format?: string | string[]
}

const DateCellEditor = (props: Readonly<IDateCellEditorProps & CustomCellEditorProps>) => {

    const defaultValue = props.value && props.value !== NotAvailable && dayjs(props.value).isValid() && dayjs(props.value) || null
    const pickerRef = useRef(null);

    // focus on the input
    useEffect(() => {
        // get ref from React component
        window.setTimeout(() => {
            const eInput = pickerRef.current!;
            eInput.focus();
        });
    }, []);

    /* Utility Methods */
    const stopEdit = () => {
        setTimeout(() => {
            props.api.stopEditing()
        });
    }

    const updateValue = (value) => props.onValueChange(value && value.format(FORMATS.JSONDate));

    const handleValueChange = useCallback((newValue: dayjs.Dayjs) => {
        updateValue(newValue);
        stopEdit();
    }, []);

    /* Component Editor Lifecycle methods */
    useGridCellEditor({
        // Gets called once before editing starts, to give editor a chance to
        // cancel the editing before it even starts.
        isCancelBeforeStart() {
            // return cancelBeforeStart;
            return false;
        },

        // Gets called once when editing is finished (eg if Enter is pressed).
        // If you return true, then the result of the edit will be ignored.
        isCancelAfterEnd() {
            return false;
        },
    });

    return (
        <DatePicker
            ref={pickerRef}
            bordered={false}
            open={true}
            className={'grid-date-editor'}
            defaultValue={defaultValue}
            format={props.format}
            onChange={handleValueChange}
        />
    );
}

export default DateCellEditor;
