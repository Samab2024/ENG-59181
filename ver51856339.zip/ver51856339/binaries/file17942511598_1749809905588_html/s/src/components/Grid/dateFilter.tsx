import { useCustomGridFilter } from "@/hooks/useCustomGridFilter";
import { useRefState } from "@/hooks/useRefState";
import { FORMATS } from "@/utils/dateHelper";
import { CustomFilterProps, useGridFilter } from "ag-grid-react";
import { DatePicker } from "antd";
import dayjs, { Dayjs } from "dayjs";
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import { forwardRef, useCallback, useEffect, useRef } from "react";

dayjs.extend(isSameOrAfter)
dayjs.extend(isSameOrBefore)

export interface DateFilterParams {
    isRange?: boolean
}

const DateFilter = (props: CustomFilterProps & DateFilterParams) => {

    const [valuesRef, values, setValues] = useRefState<[Dayjs, Dayjs]>([null, null])
    const pickerContent = useRef<HTMLDivElement>()

    const doesFilterPass = useCallback((params) => {
        const date = dayjs(params.data[props.colDef.field])
        if (props.isRange) {
            const startDate = dayjs(valuesRef.current[0].format(FORMATS.L))
            const endDate = dayjs(valuesRef.current[1].format(FORMATS.L))
            return date.isSameOrBefore(endDate) && date.isSameOrAfter(startDate)
        } else {
            return date.format(FORMATS.L) === valuesRef.current[0].format(FORMATS.L)
        }
    }, [])

    const { onModelChange } = useCustomGridFilter(() => {
        setValues(props.model || [null, null])
    }, props)

    const updateModel = () => onModelChange(valuesRef.current[0] !== null ? values : null)

    useGridFilter({
        doesFilterPass
    })

    useEffect(() => {
        setTimeout(() => {
            const ctx = pickerContent.current.querySelector('.ant-picker-panel-container')
            pickerContent.current.style.setProperty('width', ctx.clientWidth + 'px')
            pickerContent.current.style.setProperty('height', ctx.clientHeight + 'px')
        });
    }, [])

    const handleRangePickerChange = value => {
        setValues(value || [null, null])
        updateModel()
    }

    const handleDatePickerChange = value => {
        setValues([value, null])
        updateModel()
    }

    return (
        <div className="ag-date-filter">
            {props.isRange ?
                <DatePicker.RangePicker open={true} getPopupContainer={() => pickerContent.current} value={values} onChange={handleRangePickerChange} format={[FORMATS.L, FORMATS.JSONDate]} />
                :
                <DatePicker open={true} getPopupContainer={() => pickerContent.current} value={values[0]} onChange={handleDatePickerChange} format={[FORMATS.L, FORMATS.JSONDate]} />
            }
            <div ref={pickerContent} className="ag-date-filter-picker" />
        </div>
    )
};

export default forwardRef(DateFilter)