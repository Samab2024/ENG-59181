
import { decimalFormatter, percentFormatter } from '@/utils/numberHelper';
import { ICellRendererParams } from 'ag-grid-community';

export interface INumericCellRenderProps {
    suffix?: string
    isPercentage?: boolean
    fixed?: number
    placeholder?: string
}

const NumericCellRender = (props: ICellRendererParams & INumericCellRenderProps) => {
    const cellValue = props.value;
    if (!props.column.isCellEditable(props.node) && typeof cellValue !== 'number') {
        return ''
    }
    if (cellValue === null || cellValue === undefined || cellValue === '') {
        return (<span className="placeholder-text">{props.placeholder || "Please input..."}</span>)
    }
    return (
        <span>{`${props.isPercentage ? percentFormatter(cellValue, props.fixed) : decimalFormatter(cellValue, props.fixed)}${props.suffix ?? ''}`}</span>
    )
}

export default NumericCellRender