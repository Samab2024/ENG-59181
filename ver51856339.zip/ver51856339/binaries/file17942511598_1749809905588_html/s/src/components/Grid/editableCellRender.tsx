import { ICellRendererParams } from "ag-grid-community"

export interface IEditableCellRenderProps {
    placeholder?: string
}

const EditableCellRender = (props: ICellRendererParams & IEditableCellRenderProps) => {
    const cellValue = props.valueFormatted ? props.valueFormatted : props.value;
    if (!props.column.isCellEditable(props.node) && !cellValue) {
        return ''
    }
    if (cellValue === null || cellValue === undefined || cellValue === '') {
        return <span className="placeholder-text">{props.placeholder || "Please input..."}</span>
    }
    return <span title={cellValue}>{cellValue}</span>
}

export default EditableCellRender