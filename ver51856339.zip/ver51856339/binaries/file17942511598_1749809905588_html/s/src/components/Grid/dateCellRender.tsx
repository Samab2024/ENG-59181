import { FORMATS } from "@/utils/dateHelper";
import { ICellRendererParams } from 'ag-grid-community';
import dayjs from 'dayjs';

export interface IDateCellRenderProps {
    format?: string
    placeholder?: string
}

const DateCellRender = (props: ICellRendererParams & IDateCellRenderProps) => {
    const cellValue = props.valueFormatted ? props.valueFormatted : props.value;
    if (!props.column.isCellEditable(props.node) && !cellValue) {
        return ''
    }
    if (cellValue === null || cellValue === undefined || cellValue === '') {
        return (<span className="placeholder-text">{props.placeholder || "Please select..."}</span>)
    }
    return (
        <span>
            {cellValue ? dayjs(cellValue).format(props.format || FORMATS.L) : ''}
        </span>
    )
}

export default DateCellRender