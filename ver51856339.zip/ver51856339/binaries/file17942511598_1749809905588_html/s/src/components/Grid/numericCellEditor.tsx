import { NotAvailable, percentageToNumber, roundPercentage } from '@/utils/numberHelper';
import { ICellEditorParams } from 'ag-grid-community';
import { CustomCellEditorProps, useGridCellEditor } from 'ag-grid-react';
import { Input, InputRef } from 'antd';
import {
    useEffect,
    useRef,
    useState
} from 'react';

const KEY_BACKSPACE = 'Backspace';
const KEY_DELETE = 'Delete';
const KEY_ENTER = 'Enter';
const KEY_TAB = 'Tab';

export interface INumericCellEditorProps {
    suffix?: string
    isPercentage?: boolean
    isIntegerOnly?: boolean
    isNegativeAllowed?: boolean
    isTextAllowd?: boolean
    maxLength?: number
}

const isNumeric = (value: string) => /^-?\d+(\.\d+)?$/.test(value)

const NumericCellEditor = (props: ICellEditorParams & INumericCellEditorProps & CustomCellEditorProps) => {

    const createInitialState = () => {
        let startValue;

        if (props.eventKey === KEY_BACKSPACE || props.eventKey === KEY_DELETE) {
            // if backspace or delete pressed, we clear the cell
            startValue = '';
        } else if (props.eventKey && '1234567890-'.indexOf(props.eventKey) >= 0) {
            // if a letter was pressed, we start with the letter
            startValue = props.eventKey;
        } else if (props.value === undefined || props.value === null || props.value === '') {
            startValue = ''
        } else if (props.value === NotAvailable) {
            startValue = NotAvailable
        } else if (props.isPercentage && isNumeric(props.value)) {
            startValue = roundPercentage(props.value)
        } else {
            // otherwise we start with the current value
            startValue = props.value;
        }

        return {
            value: startValue,
        };
    };

    const initialState = createInitialState();
    const [value, setValue] = useState(initialState.value);
    const refInput = useRef<InputRef>(null);

    // focus on the input
    useEffect(() => {
        // get ref from React component
        window.setTimeout(() => {
            const eInput = refInput.current!;
            eInput.focus();
            // eInput.setSelectionRange(0, -1)
        });
    }, []);

    /* Utility Methods */
    const cancelBeforeStart =
        props.eventKey && '1234567890'.indexOf(props.eventKey) < 0;

    const isLeftOrRight = (event: any) => {
        return ['ArrowLeft', 'ArrowRight'].indexOf(event.key) > -1;
    };

    const isCharNumeric = (charStr: string) => {
        if (props.isTextAllowd) return true
        return !!/[\d.-]/.test(charStr);
    };

    const isValueNumeric = (value: string) => {
        if (props.isTextAllowd) return true
        if (props.isIntegerOnly) {
            if (props.isNegativeAllowed) {
                return !!/^-?\d+$/.test(value);
            } else {
                return !!/^\d+$/.test(value);
            }
        } else {
            if (props.isNegativeAllowed) {
                return !!/^-?\d+(\.\d+)?$/.test(value);
            } else {
                return !!/^\d+(\.\d+)?$/.test(value);
            }
        }
    };

    const isKeyPressedNumeric = (event: any) => {
        const charStr = event.key;
        return isCharNumeric(charStr);
    };

    const deleteOrBackspace = (event: any) => {
        return [KEY_DELETE, KEY_BACKSPACE].indexOf(event.key) > -1;
    };

    const finishedEditingPressed = (event: any) => {
        const key = event.key;
        return key === KEY_ENTER || key === KEY_TAB;
    };

    const onKeyDown = (event: any) => {
        if (isLeftOrRight(event) || deleteOrBackspace(event)) {
            event.stopPropagation();
            return;
        }

        if (!finishedEditingPressed(event) && !isKeyPressedNumeric(event) && !(event.ctrlKey || event.metaKey)) {
            if (event.preventDefault) event.preventDefault();
        }
    };

    const handleValueChange = (value: string) => {
        if (!props.maxLength && isValueNumeric(value)
            || props.maxLength && value.length <= props.maxLength && isValueNumeric(value)
            || !value
            || !props.isIntegerOnly && value.endsWith('.')
            || props.isNegativeAllowed && value === '-') {
            setValue(value);
            updateValue(value);
        }
    }

    const handlePaste: React.ClipboardEventHandler<HTMLInputElement> = e => {
        e.preventDefault()
        const pasteText = e.clipboardData.getData('text')
        const replacedText = pasteText
            .replace(/\$/g, '') //Replace $ mark
            .replace(/\,/g, '') //Replace ,
            .replace(/%/g, '') //Replace %
            .trim()
        if (isNumeric(replacedText)) {
            handleValueChange(replacedText)
        } else {
            handleValueChange(pasteText)
        }
    }

    /* Component Editor Lifecycle methods */
    useGridCellEditor({
        // Gets called once before editing starts, to give editor a chance to
        // cancel the editing before it even starts.
        isCancelBeforeStart() {
            // return cancelBeforeStart;
            return false;
        },

        // Gets called once when editing is finished (eg if Enter is pressed).
        // If you return true, then the result of the edit will be ignored.
        isCancelAfterEnd() {
            //allow to clear the value
            if (value === "") return false
            // should not compare with max number anymore if content is text
            if (props.isTextAllowd && !isNumeric(value)) return false
            // will reject the number if it greater than 1,000,000
            // not very practical, but demonstrates the method.
            return !isValueNumeric(value) || value > Number.MAX_SAFE_INTEGER || value < Number.MIN_SAFE_INTEGER;
        },
    });

    const updateValue = (value) => {
        let returnValue = value
        if (value === "") {
            returnValue = null
        } else if (props.isTextAllowd && !isNumeric(value)) {
            //do nothing, and should not convert to number
        } else if (props.isPercentage) {
            returnValue = percentageToNumber(value)
        } else {
            returnValue = Number(value);
        }
        props.onValueChange(props.parseValue(returnValue));
    }


    return (
        <Input
            ref={refInput}
            className={'grid-input-editor'}
            bordered={false}
            value={value}
            onChange={e => handleValueChange(e.target.value)}
            onKeyDown={onKeyDown}
            onPaste={handlePaste}
            suffix={props.isPercentage ? ' % ' : props.suffix}
        />
    );
}

export default NumericCellEditor;