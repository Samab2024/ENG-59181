import { classMatcher, colIdMatcher, rowIdMatcher, sleep } from "@/utils/testUtils";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ColDef, GridOptions } from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { forwardRef, useState } from "react";

const TestGrid = forwardRef<AgGridReact, GridOptions>(function TestGrid(options, ref) {

    return (
        <div className="ag-theme-quartz" style={{ height: 400, width: 600 }}>
            <AgGridReact
                ref={ref}
                singleClickEdit={true}
                suppressRowVirtualisation={true}
                suppressColumnVirtualisation={true}
                {...options}
            />
        </div>
    );
})

export const waitForGridToBeInTheDOM = () => waitFor(() => {
    expect(document.querySelector('.ag-root-wrapper')).toBeInTheDocument();
});

export const waitForDataToHaveLoaded = () => waitFor(() => {
    expect(document.querySelector('.ag-overlay-no-rows-center')).toBeNull();
});

export const generateEditorTestSuite = (name: string, cellEditor: any, cellEditorParams: any, testSet: {
    input: any
    expect: any
    method?: 'type' | 'paste'
}[]) => {
    const Grid = () => {
        const [rowData] = useState([{
            id: 1,
            value: null
        }])
        const [colDefs] = useState<ColDef[]>([{
            field: 'value',
            editable: true,
            cellEditor,
            cellEditorParams
        }])
        return <TestGrid rowData={rowData} columnDefs={colDefs} getRowId={({ data }) => data.id} />
    }

    describe(name, () => {
        const ue = userEvent.setup()

        testSet.forEach(set => {
            test(`cell edit with ${set.method || 'type'} ${set.input}, expect ${set.expect}`, async () => {
                render(
                    <Grid />
                )
                await waitForGridToBeInTheDOM()
                const row = await screen.findByText(rowIdMatcher('1'))
                const cell = await within(row).findByText(colIdMatcher('value'))
                await ue.click(cell)
                const input = await within(cell).findByText(classMatcher('grid-input-editor'))
                if (set.method === 'paste') {
                    await ue.paste(set.input)
                } else {
                    await ue.keyboard(set.input)
                }
                await ue.type(input, '{enter}')

                expect(cell).toHaveTextContent(set.expect)
            })
        })

    })

}