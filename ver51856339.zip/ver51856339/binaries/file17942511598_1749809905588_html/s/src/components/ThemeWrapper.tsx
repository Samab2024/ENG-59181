import { Global, SerializedStyles } from "@emotion/react";
import { FC, PropsWithChildren } from "react";

const ThemeWrapper: FC<PropsWithChildren<{
    globalStyle: SerializedStyles
    themeStyle: SerializedStyles
}>> = ({ children, globalStyle, themeStyle }) => {
    return (
        <>
            <Global styles={globalStyle} />
            <div css={themeStyle}>{children}</div>
        </>
    )
}

export default ThemeWrapper