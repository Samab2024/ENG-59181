import { useAppSelector } from '@/hooks/reduxHook';
import * as controlStyles from '@/styles/control.module.css';
import * as displayStyles from '@/styles/display.module.css';
import cacheStore from "@/utils/cacheStore";
import { Button, Dropdown } from "antd";
import classNames from "classnames";
import { FIAvatar, FIHelpQuestion } from "functional-icons/lib/Outline";
import { FC } from "react";
import { useNavigate } from "react-router-dom";
import { selectCurrentUser } from '../redux/userSlice';
import valueOfType from '@/utils/valueOfType';
import { css } from '@emotion/react';

export type HelpOptions = 'release-note'

const SettingBox: FC = () => {
    const navigate = useNavigate();
    const currentUser = useAppSelector(selectCurrentUser)

    const handleLogoutClick = () => {
        cacheStore.clearToken()
        navigate('/login')
    }

    const onHelpClick = (key: HelpOptions) => {
        switch (key) {
            case "release-note":
                window.open(API_ROOT + '/ReleaseNote.html', "_blank")
                break;
            default:
                break;
        }
    }

    const classes = classNames(displayStyles.flexCenter, controlStyles.noSelectable, controlStyles.pointer)
    return (
        <div css={css({ display: 'flex', alignItems: 'center', gap: '8px' })} >
            <Dropdown trigger={['click']} menu={{
                onClick: ({ key }) => onHelpClick(key as HelpOptions),
                items: [
                    { key: valueOfType<HelpOptions>("release-note"), label: 'Release note' },
                ]
            }}>
                <Button type="text" icon={<FIHelpQuestion style={{ fontSize: '20px' }} />} shape="circle" />
            </Dropdown>
            <Dropdown trigger={['click']} menu={{
                onClick: () => handleLogoutClick(),
                items: [{ key: 'logout', label: 'Logout' }]
            }}>
                <div className={classes}>
                    <FIAvatar style={{ fontSize: '24px', marginRight: '4px' }} />
                    <span>{currentUser?.name}</span>
                </div>
            </Dropdown>
        </div>
    )
}

export default SettingBox