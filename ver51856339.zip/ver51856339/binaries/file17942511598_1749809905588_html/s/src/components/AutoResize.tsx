import React, { FunctionComponent, useEffect } from 'react'
import { useBreakpoints } from '../hooks/useBreakpoints'

export const AutoResize: FunctionComponent<React.PropsWithChildren> = ({ children }) => {
    const { updateBreakpoint } = useBreakpoints()
    useEffect(() => {
        updateBreakpoint()
        window.addEventListener('resize', updateBreakpoint)
        return () => {
            window.removeEventListener('resize', updateBreakpoint)
        }
    }, [])
    return <>{children}</>
}

export default AutoResize