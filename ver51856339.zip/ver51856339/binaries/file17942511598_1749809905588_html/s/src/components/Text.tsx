import React, { FunctionComponent } from 'react'

type T_header = React.PropsWithChildren<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>>

export const Header1: FunctionComponent<T_header> = ({ children, ...rest }) => {
    return <h3 {...rest}>{children}</h3>
}

export const Header2: FunctionComponent<T_header> = ({ children, ...rest }) => {
    return <h4 {...rest}>{children}</h4>
}

export const ParagraphTitle: FunctionComponent<T_header> = ({ children, ...rest }) => {
    return <h6 {...rest}>{children}</h6>
}

export default {
    Header1,
    Header2,
    ParagraphTitle,
}