import { render, screen, tagMatcher } from '@/utils/testUtils';
import userEvent from "@testing-library/user-event";
import { FICheckmark } from "functional-icons/lib/Outline";
import IconButton from "../IconButton";

describe('IconButton', () => {
    const ue = userEvent.setup()

    test('renders component', () => {
        render(
            <IconButton icon={FICheckmark} />
        )
        expect(screen.getByRole('button')).toBeInTheDocument()
        expect(screen.getByText(tagMatcher('svg')))
            .toHaveAttribute('data-icon', expect.stringContaining("Checkmark"))
        expect(screen.getByText(tagMatcher('i')))
            .toHaveStyle("font-size: 22px")
        // screen.debug()
    })

    test('should able to change the size', () => {
        const { rerender } = render(
            <IconButton icon={FICheckmark} size="small" />
        )
        expect(screen.getByRole('button')).toHaveClass("ant-btn-sm")
        expect(screen.getByText(tagMatcher('i'))).toHaveStyle("font-size: 16px")

        rerender(
            <IconButton icon={FICheckmark} size="middle" />
        )
        expect(screen.getByText(tagMatcher('i'))).toHaveStyle("font-size: 22px")

        rerender(
            <IconButton icon={FICheckmark} size="large" />
        )
        expect(screen.getByRole('button')).toHaveClass("ant-btn-lg")
        expect(screen.getByText(tagMatcher('i'))).toHaveStyle("font-size: 28px")
    })

    test('should able to click', async () => {
        const clickHandler = jest.fn()
        render(
            <IconButton icon={FICheckmark} onClick={clickHandler} />
        )
        await ue.click(screen.getByRole("button"))
        expect(clickHandler).toBeCalled()
    })

})