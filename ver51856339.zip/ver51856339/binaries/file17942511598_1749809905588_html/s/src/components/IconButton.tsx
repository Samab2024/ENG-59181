import { Button } from 'antd'
import { ButtonProps, ButtonSize } from 'antd/lib/button'
import { IconProps } from 'functional-icons/lib/IconWrapper'
import { FC } from 'react'

const IconButton: FC<{
    icon: FC<IconProps>,
    size?: ButtonSize
} & Omit<ButtonProps, 'icon' | 'size'>> = ({ size, icon, ...rest }) => {
    const Icon = icon
    return (
        <Button type="text" icon={<Icon style={{ fontSize: size == 'small' ? 16 : size === 'large' ? 28 : 22 }} />} {...rest} size={size}></Button>
    )
}

export default IconButton