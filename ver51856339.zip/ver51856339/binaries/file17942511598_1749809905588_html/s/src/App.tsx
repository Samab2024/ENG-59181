import { useAppDispatch, useAppSelector } from '@/hooks/reduxHook'
import { setupAxios } from '@/services/request'
import * as display from '@/styles/display.module.css'
import { Spin } from 'antd'
import { FC, useEffect, useState } from 'react'
import { useLocation, useNavigate, useRoutes } from 'react-router-dom'
import { bindActionCreators } from 'redux'
import { selectCurrentUser, setUser } from './redux/userSlice'
import { routes } from './routes'
import cacheStore from '@/utils/cacheStore'
import AuthAPI from '@/services/api/AuthAPI'
import notification from '@/utils/notification'

const App: FC = () => {
    const [loading, setLoading] = useState(true)
    const currentUser = useAppSelector(selectCurrentUser)
    const dispatch = useAppDispatch()
    const setCurrentUser = bindActionCreators(setUser, dispatch)

    const location = useLocation()
    const navigate = useNavigate()
    const routeEle = useRoutes(routes)

    useEffect(() => {
        setupAxios(navigate, location)
        if (cacheStore.hasToken() && !currentUser) {
            setLoading(true)
            AuthAPI.getCurrentUser()
                .then(user => {
                    setCurrentUser(user)
                })
                .catch(e => notification.error(e.message))
                .finally(() => setLoading(false))
        } else {
            setLoading(false)
        }
    }, [])

    if (loading) {
        return (
            <Spin spinning={true}>
                <div className={display.wholeScreen}></div>
            </Spin>
        )
    }

    return routeEle
}

export default App
