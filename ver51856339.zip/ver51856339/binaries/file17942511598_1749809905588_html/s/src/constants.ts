
export enum ReviewStatusEnum {
    NotStarted = 'Not Started',
    InProgress = 'In Progress',
    Completed = 'Completed'
}

export const ReviewStatus = [
    ReviewStatusEnum.NotStarted,
    ReviewStatusEnum.InProgress,
    ReviewStatusEnum.Completed
]

export const ADMIN_PERMISSION = '1, 2, 3'

export enum AssetType {
    CLO = 'CLO'
}

export enum FormatTypeEnum {
    IsDateTime = "IsDateTime",
    IsNumeric = 'IsNumeric',
    IsString = "IsString"
}

export const FORMAT_TYPE_OPTIONS = [
    { value: FormatTypeEnum.IsDateTime, label: 'Date Time' },
    { value: FormatTypeEnum.IsNumeric, label: 'Numeric' },
    { value: FormatTypeEnum.IsString, label: 'Text' },
]

export const PROCESS_TYPES = {
    ReviewCalculation: 'Review-Calculation',
    Provided: 'Provided',
    PassThrough: 'Pass-Through',
    Calculation: 'Calculation'
}

export const VARIOUS = 'Various'

export const USER_HELP_GUIDE_LINK = 'https://pwc.sharepoint.com/:x:/r/sites/GBL-xLoS-FMRETech/_layouts/15/Doc.aspx?sourcedoc=%7B0C5EA6D5-49ED-4F1A-9626-91AE3456EC09%7D&file=DDS%20Calculator%20User%20Help%20Guide.xlsx&action=default&mobileredirect=true'