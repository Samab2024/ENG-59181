
export const IS_DEBUG = process.env.NODE_ENV !== 'production'
