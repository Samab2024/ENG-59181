import { Global } from "@emotion/react";
import { FC } from "react";
import useAntdStyle from './styles/antd.style';
import useGlobalStyle from './styles/global.style';

const GlobalStyles: FC = () => {
    const globalStyle = useGlobalStyle()
    const antdStyle = useAntdStyle()
    return (
        <Global styles={[globalStyle, antdStyle]} />
    )
}

export default GlobalStyles