import ErrorBoundary from "@/components/ErrorBoundary";
import createCache from '@emotion/cache';
import { CacheProvider } from "@emotion/react";
import { ConfigProvider } from "antd";
import enUS from 'antd/locale/en_US';
import { createRoot } from 'react-dom/client';
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import App from './App';
import GlobalMessage from "./GlobalMessage";
import GlobalStyles from "./GlobalStyle";
import { setupStore } from "./redux/store";
import themeConfig from "./themes/pwcTheme";

//styles
import '@/styles/font.css';
import 'antd/dist/reset.css';

const store = setupStore()
const container = document.getElementById('root')
const root = createRoot(container) // createRoot(container!) if you use TypeScript

// https://github.com/emotion-js/emotion/issues/1105#issuecomment-557726922
const cache = createCache({ key: 'css' });
cache.compat = true;

root.render(
    <ConfigProvider locale={enUS} popupMatchSelectWidth={false} theme={themeConfig} componentSize="small">
        <CacheProvider value={cache}>
            <Provider store={store}>
                <BrowserRouter basename={'/' + APPLICATION_NAME}>
                    <ErrorBoundary>
                        <App />
                        <GlobalStyles />
                        <GlobalMessage />
                    </ErrorBoundary>
                </BrowserRouter>
            </Provider>
        </CacheProvider>
    </ConfigProvider>
)