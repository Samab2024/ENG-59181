import { MessageInstance } from "antd/es/message/interface";
import EventEmitter from "./utils/event";
import { ModalStaticFunctions } from "antd/es/modal/confirm";
import { MessageArgsProps, Modal, ModalFuncProps, message, notification } from "antd";
import { ArgsProps, NotificationConfig, NotificationInstance } from "antd/es/notification/interface";
import { FC, useEffect } from "react";

export const MessageEventEmitter = new EventEmitter<{
    type: keyof Omit<MessageInstance, 'destroy'>
    props: MessageArgsProps
} | {
    type: keyof Pick<MessageInstance, 'destroy'>
    props: React.Key
}>()

export const ModalEventEmitter = new EventEmitter<{
    type: keyof Omit<ModalStaticFunctions, 'warn'>;
    props: ModalFuncProps
}>()

export const NotificationEventEmitter = new EventEmitter<{
    type: keyof Omit<NotificationInstance, 'destroy'>
    props: ArgsProps
}>()

const DEFAULT_NOTIFICATION_PROPS: NotificationConfig = {
    placement: 'bottomRight',
    bottom: 50,
}

const GlobalMessage: FC = () => {
    const [notificationApi, notificationCtx] = notification.useNotification()
    const [modalApi, modalCtx] = Modal.useModal()
    const [messageApi, messageCtx] = message.useMessage()
    useEffect(() => {
        const messageDestroyer = MessageEventEmitter.addEventListener((e) => {
            if (e.type === 'destroy') {
                messageApi.destroy(e.props)
            } else {
                messageApi[e.type](e.props)
            }
        })
        const modalDestroyer = ModalEventEmitter.addEventListener((e) => {
            modalApi[e.type](e.props)
        })
        const notificationDestroyer = NotificationEventEmitter.addEventListener((e) => {
            notificationApi[e.type](Object.assign(DEFAULT_NOTIFICATION_PROPS, e.props))
        })
        return () => {
            messageDestroyer()
            modalDestroyer()
            notificationDestroyer()
        }
    }, [])
    return <>
        {notificationCtx}
        {modalCtx}
        {messageCtx}
    </>
}

export default GlobalMessage