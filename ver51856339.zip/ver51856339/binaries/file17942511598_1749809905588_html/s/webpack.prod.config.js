const path = require('path')
const defaultConfig = require('./webpack.config')

const config = {
    ...defaultConfig({
        APPLICATION_NAME: JSON.stringify('DueDiligence'),
        API_ROOT: JSON.stringify('/DueDiligence'),
        AUTH_URL: JSON.stringify('/'),
        PUBLIC_URL: JSON.stringify('/DueDiligence'),
        BUILD_NO: JSON.stringify(''),

    }, true),
    mode: 'production',
    output: {
        path: path.resolve(__dirname, 'build'),
        filename: '[name].js?[chunkhash]',
        chunkFilename: '[id].js?[chunkhash]',
        publicPath: '/DueDiligence/',
    }
}

module.exports = config