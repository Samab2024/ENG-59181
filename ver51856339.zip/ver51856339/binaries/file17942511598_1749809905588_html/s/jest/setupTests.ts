// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';

// https://jestjs.io/docs/manual-mocks#mocking-methods-which-are-not-implemented-in-jsdom
// Not use jest.fn() here because we set resetMocks=true
if (!window.matchMedia) {
    Object.defineProperty(global.window, 'matchMedia', {
        value: () => ({
            matches: false,
            addListener: () => { },
            removeListener: () => { }
        })
    })
}

Object.defineProperty(global, 'API_ROOT', { value: 'jest.API_ROOT' })
Object.defineProperty(global, 'AUTH_URL', { value: 'jest.AUTH_URL' })
Object.defineProperty(global, 'APPLICATION_NAME', { value: 'jest.APPLICATION_NAME' })
Object.defineProperty(global, 'PUBLIC_URL', { value: 'jest.PUBLIC_URL' })
Object.defineProperty(global, 'BUILD_NO', { value: 'jest.BUILD_NO' })

//Aggrid support
import { TextEncoder } from 'util';
Object.defineProperty(global, 'TextEncoder', { value: TextEncoder, writable: true })

globalThis.IS_REACT_ACT_ENVIRONMENT = true;
