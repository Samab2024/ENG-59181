const { CleanWebpackPlugin } = require('clean-webpack-plugin')
const { DefinePlugin } = require('webpack')
const ESLintPlugin = require('eslint-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin')
const path = require('path')
const svgToMiniDataURI = require('mini-svg-data-uri')
const TsconfigPathsPlugin = require('tsconfig-paths-webpack-plugin')
const CopyPlugin = require("copy-webpack-plugin");
const MonacoWebpackPlugin = require('monaco-editor-webpack-plugin');

// const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

// For our css modules these will be locally scoped
const CSSModuleLoader = {
    loader: 'css-loader',
    options: {
        modules: {
            localIdentName: '[name]_[local]_[hash:base64:5]',
            namedExport: true,
        },
        importLoaders: 1,
    }
}

// For our normal CSS files we would like them globally scoped
const CSSLoader = {
    loader: 'css-loader',
    options: {
        modules: {
            exportGlobals: true,
            localIdentName: '[local]',
        },
        importLoaders: 1,
    }
}

// Our PostCSSLoader
const autoprefixer = require('autoprefixer')
const PostCSSLoader = {
    loader: 'postcss-loader',
    options: {
        postcssOptions: {
            ident: 'postcss',
            sourceMap: false, // turned off as causes delay
            plugins: () => [
                autoprefixer({
                    browsers: ['>1%', 'last 4 versions', 'Firefox ESR', 'not ie < 9']
                })
            ]
        }
    }
}

const config = (envDef, isProd) => ({
    entry: [path.join(__dirname, 'src', 'index.tsx')],
    output: {
        path: path.resolve(__dirname, 'build'),
        filename: '[name].js',
        chunkFilename: '[name].js',
        publicPath: '/',
    },
    module: {
        rules: [
            {
                test: /\.(ts|js)x?$/i,
                use: 'swc-loader',
                exclude: /node_modules/,
            },
            {
                test: /\.css$/,
                exclude: /\.module\.css$/,
                use: ['style-loader', CSSLoader, PostCSSLoader]
            },
            {
                test: /\.module\.css$/,
                use: ['style-loader', CSSModuleLoader, PostCSSLoader]
            },
            {
                test: /\.(eot|ttf|woff|woff2)(\?.+)?$/i,
                type: 'asset/resource',
                generator: {
                    filename: 'fonts/[hash][ext][query]'
                }
            },
            {
                test: /\.json$/,
                type: 'asset/resource',
                generator: {
                    filename: '[name][ext]'
                }
            },
            {
                test: /\.(pdf|xlsx|png|PNG|jpg|jpeg|gif)(\?.+)?$/i,
                type: 'asset',
                generator: {
                    filename: 'assets/[hash][ext][query]'
                },
                parser: {
                    dataUrlCondition: {
                        maxSize: 10 * 1024 // 10kb
                    }
                },
            },
            {
                test: /\.svg$/i,
                type: 'asset/inline',
                generator: {
                    dataUrl: content => svgToMiniDataURI(content.toString())
                }
            },
        ],
    },
    plugins: [
        //HTML Webpack Plugin
        new HtmlWebpackPlugin({
            template: './src/index.html',
        }),
        // new BundleAnalyzerPlugin(),
        new CleanWebpackPlugin(),
        new DefinePlugin(envDef),
        new ESLintPlugin({
            extensions: ["ts", "tsx"],
            fix: false,
            emitError: true,
            emitWarning: false,
            failOnError: true
        }),
        new MonacoWebpackPlugin(),
        isProd && new CopyPlugin({
            patterns: [
                { from: "public", to: "" },
            ],
        }),
    ].filter(Boolean),
    resolve: {
        extensions: ['.tsx', '.ts', '.js'],
        plugins: [new TsconfigPathsPlugin()],
    },
    optimization: {
        splitChunks: {
            chunks: 'all',
            name: 'vendor',
            maxInitialRequests: Infinity,
            minSize: 0,
            cacheGroups: {
                vendor: {
                    test: /[\\/]node_modules[\\/]/,
                    name(module) {
                        // https://medium.com/hackernoon/the-100-correct-way-to-split-your-chunks-with-webpack-f8a9df5b7758
                        // get the name. E.g. node_modules/packageName/not/this/part.js
                        // or node_modules/packageName
                        const packageName = module.context.match(/[\\/]node_modules[\\/](.*?)([\\/]|$)/)[1];

                        // npm package names are URL-safe, but some servers don't like @ symbols
                        // return `npm.${packageName.replace('@', '')}`;
                        if (packageName.includes('ag-grid')) {
                            return `vendor.ag-grid`
                        } else if (packageName.includes('antd') || packageName.includes('rc-')) {
                            return `vendor.antd`;
                        } else if (packageName.includes('monaco')) {
                            return `vendor.monaco`;
                        } else if (packageName.includes('functional-icons')) {
                            return `vendor.icon`;
                        } else {
                            return 'vendor'
                        }
                    },
                },
            },
        },
    },
})

module.exports = config