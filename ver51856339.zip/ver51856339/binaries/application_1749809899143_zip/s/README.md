# boilerplate

## Get Start

- run `npm i`

## Development

- run `npm start` to start local server

- with started up a local server, access `/demo` page to get almost all components needed during devlopment, details pattern please find in `app/Demo` folder.

- theres has a lot of usefull css class in `app/app.less` file.

### Create componment

- import `app/styles/varibles.less` file to access all varibles and colors to help create theme customizeable component.

## Deploy

- update config file `webpack.prod.config.js` with correct infomation.

- run `npm run build` to build production package.

- deploy everything under `/build` folder.

## Reference

- https://blog.logrocket.com/testing-typescript-apps-using-jest/

- https://testing-library.com/docs/

- https://www.robinwieruch.de/react-testing-library/

- https://www.w3.org/TR/html-aria/#docconformance

- https://github.com/testing-library/jest-dom

- https://stately.ai/viz
