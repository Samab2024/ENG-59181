﻿import array
import math
from datetime import datetime, date
from collections import defaultdict

# empty array
#calc_array = []

NA = 'N/A' 

def type_check(*arg_types, **kwarg_types):
    type_name_map = {
        (float, int): "Numeric",
        float: "Numeric",
        int: "Numeric",
        str: "Text",
        bool: "Boolean",
        (date, datetime): "Date",
        date: "Date",
        datetime: "Date",
        list: "List",
        dict: "Dictionary",
        callable: "Function",
        object: "Any"
    }

    def decorator(func):
        def wrapper(*args, **kwargs):
            # Manually specify parameter names
            param_names = func.__code__.co_varnames[:func.__code__.co_argcount]

            # Check each element in *args
            for i, arg in enumerate(args):
                expected_types = arg_types[i] if i < len(arg_types) else arg_types[0]
                if not isinstance(arg, expected_types):
                    if isinstance(expected_types, tuple):
                        type_name = type_name_map.get(expected_types, ' or '.join(t.__name__ for t in expected_types))
                    else:
                        type_name = type_name_map.get(expected_types, expected_types.__name__)
                        
                    if(len(args) > len(arg_types)):
                        param_name = f'arg{i + 1}'
                    else:
                        param_name = param_names[i] if i < len(param_names) else f'arg{i}'
                    #actual_type_name = type_name_map.get(type(arg), type(arg).__name__)
                    #print("----------------------------------------------------------------------------")
                    #print(f"Argument {i}: name={param_name}, type={type_name}, actualtype={actual_type_name}, acturalValue={arg}")
                    raise TypeError( f"calls {func.__name__} failed：parameter [{param_name}] should be {type_name}")
            
            # Check keyword arguments
            for key, expected_types in kwarg_types.items():
                if key in kwargs and not isinstance(kwargs[key], expected_types):
                    if isinstance(expected_types, tuple):
                        type_name = type_name_map.get(expected_types, ' or '.join(t.__name__ for t in expected_types))
                    else:
                        type_name = type_name_map.get(expected_types, expected_types.__name__)
                    raise TypeError(f"calls {func.__name__} failed: parameter [{key}] should be {type_name}")

            return func(*args, **kwargs)
        return wrapper
    return decorator


def ADD(number1, number2):
    try:
        return number1 + number2
    except:
        return NA


def MINUS(number1, number2):
    try:
        return number1 - number2
    except:
        return NA


def MULTIPLY(number1, number2):
    try:
        return number1 * number2
    except:
        return NA


@type_check((float, int), (float, int))
def CEILING(number, significance):
    if significance == 0:
        raise Exception("Call CEILING failed: significance can not be 0.");
    return math.ceil(number / significance) * significance


@type_check((float, int), (float, int))
def FLOOR(number, significance):
    return math.floor(number / significance) * significance


@type_check((float, int), (float, int), (float, int), pv=(float, int), type=(float, int))
def FV(rate, nper, pmt, pv=0, type=0):
    if rate != 0:
        if type == 1:
            return -pmt * ((1 + rate) ** nper - 1) / rate * (1 + rate) - pv * (1 + rate) ** nper
        else:
            return -pmt * ((1 + rate) ** nper - 1) / rate - pv * (1 + rate) ** nper
    else:
        # If rate is 0, the future value is just the sum of nper payments and the present value
        return -pmt * nper - pv


@type_check((datetime, date, int, float, object), str)
def TEXT(value, format_text):
    if isinstance(value, datetime):
        return value.strftime(format_text)
       
    if isinstance(value, (int, float)):
        if '0' in format_text:
            start = format_text.find('0')
            end = start
            while end < len(format_text) and (format_text[end].isdigit() or format_text[end] == '.'):
                end += 1
 
            numeric_format = format_text[start:end]
            decimal_places = numeric_format.count('0', numeric_format.find('.')+1) if '.' in numeric_format else 0
            formatted_value = f"{value:.{decimal_places}f}"
            return format_text.replace(numeric_format, formatted_value)
       
    return str(value)


def IF(condition, true_value, false_value):
    if condition:
        return true_value()
    else:
        return false_value()


def DIV(number1, number2):
    try:
        return 0.0 if number2 == 0.0 else number1/number2
    except:
        return NA


@type_check((float, int))
def SUM(*args):
    if len(args) == 1 and isinstance(args[0], list):
        # Pick up the Value and then sum 
        return sum(item[next(iter(item.keys() - {'LoanId'}))] for item in args[0])
    return sum(args)


def SUMIF(criteria_list, criteria_value, sum_list):
    try:
        # find the loanIds which are matched the criteria
        matching_loan_ids = set()
        for item in criteria_list:
            for key, value in item.items():
                if key != 'LoanId' and value == criteria_value:
                    matching_loan_ids.add(item.get('LoanId'))
                    break
  
        # find the value which are matched the loanIds in Sum_list and Sum them  
        total_sum = 0  
        for item in sum_list:  
            if item.get('LoanId') in matching_loan_ids:
                for key, value in item.items():
                    if key != 'LoanId':
                        total_sum += value
                        break

        return total_sum
    except Exception as e:
        return NA


@type_check((float, int))
def MAX(*args):
    return max(args)


@type_check((float, int))
def MIN(*args):
    return min(args)


@type_check((bool, int, float))
def OR(*args):
    return any(args)


@type_check((float, int), int)
def ROUND(number, digits):
    return round(number, digits)


@type_check((date, datetime), (date, datetime), str)
def DATEDIF(start_date, end_date, unit):
    if unit == 'd':
        diff = (end_date - start_date).days
    elif unit == 'm':
        diff = (end_date.year - start_date.year) * 12 + end_date.month - start_date.month
        if end_date.day < start_date.day:
            diff -= 1
    elif unit == 'y':
        diff = end_date.year - start_date.year  
        if end_date.month < start_date.month or (end_date.month == start_date.month and end_date.day < start_date.day):  
            diff -= 1
    else:  
        raise ValueError("Invalid unit: {}".format(unit))

    return diff


@type_check((date, datetime), (date, datetime), method = (float, int))
def DAYS360(start_date, end_date, method = 0):
    if method == 0:
        # US (NASD) method - 30/360  
        if start_date.month == 2 and start_date.day == 29:
            start_date = date(start_date.year, 3, 1)
        if end_date.month == 2 and end_date.day == 29:
            end_date = date(end_date.year, 2, 28)
        days = (end_date.year - start_date.year) * 360 + (end_date.month - start_date.month) * 30 + (end_date.day - start_date.day)
    elif method == 1:
        # European method - 30/360  
        days = (end_date.year - start_date.year) * 360 + (end_date.month - start_date.month) * 30 + max(0, 30 - start_date.day) + min(30, end_date.day)
    else:
        # Actual/360 method  
        days = (end_date - start_date).days
    return days


def pmt_internal(rate, nper, pv):
    try:
        pmt = (rate * pv) / (1 - (1 + rate) ** (-nper))
        return pmt
    except:
        return NA


@type_check((date, datetime), (float, int))
def EDATE(start_date, months):
    dt0 = start_date
    year = dt0.year
    month = dt0.month
    day = dt0.day
  
    # Calculating a new year and month
    year_delta, month = divmod(month + months - 1, 12)
    year += year_delta
    month += 1
  
    # Dealing with situations that span across different years.
    if month > 12:
        year += 1
        month -= 12
  
    # Calculating a new date  
    dt1 = datetime(year=year, month=month, day=day)
    if day > 28:
        max_day = (dt1.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        dt1 = dt1.replace(day=min(day, max_day.day))
    return dt1


@type_check((float, int), (float, int), (date, datetime), (float, int), (float, int), (float, int), (date, datetime))
def AMORTSCHEDULE(remain_amortization_term, orginal_loan_amount, maturity_date, gross_interest_rate, seasoning, io_period, cutoff_date):
    if(remain_amortization_term == 0):
        return orginal_loan_amount
    else:
        periods = abs(DATEDIF(maturity_date, cutoff_date, "m"))
        ending_balance = orginal_loan_amount
        for period in range(1, periods + 1):
            payment = period + seasoning
            privious_date = EDATE(cutoff_date, period - 1)
            date = EDATE(cutoff_date, period)
            days = abs(DATEDIF(date, privious_date, "d"))
            orig_balance = ending_balance
            interest = orig_balance * gross_interest_rate * days / 360
            payments = interest if payment <= io_period else pmt_internal(gross_interest_rate/12, remain_amortization_term + io_period - payment + 1, orig_balance)
            principal = 0 if payment < io_period else payments - interest
            ending_balance = orig_balance - principal
        return ending_balance


#start: New basic function
def IFERROR(operation, fallback_value):
    try:
        result = operation()
    except Exception as e:
        result = fallback_value
    return result


@type_check((str, datetime))
def DAY(date):
    try:
        if not isinstance(date, datetime):
            date = datetime.strptime(date, '%Y-%m-%d')
        return date.day
    except ValueError:
        raise Exception("Call DAY faield: Invalid date format.")


@type_check((str, datetime))
def MONTH(date):
    try:
        if not isinstance(date, datetime):
            date = datetime.strptime(date, '%Y-%m-%d')
        return date.month
    except ValueError:
        raise Exception("Call MONTH faield: Invalid date format.")


@type_check((str, datetime))
def YEAR(date):
    try:
        if not isinstance(date, datetime):
            date = datetime.strptime(date, '%Y-%m-%d')
        return date.year
    except ValueError:
        raise YEAR("Call YEAR faield: Invalid date format.")


@type_check((float, int), (float, int), (float, int), fv = (float, int), type = (float, int))
def PMT(rate, nper, pv, fv=0, type=0):
    if rate != 0:
        payment = (rate * (pv * (1 + rate)**nper + fv)) / ((1 + rate * type) * ((1 + rate)**nper - 1))
    else:  
        payment = (pv + fv) / nper
    return -payment


@type_check((float, int), (float, int))
def MROUND(number, multiple):
    return round(number / multiple) * multiple


@type_check((bool, int, float))
def AND(*conditions):
    return all(conditions)


def SUMCHILDNODES(field_name, data_source, current_loan_id, current_parent_id):
    try:
        if current_parent_id:
            return 0

        total_sum = 0

        for record in data_source:
            if record.ParentId == int(current_loan_id) and record.Field == field_name:
                if record.Value:
                    total_sum += float(record.Value)
        return total_sum
    except:
        return NA


def SUMPARENTNODE(field_name, data_source, current_loan_id, current_parent_id):
    try:
        loan_id_to_check = current_parent_id if current_parent_id is not None else current_loan_id

        for record in data_source:
            if record.LoanId == int(loan_id_to_check) and record.Field == field_name:
                if record.Value:
                    return float(record.Value)
        return 0
    except:
        return NA


@type_check((int, float))
def STR(number):
    return str(number)


@type_check((str))
def NUMBER(string):
    try:
        # First, try to convert to an integer
        return int(string)
    except ValueError:
         # If that fails, try to convert to a float
        return float(string)
#end


class Loan(object):
    def __init__(self):
        self.test=20
        self.test2=21
    def __getattribute__(self,name):
        if name=='test':
            return 0.
        else:
            return object.__getattribute__(self, name)
 

class LoanWrapper:
    def __init__(self, loan, loan_values):
        self.loan = loan
        # Create a mapping for easier access and modification
        self.loan_values_mapping = {lv.Field: lv for lv in loan_values if lv.LoanId == loan.LoanId}

    def __getattr__(self, attr):
        if attr in self.loan_values_mapping:
            data_format_type = self.loan_values_mapping[attr].DataFormatType
            data_format = self.loan_values_mapping[attr].DataFormat
            if self.loan_values_mapping[attr].Value == "N/A":
                return self.loan_values_mapping[attr].Value
            if self.loan_values_mapping[attr].Value is None or self.loan_values_mapping[attr].Value == "":
                return ""
            
            if data_format_type == 'IsNumeric':
                try:
                    calc_factor_value = float(self.loan_values_mapping[attr].Value)
                except:
                    calc_factor_value = self.loan_values_mapping[attr].Value
            elif data_format_type == 'IsDateTime':
                try:
                    calc_factor_value = datetime.strptime(self.loan_values_mapping[attr].Value, "%Y-%m-%d")
                except:
                    calc_factor_value = self.loan_values_mapping[attr].Value
            else:
                calc_factor_value = '' if self.loan_values_mapping[attr].Value is None else self.loan_values_mapping[attr].Value
            loanid = self.loan_values_mapping[attr].LoanId
            #calc_array.append({'loanid': loanid, 'field': attr, 'value': calc_factor_value, 'formatType': data_format_type, 'format': data_format})
            return calc_factor_value
        raise AttributeError(f"{type(self).__name__!r} object has no attribute {attr!r}")

    def __setattr__(self, attr, value):
        if attr in ['loan', 'loan_values_mapping']:  # Handle setting of internal attributes
            super().__setattr__(attr, value)
        elif attr in self.loan_values_mapping:
            self.loan_values_mapping[attr].Value = value
        else:
            raise AttributeError(f"{type(self).__name__!r} object has no attribute {attr!r}")

# class LoanWrapper:
#     def __init__(self, loan, loan_values):
#         self.loan = loan
#         self.loan_values = {lv['field']: lv['value'] for lv in loan_values if lv['loanid'] == loan['loanid']}
#
#     def __getattr__(self, attr):
#         # Return the value corresponding to the attribute if it exists, else raise an AttributeError
#         if attr in self.loan_values:
#             return self.loan_values[attr]
#         raise AttributeError(f"{type(self).__name__!r} object has no attribute {attr!r}")
#
#     def __setattr__(self, attr, value):
#         if attr in ['loan', 'loan_values_mapping']:  # Handle setting of internal attributes
#             super().__setattr__(attr, value)
#         elif attr in self.loan_values_mapping:
#             self.loan_values_mapping[attr]['value'] = value
#         else:
#             raise AttributeError(f"{type(self).__name__!r} object has no attribute {attr!r}")

class Test:
    def __init__(self, loans, loan_values):
        self.loans = loans
        self.loan_values = loan_values

    def __getitem__(self, index):
        # Get the loan at the provided index
        loan = self.loans[index]
        # Return a LoanWrapper object for the loan
        return LoanWrapper(loan, self.loan_values)


class DealWrapper:
    def __init__(self, deal_configs, loan_id):
        # Create a mapping for easier access and modification
        self.deal_configs_mapping = {dc.Field: dc for dc in deal_configs }
        self.loan_id = loan_id

    def __getattr__(self, attr):
        if attr in self.deal_configs_mapping:
            data_format_type = self.deal_configs_mapping[attr].DataFormatType
            data_format = self.deal_configs_mapping[attr].DataFormat
            if self.deal_configs_mapping[attr].Value == "N/A": 
                return self.deal_configs_mapping[attr].Value
            if self.deal_configs_mapping[attr].Value is None or self.deal_configs_mapping[attr].Value == "":
                return ""
            
            if data_format_type == 'IsNumeric':
                try:
                    deal_config_value = float(self.deal_configs_mapping[attr].Value)
                except:
                    deal_config_value = self.deal_configs_mapping[attr].Value
            elif data_format_type == 'IsDateTime':
                try:
                    deal_config_value = datetime.strptime(self.deal_configs_mapping[attr].Value, "%Y-%m-%d")
                except:
                    deal_config_value = self.deal_configs_mapping[attr].Value
            else:
                deal_config_value = '' if self.deal_configs_mapping[attr].Value is None else self.deal_configs_mapping[attr].Value
           
            #calc_array.append({'loanid': self.loan_id, 'field': attr, 'value': deal_config_value, 'formatType': data_format_type, 'format': data_format})
            return deal_config_value
            #calc_factor_value = self.loan_values_mapping[attr].Value
            #return self.deal_configs_mapping[attr].Value
        raise AttributeError(f"{type(self).__name__!r} object has no attribute {attr!r}")

    def __setattr__(self, attr, value):
        if attr in ['deal_configs_mapping', 'loan_id']:  # Handle setting of internal attributes
            super().__setattr__(attr, value)
        elif attr in self.deal_configs_mapping:
            self.deal_configs_mapping[attr].Value = value
        else:
            raise AttributeError(f"{type(self).__name__!r} object has no attribute {attr!r}")


class TotalLoanCategorizer:
    def __init__(self, loan_value):
        self.loan_value = loan_value
        self._categorized_data = defaultdict(list)
        self._categorize_data()
  
    def _categorize_data(self):
        for entry in self.loan_value:
            field = entry.Field
            loan_id = entry.LoanId
            value = entry.Value
            
            try:
                value = self.convert_value(value, entry.DataFormatType)
            except ValueError:
                pass
            self._categorized_data[field].append({'LoanId': loan_id, field: value})
            
    def convert_value(self, value, data_format_type):
        if value == "N/A": 
            return value
        if value is None:
            return ""
        
        if data_format_type == "IsNumeric":
            return float(value) if '.' in value else int(value)
        elif data_format_type == 'IsDateTime':
            return datetime(1899,12,30) if value is None else datetime.strptime(value, "%Y-%m-%d")
        return value
  
    def __getattr__(self, name):
        if name in self._categorized_data:
            return self._categorized_data[name]
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

##deal_configs = [
#        {'dealId': 50, 'field': 'TotalCutoffBalance', 'value': '10.3'},
#        {'dealId': 50, 'field': 'FeeTotalAdmin', 'value': '200.1'},
#        {'dealId': 50, 'field': 'SOFR', 'value': '30'},      
#]

#deal = DealWrapper(deal_configs)
#result = deal.TotalCutoffBalance

# calc_json_str = json.dumps(calc_array)

#header_map =[{'field': 'BALANCE', 'type':'number'},
#             {'field': 'PRICE', 'type':'number'}
#            ]
#
#loan_value = [
#        {'loanid': 11, 'field': 'LOAN_ID', 'value': '10.3'},
#        {'loanid': 11, 'field': 'BALANCE', 'value': '200.1'},
#        {'loanid': 11, 'field': 'PRICE', 'value': '30'},
#        {'loanid': 22, 'field': 'LOAN_ID', 'value': '10.5'},
#        {'loanid': 22, 'field': 'BALANCE', 'value': '300'},
#        {'loanid': 22, 'field': 'PRICE', 'value': '50'},
#    ]
#
#loan = [
#        {'loanid': 11, 'name': 'abc'},
#        {'loanid': 22, 'name': 'def'}
#    ]
#
#d = Test(loan,loan_value)
#
#result = IF(int(float(d[0].LOAN_ID))==d[0].LOAN_ID,d[0].BALANCE, d[0].PRICE)
#print(result)
#
#print(int(d[0].BALANCE))
#d[0].PRICE = '10'
#print(loan_value)