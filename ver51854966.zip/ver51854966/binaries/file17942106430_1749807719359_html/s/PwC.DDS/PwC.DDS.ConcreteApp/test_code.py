﻿def add_numbers(a, b):  
    return a + b  
  
def minus_numbers(a, b):  
    return a - b

def multiply_numbers(a, b):  
    return a * b

def IF(condition, true_value, false_value):  
    if condition:  
        return true_value  
    else:  
        return false_value

class Loan(object):
    def __init__(self):
        self.test=20
        self.test2=21
    def __getattribute__(self,name):
        if name=='test':
            return 0.
        else:
            return object.__getattribute__(self, name)

 

class Test(object):
    loan_value = [  
        {'loanid': 1, 'field': 'BALANCE', 'value': '200'},  
        {'loanid': 1, 'field': 'PRICE', 'value': '30'},  
        {'loanid': 2, 'field': 'BALANCE', 'value': '300'},  
        {'loanid': 2, 'field': 'PRICE', 'value': '50'},  
    ] 
    def __init__(self,base):
        object.__setattribute__(self,'base',base)

    def __getattribute__(self, name):
        field = loan_value[name]
        return getattr(self.base, field.Name)

class LoanWrapper:  
    def __init__(self, loan, loan_values):  
        self.loan = loan  
        self.loan_values = {lv['field']: lv['value'] for lv in loan_values if lv['loanid'] == loan['loanid']}  
      
    def __getattr__(self, attr):  
        # Return the value corresponding to the attribute if it exists, else raise an AttributeError  
        if attr in self.loan_values:  
            return self.loan_values[attr]  
        raise AttributeError(f"{type(self).__name__!r} object has no attribute {attr!r}")  
    
class Test:  
    def __init__(self, loans, loan_values):  
        self.loans = loans  
        self.loan_values = loan_values  
  
    def __getitem__(self, index):  
        # Get the loan at the provided index  
        loan = self.loans[index]  
        # Return a LoanWrapper object for the loan  
        return LoanWrapper(loan, self.loan_values)  