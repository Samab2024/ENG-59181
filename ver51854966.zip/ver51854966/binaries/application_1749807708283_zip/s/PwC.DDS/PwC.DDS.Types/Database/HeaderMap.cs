﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace PwC.DDS.Types.Database
{
    [Table("HeaderMap")]
    public class HeaderMap : Extensions.IDataModel
    {
        public HeaderMap()
        {
            LoanReviews = new HashSet<LoanReview>();
        }

        [Key]
        public long HeaderMapId { get; set; }

        public long DealId { get; set; }

        public int ReportOrder { get; set; }

        public int DisplayOrder { get; set; }

        public int LevelOfReview { get; set; }

        [StringLength(200)]
        public string? ClientHeader { get; set; }

        [StringLength(200)]
        public string? PwCHeader { get; set; }

        [StringLength(200)]
        public string? CalculatorHeader { get; set; }

        [StringLength(5000)]
        public string? CalculatorFormula { get; set; }

        [StringLength(20)]
        public string? ProcessType { get; set; }

        public long SourceDocSectionId { get; set; }

        [StringLength(50)]
        public long SourceId { get; set; }

		[ForeignKey("DataFormat"), Column(Order = 0)]
		public int DataFormatId { get; set; }

        public long? ScreenShotId { get; set; }

        public long? DropdownCategoryId { get; set; }

        [StringLength(2000)]
        public string? FieldGuide { get; set; }

        public bool IsActive { get; set; }

        public bool IsExcludedInReport { get; set; }

        public bool IsBlindReview { get; set; }

        public decimal Threadhold { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; } 

        public virtual DealSetup DealSetup { get; set; }

        public virtual SourceDocSection SourceDocSection { get; set; }

        public virtual Source Source { get; set; }

        public virtual DataFormat DataFormat { get; set; }

		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<LoanReview> LoanReviews { get; set; }
    }

    public class HeaderMapEntityTypeConfiguration : IEntityTypeConfiguration<HeaderMap>
    {
        public void Configure(EntityTypeBuilder<HeaderMap> builder)
        {
            builder.HasKey(o => new { o.HeaderMapId});
            builder.Property(e => e.ClientHeader).IsUnicode(true);
            builder.Property(e => e.PwCHeader).IsUnicode(true);
            builder.Property(e => e.ProcessType).IsUnicode(false);
            builder.Property(e => e.FieldGuide).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
            builder.Property(e => e.Threadhold).HasPrecision(17, 4);
            builder.HasMany(e => e.LoanReviews).WithOne(e => e.HeaderMap).HasForeignKey(e => new { e.HeaderMapId });
        }
    }
}
