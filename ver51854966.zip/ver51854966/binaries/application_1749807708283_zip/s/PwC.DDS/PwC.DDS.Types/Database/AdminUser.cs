﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PwC.DDS.Types.Database
{
    [Table("AdminUser")]
    public class AdminUser
    {
        [Key]
        public int EmployeeID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Guid { get; set; }

        public string Email { get; set; }
    }

    public class AdminUserEntityTypeConfiguration : IEntityTypeConfiguration<AdminUser>
    {
        public void Configure(EntityTypeBuilder<AdminUser> builder)
        {
            builder.HasKey(o => new { o.EmployeeID });
        }
    }
}
