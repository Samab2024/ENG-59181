﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PwC.DDS.Types.Database
{
    [Table("vEmployeeDetails")]
    public class vEmployeeDetails
    {
        [Key]
        public int EmployeeID { get; set; }

        public string? FirstName { get; set; }

        public string? LastName { get; set; }

        public string? Guid { get; set; }

        public string? Email { get; set; }
    }

    public class vEmployeeDetailsEntityTypeConfiguration : IEntityTypeConfiguration<vEmployeeDetails>
    {
        public void Configure(EntityTypeBuilder<vEmployeeDetails> builder)
        {
            builder.HasKey(o => new { o.EmployeeID });
        }
    }
}
