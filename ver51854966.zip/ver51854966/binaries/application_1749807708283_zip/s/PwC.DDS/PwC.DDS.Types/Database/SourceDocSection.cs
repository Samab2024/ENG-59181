﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace PwC.DDS.Types.Database
{
    [Table("SourceDocSection")]
    public class SourceDocSection : Extensions.IDataModel
    {
        [SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public SourceDocSection()
        {
            HeaderMaps = new HashSet<HeaderMap>();
        }

        [Key]
        public long SourceDocSectionId { get; set; }

        public long DealId { get; set; }

        public long SectionId { get; set; }

        [StringLength(200)]
        public string Name { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsAllowCopy { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DealSetup DealSetup { get; set; }

        public virtual Section Section { get; set; }

        public virtual ICollection<HeaderMap> HeaderMaps { get; set; }
    }

    public class SourceDocSectionEntityTypeConfiguration : IEntityTypeConfiguration<SourceDocSection>
    {
        public void Configure(EntityTypeBuilder<SourceDocSection> builder)
        {
            builder.HasKey(o => new { o.SourceDocSectionId });
            builder.Property(e => e.Name).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
            builder.HasMany(e => e.HeaderMaps).WithOne(e => e.SourceDocSection).HasForeignKey(e => new { e.SourceDocSectionId });
        }
    }
}
