﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Database.Extensions
{
    public interface IDataModel
    {
        DateTime CreatedTime { get; set; }
        string CreatedBy { get; set; }
        DateTime LastUpdatedTime { get; set; }
        string LastUpdatedBy { get; set; }
    }

    public static class DataModelExtension
    {
        public static T UpdateBy<T>(this T self, string requestedBy) where T : IDataModel
        {
            self.LastUpdatedBy = requestedBy;
            self.LastUpdatedTime = DateTime.UtcNow;
            return self;
        }

        public static T CreateBy<T>(this T self, string requestedBy) where T : IDataModel
        {
            self.CreatedBy = requestedBy;
            self.CreatedTime = DateTime.UtcNow;
            self.LastUpdatedBy = requestedBy;
            self.LastUpdatedTime = self.CreatedTime;
            return self;
        }
    }
}
