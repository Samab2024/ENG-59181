﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace PwC.DDS.Types.Database
{
    [Table("Loan")]
    public class Loan : Extensions.IDataModel
    {
        public Loan()
        {
            LoanReviews = new HashSet<LoanReview>();
        }

        [Key]
        public long LoanId { get; set; }

        public long DealId { get; set; }

        public long SellerId { get; set; }

        public long? ParentId { get; set; }

        [StringLength(200)]
        public string LoanNumber { get; set; }

        [StringLength(200)]
        public string? PropertyName { get; set; }

        [StringLength(2000)]
        public string? MissingDoc { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public bool IsRandomReview { get; set; }

        public virtual DealSetup DealSetup { get; set; }

        public virtual Seller Seller { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<LoanReview> LoanReviews { get; set; }
    }

    public class LoanEntityTypeConfiguration : IEntityTypeConfiguration<Loan>
    {
        public void Configure(EntityTypeBuilder<Loan> builder)
        {
            builder.HasKey(o => new { o.LoanId});
            builder.Property(e => e.LoanNumber).IsUnicode(true);
            builder.Property(e => e.PropertyName).IsUnicode(true);
            builder.Property(e => e.MissingDoc).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
            builder.HasMany(e => e.LoanReviews).WithOne(e => e.Loan).HasForeignKey(e => new { e.LoanId });
        }
    }
}
