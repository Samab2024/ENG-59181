﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace PwC.DDS.Types.Database
{
    [Table("DropdownCategoryOption")]
    public class DropdownCategoryOption : Extensions.IDataModel
    {
        public DropdownCategoryOption()
        {

        }

        [Key]
        public long CategoryOptionId { get; set; }

        public long DealId { get; set; }

        public long CategoryId { get; set; }

        [StringLength(2000)]
        public string OptionName { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DropdownCategory DropdownCategory { get; set; }
    }

    public class DropdownCategoryOptionEntityTypeConfiguration : IEntityTypeConfiguration<DropdownCategoryOption>
    {
        public void Configure(EntityTypeBuilder<DropdownCategoryOption> builder)
        {
            builder.HasKey(o => new { o.CategoryOptionId });
            builder.Property(e => e.OptionName).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
        }
    }
}
