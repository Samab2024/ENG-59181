﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace PwC.DDS.Types.Database
{
    [Table("Section")]
    public class Section : Extensions.IDataModel
    {
        public Section()
        {
            SourceDocSections = new HashSet<SourceDocSection>();
        }

        [Key]
        public long SectionId { get; set; }

        public long DealId { get; set; }

        [StringLength(200)]
        public string Name { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DealSetup DealSetup { get; set; }

        public virtual ICollection<SourceDocSection> SourceDocSections { get; set; }
    }

    public class SectionEntityTypeConfiguration : IEntityTypeConfiguration<Section>
    {
        public void Configure(EntityTypeBuilder<Section> builder)
        {
            builder.HasKey(o => new { o.SectionId });
            builder.Property(e => e.Name).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
            builder.HasMany(e => e.SourceDocSections).WithOne(e => e.Section).HasForeignKey(e => new { e.SectionId });
        }
    }
}
