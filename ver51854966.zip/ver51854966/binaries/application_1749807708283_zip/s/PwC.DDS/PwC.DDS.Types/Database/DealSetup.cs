﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Diagnostics.CodeAnalysis;
using static System.Collections.Specialized.BitVector32;

namespace PwC.DDS.Types.Database
{
    [Table("DealSetup")]
    public class DealSetup : Extensions.IDataModel
    {
        [SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public DealSetup()
        {
            Loans = new HashSet<Loan>();
            HeaderMaps = new HashSet<HeaderMap>();
            Reviewers = new HashSet<Reviewer>();
            LoanReviews = new HashSet<LoanReview>();
            ScreenShot = new HashSet<ScreenShot>();
            Sections = new HashSet<Section>();
            Sellers = new HashSet<Seller>();
            Sources = new HashSet<Source>();
            Processes = new HashSet<Process>();
            SourceDocSections = new HashSet<SourceDocSection>();
            DropdownCategorys = new HashSet<DropdownCategory>();
            UploadFileInfos = new HashSet<UploadFileInfo>();
            CalculatorGlobalFields = new HashSet<CalculatorGlobalField>();
        }

        [Key]
        public long DealId { get; set; }

        [StringLength(100)]
        public string DealName { get; set; }

        [StringLength(500)]
        public string? DealDesc { get; set; }

        [StringLength(100)]
        public string AssetType { get; set; }

        [StringLength(100)]
        public string? KeyColumn { get; set; }

        [Column(TypeName = "date")]
        public DateTime? CutOffDate { get; set; }

        public int LevelOfReview { get; set; }

        [StringLength(500)]
        public string? DealAdmin { get; set; }

        [StringLength(500)]
        public string? DealContact { get; set; }

        [StringLength(500)]
        public string? ClientName { get; set; }

        public long? DuplicateHMDealId { get; set; }

        public DateTime? DuplicateHMDate { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public bool IsBlindReview { get; set; }

        public bool IsExRptIncludePwCComments { get; set; }

        [StringLength(20)]
        public string? DealStatus { get; set; }

        [StringLength(20)]
        public string? DealState { get; set; }

        public DateTime? DealStateChangeTime { get; set; }

        [StringLength(128)]
        public string? DealStateChangeBy { get; set; }

        [StringLength(100)]
        public string? LoanNumberDisplayColumn { get; set; }

        public int LevelOfReviewForCalculation { get; set; }

        public bool NeedRecalculation { get; set; }


        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Loan> Loans { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<HeaderMap> HeaderMaps { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Reviewer> Reviewers { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<LoanReview> LoanReviews { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ScreenShot> ScreenShot { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Section> Sections { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Seller> Sellers { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Source> Sources { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Process> Processes { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<SourceDocSection> SourceDocSections { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]

        public virtual ICollection<DropdownCategory> DropdownCategorys { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]

        public virtual ICollection<UploadFileInfo> UploadFileInfos { get; set; }

        [SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]

        public virtual ICollection<CalculatorGlobalField> CalculatorGlobalFields { get; set; }        
    }

    public class DealSetupEntityTypeConfiguration : IEntityTypeConfiguration<DealSetup>
    {
        public void Configure(EntityTypeBuilder<DealSetup> builder)
        {
            builder.Property(e => e.DealName).IsUnicode(false);
            builder.Property(e => e.DealDesc).IsUnicode(false);
            builder.Property(e => e.DealAdmin).IsUnicode(false);
            builder.Property(e => e.DealContact).IsUnicode(false);
            builder.Property(e => e.ClientName).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
            builder.Property(e => e.DealStateChangeBy).IsUnicode(false);
            builder.HasMany(e => e.Loans).WithOne(e => e.DealSetup).HasForeignKey(e=>e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.HeaderMaps).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.Reviewers).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.LoanReviews).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.ScreenShot).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.Sections).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.Sellers).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.Sources).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.Processes).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.SourceDocSections).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.DropdownCategorys).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.UploadFileInfos).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(e => e.CalculatorGlobalFields).WithOne(e => e.DealSetup).HasForeignKey(e => e.DealId).OnDelete(DeleteBehavior.Restrict);
        }
    }
}
