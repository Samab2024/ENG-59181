﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace PwC.DDS.Types.Database
{
    [Table("Seller")]
    public class Seller : Extensions.IDataModel
    {
        public Seller()
        {
            Loans = new HashSet<Loan>();
        }

        [Key]
        public long SellerId { get; set; }

        public long DealId { get; set; }

        [StringLength(200)]
        public string Name { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DealSetup DealSetup { get; set; }

        public virtual ICollection<Loan> Loans { get; set; }
    }

    public class SellerEntityTypeConfiguration : IEntityTypeConfiguration<Seller>
    {
        public void Configure(EntityTypeBuilder<Seller> builder)
        {
            builder.HasKey(o => new { o.SellerId });
            builder.Property(e => e.Name).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
            builder.HasMany(e => e.Loans).WithOne(e => e.Seller).HasForeignKey(e => new { e.SellerId });
        }
    }
}
