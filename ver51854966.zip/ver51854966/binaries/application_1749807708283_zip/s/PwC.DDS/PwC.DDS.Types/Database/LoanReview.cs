﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PwC.DDS.Types.Database
{
    [Table("LoanReview")]
    public class LoanReview : Extensions.IDataModel
    {
        [Key]
        public long DealId { get; set; }

        [Key]    
        public long LoanId { get; set; }

        [Key]
        public long HeaderMapId { get; set; }

        [StringLength(2000)]
        public string? ClientValue { get; set; }

        [StringLength(2000)]
        public string? ClientDisplayValue { get; set; }

        public string? ClientValueFormat { get; set; }

        [StringLength(2000)]
        public string? FirstReviewValue { get; set; }

        [StringLength(200)]
        public string? FirstReviewFormula { get; set; }

        public bool IsFirstReviewed { get; set; }

        [StringLength(2000)]
        public string? SecondReviewValue { get; set; }

        [StringLength(200)]
        public string? SecondReviewFormula { get; set; }

        public bool IsSecondReviewed { get; set; }

        [StringLength(2000)]
        public string? ThirdReviewValue { get; set; }

        [StringLength(200)]
        public string? ThirdReviewFormula { get; set; }

        public bool IsThirdReviewed { get; set; }

        [StringLength(2000)]
        public string? FinalValue { get; set; }

        [StringLength(5000)]
        public string? PwCComments { get; set; }

        [StringLength(5000)]
        public string? InternalComments { get; set; }

        public bool? IsTie { get; set; }

		public DateTime? FirstReviewUpdatedTime { get; set; }

		[StringLength(128)]
		public string? FirstReviewUpdatedBy { get; set; }

		public DateTime? SecondReviewUpdatedTime { get; set; }

		[StringLength(128)]
		public string? SecondReviewUpdatedBy { get; set; }

		public DateTime? ThirdReviewUpdatedTime { get; set; }

		[StringLength(128)]
		public string? ThirdReviewUpdatedBy { get; set; }

		public DateTime? FinalValueUpdatedTime { get; set; }

		[StringLength(128)]
		public string? FinalValueUpdatedBy { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DealSetup DealSetup { get; set; }

        public virtual Loan Loan { get; set; }

        public virtual HeaderMap HeaderMap { get; set; }
    }

    public class LoanReviewEntityTypeConfiguration : IEntityTypeConfiguration<LoanReview>
    {
        public void Configure(EntityTypeBuilder<LoanReview> builder)
        {
            builder.HasKey(o => new { o.DealId, o.LoanId, o.HeaderMapId });
            builder.Property(e => e.ClientValue).IsUnicode(true);
            builder.Property(e => e.ClientDisplayValue).IsUnicode(true);
            builder.Property(e => e.ClientValueFormat).IsUnicode(true);
            builder.Property(e => e.FirstReviewValue).IsUnicode(true);
            builder.Property(e => e.FirstReviewFormula).IsUnicode(false);
            builder.Property(e => e.SecondReviewValue).IsUnicode(true);
            builder.Property(e => e.SecondReviewFormula).IsUnicode(false);
            builder.Property(e => e.ThirdReviewValue).IsUnicode(true);
            builder.Property(e => e.ThirdReviewFormula).IsUnicode(false);
            builder.Property(e => e.FinalValue).IsUnicode(true);
            builder.Property(e => e.PwCComments).IsUnicode(false);
            builder.Property(e => e.InternalComments).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
			builder.Property(e => e.FirstReviewUpdatedBy).IsUnicode(false);
			builder.Property(e => e.SecondReviewUpdatedBy).IsUnicode(false);
			builder.Property(e => e.ThirdReviewUpdatedBy).IsUnicode(false);
			builder.Property(e => e.FinalValueUpdatedBy).IsUnicode(false);
		}
    }
}
