﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Types.Database;

namespace PwC.DDS.Database
{
    public partial class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        public virtual DbSet<AdminUser> AdminUsers { get; set; }
        public virtual DbSet<vEmployeeDetails> EmployeeDetails { get; set; }
        public virtual DbSet<DataFormat> DataFormats { get; set; }
        public virtual DbSet<DealSetup> DealSetups { get; set; }
        public virtual DbSet<HeaderMap> HeaderMaps { get; set; }
        public virtual DbSet<Loan> Loans { get; set; }
        public virtual DbSet<LoanReview> LoanReviews { get; set; }
        public virtual DbSet<Lookup> Lookups { get; set; }
        public virtual DbSet<Reviewer> Reviewers { get; set; }
        public virtual DbSet<ScreenShot> ScreenShots { get; set; }
        public virtual DbSet<Section> Sections { get; set; }
        public virtual DbSet<Seller> Sellers { get; set; }
        public virtual DbSet<Source> Sources { get; set; }
        public virtual DbSet<Process> Processes { get; set; }
        public virtual DbSet<SourceDocSection> SourceDocSections { get; set; }
        public virtual DbSet<DropdownCategory> DropdownCategorys { get; set; }
        public virtual DbSet<DropdownCategoryOption> DropdownCategoryOptions { get; set; }
        public virtual DbSet<UploadFileInfo> UploadFileInfos { get; set; }
        public virtual DbSet<CalculatorGlobalField> CalculatorGlobalFields { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
        }
    }
}
