﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Database
{
    [Table("CalculatorGlobalField")]
    public class CalculatorGlobalField : Extensions.IDataModel
    {
        [Key]
        public long CalculatorGlobalFieldId { get; set; }

        public long DealId { get; set; }

        [StringLength(200)]
        public string FieldName { get; set; }

        [StringLength(200)]
        public string FieldValue { get; set; }

        [ForeignKey("DataFormat"), Column(Order = 0)]
        public int DataFormatId { get; set; }

        [StringLength(5000)]
        public string? CalculatorFormula { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DealSetup DealSetup { get; set; }

        public virtual DataFormat DataFormat { get; set; }
    }

    public class CalculatorGlobalFieldEntityTypeConfiguration : IEntityTypeConfiguration<CalculatorGlobalField>
    {
        public void Configure(EntityTypeBuilder<CalculatorGlobalField> builder)
        {
            builder.HasKey(o => new { o.CalculatorGlobalFieldId });
            builder.Property(e => e.FieldName).IsUnicode(true);            
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
        }    
    }
}
