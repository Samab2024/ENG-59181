﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace PwC.DDS.Types.Database
{
    [Table("Process")]
    public class Process : Extensions.IDataModel
    {
        [Key]
        public long ProcessId { get; set; }

        public long DealId { get; set; }

        public DateTime? StartTime { get; set; }

        public DateTime? EndTime { get; set; }

        [StringLength(20)]
        public string? RunType { get; set; }

        [StringLength(300)]
        public string? FileName { get; set; }

        [StringLength(30)]
        public string? SheetName { get; set; }

        public long? SellerId { get; set; }

        public int? ReviewLevel { get; set; }

        [StringLength(20)]
        public string? Status { get; set; }

        [StringLength(2000)]
        public string? Message { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DealSetup DealSetup { get; set; }
    }

    public class ProcessEntityTypeConfiguration : IEntityTypeConfiguration<Process>
    {
        public void Configure(EntityTypeBuilder<Process> builder)
        {
            builder.HasKey(o => new { o.ProcessId });
            builder.Property(e => e.RunType).IsUnicode(false);
            builder.Property(e => e.FileName).IsUnicode(false);
            builder.Property(e => e.SheetName).IsUnicode(false);
            builder.Property(e => e.Status).IsUnicode(false);
            builder.Property(e => e.Message).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
        }
    }
}
