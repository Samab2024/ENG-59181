﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PwC.DDS.Types.Database
{
    [Table("ScreenShot")]
    public class ScreenShot
    {
        [Key]
        public long ScreenShotId { get; set; }

        public long DealId { get; set; }

        [Required]
        public byte[]? Image { get; set; }

        public virtual DealSetup DealSetup { get; set; }
    }

    public class ScreenShotEntityTypeConfiguration : IEntityTypeConfiguration<ScreenShot>
    {
        public void Configure(EntityTypeBuilder<ScreenShot> builder)
        {
            builder.HasKey(o => new { o.ScreenShotId });
        }
    }
}
