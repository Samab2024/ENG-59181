﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using System.Text.RegularExpressions;

namespace PwC.DDS.Types.Database
{
    [Table("DataFormat")]
    public class DataFormat : Extensions.IDataModel
    {
        [SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public DataFormat()
        {
            HeaderMaps = new HashSet<HeaderMap>();
        }

        [Key]
        public int DataFormatId { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(100)]
        public string Type { get; set; }

        [StringLength(100)]
        public string Format { get; set; }

        [StringLength(100)]
        public string? Code { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsEditable { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }            

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

		[InverseProperty(nameof(HeaderMap.DataFormat))]
		public virtual ICollection<HeaderMap> HeaderMaps { get; set; }
	}

    public class DataFormatEntityTypeConfiguration : IEntityTypeConfiguration<DataFormat>
    {
        public void Configure(EntityTypeBuilder<DataFormat> builder)
        {
            builder.Property(e => e.Name).IsUnicode(false);
            builder.Property(e => e.Type).IsUnicode(false);
            builder.Property(e => e.Format).IsUnicode(false);
            builder.Property(e => e.Code).IsUnicode(false);           
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
            builder.HasMany(e => e.HeaderMaps).WithOne(e => e.DataFormat).HasForeignKey(e => new { e.DataFormatId });
        }
    }
}
