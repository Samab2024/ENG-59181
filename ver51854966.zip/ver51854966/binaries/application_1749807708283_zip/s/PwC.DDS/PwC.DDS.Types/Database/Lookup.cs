﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace PwC.DDS.Types.Database
{
    [Table("Lookup")]
    public class Lookup : Extensions.IDataModel
    {
        [Key]
        public int LookupId { get; set; }

        [Required]
        [StringLength(50)]
        public string Category { get; set; }

        public int Sequence { get; set; }

        [Required]
        [StringLength(100)]
        public string Code { get; set; }

        [Required]
        [StringLength(100)]
        public string Display { get; set; }

        [StringLength(200)]
        public string Description { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }
    }

    public class LookupEntityTypeConfiguration : IEntityTypeConfiguration<Lookup>
    {
        public void Configure(EntityTypeBuilder<Lookup> builder)
        {
            builder.Property(e => e.Category).IsUnicode(false);
            builder.Property(e => e.Code).IsUnicode(false);
            builder.Property(e => e.Display).IsUnicode(false);
            builder.Property(e => e.Description).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
        }
    }
}
