﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace PwC.DDS.Types.Database
{
    [Table("DropdownCategory")]
    public class DropdownCategory : Extensions.IDataModel
    {
        public DropdownCategory()
        {

        }

        [Key]
        public long CategoryId { get; set; }

        public long DealId { get; set; }

        [StringLength(200)]
        public string CategoryName { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DealSetup DealSetup { get; set; }

        public virtual ICollection<DropdownCategoryOption> DropdownCategoryOptions { get; set; }
    }

    public class DropdownCategoryEntityTypeConfiguration : IEntityTypeConfiguration<DropdownCategory>
    {
        public void Configure(EntityTypeBuilder<DropdownCategory> builder)
        {
            builder.HasKey(o => new { o.CategoryId });
            builder.Property(e => e.CategoryName).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
            builder.HasMany(e => e.DropdownCategoryOptions).WithOne(e => e.DropdownCategory).HasForeignKey(e => e.CategoryId);
        }
    }
}
