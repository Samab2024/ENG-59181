﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PwC.DDS.Types.Database
{
	[Table("UploadFileInfo")]
	public class UploadFileInfo : Extensions.IDataModel
	{
		[Key]
		public long UploadFileInfoId { get; set; }
		public long DealId { get; set; }
		[StringLength(500)]
		public string? InitiateFileName { get; set; }
        public byte[]? InitiateFile { get; set; }
		[StringLength(500)]
		public string? UpdateFileName { get; set; }
		public byte[]? UpdateFile { get; set; }
		public DateTime CreatedTime { get; set; }
		[StringLength(128)]
		public string CreatedBy { get; set; }
		public DateTime LastUpdatedTime { get; set; }
		[StringLength(128)]
		public string LastUpdatedBy { get; set; }
		public virtual DealSetup DealSetup { get; set; }
	}
	public class UploadFileInfoEntityTypeConfiguration : IEntityTypeConfiguration<UploadFileInfo>
	{
		public void Configure(EntityTypeBuilder<UploadFileInfo> builder)
		{
			builder.HasKey(o => new { o.UploadFileInfoId });
			builder.Property(e => e.InitiateFileName).IsUnicode(false);
			builder.Property(e => e.UpdateFileName).IsUnicode(false);
			builder.Property(e => e.CreatedBy).IsUnicode(false);
			builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
		}
	}
}
