﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PwC.DDS.Types.Database
{
    [Table("Reviewer")]
    public class Reviewer : Extensions.IDataModel
    {
        [Key]
        public long ReviewerId { get; set; }

        public long DealId { get; set; }

        public long LoanId { get; set; }

        public long HeaderMapId { get; set; }

        public long SectionId { get; set; }

        [StringLength(128)]
        public string? Reviewer1 { get; set; }

        [StringLength(20)]
        public string? ReviewerStatus1 { get; set; }

        [StringLength(128)]
        public string? Reviewer2 { get; set; }

        [StringLength(20)]
        public string? ReviewerStatus2 { get; set; }

        [StringLength(128)]
        public string? Reviewer3 { get; set; }

        [StringLength(20)]
        public string? ReviewerStatus3 { get; set; }

        public DateTime CreatedTime { get; set; }

        [StringLength(128)]
        public string CreatedBy { get; set; }

        public DateTime LastUpdatedTime { get; set; }

        [StringLength(128)]
        public string LastUpdatedBy { get; set; }

        public virtual DealSetup DealSetup { get; set; }
    }

    public class ReviewerEntityTypeConfiguration : IEntityTypeConfiguration<Reviewer>
    {
        public void Configure(EntityTypeBuilder<Reviewer> builder)
        {
            builder.HasKey(o => new { o.ReviewerId });
            builder.Property(e => e.Reviewer1).IsUnicode(false);
            builder.Property(e => e.ReviewerStatus1).IsUnicode(false);
            builder.Property(e => e.Reviewer2).IsUnicode(false);
            builder.Property(e => e.ReviewerStatus2).IsUnicode(false);
            builder.Property(e => e.Reviewer3).IsUnicode(false);
            builder.Property(e => e.ReviewerStatus3).IsUnicode(false);
            builder.Property(e => e.CreatedBy).IsUnicode(false);
            builder.Property(e => e.LastUpdatedBy).IsUnicode(false);
        }
    }
}
