﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class DealSetupDTO
    {
        public long DealId { get; set; }
        [MaxLength(100)]
        public string DealName { get; set; }
        [MaxLength(500)]
        public string? DealDesc { get; set; }
        [MaxLength(100)]
        public string AssetType { get; set; }
        [MaxLength(100)]
        public string? KeyColumn { get; set; }
        public DateTime? CutOffDate { get; set; }
        public int LevelOfReview { get; set; }
        [MaxLength(500)]
        public string? DealAdmin { get; set; }
        [MaxLength(1000)]
        public string? DealContact { get; set; }
        [MaxLength(500)]
        public string? ClientName { get; set; }
        public bool IsBlindReview { get; set;}
        public bool IsExRptIncludePwCComments { get; set; }
        [MaxLength(20)]
        public string? DealStatus { get; set; }
        [MaxLength(100)]
        public string? LoanNumberDisplayColumn { get; set; }
        public bool IsDealAdmin { get; set; } // Calc field
        public bool IsEditable { get; set; } // Calc field
        public bool IsReadOnly { get; set; } // Calc field
        public bool? IsAllowRandomReview { get; set; } // Calc field
        public bool? IsRandomReview { get; set; } // Calc field
        public int LevelOfReviewForCalculation { get; set; }
    }
}
