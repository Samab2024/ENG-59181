﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class ImportDataDTO
    {
        public long DealId { get; set; }

        public List<long> SellerIds { get; set; }

        public IFormFile File { get; set; }

        [MaxLength(31)]
        public string SheetName { get; set; }

        public ImportRunType ImportRunType { get; set; }

        public ReviewLevel? ReviewLevel { get; set; }

        public ImportLoanMapDTO[]? LoanMaps { get; set; }

        public ImportHeaderMapDTO[]? HeaderMaps { get; set; }
    }

    public class ImportLoanMapDTO
    {
        public long OrgLoanId { get; set; }
        public long NewLoanId { get; set; }
    }

    public class ImportHeaderMapDTO
    {
        public long OrgHeaderId { get; set; }
        public long NewHeaderId { get; set; }
    }
}
