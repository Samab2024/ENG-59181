﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
	public class PwCTapeReportDTO
	{
		public long LoanId { get; set; }
		public long HeaderMapId { get; set; }
		public string? HeaderMapName { get; set; }
        public string? ProcessType { get; set; }
        public int LevelOfReview { get; set; }
        public string? ClientValue { get; set; }
        public string? OriginalCustomFormat { get; set; }
        public string? FirstReviewValue { get; set; }
        public string? SecondReviewValue { get; set; }
        public string? ThirdReviewValue { get; set; }
        public string? PwCValue { get; set;}
        public string? PwCComments { get; set; }
        public string? DataFormatType { get; set; }
        public string? CustomFormat { get; set; }
        public bool IsFirstReviewed { get; set; }
        public bool IsSecondReviewed { get; set; }
        public bool IsThirdReviewed { get; set; }
    }
}
