﻿namespace PwC.DDS.Types.Interface.Reviewer
{
    public class ReviewStatusSummaryDTO
    {
        public long? LoanId { get; set; }
        public int TotalFields { get; set; }
        public int ReviewedFields { get; set; }
        public int ReviewCompleteFields { get; set; }
        public int ExceptionFields { get; set; }
    }

    public class LoanReviewStatusDTO
    {
        public long? LoanId { get; set; }
        public long? HeaderMapId { get; set; }
        public int? LevelOfReview { get; set; }
        public bool? IsFirstReviewed { get; set; }
        public bool? IsSecondReviewed { get; set; }
        public bool? IsThirdReviewed { get; set; }
        public bool? IsTie { get; set; }
    }
}
