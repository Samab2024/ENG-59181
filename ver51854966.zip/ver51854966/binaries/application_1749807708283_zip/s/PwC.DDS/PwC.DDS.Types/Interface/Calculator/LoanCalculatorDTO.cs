﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class LoanCalculatorDto
    {
        public long LoanId { get; set; }
        public string LoanNumber { get; set;}
        public long? ParentId { get; set; }
    }
}
