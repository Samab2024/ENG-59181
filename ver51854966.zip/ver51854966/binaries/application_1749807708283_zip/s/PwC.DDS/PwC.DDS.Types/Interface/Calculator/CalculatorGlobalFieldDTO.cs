﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class CalculatorGlobalFieldDTO
    {
        public long CalculatorGlobalFieldId { get; set; }
        public long DealId { get; set; } 
        [MaxLength(200)]
        public string FieldName { get; set; }
        [MaxLength(200)]
        public string FieldValue { get; set; }      
        public int DataFormatId { get; set; }
        [MaxLength(5000)]
        public string? CalculatorFormula { get; set; }       
        public int DisplayOrder { get; set; }
        public bool IsActive { get; set; }
    }
}
