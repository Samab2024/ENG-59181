﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class LoanDTO
    {
        public long LoanId { get; set; }
        [MaxLength(200)]
        public string? LoanNumber { get; set; }
        [MaxLength(200)]
        public string? PropertyName { get; set; }
        [MaxLength(2000)]
        public string? MissingDoc { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? CreatedTime { get; set; }
        [MaxLength(128)]
        public string? CreatedBy { get; set; }
        public DateTime? LastUpdatedTime { get; set; }
        [MaxLength(128)]
        public string? LastUpdatedBy { get; set; }
    }
}
