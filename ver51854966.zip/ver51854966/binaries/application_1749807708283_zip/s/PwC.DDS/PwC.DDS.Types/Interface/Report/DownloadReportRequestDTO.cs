﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class DownloadReportRequestDTO
    {
        public List<long> SellerIds { get; set; }
        public bool IncludeCalculationException { get; set; } = true;
        public bool IncludePwcHeaderFields { get; set; }
        public bool includePwcComments { get; set; } = false;
    }
}
