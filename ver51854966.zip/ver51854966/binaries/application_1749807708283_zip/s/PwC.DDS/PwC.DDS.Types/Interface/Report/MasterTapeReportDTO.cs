﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
	public class MasterTapeReportDTO
	{
		public string? FreddieMacLoanNumber { get; set; }
		public string? PropertyName { get; set; }
		public string? FieldName { get; set; }
		public string? ClientValue { get; set; }
        public string? OriginalCustomFormat { get; set; }
        public string? PwCValue { get; set; }
        public string? PwCComments { get; set; }
        public string? InternalComments { get; set; }
        public DateTime? LastUpdatedTime { get; set; }
		public string? LastUpdatedBy { get; set; }
		public string? DataFormatType { get; set; }
		public string? CustomFormat { get; set; }
	}
}
