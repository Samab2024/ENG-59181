﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
	public class HeaderReviewDTO
	{
		public long HeaderMapId { get; set; }
		public string? ClientHeader { get; set; }
		public string? PwCHeader { get; set; }
		public string? FieldGuide { get; set; }
		public int? DataFormatId { get; set; }
		public string? DataFormatType { get; set; }
		public string? DataFormatCode { get; set; }
		public long? DropdownCategoryId { get; set; }
		public string[]? DropdownCategoryOptions { get; set; }
		public int LevelOfReview { get; set; }
		public string DealName { get; set; }
		public bool IsDealAdmin { get; set; }
		public bool IsBlindReview { get; set; }
		public long? PrvHeaderMapId { get; set; }
		public string? PrvClientHeader { get; set; }
		public long? NextHeaderMapId { get; set; }
		public string? NextClientHeader { get; set; }
		public decimal Threadhold { get; set; }

		public HeaderReviewSection[] ReviewSection { get; set; }
	}

	public class HeaderReviewSection
	{
		public long SourceDocSectionId { get; set; }
        [MaxLength(200)]
        public string SourceDocSectionName { get; set; }
		public bool IsAllowCopy { get; set; }
		public int DisplayOrder { get; set; }
        [MaxLength(20)]
        public string Permission { get; set; }
		public HeaderReviewData[] ReviewData { get; set; }
	}
	public class HeaderReviewData
	{
		public long LoanId { get; set; }
		public string? LoanNumber { get; set; }
		public string? PropertyName { get; set; }
		public string? ClientValue { get; set; }
		public string? ClientDisplayValue { get; set; }
		public string? FirstReviewValue { get; set; }
        public bool IsFirstReviewed { get; set; }
        public string? SecondReviewValue { get; set; }
        public bool IsSecondReviewed { get; set; }
        public string? ThirdReviewValue { get; set; }
        public bool IsThirdReviewed { get; set; }
        public string? PwCComments { get; set; }
        public string? InternalComments { get; set; }
        public bool? IsTie { get; set; }
		public int LevelOfReview { get; set; }		
	}

    public class HeaderReviewCell
    {
        public long LoanId { get; set; }
        /// <summary>
        /// 1: First Review; 2: Second Review; 3: Third Reivew
        /// </summary>
        public ReviewLevel ReviewLevel { get; set; }
        public bool IsReviewed { get; set; }
        [MaxLength(2000)]
        public string? OldReviewValue { get; set; }
        [MaxLength(2000)]
        public string? NewReviewValue { get; set; }
        [MaxLength(5000)]
        public string? PwCComments { get; set; }
        [MaxLength(5000)]
        public string? InternalComments { get; set; }
        public bool? IsTie { get; set; }
    }
}
