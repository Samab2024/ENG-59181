﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class DropdownCategoryDTO
    {
        public long CategoryId { get; set; }

        public string CategoryName { get; set; }

        public int DisplayOrder { get; set; }

        public bool IsDeleteable { get; set; }

        public DropdownCategoryOptionDTO[] DropdownCategoryOptions { get; set; }
    }
}
