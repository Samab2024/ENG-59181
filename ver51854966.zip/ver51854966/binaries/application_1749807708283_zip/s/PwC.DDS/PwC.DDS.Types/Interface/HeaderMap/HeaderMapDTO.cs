﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class DealHeaderMapDTO
    {
        public long DealId { get; set; }
        public string DealName { get; set; }
        public int LevelOfReview { get; set; }
        public bool IsEditable { get; set; } // Calc field
        public HeaderMapDTO[] HeaderMap { get; set; }
    }

    public class HeaderMapDTO
    {
        public long HeaderMapId { get; set; }
        public int DisplayOrder { get; set; }
        public int LevelOfReview { get; set; }
        [MaxLength(200)]
        public string? ClientHeader { get; set; }
        [MaxLength(200)]
        public string? PwCHeader { get; set; }
        [MaxLength(200)]
        public string? CalculatorHeader { get; set; }
        [MaxLength(5000)]
        public string? CalculatorFormula { get; set; }
        [MaxLength(20)]
        public string? ProcessType { get; set; }
        public long? SourceDocSectionId { get; set; }
        public long? SourceId { get; set; }
		public int DataFormatId { get; set; }
        public long? ScreenShotId { get; set; }
        public long? DropdownCategoryId { get; set; }
        [MaxLength(2000)]
        public string? FieldGuide { get; set; }      
        public bool IsActive { get; set; }
        public bool IsExcludedInReport { get; set; }
        public bool IsBlindReview { get; set; }
        public decimal Threadhold { get; set; }
    }
}
