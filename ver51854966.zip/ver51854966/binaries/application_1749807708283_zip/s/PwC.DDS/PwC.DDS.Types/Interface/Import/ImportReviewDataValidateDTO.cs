﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class ImportReviewDataValidateDTO
    {
        public string[]? UpdateFields { get; set; }
        public string[]? UpdateLoans { get; set; }
    }
}
