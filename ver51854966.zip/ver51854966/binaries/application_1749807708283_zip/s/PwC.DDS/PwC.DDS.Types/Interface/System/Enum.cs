﻿using PwC.DDS.Types.Database;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Reflection.Emit;

namespace PwC.DDS.Types.Interface
{
    public enum DealState
    {
        [Display(Name = "Active")]
        Active = 0,

        [Display(Name = "Archived")]
        Archived,

        [Display(Name = "Deleted")]
        Deleted
    }

    public enum AssetType
    {
        [Display(Name = "CMBS")]
        CMBS = 0,
        [Display(Name = "ABS")]
        ABS,
        [Display(Name = "CLO")]
        CLO,
        [Display(Name = "SFR")]
        SFR
    }

    public enum LoanStatus
    {
        [Display(Name = "NotStart")]
        NotStart = 0,

        [Display(Name = "InReview")]
        InReview,

        [Display(Name = "Exception")]
        Exception,

        [Display(Name = "Completed")]
        Completed
    }

    public enum ReviewStatus
    {
        [Display(Name = "Not Started")]
        NotStarted = 0,

        [Display(Name = "In Progress")]
        InProgress,

        [Display(Name = "Completed")]
        Complete
    }

    public enum ProcessType
    {
        [Display(Name = "Provided")]
        Provided = 0,

        [Display(Name = "Review")]
        Review = 1,

        [Display(Name = "Calculation")]
        Calculation = 2,

        [Display(Name = "Pass-Through")]
        PassThrough = 3,

        [Display(Name = "Review-Attribute")]
        ReviewAttribute = 4,

        [Display(Name = "Review-Calculation")]
        ReviewCalculation = 5
    }

    public enum ImportRunType
    {
        [Display(Name = "Validate CD")]
        ValidateCD = 0,
        [Display(Name = "Import CD")]
        ImportCD = 1,
        [Display(Name = "Validate RD")]
        ValidateRD = 2,
        [Display(Name = "Import RD")]
        ImportRD = 3
    }

    public enum ReportType 
    {
        [Display(Name = "Master Tape Report")]
        MasterTapeReport = 1,

        [Display(Name = "Exception Report")]
        ExceptionReport = 2,

        [Display(Name = "PwC Tape Report")]
		PwCTapeReport = 3,

        [Display(Name = "Feedback Report")]
        FeedbackReport = 4,

        [Display(Name = "Loan Status Report")]
        LoanStatusReport = 5
    }

    public enum ReportOrder 
    {
        [Display(Name = "By Loan")]
        ByLoan = 1,

        [Display(Name = "By Attribute")]
        ByAttribute = 2,
    }

    public enum DataFormatType 
    {
        [Display(Name = "IsString")]
        IsString = 0,
        [Display(Name = "IsDateTime")]
        IsDateTime = 1,
        [Display(Name = "IsNumeric")]
        IsNumeric = 2
    }

    public enum ReviewLevel 
    {
		[Display(Name = "1st Review")]
		FirstReview = 1,
		[Display(Name = "2nd Review")]
		SecondReview = 2,
		[Display(Name = "3rd Review")]
		ThirdReview = 3
	}

    public static class Constent
    {
        public static string ProcessType = "ProcessType";
        public static string Source = "Source";
        public static string Section = "Section";
        public static string DF_Text = "Text";
        public static string HeaderMap = "HeaderMap";
        public static string ErrorMessage = "Error Message";
    }

    public class HeaderMapData
    {
        public const string ClientHeader = "Client Header";
        public const string CalculatorHeader = "Calculator Header";
        public const string PwCHeader = "PwC Header";
        public const string ProcessType = "Process Type";
        public const string SourceDocSection = "Source Doc Section";
        public const string Source = "Source";
        public const string Format = "Format";
        public const string Threadhold = "Threadhold";
        public const string LookupCategory = "Lookup Category";
        public const string FieldGuide = "Field Guide";
        public const string LevelOfReview = "Level Of Review";
        public const string BlindReview = "Blind Review";
        public const string ExcludedInExceptionReport = "Excluded In Exception Report";
    }

    public class DataLoader
    {
        public static string[] GetFieldsList(string type)
        {
            type = "PwC.DDS.Types.Interface." + type;
            FieldInfo[] myFieldInfo = null;
            List<string> fieldsList = new List<string>();
            Type myType = Type.GetType(type, false, true);
            if (myType != null)
            {
                myFieldInfo = myType.GetFields(BindingFlags.Public | BindingFlags.Static);
                foreach (var field in myFieldInfo)
                {
                    fieldsList.Add(item: Convert.ToString(field.GetValue(obj: null)));
                }
            }
            return fieldsList.ToArray();
        }
    }
}
