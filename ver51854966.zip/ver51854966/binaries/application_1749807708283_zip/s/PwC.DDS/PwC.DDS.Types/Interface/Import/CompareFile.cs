﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
	public class CompareFile
	{
		public IFormFile ClientFile { get; set; }
		public IFormFile PwCFile { get; set; }
	}
}
