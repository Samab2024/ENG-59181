﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class CalculationResult
    {
        public List<string> Errors { get; set; }
        public List<CalculatorFieldDTO> Results { get; set; }
    }

    public class CalculatorFieldDTO
    {
        public long DealId { get; set; }
        public long LoanId { get; set; }
        public long? ParentId { get; set; }
        public string Field { get; set; }
        public string? Value { get; set; }
        public string? DisplayValue { get; set; }
        public bool? IsTie { get; set; }
        public string? DataFormatType { get; set; }
        public string? DataFormat { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsDealLevel { get; set; }
    }
}
