﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
	public class LoanRandomDTO
	{
		public long DealId { get; set; }
		public long RandomNumber { get; set; }
	}
}
