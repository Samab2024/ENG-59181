﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class LastImportInfoDTO
    {
        public string? FileName { get; set; }
        public string? ImportBy { get; set; }
        public DateTime? ImportTime { get; set; }
    }
}
