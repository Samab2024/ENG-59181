﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class ExceptionReportDTO
    {
        public string? LoanNumber { get; set; }
        public string? PropertyName { get; set; }
        public string? ProcessType { get; set; }
        public string? FieldName { get; set; }
        public int? DealLevelOfReview { get; set; }
        public string? ClientValue { get; set; }
		public string? OriginalCustomFormat { get; set; }
		public string? PwCValue { get; set; }
        public string? FirstReviewValue { get; set; }
        public string? SecondReviewValue { get; set; }
        public string? ThirdReviewValue { get; set; }
        public string? DataFormatType { get; set; }
        public string? CustomFormat { get; set; }
        public string? AccountantsNeither { get; set; }
        public string? NeitherValue { get; set; }
        public string? Comments { get; set; }
        public string? PwCComments { get; set; }
        public bool IsFirstReviewed { get; set; }
        public bool IsSecondReviewed { get; set; }
        public bool IsThirdReviewed { get; set; }
    }
}
