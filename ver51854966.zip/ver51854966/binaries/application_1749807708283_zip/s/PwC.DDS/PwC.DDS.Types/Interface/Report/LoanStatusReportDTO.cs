﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class LoanStatusReportDTO
    {
        public string? LoanNumber { get; set; }
        public string? PropertyName { get; set; }
        public int? TotalFields { get; set; }
        public int? ReviewStatus1 { get; set; }
        public int? ReviewStatus2 { get; set; }
        public int? ReviewStatus3 { get; set; }
        public int? ExceptionStatus { get; set; }
    }
}
