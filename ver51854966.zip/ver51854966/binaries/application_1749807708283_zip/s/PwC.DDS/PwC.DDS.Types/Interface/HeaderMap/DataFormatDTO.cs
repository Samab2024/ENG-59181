﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class DataFormatDTO
    {
        public int DataFormatId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Format { get; set; }
        public string? Code { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsEditable { get; set; }
    }
}
