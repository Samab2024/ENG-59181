﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class HeaderDTO
    {
        public long ReviewerId { get; set; }
        public long DealId { get; set; }
        public long HeaderMapId { get; set; }
        public int? DisplayOrder { get; set; }
        [MaxLength(200)]
        public string? ClientHeader { get; set; }
        [MaxLength(200)]
        public string? PwCHeader { get; set; }
        [MaxLength(128)]
        public string? Reviewer1 { get; set; }
        [MaxLength(20)]
        public string? ReviewerStatus1 { get; set; }
        [MaxLength(128)]
        public string? Reviewer2 { get; set; }
        [MaxLength(20)]
        public string? ReviewerStatus2 { get; set; }
        [MaxLength(128)]
        public string? Reviewer3 { get; set; }
        [MaxLength(20)]
        public string? ReviewerStatus3 { get; set; }
    }
}
