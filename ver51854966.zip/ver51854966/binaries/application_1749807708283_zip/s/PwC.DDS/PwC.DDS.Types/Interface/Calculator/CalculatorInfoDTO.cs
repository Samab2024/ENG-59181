﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class CalculatorInfoDTO
    {
        public long DealId { get; set; }

        public long HeaderMapId { get; set; }

        public string Script { get; set; }

        public CalculatorFieldDTO[]? CalculatedResult { get; set; }

        public bool IsCalculateAllReferenceFormulas { get; set; }
    }
}
