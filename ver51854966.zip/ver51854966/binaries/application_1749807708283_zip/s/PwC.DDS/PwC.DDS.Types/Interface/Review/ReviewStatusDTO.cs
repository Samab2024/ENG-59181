﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class ReviewStatusDTO
    {
        public int ReadyFor1stReviewCount { get; set; }
        public int ReadyFor2ndReviewCount { get; set; }
        public int ReadyForFinalReviewCount { get; set; }
        public int CompletedCount { get; set; }
    }
}
