﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class HeaderMapReportDTO
    {
        public int DisplayOrder { get; set; }
        public string? ClientHeader { get; set; }
        public string? PwCHeader { get; set; }
        public string? CalculatorHeader { get; set; }
        public string? Formula { get; set; }
        public string? ProcessType { get; set; }
        public string? SourceDocSection { get; set; }
        public string? Source { get; set; }
        public string? DataFormat { get; set; }
        public decimal Threadhold { get; set; }
        public string? DropdownCategory { get; set; }
        public string? FieldGuide { get; set; }
        public int LevelOfReview { get; set; }
        public bool IsBlindReview { get; set; }
        public bool IsExcludedInReport { get; set; }
        public bool HasScreenShot { get; set; }
    }
}
