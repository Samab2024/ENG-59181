﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class ImportHeaderMapDataDTO
    {
        public long DealId { get; set; }

        public IFormFile File { get; set; }

        [MaxLength(31)]
        public string SheetName { get; set; }
    }

    public class ExportHeaderMapDataDTO
    {
        public string FileName { get; set; }
    }
}
