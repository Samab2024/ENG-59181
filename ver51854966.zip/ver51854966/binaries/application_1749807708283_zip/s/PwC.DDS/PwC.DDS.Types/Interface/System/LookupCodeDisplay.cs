﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types
{
    public class LookupCodeDisplay
    {
        public string Code { get; set; }
        public string Display { get; set; }
        public int Sequence { get; set; }
    }
}
