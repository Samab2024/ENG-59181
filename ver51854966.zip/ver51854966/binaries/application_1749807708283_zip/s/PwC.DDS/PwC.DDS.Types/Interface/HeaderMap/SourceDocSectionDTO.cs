﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class SourceDocSectionDTO
    {
        public long SourceDocSectionId { get; set; }
        public long SectionId { get; set; }
        public string Name { get; set; }
        public int DisplayOrder { get; set; }
        public bool IsAllowCopy { get; set; }
        public bool IsDeleteable { get; set; }
    }
}
