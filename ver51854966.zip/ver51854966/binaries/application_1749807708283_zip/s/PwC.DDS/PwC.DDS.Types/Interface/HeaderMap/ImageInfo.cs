﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class ImageInfo
    {
        public long DealId { get; set; }

        public IFormFile Image { get; set; }
    }
}
