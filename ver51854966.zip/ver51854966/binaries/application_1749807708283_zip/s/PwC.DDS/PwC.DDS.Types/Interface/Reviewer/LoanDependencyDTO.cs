﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class LoanDependencyDTO
    {
        public long LoanId { get; set; }
        public long? ParentId { get; set; }
        public long SellerId { get; set; }
        public string LoanNumber { get; set; }
        public string PropertyName { get; set; }
        public string SellerName { get; set; }
        public int DisplayOrder { get; set; }
    }
}
