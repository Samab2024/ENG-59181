﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Types.Interface
{
    public class ImportDataValidateDTO
    {
        public HeaderValidateInfoDTO[]? MissingFields { get; set; }
        public HeaderValidateInfoDTO[]? NewFields { get; set; }
        public LoanValidateInfoDTO[]? MissingLoans { get; set; }
        public LoanValidateInfoDTO[]? NewLoans { get; set; }
    }

    public class LoanValidateInfoDTO
    {
        public long LoanId { get; set; }
        public string LoanNumber { get; set; }
        public bool IsAllowRemap { get; set; } = true;
    }

    public class HeaderValidateInfoDTO
    {
        public long HeaderId { get; set; }
        public string HeaderName { get; set; }
    }
}
