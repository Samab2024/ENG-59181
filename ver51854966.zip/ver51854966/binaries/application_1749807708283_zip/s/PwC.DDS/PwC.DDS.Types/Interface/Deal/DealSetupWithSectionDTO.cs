﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class DealSetupWithSectionDTO
    {
        public long DealId { get; set; }
        [MaxLength(100)]
        public string DealName { get; set; }
        [MaxLength(500)]
        public string? DealDesc { get; set; }
        [MaxLength(100)]
        public string AssetType { get; set; }
        [MaxLength(100)]
        public string? KeyColumn { get; set; }
        public DateTime? CutOffDate { get; set; }
        public int LevelOfReview { get; set; }
        [MaxLength(500)]
        public string? DealAdmin { get; set; }
        [MaxLength(1000)]
        public string? DealContact { get; set; }
        [MaxLength(500)]
        public string? ClientName { get; set; }
        public bool IsBlindReview { get; set; }
        public bool IsExRptIncludePwCComments { get; set; }
        [MaxLength(20)]
        public string? DealStatus { get; set; }
        public string[]? DocSections { get; set; }

        [MaxLength(100)]
        public string? LoanNumberDisplayColumn { get; set; }
    }
}
