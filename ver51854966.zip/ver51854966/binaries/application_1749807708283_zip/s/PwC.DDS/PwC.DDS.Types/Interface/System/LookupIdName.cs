﻿namespace PwC.DDS.Types
{
    public class LookupIdName
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public long? DealId { get; set; }
    }
}
