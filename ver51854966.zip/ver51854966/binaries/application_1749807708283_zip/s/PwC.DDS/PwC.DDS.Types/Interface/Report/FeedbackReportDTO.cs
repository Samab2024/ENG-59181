﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Types.Interface
{
    public class FeedbackReportDTO
    {
        public string? LoanNumber { get; set; }
        public string? PropertyName { get; set; }
        public string? FieldName { get; set; }
        public string? SourceDocSection { get; set; }
        public string? Reviewer1 { get; set; }
        public string? Reviewer2 { get; set; }
        public string? Reviewer3 { get; set; }
        public string? ReviewValue1 { get; set; }
        public string? ReviewValue2 { get; set; }
        public string? ReviewValue3 { get; set; }
        public string? PwCComments { get; set; }
        public int? LevelOfReview { get; set; }
        public string? DataFormatType { get; set; }
        public string? CustomFormat { get; set; }
    }
}
