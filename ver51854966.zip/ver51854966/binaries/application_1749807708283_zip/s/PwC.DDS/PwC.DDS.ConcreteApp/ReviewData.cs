﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.ConcreteApp
{
    public static class ReviewData
    {
        public static SampleObject[] sampleArray = new SampleObject[]
        {
            new SampleObject { Balance = 1000, SalePct = 0.1m, SaleBalance = 0 },
            new SampleObject { Balance = 2000, SalePct = 0.2m, SaleBalance = 0 },
            new SampleObject { Balance = 1500, SalePct = 0.15m, SaleBalance = 0 }
        };
    }

    public class SampleObject
    {
        public decimal Balance { get; set; }
        public decimal SalePct { get; set; }
        public decimal SaleBalance { get; set; }
    }
}
