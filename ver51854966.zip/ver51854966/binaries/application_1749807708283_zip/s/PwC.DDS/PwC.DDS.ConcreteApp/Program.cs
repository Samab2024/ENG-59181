﻿// See https://aka.ms/new-console-template for more information
using PwC.DDS.ConcreteApp;

Console.WriteLine("Hello, World!");

var pe = new PythonEngine();
pe.test2();