﻿using Microsoft.EntityFrameworkCore;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;
using PwC.DDS.Core;
using PwC.DDS.Types.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Xml.Linq;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using PwC.DDS.Database;
using Microsoft.AspNetCore.Http;
using static IronPython.Runtime.Profiler;

namespace PwC.DDS.ConcreteApp
{
    public class PythonEngine
    {
        public void RunPython()
        {
            // Create a Python engine  
            var engine = Python.CreateEngine();
            var scope = engine.CreateScope();


            // Sample1: Execute Python code directly 
            var script1 = @"print('Hello from IronPython!')";
            engine.Execute(script1);


            // Sample2: Call a Python function from C#
            var script2 = @"  
def add_numbers(a, b):  
    return a + b  
                            ";
            engine.Execute(script2, scope);
            var func_add_numbers = scope.GetVariable("add_numbers");
            var an_result = func_add_numbers(2, 3);


            // Sample3: Call a Python function from C#
            var script3 = @"  
def add_numbers(a, b):  
    return a + b  
  
result = add_numbers(x, y)  
                            ";
            ScriptSource source = engine.CreateScriptSourceFromString(script3);
            CompiledCode compiledCode = source.Compile();

            scope.SetVariable("x", 10);
            scope.SetVariable("y", 20);
            var result = compiledCode.Execute(scope);
            if (scope.TryGetVariable("result", out dynamic result1))
                Console.WriteLine(result1);


            // Sample4: Call a Python function from C#
            var script4 = @"  
def add_numbers(a, b):  
    return a + b  
  
def minus_numbers(a, b):  
    return a - b

{0}
            ";
            string expr = "mn_result = minus_numbers(x4,y4)";
            var final_script4 = string.Format(script4, expr);
            scope.SetVariable("x4", 10);
            scope.SetVariable("y4", 20);
            engine.Execute(final_script4, scope);
            if (scope.TryGetVariable("mn_result", out dynamic mn_result))
                Console.WriteLine(mn_result);

            // Sample5
            string formula = "SaleBalance = multiply_numbers(Balance/2,SalePct)";
            var fullPath = @"C:\Users\cyao027\Documents\Alias\DueDiligence\Backend\PwC.DDS\PwC.DDS.ConcreteApp\test_code.py";
            //string fullPath = Directory.GetCurrentDirectory() + @"\test_code.py";

            string importScript = "import sys" + Environment.NewLine +
                                  "sys.path.append( r\"{0}\" )" + Environment.NewLine +
                                  "from {1} import *" + Environment.NewLine +
                                  "{2}";
            string scriptStr = string.Format(importScript, Path.GetDirectoryName(fullPath), Path.GetFileNameWithoutExtension(fullPath), formula);

            var scriptSource = engine.CreateScriptSourceFromString(scriptStr);
            var compiled = scriptSource.Compile();

            var data = ReviewData.sampleArray;
            foreach (var pm in data)
            {
                var scope5 = engine.CreateScope();
                scope5.SetVariable("Balance", pm.Balance);
                scope5.SetVariable("SalePct", pm.SalePct);
                compiled.Execute(scope5);
                if (scope5.TryGetVariable("SaleBalance", out dynamic tmp_result))
                    pm.SaleBalance = tmp_result;
            }
        }

        public void test()
        {
            List<MyObject> objects = new List<MyObject>
            {
                new MyObject { Value1 = 10, Value2 = 20 },
                new MyObject { Value1 = 30, Value2 = 40 },
                new MyObject { Value1 = 50, Value2 = 60 }
            };

            //var records = new List<ReviewObject>
            //{
            //    new ReviewObject { Header = "Column A", Loan = "Loan1", Data = 20 },
            //    new ReviewObject { Header = "Column B", Loan = "Loan1", Data = 30 },
            //    new ReviewObject { Header = "Column C", Loan = "Loan1", Data = 0 },
            //    new ReviewObject { Header = "Column A", Loan = "Loan2", Data = 50 },
            //    new ReviewObject { Header = "Column B", Loan = "Loan2", Data = 60 },
            //    new ReviewObject { Header = "Column C", Loan = "Loan2", Data = 0 }
            //};


            //List<ReviewTmp> newList = new List<ReviewTmp>();

            //foreach (ReviewObject obj in records)
            //{
            //    ReviewTmp tmp = newList.Find(x => x.Loan == obj.Loan);
            //    if (tmp == null)
            //    {
            //        tmp = new ReviewTmp { Loan = obj.Loan, Columns = new Dictionary<string, object>() };
            //        newList.Add(tmp);
            //    }

            //    tmp.Columns[obj.Header] = obj.Data;
            //}


            var engine = Python.CreateEngine();
            var scope = engine.CreateScope();
            //            var script = @"
            //def calculate_field(obj):  
            //    return obj.Value1 + obj.Value2  

            //calculated_list = [calculate_field(obj) for obj in objects]";

            var script1 = @"
for row in range(0, len(objects)):
    objects[row].Value3 = add_numbers(objects[row].Value1, objects[row].Value2)
";

            var script3 = @"
for row in range(0, len(objects)):
    if row = 1
        objects[row].Value3 = 0
    else:
        objects[row].Value3 = add_numbers(objects[row-1].Value1, objects[row-1].Value2)
";

            var script2 = @"
for row in range(0, len(objects)):
    objects[row].Value4 = minus_numbers(objects[row].Value1, objects[row].Value2)
";
            var fullPath = @"C:\Users\cyao027\Documents\Alias\DueDiligence\Backend\PwC.DDS\PwC.DDS.ConcreteApp\test_code.py";
            string importScript = "import sys" + Environment.NewLine +
                                  "sys.path.append( r\"{0}\" )" + Environment.NewLine +
                                  "from {1} import *" + Environment.NewLine +
                                  "{2}";
            var script = script1 + Environment.NewLine + script2;
            string scriptStr = string.Format(importScript, Path.GetDirectoryName(fullPath), Path.GetFileNameWithoutExtension(fullPath), script);

            // Add the list of objects to the scope  
            scope.SetVariable("objects", objects);

            // Execute the script  
            engine.Execute(scriptStr, scope);

            // Get the calculated list from the scope  
            var calculatedList = scope.GetVariable<IList<MyObject>>("objects");

            // Print the calculated list  
            foreach (var item in calculatedList)
            {
                Console.WriteLine(item.Value3 + " " + item.Value4);
            }
        }

        public void test2()
        {
            List<MyObject> objects = new List<MyObject>
            {
                new MyObject { Value1 = 10, Value2 = 20 },
                new MyObject { Value1 = 30, Value2 = 40 },
                new MyObject { Value1 = 50, Value2 = 60 }
            };

            var engine = Python.CreateEngine();
            var scope = engine.CreateScope();

            var script1 = @"
for row in range(0, len(objects)):
    objects[row].Value3 = add_numbers(objects[row].Value1, objects[row].Value2)
";
            var fullPath = @"C:\Users\cyao027\Documents\Alias\DueDiligence\Backend\PwC.DDS\PwC.DDS.ConcreteApp\test_code.py";
            string importScript = "import sys" + Environment.NewLine +
                                  "sys.path.append( r\"{0}\" )" + Environment.NewLine +
                                  "from {1} import *" + Environment.NewLine +
                                  "{2}";
            var script = script1;
            string scriptStr = string.Format(importScript, Path.GetDirectoryName(fullPath), Path.GetFileNameWithoutExtension(fullPath), script);

            // Add the list of objects to the scope  
            scope.SetVariable("objects", objects);

            // Execute the script  
            engine.Execute(scriptStr, scope);

            // Get the calculated list from the scope  
            var calculatedList = scope.GetVariable<IList<MyObject>>("objects");

            // Print the calculated list  
            foreach (var item in calculatedList)
            {
                Console.WriteLine(item.Value3 + " " + item.Value4);
            }
        }
    }

    public class MyObject
    {
        public object Value1 { get; set; }
        public int Value2 { get; set; }
        public int? Value3 { get; set; }
        public int? Value4 { get; set; }
    }

    public class ReviewObject
    {
        public string Header { get; set; }
        public string Loan { get; set; }
        public object Data { get; set; }
    }
}
