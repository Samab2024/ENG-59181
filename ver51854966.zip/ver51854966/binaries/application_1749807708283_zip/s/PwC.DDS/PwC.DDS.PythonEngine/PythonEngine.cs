﻿using IronPython.Hosting;
using IronPython.Runtime;
using Microsoft.Scripting.Hosting;
using PwC.DDS.Infrastructure;
using PwC.DDS.PythonEngine;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System.Text.RegularExpressions;

namespace PwC.DDS.PythonEngine
{
    public class PyEngine
    {
        private const string IronPythonRelativePath = @"\base_calculator.py";

        public static string PythonLibraryPath;

        private readonly ScriptEngine engine;

        private readonly string ironPythonFullPath;

        public PyEngine()
        {
            engine = Python.CreateEngine();
            if (!string.IsNullOrEmpty(PythonLibraryPath))
            {
                engine.SetSearchPaths(new[] { PythonLibraryPath });
            }
            ironPythonFullPath = AppContext.BaseDirectory + IronPythonRelativePath;
        }

        public CalculationResult Execute(string formula, string calcField, DataFormat calcFieldFormat, LoanCalculatorDto[] loans, CalculatorFieldDTO[] loanValues, CalculatorFieldDTO[] dealConfigs, HeaderMap[] headerMaps, LoanReview[] calcFieldLoanReviews)
        {
            var calculationResult = new CalculationResult();
            calculationResult.Results = new List<CalculatorFieldDTO>();
            calculationResult.Errors = new List<string>();

            // Create a Python engine	
            var scope = engine.CreateScope();
            var importScript = "import sys" + Environment.NewLine +
                                  "sys.path.append( r\"{0}\" )" + Environment.NewLine +
                                  "from {1} import *" + Environment.NewLine +
                                  "{2}";


            #region keep as it is now
            // Add the list of objects to the scope  
            //scope.SetVariable("loans", loans);

            //if (formular.Contains("[row]"))
            //{
            //    for (int row = 0; row < 10; row++)
            //    {
            //        var script = formular.Replace("row", row.ToString());
            //        string scriptStr = string.Format(importScript, Path.GetDirectoryName(IronPythonFullPath), Path.GetFileNameWithoutExtension(IronPythonFullPath), script);
            //        // Execute the script  
            //        engine.Execute(scriptStr, scope);
            //    }
            //}
            //else
            //{
            //    var script = formular;
            //    string scriptStr = string.Format(importScript, Path.GetDirectoryName(IronPythonFullPath), Path.GetFileNameWithoutExtension(IronPythonFullPath), script);
            //    // Execute the script  
            //    engine.Execute(scriptStr, scope);
            //}


            //if (scope.TryGetVariable("result", out dynamic loan))
            //{
            //    scope.SetVariable("loan", loan);

            //    var formularScript = formular.Contains("[row]") ? @"for row in range(0, len(loan)):" + Environment.NewLine + "\t" + formular : formular;

            //    string scriptStr = string.Format(importScript, Path.GetDirectoryName(ironPythonFullPath), Path.GetFileNameWithoutExtension(ironPythonFullPath), formularScript);

            //    // Execute the script  
            //    engine.Execute(scriptStr, scope);


            //    // Get the calculated list from the scope  
            //    var calculatedList = scope.GetVariable<IList<Loan>>("loans");

            //    // Print the calculated list  
            //    foreach (var item in calculatedList)
            //    {
            //        Console.WriteLine(item);
            //    }
            //}
            #endregion

            scope.SetVariable("dealConfigs", dealConfigs);
            scope.SetVariable("loanEntites", loans);
            scope.SetVariable("loanValues", loanValues);

            List<CalculatorFieldDTO> calcResultList = new();


            List<CalculatorFieldDTO> allCalcFieldList = [.. loanValues, .. dealConfigs];

            List<CalculatorFieldDTO> usedCalcFieldList = new();
            foreach (var item in allCalcFieldList)
            {
                var loanLevelRegex = new Regex($@"\b\]\.{item.Field}\b");
                var totalLoanLevelRegex = new Regex($@"\bloans\.{item.Field}\b");
                var dealLevelRegex = new Regex($@"\bdeal\.{item.Field}\b");
                if (loanLevelRegex.IsMatch(formula))
                {
                    usedCalcFieldList.Add(item);
                }
                else if (totalLoanLevelRegex.IsMatch(formula))
                {
                    usedCalcFieldList.Add(item);
                }
                else if (dealLevelRegex.IsMatch(formula))
                {
                    usedCalcFieldList.Add(item);
                }

            }


            for (int row = 0; row < loans.Length; row++)
            {
                if (scope.ContainsVariable("calc_result"))
                {
                    scope.RemoveVariable("calc_result");
                }

                scope.SetVariable("loanId", loans[row].LoanId);

                string formulaScript = Regex.Replace(formula, @"\[row\]", $"[{row}]");

                // update [row-1] & [row+1] as the calculate value
                formulaScript = Regex.Replace(formulaScript, @"\[row\s*([\+\-])\s*(\d+)\]", match =>
                {
                    int offset = int.Parse(match.Groups[2].Value);
                    int calculatedRow = match.Groups[1].Value == "+" ? row + offset : row - offset;
                    return $"[{calculatedRow}]";
                });

                /**It will check if formula contains "SUMCHILDFORMULA"
                 * If yes, will update the script based on what python needed
                 * If no, skip this part*******/
                formulaScript = ParseSumChildFormula(formulaScript, loans[row]);

                var script = @"loan = Test(loanEntites, loanValues)" + Environment.NewLine
                    + "deal = DealWrapper(dealConfigs, loanId)" + Environment.NewLine
                    + "loans = TotalLoanCategorizer(loanValues)" + Environment.NewLine
                    + "calc_result = " + formulaScript;

                string parseScript = string.Format(importScript, Path.GetDirectoryName(ironPythonFullPath), Path.GetFileNameWithoutExtension(ironPythonFullPath), script);

                try
                {
                    engine.Execute(parseScript, scope);
                }
                catch (Exception e)
                {
                    var errorMsg = e.Message;
                    if (errorMsg.Contains("object has no attribute"))
                    {
                        int lastIndex = e.Message.LastIndexOf("'");
                        int secondLastIndex = e.Message.LastIndexOf("'", lastIndex - 1);
                        string attribute = e.Message.Substring(secondLastIndex + 1, lastIndex - secondLastIndex - 1);
                        throw new DdsInvalidOperationException($"There is no any calculator header which is named '{attribute}'");
                    }

                    if (errorMsg.Contains("failed：parameter"))
                    {
                        errorMsg = $"Loan {loans[row].LoanNumber} {e.Message}";
                    }
                    if (!calculationResult.Errors.Contains(errorMsg))
                    {
                        calculationResult.Errors.Add(errorMsg);
                    }
                }


                calcResultList.Add(
                        new CalculatorFieldDTO()
                        {
                            LoanId = loans[row].LoanId,
                            Field = "LoanNo",
                            Value = loans[row].LoanNumber,
                            DisplayValue = loans[row].LoanNumber,
                            DisplayOrder = 1
                        }
                    );

                var loanReview = calcFieldLoanReviews.FirstOrDefault(lr => lr.LoanId == loans[row].LoanId);
                calcResultList.Add(
                        new CalculatorFieldDTO()
                        {
                            LoanId = loans[row].LoanId,
                            Field = "ClientValue",
                            Value = loanReview.ClientValue,
                            DisplayValue = loanReview.ClientDisplayValue,
                            DisplayOrder = 2
                        }
                    );


                if (scope.TryGetVariable("calc_result", out dynamic calcResultValue))
                {
                    Type type = calcResultValue.GetType();
                    var isPythonList = type == typeof(PythonList);

                    var calcItem = new CalculatorFieldDTO()
                    {
                        LoanId = loans[row].LoanId,
                        Field = calcField,
                        DataFormatType = calcFieldFormat?.Type,
                        DataFormat = calcFieldFormat?.Format,
                        Value = isPythonList ? "N/A" : FormatReuslt(calcResultValue, calcFieldFormat?.Type),
                        DisplayOrder = 3
                    };

                    calcResultList.Add( calcItem );

                    //update the calculate result to original list
                    var loanValue = loanValues.FirstOrDefault(lv => lv.LoanId == loans[row].LoanId && lv.Field == calcField);
                    if (loanValue != null)
                    {
                        loanValue.Value = calcItem.Value;
                        scope.SetVariable("loanValues", loanValues);
                    }
                }
                else
                {
                    calcResultList.Add(
                        new CalculatorFieldDTO()
                        {
                            LoanId = loans[row].LoanId,
                            Field = calcField,
                            DataFormatType = calcFieldFormat?.Type,
                            DataFormat = calcFieldFormat?.Format,
                            Value = "N/A",
                            DisplayOrder = 3
                        }
                    );
                }

                var usedCalcFieldsForSpecificLoan = usedCalcFieldList.Where(f => f.IsDealLevel || (f.IsDealLevel == false && f.LoanId == loans[row].LoanId)).ToList();
                if (usedCalcFieldsForSpecificLoan.Count > 0)
                {
                    int index = 4;
                    foreach (var calcFieldInfo in usedCalcFieldsForSpecificLoan)
                    {
                        if (calcResultList.Any(r => r.LoanId == calcFieldInfo.LoanId && r.Field == calcFieldInfo.Field))
                            continue;

                        calcResultList.Add(
                            new CalculatorFieldDTO()
                            {
                                LoanId = calcFieldInfo.IsDealLevel ? loans[row].LoanId : calcFieldInfo.LoanId,
                                Field = calcFieldInfo.Field,
                                DataFormatType = calcFieldInfo.DataFormatType,
                                DataFormat = calcFieldInfo.DataFormat,
                                Value = calcFieldInfo.Value,
                                DisplayOrder = index,
                            }
                        );

                        index++;
                    }
                }
            }

            calculationResult.Results = calcResultList;

            return calculationResult;
        }

        private string FormatReuslt(dynamic value, string formatType)
        {
            if (formatType == "IsNumeric")
            {
                if(value is double)
                {
                    return ((double)value).ToString();
                }
                else
                {
                    return value.ToString();
                }               
            }
            else if (formatType == "IsDateTime")
            {
                //TODO: need to get date format from DB
                return (new DateTime(value.year, value.month, value.day)).ToString("MM/dd/yyyy");
            }
            else
            {
                return value.ToString();
            }
        }
    
        private string ParseSumChildFormula(string formulaScript, LoanCalculatorDto loan)
        {
            string sumChildNodesPattern = @"SUMCHILDNODES\(([^)]+)\)";
            Match sumChildNodesmatch = Regex.Match(formulaScript, sumChildNodesPattern);

            string sumParentNodePattern = @"SUMPARENTNODE\(([^)]+)\)";
            Match sumParentNodematch = Regex.Match(formulaScript, sumParentNodePattern);
            if (sumChildNodesmatch.Success || sumParentNodematch.Success)
            {
                string extractedContent = sumChildNodesmatch.Success ? sumChildNodesmatch.Groups[1].Value : sumParentNodematch.Groups[1].Value;
                if (extractedContent.StartsWith("loans."))
                {
                    extractedContent = extractedContent.Substring("loans.".Length);
                }
                var parentIdValue = loan.ParentId == null ? "None" : loan.ParentId.ToString();
                var functionName = sumChildNodesmatch.Success ? "SUMCHILDNODES" : "SUMPARENTNODE";
                var newSumChildNodesContent = $"{functionName}('{extractedContent}', loanValues, {loan.LoanId.ToString()}, {parentIdValue})";

                formulaScript = Regex.Replace(formulaScript, sumChildNodesmatch.Success ? sumChildNodesPattern : sumParentNodePattern, newSumChildNodesContent);
            }

            return formulaScript;
        }
    }
}