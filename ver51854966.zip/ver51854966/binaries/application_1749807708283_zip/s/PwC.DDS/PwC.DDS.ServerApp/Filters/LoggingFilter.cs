﻿using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using PwC.DDS.Infrastructure.Logging;
using System.Web;

namespace PwC.DDS
{
    public class LoggingFilter : IAsyncActionFilter
    {
        private static string SanitizeMessage(string message)
        {
            // VeraCode fix
            message = message.Replace(Environment.NewLine, "_");
            return HttpUtility.UrlEncode(message);
        }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var logger = DdsLogger.Create((context.ActionDescriptor as ControllerActionDescriptor).ControllerName);
            try
            {
                var request = context.HttpContext.Request;
                var currentUser = context.HttpContext.GetUserId() ?? "anon";
                logger.LogInformation(SanitizeMessage($"{currentUser}|{request.Method}|{request.Path.Value}_"));
                await next();
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Error when logging action.");
            }
        }
    }
}
