﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using PwC.DDS.Infrastructure;
using PwC.DDS.Infrastructure.Logging;
using PwC.DDS.Types.Interface;
using System.Net;

namespace PwC.DDS
{
    public class ExceptionFilter : IAsyncExceptionFilter
    {
        public Task OnExceptionAsync(ExceptionContext context)
        {
            var logger = DdsLogger.Create((context.ActionDescriptor as ControllerActionDescriptor).ControllerName);
            logger.LogError(context.Exception, $"{(context.ActionDescriptor as ControllerActionDescriptor).ActionName}");
            ObjectResult objectResult;
            switch (context.Exception)
            {
                case NotImplementedException _:
                    objectResult = new ObjectResult(new ResponseData<object> { Message = "The function requested hasn't been implemented yet." });
                    objectResult.StatusCode = (int)HttpStatusCode.NotImplemented;
                    break;
                case DdsInvalidOperationException _:
                    objectResult = new ObjectResult(new ResponseData<object> { Message = context.Exception.Message });
                    objectResult.StatusCode = (int)HttpStatusCode.BadRequest;
                    break;
                case DdsPermissionException _:
                    objectResult = new ObjectResult(new ResponseData<object> { Message = context.Exception.Message });
                    objectResult.StatusCode = (int)HttpStatusCode.Forbidden;
                    break;
                case DdsException _:
                    objectResult = new ObjectResult(new ResponseData<object> { Message = context.Exception.Message });
                    objectResult.StatusCode = (int)HttpStatusCode.BadRequest;
                    break;
                default:
                    objectResult = new ObjectResult(new ResponseData<object> { Message = $"Unexpected error happened, please contact the administrator. \r\nError: {context.Exception.GetBaseException().Message}" });
                    objectResult.StatusCode = (int)HttpStatusCode.InternalServerError;
                    break;
            }

            context.Result = objectResult;
            context.ExceptionHandled = true;
            return Task.CompletedTask;
        }
    }
}
