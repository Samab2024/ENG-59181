﻿using Aspose.Cells;
using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;
using System.IO;

namespace PwC.DDS.ServerApp.Controllers
{
    [ApiController]
    [Route("api/Import")]
    public class ImportController : AbstractController
    {
        private readonly IImportProvider _provider;
        public ImportController(IImportProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Load sheets name from excel
        /// </summary>
        [HttpPost("LoadSheets")]
        public async Task<IActionResult> LoadSheets([FromForm] ImporFile importFile)
        {
            var data = await _provider.LoadSheets(ax, importFile.File);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Import data for seller
        /// </summary>
        [HttpPost("ImportData")]
        public async Task<IActionResult> ImportData([FromForm] ImportDataDTO importInfo)
        {
            var data = await _provider.ImportData(ax, importInfo);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Get last import info 
        /// </summary> 
        [HttpGet("{dealId}/GetLastImportInfo")]
        public async Task<IActionResult> GetLastImportInfo(long dealId)
        {
            var data = await _provider.GetLastImportInfo(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Get last import file 
        /// </summary> 
        [HttpPost("{dealId}/GetLastImportFile")]
        public async Task<IActionResult> GetLastImportFile(long dealId)
        {
            var info = await _provider.GetLastImportInfo(ax, dealId);
            return File(await _provider.GetLastImportFile(ax, dealId), "application/octstream", info?.FileName);
        }

        /// <summary>
        /// Compare client and PwC
        /// </summary>
        /// <param name="compareFile"></param>
        /// <returns></returns>
		[HttpPost("CompareFile")]
		public async Task<IActionResult> CompareData([FromForm] CompareFile compareFile)
		{
			string fileName = $"Client and PwC Exception {DateTime.Now.ToString("MM/dd/yyyy")}.{FileFormatType.Xlsx.ToString().ToLowerInvariant()}";
			return File(await _provider.CompareData(ax, compareFile), "application/octstream", fileName);
		}
	}
}
