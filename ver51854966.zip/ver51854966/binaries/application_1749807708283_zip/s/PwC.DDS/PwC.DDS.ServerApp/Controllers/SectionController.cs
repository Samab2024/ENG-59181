﻿using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [Route("api/Section")]
    [ApiController]
    public class SectionController : AbstractController
    {
        private readonly ISectionProvider _provider;
        public SectionController(ISectionProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Get Section (Legal Terms, Third Parties) - Used for reviewer
        /// </summary>
        [HttpGet("{dealId}")]
        public async Task<IActionResult> GetSections(long dealId)
        {
            var data = await _provider.GetSections(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update Section
        /// </summary>
        [HttpPost("{dealId}/UpdateSection")]
        public async Task<IActionResult> UpdateSections(long dealId, SectionDTO[] sections)
        {
            await _provider.UpdateSections(ax, dealId, sections);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }
    }
}
