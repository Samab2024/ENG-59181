﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Web;

namespace PwC.DDS.ServerApp.Controllers
{
    [ApiController]
    [Route("api/Auth")]
    public class AuthController : AbstractController
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IUserProvider _provider;

        public AuthController(IHttpClientFactory clientFactory, IUserProvider provider)
        {
            _httpClientFactory = clientFactory;
            _provider = provider;
        }

        /// <summary>  
        /// Get app token
        /// </summary>
        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequestToken token)
        {
            if (!string.IsNullOrEmpty(token.OaToken))
            {
                var result = GetPwCUserInfo(token.OaToken);
                var dynUserProfile = JsonConvert.DeserializeObject<PwcUserInformation>(result);
                var userIdentity = dynUserProfile?.PwcWorkerIDStr ?? string.Empty;
                if (dynUserProfile == null || string.IsNullOrEmpty(userIdentity))
                {
                    return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status404NotFound, Message = $"User profile not found: {result}" });
                }

                var isAdmin = await _provider.IsAdmin(ax, dynUserProfile.UserId);
                var currentUser = new CurrentUser
                {
                    Name = dynUserProfile.Name,
                    Email = dynUserProfile.Email,
                    Guid = dynUserProfile.UserId,
                    IsAdmin = isAdmin,
                    AccessToken = GenerateAccessToken(dynUserProfile, isAdmin)
                };

                var data = new LoginResponse() { CurrentUser = currentUser };
                return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
            }
            else
            {
                return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status401Unauthorized, Message = $"Token can't be empty" });
            }
        }

        /// <summary>  
        /// Get all users - Used for setup deal admin/contact
        /// </summary>
        [HttpGet("Users")]
        public async Task<IActionResult> GetUsers()
        {
            var data = await _provider.GetUsers(ax);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Get reviewers - Used for setup loan/attribute reviewer
        /// </summary>
        [HttpGet("Reviewers/{dealId}")]
        public async Task<IActionResult> GetReviewers(long dealId)
        {
            var data = await _provider.GetReviewers(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Get current user info
        /// </summary>
        [HttpGet("CurrentUser")]
        public async Task<IActionResult> GetCurrentUser()
        {
            var data = new CurrentUser
            {
                Name = ax.UserName,
                Email = ax.UserEmail,
                Guid = ax.UserId,
                IsAdmin = ax.IsAdmin
            };
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>
        /// Generate token (Jwt) based on DB data and OpenAM token
        /// </summary>
        private string GenerateAccessToken(PwcUserInformation userProfile, bool isAdmin)
        {
            var claims = new[]
            {
              new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
              new Claim(RegsiteredCliamNames.UserId, userProfile.UserId, ClaimValueTypes.String),
              new Claim(RegsiteredCliamNames.UserName, userProfile.Name,ClaimValueTypes.String),
              new Claim(RegsiteredCliamNames.UserEmail, userProfile.Email,ClaimValueTypes.String),
              new Claim(RegsiteredCliamNames.IsAdmin, isAdmin.ToString(), ClaimValueTypes.Boolean)
            };

            var settings = ax.Config.JWTSettings;
            var newToken = new JwtSecurityToken(
              issuer: settings.Issuer,
              audience: settings.Issuer,
              signingCredentials: GetSecurityCredentials(settings.RsaPrivateKey),
              claims: claims,
              notBefore: DateTime.UtcNow,
              expires: DateTime.UtcNow.AddHours(settings.ExpireHours ?? 24)
            );

            return new JwtSecurityTokenHandler().WriteToken(newToken);
        }

        private SigningCredentials GetSecurityCredentials(string privateKey)
        {
            var rsa = RSA.Create();
            rsa.ImportRSAPrivateKey(Convert.FromBase64String(privateKey), out _);

            return new SigningCredentials(new RsaSecurityKey(rsa), SecurityAlgorithms.RsaSha256)
            {
                CryptoProviderFactory = new CryptoProviderFactory { CacheSignatureProviders = false }
            };
        }

        private string GetPwCUserInfo(string token)
        {
            try
            {
                var url = $"{ax.Config.AppSettings.OFISUSERPROFILEURL}?access_token={HttpUtility.UrlEncode(token)}";
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
                client.BaseAddress = new Uri(url);
                System.Threading.Tasks.Task<HttpResponseMessage> message = client.GetAsync("");
                var result = message.Result.Content.ReadAsStringAsync().Result;
                return result;
            }
            catch (Exception err)
            {
                throw new Exception($"Failed to valid OpenAM token, details: {err.InnerException}");
            }
        }
    }
}
