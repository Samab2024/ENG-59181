﻿using Aspose.Cells;
using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [Route("api/Calculator")]
    [ApiController]
    public class CalculatorController : AbstractController
    {
        private readonly ICalculatorProvider _provider;
        public CalculatorController(ICalculatorProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Test Formula
        /// </summary>
        [HttpPost("TestFormula")]
        public async Task<IActionResult> TestFormula([FromBody] CalculatorInfoDTO calculatorInfoDTO)
        {
            var data = await _provider.TestFormula(ax, calculatorInfoDTO.DealId, calculatorInfoDTO.HeaderMapId, calculatorInfoDTO.Script, calculatorInfoDTO.IsCalculateAllReferenceFormulas);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Save Formula and related calculated value
        /// </summary>
        [HttpPost("SaveFormulaAndCaculatedResult")]
        public async Task<IActionResult> SaveFormulaAndCaculatedResult([FromBody] CalculatorInfoDTO calculatorInfo)
        {
            var data = await _provider.SaveFormulaAndCaculatedResult(ax, calculatorInfo);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Recaculate All
        /// </summary>
        [HttpGet("{dealId}")]
        public async Task<IActionResult> RecaculateAll(long dealId)
        {
            var data = await _provider.ReCalculateAll(ax, dealId); ;
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }


        /// <summary>  
        /// Get Calculator Global Fields
        /// </summary>
        [HttpGet("{dealId}/CalculatorGlobalField")]
        public async Task<IActionResult> GetCalculatorGlobalField(long dealId)
        {
            var data = await _provider.GetCalculatorGlobalField(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update Calculator Global Field
        /// </summary>
        [HttpPost("{dealId}/UpdateCalculatorGlobalField")]
        public async Task<IActionResult> UpdateCalculatorGlobalField(long dealId, CalculatorGlobalFieldDTO[] calculatorGlobalFields)
        {
            await _provider.UpdateCalculatorGlobalField(ax, dealId, calculatorGlobalFields);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

    }
}
