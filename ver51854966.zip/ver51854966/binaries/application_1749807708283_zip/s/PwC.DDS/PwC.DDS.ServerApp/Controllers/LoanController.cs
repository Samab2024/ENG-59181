﻿using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [Route("api/Loan")]
    [ApiController]
    public class LoanController : AbstractController
    {
        private readonly ILoanProvider _provider;
        public LoanController(ILoanProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Get loan info 
        /// </summary> 
        [HttpGet("{dealId}/Loans")]
        public async Task<IActionResult> GetLoans(long dealId, bool isActive)
        {
            var data = await _provider.GetLoans(ax, dealId, isActive);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update loan info 
        /// </summary> 
        [HttpPost("UpdateLoan")]
        public async Task<IActionResult> UpdateLoan([FromBody] LoanDTO loan)
        {
            await _provider.UpdateLoan(ax, loan);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }
        
        /// <summary>  
        /// Set random loan
        /// </summary> 
        [HttpPost("UpdateLoanRandom")]
		public async Task<IActionResult> UpdateLoanRandom([FromBody] LoanRandomDTO loanRondom)
		{
			await _provider.UpdateLoanRandom(ax, loanRondom);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
		}

        /// <summary>  
        /// Get loan dependency info 
        /// </summary> 
        [HttpGet("{dealId}/LoanDependency")]
        public async Task<IActionResult> GetLoanDependency(long dealId)
        {
            var data = await _provider.GetLoanDependency(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update loan dependency info 
        /// </summary>
        [HttpPost("{dealId}/UpdateLoanDependency")]
        public async Task<IActionResult> UpdateLoanDependency(long dealId, LoanDependencyDTO[] loanDependencyDTOs)
        {
            await _provider.UpdateLoanDependency(ax, dealId, loanDependencyDTOs);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }
    }
}
