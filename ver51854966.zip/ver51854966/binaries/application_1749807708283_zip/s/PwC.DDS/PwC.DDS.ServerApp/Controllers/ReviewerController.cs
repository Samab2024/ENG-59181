﻿using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [Route("api/Reviewer")]
    [ApiController]
    public class ReviewerController : AbstractController
    {
        private readonly IReviewerProvider _provider;
        public ReviewerController(IReviewerProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Get attribute reviewer list  
        /// </summary> 
        [HttpGet("{dealId}/AttributeReviewers")]
        public async Task<IActionResult> GetAttributeReviewers(long dealId)
        {
            var data = await _provider.GetAttributeReviewers(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Get attribute reviewer  
        /// </summary> 
        [HttpGet("HeaderMaps/{headerId}")]
        public async Task<IActionResult> GetAttributeReviewer(long headerId)
        {
            var data = await _provider.GetAttributeReviewer(ax, headerId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Update attribute reviewer info 
        /// </summary> 
        [HttpPost("UpdateAttributeReviewer")]
        public async Task<IActionResult> UpdateAttributeReviewer([FromBody] HeaderDTO reviewer)
        {
            await _provider.UpdateAttributeReviewer(ax, reviewer);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Get loan reviewer list  
        /// </summary> 
        [HttpGet("{dealId}/Sections/{sectionId}/LoanReviewers")]
        public async Task<IActionResult> GetLoanReviewers(long dealId, long sectionId)
        {
            var data = await _provider.GetLoanReviewers(ax, dealId, sectionId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Get loan reviewer  
        /// </summary> 
        [HttpGet("Loans/{loanId}/Sections/{sectionId}")]
        public async Task<IActionResult> GetLoanReviewer(long loanId, long sectionId)
        {
            var data = await _provider.GetLoanReviewer(ax, loanId, sectionId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Update loan reviewer info 
        /// </summary>
        [HttpPost("UpdateLoanReviewer")]
        public async Task<IActionResult> UpdateLoanReviewer([FromBody] ReviewerDTO reviewer)
        {
            await _provider.UpdateLoanReviewer(ax, reviewer);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }
    }
}
