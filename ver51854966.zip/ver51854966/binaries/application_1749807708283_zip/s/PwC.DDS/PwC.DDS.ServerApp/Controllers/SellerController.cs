﻿using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [Route("api/Seller")]
    [ApiController]
    public class SellerController : AbstractController
    {
        private readonly ISellerProvider _provider;
        public SellerController(ISellerProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Get Seller (Default) - Used for import
        /// </summary>
        [HttpGet("{dealId}")]
        public async Task<IActionResult> GetSellers(long dealId)
        {
            var data = await _provider.GetSellers(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update Seller
        /// </summary>
        [HttpPost("{dealId}/UpdateSeller")]
        public async Task<IActionResult> UpdateSeller(long dealId, SellerDTO[] sellers)
        {
            await _provider.UpdateSeller(ax, dealId, sellers);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }
    }
}
