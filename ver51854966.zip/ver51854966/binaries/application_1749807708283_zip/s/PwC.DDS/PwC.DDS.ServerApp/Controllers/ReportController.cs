﻿using Aspose.Cells;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
	[ApiController]
	[Route("api/Report")]
	public class ReportController : AbstractController
	{
		private readonly IReportProvider _provider;
		private readonly IDealProvider _dealProvider;
		public ReportController(IReportProvider provider, IDealProvider dealProvider)
		{
			_provider = provider;
			_dealProvider = dealProvider;
        }

        /// <summary>  
        /// Downloads Report.
        /// </summary>  
        /// <param name="dealId">The ID of the deal.</param>  
        /// <param name="reportType">1.Master Tape report; 2.Exception report; 3.PwC Tape report; 4.Feedback report; 5.Loan Status report</param>  
        /// <param name="levelOfReview">Level of Review: 1, 2, 3. (The min value will more than 2)</param> 
        /// <param name="reportOrder">Report Order: 1.By Loan; 2.By attribute</param>
		/// <param name="downloadReportRequestDTO">downloadReportRequestDTO: 1.Seller Ids; 2.Include Calculation Exception</param>
        /// <returns>The downloaded report.</returns>  
        [Route("{dealId}/DownloadReport/ReportType/{reportType}/{levelOfReview}")]
		[HttpPost]
		public async Task<IActionResult> DownloadReport(long dealId, ReportType reportType, [FromBody] DownloadReportRequestDTO downloadReportRequestDTO, int levelOfReview = 2, ReportOrder reportOrder = ReportOrder.ByLoan)
		{
			var dealName = await _dealProvider.GetDealName(ax, dealId);
			if (reportType == ReportType.MasterTapeReport)
			{
				string fileName = $"{dealName}_PwC Master Tape Report_{DateTime.Now.ToString("yyyyMMdd")}.{FileFormatType.Xlsx.ToString().ToLowerInvariant()}";
				return File(await _provider.DownloadMasterTapeReport(ax, dealId, downloadReportRequestDTO.SellerIds, levelOfReview, reportOrder), "application/octstream", fileName);
			}
			else if (reportType == ReportType.ExceptionReport)
			{
				string fileName = $"{dealName}_PwC Exception Report_{DateTime.Now.ToString("yyyyMMdd")}.{FileFormatType.Xlsx.ToString().ToLowerInvariant()}";
				return File(await _provider.DownloadExceptionReport(ax, dealId, downloadReportRequestDTO.SellerIds, levelOfReview, reportOrder, downloadReportRequestDTO.IncludeCalculationException), "application/octstream", fileName);
			}
			else if (reportType == ReportType.PwCTapeReport)
			{
				string fileName = $"{dealName}_PwC Tape Report_{DateTime.Now.ToString("yyyyMMdd")}.{FileFormatType.Xlsx.ToString().ToLowerInvariant()}";
				return File(await _provider.DownloadPwCTapeReport(ax, dealId, downloadReportRequestDTO.SellerIds, levelOfReview, downloadReportRequestDTO.IncludePwcHeaderFields, downloadReportRequestDTO.includePwcComments), "application/octstream", fileName);
			}
			else if (reportType == ReportType.FeedbackReport)
			{
				string fileName = $"{dealName}_PwC Feedback Report_{DateTime.Now.ToString("yyyyMMdd")}.{FileFormatType.Xlsx.ToString().ToLowerInvariant()}";
				return File(await _provider.DownloadFeedbackReport(ax, dealId, downloadReportRequestDTO.SellerIds, reportOrder), "application/octstream", fileName);
			}
			else if (reportType == ReportType.LoanStatusReport)
			{
				string fileName = $"{dealName}_PwC Loan Status Report_{DateTime.Now.ToString("yyyyMMdd")}.{FileFormatType.Xlsx.ToString().ToLowerInvariant()}";
				return File(await _provider.DownloadLoanStatusReport(ax, dealId, downloadReportRequestDTO.SellerIds, reportOrder), "application/octstream", fileName);
			}
			else
			{
				return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status400BadRequest, Data = null, Count = 1, Message = string.Empty });
			}
		}
	}
}
