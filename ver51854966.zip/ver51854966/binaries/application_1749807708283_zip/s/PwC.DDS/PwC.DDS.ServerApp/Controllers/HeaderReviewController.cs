﻿using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [Route("api/HeaderReview")]
    [ApiController]
    public class HeaderReviewController : AbstractController
    {
        private readonly IHeaderReviewProvider _provider;

        public HeaderReviewController(IHeaderReviewProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Get attribute review form 
        /// </summary>
        [HttpGet("{dealId}/Headers/{headerId}")]
        public async Task<IActionResult> GetHeaderReview(long dealId, long headerId)
        {
            var data = await _provider.GetHeaderReview(ax, dealId, headerId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Update attribute review form 
        /// </summary>
        [HttpPost("{dealId}/Headers/{headerId}/UpdateHeaderReview")]
        public async Task<IActionResult> UpdateHeaderReview(long dealId, long headerId, [FromBody] HeaderReviewSection headerReviews)
        {
            await _provider.UpdateHeaderReview(ax, dealId, headerId, headerReviews);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Update attribute review form  by cell
        /// </summary>
        [HttpPost("{dealId}/Headers/{headerId}/UpdateHeaderReviewCell")]
        public async Task<IActionResult> UpdateHeaderReviewCell(long dealId, long headerId, [FromBody] HeaderReviewCell headerMapReview)
        {
            await _provider.UpdateHeaderReview(ax, dealId, headerId, headerMapReview);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Get attribute review status summary 
        /// </summary>
        [HttpGet("{dealId}/HeaderReviewStatus")]
        public async Task<IActionResult> GetHeaderReviewStatus(long dealId)
        {
            var data = await _provider.GetHeaderReviewStatus(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }
    }
}
