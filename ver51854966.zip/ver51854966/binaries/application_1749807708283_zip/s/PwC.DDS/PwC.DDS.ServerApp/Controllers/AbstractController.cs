﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Database;
using PwC.DDS.Infrastructure;

namespace PwC.DDS.ServerApp.Controllers
{
    // name this abstract will make this file to be on top of file list, which makes file structure more clear
    public class AbstractController : ControllerBase
    {
        // ATTENTION not available in AllowAnonymous action
        protected DdsActionContext ax => new()
        {
            UserId = HttpContext.GetUserId(),
            UserName = HttpContext.GetUserName(),
            UserEmail = HttpContext.GetUserEmail(),
            IsAdmin = HttpContext.GetIsAdmin(),
            //Permissions = HttpContext.GetPermissionActions(),
            DataContext = HttpContext.RequestServices.GetService<DataContext>(),
            Mapper = HttpContext.RequestServices.GetService<IMapper>(),
            ICache = HttpContext.RequestServices.GetService<IMemoryCacheHelper>(),
            IConfig = HttpContext.RequestServices.GetService<IConfiguration>(),
            //DealId = HttpContext.GetDealId(),
        };

        protected async Task<IActionResult> Ok<T>(Task<T> content)
        {
            return Ok(await content);
        }
    }
}
