﻿using Aspose.Cells;
using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [Route("api/HeaderMap")]
    [ApiController]
    public class HeaderMapController : AbstractController
    {
        private readonly IHeaderMapProvider _provider;
        public HeaderMapController(IHeaderMapProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Get header map list 
        /// </summary>
        [HttpGet("{dealId}/DealHeaderMap")]
        // ProcessType-string
        // SourceDocSection-int(deal level)
        // Source-string
        // DataFormat-int
        // FieldGuide-string
        // ScreenShot-int(deal level)
        public async Task<IActionResult> GetDealHeaderMap(long dealId)
        {
            var data = await _provider.GetDealHeaderMap(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Update header map list 
        /// </summary>
        [HttpPost("{dealId}/UpdateDealHeaderMap")]
        // Tips: Send back only changed entities (HeaderMapId>0) and new entities (HeaderMapId=0)
        // Tips: PwC header can not be empty
        // Tips: Only PwC entities can be deleted or added, which Client Header is empty. If need to change client entities, use import process.
        public async Task<IActionResult> UpdateDealHeaderMap(long dealId, HeaderMapDTO[] headerMaps)
        {
            await _provider.UpdateDealHeaderMap(ax, dealId, headerMaps);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Copy header map from another deal 
        /// </summary>
		[HttpPost("{dealId}/CopyHeaderMap")]
        // Tips: isOverride - False (Update the records which PwC Header is empty in case Client Header matches)
        // Tips: isOverride - True (Update all records in case Client Header matches)
        public async Task<IActionResult> CopyHeaderMap(long dealId, [FromBody]CopyHeaderMapConfigDTO copyHeaderMapConfig)
        {          
            await _provider.CopyHeaderMap(ax, dealId, copyHeaderMapConfig.DealIdRef, copyHeaderMapConfig.IsOverride);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Create new PwC header map 
        /// </summary>
        [HttpPost("{dealId}/CreateHeaderMap")]
		public async Task<IActionResult> CreateHeaderMap(long dealId, [FromBody] HeaderMapDTO headerMap)
		{
			var data = await _provider.CreateHeaderMap(ax, dealId, headerMap);
			return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
		}

        /// <summary>
        /// Download header map
        /// </summary>
		[HttpPost("{dealId}/DownloadHeaderMap")]
        public async Task<IActionResult> DownloadHeaderMap(long dealId)
        {
            string fileName = $"Header Map_{dealId}_{DateTime.Now.ToString("MM/dd/yyyy")}.{FileFormatType.Xlsx.ToString().ToLowerInvariant()}";
            return File(await _provider.DownloadHeaderMap(ax, dealId), "application/octstream", fileName);
        }

        /// <summary>  
        /// Import header map
        /// </summary>
        [HttpPost("ImportHeaderMap")]
        public async Task<IActionResult> ImportHeaderMap([FromForm] ImportHeaderMapDataDTO importInfo)
        {
            var data = await _provider.ImportHeaderMap(ax, importInfo);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>
        /// Download header map exception
        /// </summary>
		[HttpPost("DownloadHeaderMapException")]
        public async Task<IActionResult> DownloadHeaderMapException([FromBody] ExportHeaderMapDataDTO exportInfo)
        {
            string newfileName = $"Header Map Exception {DateTime.Now.ToString("MM/dd/yyyy")}.{FileFormatType.Xlsx.ToString().ToLowerInvariant()}";
            return File(await _provider.DownloadHeaderMapException(ax, exportInfo.FileName), "application/octstream", newfileName);
        }

        #region Fields Settings
        /// <summary>  
        /// Get Source (Bloomberg, Market Data, Other Loan aggreement) 
        /// </summary>
        [HttpGet("{dealId}/Source")]
        public async Task<IActionResult> GetSource(long dealId)
        {
            var data = await _provider.GetSource(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update Source
        /// </summary>
        [HttpPost("{dealId}/UpdateSource")]
        public async Task<IActionResult> UpdateSource(long dealId, SourceDTO[] sources)
        {
            await _provider.UpdateSource(ax, dealId, sources);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Get Source Doc Section
        /// </summary>
        [HttpGet("{dealId}/SourceDocSection")]
        public async Task<IActionResult> GetSourceDocSection(long dealId)
        {
            var data = await _provider.GetSourceDocSection(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update Source Doc Section
        /// </summary>
        [HttpPost("{dealId}/UpdateSourceDocSection")]
        public async Task<IActionResult> UpdateSourceDocSection(long dealId, SourceDocSectionDTO[] sourceDocSections)
        {
            await _provider.UpdateSourceDocSection(ax, dealId, sourceDocSections);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Get Dropdown Categorys
        /// </summary>
        [HttpGet("{dealId}/DropdownCategory")]
        public async Task<IActionResult> GetDropdownCategory(long dealId)
        {
            var data = await _provider.GetDropdownCategory(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update Dropdown Categorys
        /// </summary>
        [HttpPost("{dealId}/UpdateDropdownCategory")]
        public async Task<IActionResult> UpdateDropdownCategory(long dealId, DropdownCategoryDTO[] dropdownCategorys)
        {
            await _provider.UpdateDropdownCategory(ax, dealId, dropdownCategorys);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Get Process Type (Provided, Review, Calculation, Pass-Through)
        /// </summary>
        [HttpGet("PFProcessType")]
        public async Task<IActionResult> GetProcessType()
        {
            var data = await _provider.GetProcessType(ax);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Get Data Format - system level
        /// </summary>
        [HttpGet("PFDataFormat")]
        public async Task<IActionResult> GetDataFormat()
        {
            var data = await _provider.GetDataFormat(ax);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Update Data Format - system level
        /// </summary>
        [HttpPost("UpdatePFDataFormat")]
        public async Task<IActionResult> UpdateDataFormat(DataFormatDTO[] dataFormats)
        {
            await _provider.UpdateDataFormat(ax, dataFormats);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }        

        /// <summary>  
        /// Upload Screen Shot
        /// </summary>
        [HttpPost("UploadScreenShot")]
        public async Task<IActionResult> UploadScreenShot([FromForm] ImageInfo imgInfo)
        {
            var data = await _provider.UploadScreenShot(ax, imgInfo);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Download Screen Shot
        /// </summary>
        [HttpGet("DownloadScreenShot")]
        public async Task<IActionResult> DownloadScreenShot(long screenShotId)
        {
            var data = await _provider.DownloadScreenShot(ax, screenShotId);
            return File(data, "image/jpeg");
        }        
        #endregion
    }
}
