﻿using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [ApiController]
    [Route("api/Deal")]
    public class DealController : AbstractController
    {
        private readonly IDealProvider _provider;
        public DealController(IDealProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Creare new deal
        /// </summary>
        [HttpPost("CreateDeal")]
        public async Task<IActionResult> CreateDeal([FromBody] DealSetupWithSectionDTO dealSetup)
        {
            var data = await _provider.CreateDeal(ax, dealSetup);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Update deal
        /// </summary>
        [HttpPost("UpdateDeal")]
        public async Task<IActionResult> UpdateDeal([FromBody] DealSetupDTO dealSetup)
        {
            var data = await _provider.UpdateDeal(ax, dealSetup);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Get deal list
        /// </summary>
        [HttpGet("Deals")]
        public async Task<IActionResult> GetDeals(string dealState)
        {
            var data = await _provider.GetDeals(ax, dealState);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = data.Count(), Message = string.Empty });
        }

        /// <summary>  
        /// Get deal
        /// </summary>
        [HttpGet("{dealId}")]
        public async Task<IActionResult> GetDeal(long dealId)
        {
            var data = await _provider.GetDeal(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Change deal state
        /// </summary>
        [HttpPost("{dealId}/UpdateDealState")]
        public async Task<IActionResult> UpdateDealState(long dealId, string dealState)
        {
            await _provider.UpdateDealState(ax, dealId, dealState);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Delete deal
        /// </summary>
        [HttpDelete("{dealId}/DeleteDeal")]
        public async Task<IActionResult> DeleteDeal(long dealId)
        {
            await _provider.DeleteDeal(ax, dealId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }
    }
}
