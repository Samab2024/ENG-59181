﻿using Microsoft.AspNetCore.Mvc;
using PwC.DDS.Core;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp.Controllers
{
    [Route("api/LoanReview")]
    [ApiController]
    public class LoanReviewController : AbstractController
    {
        private readonly ILoanReviewProvider _provider;
        public LoanReviewController(ILoanReviewProvider provider)
        {
            _provider = provider;
        }

        /// <summary>  
        /// Get loan review form by section
        /// </summary>
        [HttpGet("{dealId}/Loans/{loanId}/Sections/{sectionId}")]
        public async Task<IActionResult> GetLoanReview(long dealId, long loanId, long sectionId)
        {
            var data = await _provider.GetLoanReview(ax, dealId, loanId, sectionId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Update loan review form
        /// </summary>
        [HttpPost("{dealId}/Loans/{loanId}/UpdateLoanReview")]
        public async Task<IActionResult> UpdateLoanReview(long dealId, long loanId, [FromBody] LoanReviewSection loanReviews)
        {
            await _provider.UpdateLoanReview(ax, dealId, loanId, loanReviews);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
        }

        /// <summary>  
        /// Update loan review form by cell
        /// </summary>
		[HttpPost("{dealId}/Loans/{loanId}/UpdateLoanReviewCell")]
		public async Task<IActionResult> UpdateLoanReview(long dealId, long loanId, [FromBody] LoanReviewCell loanReview)
		{
			await _provider.UpdateLoanReview(ax, dealId, loanId, loanReview);
			return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = null, Count = 1, Message = string.Empty });
		}

        /// <summary>  
        /// Get loan review status summary 
        /// </summary>
		[HttpGet("{dealId}/Sections/{sectionId}/LoanReviewStatus")]
        public async Task<IActionResult> LoanReviewStatus(long dealId, long sectionId)
        {
            var data = await _provider.LoanReviewStatus(ax, dealId, sectionId);
            return new ObjectResult(new ResponseData<object> { Status = StatusCodes.Status200OK, Data = data, Count = 1, Message = string.Empty });
        }
    }
}
