﻿using Newtonsoft.Json;

namespace PwC.DDS
{
    /// <summary>
    /// User model of OpenAM auth
    /// </summary>
    public class PwcUserInformation
    {
        [JsonProperty("cloudEmail")]
        public string Email { get; set; }

        [JsonProperty("PwClos")]
        public string PwClos { get; set; }

        [JsonProperty("given_name")]
        public string GivenName { get; set; }

        [JsonProperty("family_name")]
        public string FamilyName { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("uid")]
        public string UserId { get; set; }

        [JsonProperty("costcenter")]
        public string CostCenter { get; set; }

        [JsonProperty("employeeNumber")]
        public string StaffNumber { get; set; }

        [JsonProperty("sub")]
        public string Sub { get; set; }

        [JsonProperty("upn")]
        public string Upn { get; set; }

        [JsonProperty("pwcWorkerID")]
        public string PwcWorkerIDStr { get; set; } = "";

        public int? PwcWorkerID
        {
            get
            {
                int.TryParse(PwcWorkerIDStr, out int workerId);
                return workerId;
            }
        }
    }
}
