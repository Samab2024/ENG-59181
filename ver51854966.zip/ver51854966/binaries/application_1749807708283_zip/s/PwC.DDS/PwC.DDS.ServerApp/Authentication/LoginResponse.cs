﻿namespace PwC.DDS.ServerApp
{
    public class LoginResponse
    {
        public CurrentUser CurrentUser { get; set; }
    }
}
