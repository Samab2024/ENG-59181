﻿namespace PwC.DDS.ServerApp
{
    public class CurrentUser
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Guid { get; set; }
        public bool IsAdmin { get; set; }
        public string AccessToken { get; set; }
    }
}
