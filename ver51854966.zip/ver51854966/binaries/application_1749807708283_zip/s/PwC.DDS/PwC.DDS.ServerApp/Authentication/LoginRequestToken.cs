﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace PwC.DDS.ServerApp
{
    public class LoginRequestToken
    {
        [JsonProperty("oaToken")]
        [MaxLength(2000)]
        public string OaToken { get; set; }

        [JsonProperty("accessToken")]
        [MaxLength(2000)]
        public string AccessToken { get; set; }
    }
}
