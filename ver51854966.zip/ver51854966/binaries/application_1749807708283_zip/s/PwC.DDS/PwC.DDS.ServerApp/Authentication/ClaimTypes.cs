﻿using System.Security.Claims;

namespace PwC.DDS
{
    public static class ClaimTypes
    {
        public static string GetUserId(this HttpContext context)
        {
            return context.User?.FindFirstValue(RegsiteredCliamNames.UserId) ?? string.Empty;
        }

        public static string GetUserName(this HttpContext context)
        {
            return context.User?.FindFirstValue(RegsiteredCliamNames.UserName) ?? string.Empty;
        }

        public static string GetUserEmail(this HttpContext context)
        {
            return context.User?.FindFirstValue(RegsiteredCliamNames.UserEmail) ?? string.Empty;
        }

        public static bool GetIsAdmin(this HttpContext context)
        {
            return context.User?.FindFirstValue(RegsiteredCliamNames.IsAdmin) == "true" ? true : false;
        }
    }

    public struct RegsiteredCliamNames
    {
        public const string UserId = "UserId";
        public const string UserEmail = "UserEmail";
        public const string UserName = "UserName";
        public const string IsAdmin = "IsAdmin";
    }
}
