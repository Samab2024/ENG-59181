﻿using AutoMapper;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.ServerApp
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<DealSetup, DealSetupWithSectionDTO>().ReverseMap();
            CreateMap<DealSetup, DealSetupDTO>().ReverseMap();
            CreateMap<Loan, LoanDTO>().ReverseMap();
            CreateMap<Reviewer, ReviewerDTO>().ReverseMap();
            CreateMap<Reviewer, HeaderDTO>().ReverseMap();
            CreateMap<HeaderMap, HeaderMapDTO>().ReverseMap();
            CreateMap<HeaderMap, HeaderDTO>().ReverseMap();
            CreateMap<SourceDocSection, SourceDocSectionDTO>().ReverseMap();
            CreateMap<DataFormat, DataFormatDTO>().ReverseMap();
            CreateMap<Section, SectionDTO>().ReverseMap();
            CreateMap<Source, SourceDTO>().ReverseMap();
            CreateMap<Seller, SellerDTO>().ReverseMap();
            CreateMap<DropdownCategory, DropdownCategoryDTO>().ReverseMap();
            CreateMap<DropdownCategoryOption, DropdownCategoryOptionDTO>().ReverseMap();
            CreateMap<Process, ImportDataDTO>().ReverseMap()
                .ForMember(dest => dest.StartTime, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.FileName, opt => opt.MapFrom(src => src.File.FileName))
                .ForMember(dest => dest.RunType, opt => opt.MapFrom(src => src.ImportRunType.GetDisplayName()));
            CreateMap<CalculatorGlobalField, CalculatorGlobalFieldDTO>().ReverseMap();
        }
    }
}
