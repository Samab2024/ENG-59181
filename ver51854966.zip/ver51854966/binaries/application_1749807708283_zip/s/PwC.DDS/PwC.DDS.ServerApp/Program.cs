using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.OpenApi.Models;
using NLog;
using NLog.Extensions.Logging;
using NLog.Web;
using PwC.DDS;
using PwC.DDS.Infrastructure.Logging;
using PwC.DDS.ServerApp;
using System.Reflection;

var logger = LogManager.Setup().LoadConfigurationFromAppSettings().GetCurrentClassLogger();
logger.Debug("init DDS");
try
{
    var builder = WebApplication.CreateBuilder(args);
    var config = builder.Configuration;

    DdsLogger.SetFactory(LoggerFactory.Create(builder => builder.AddNLog()));

    // Add services to the container.
    const string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
    var contentTypeprovider = new FileExtensionContentTypeProvider();

    builder.Services.AddCors(options =>
    {
        options.AddPolicy(name: MyAllowSpecificOrigins,
            builder =>
            {
                builder.AllowAnyOrigin() //.WithOrigins(whitelist)
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .WithExposedHeaders("content-disposition");                   
            });
    });

    builder.Services.AddLogging(logBuilder => {
        logBuilder.ClearProviders();
        logBuilder.AddNLog();
    });
    builder.Services.AddResponseCompression(options =>
    {
        options.EnableForHttps = true;
    });
    builder.Services.Configure<MvcOptions>(opt =>
    {
        opt.Filters.Add<LoggingFilter>();
        opt.Filters.Add<ExceptionFilter>();
    });
    builder.Services.AddJwtAuthentication(config);
    builder.Services.AddHttpClient();
    builder.Services.AddDataContext(config);
    builder.Services.RegisterService();
    builder.Services.AddControllers();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(c =>
    {
        c.SwaggerDoc("v1", new OpenApiInfo { Title = "PwC.DDS", Version = "v1" });
        var xmlFilename = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
        c.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFilename));
        c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
        c.CustomSchemaIds(x => x.FullName);
        c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
        {
            Name = "Authorization",
            Type = SecuritySchemeType.ApiKey,
            Scheme = "Bearer",
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 1safsfsdfdfd\"",
        });
        c.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    }
                },
                new string[] {}
            }
        });
    });

    var app = builder.Build();
    PwC.DDS.PythonEngine.PyEngine.PythonLibraryPath = Path.Combine(app.Environment.ContentRootPath, "Lib/Python");
    app.UseSwagger();
    app.UseSwaggerUI();
    app.UseHttpsRedirection();
    app.UseDefaultFiles();
    app.UseStaticFiles(new StaticFileOptions
    {
        ContentTypeProvider = contentTypeprovider,
    });

    app.UseRouting();
    app.UseCors(MyAllowSpecificOrigins);
    app.UseAuthentication();
    app.UseAuthorization();
    app.MapControllers().RequireAuthorization();
    app.UseEndpoints(endpoints =>
    {
        endpoints.MapFallbackToFile("/index.html");
    });
    app.Run();
}
catch (Exception exception)
{
    // NLog: catch setup errors
    logger.Error(exception, "Stopped program because of exception");
    throw;
}
finally
{
    // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
    LogManager.Shutdown();
}