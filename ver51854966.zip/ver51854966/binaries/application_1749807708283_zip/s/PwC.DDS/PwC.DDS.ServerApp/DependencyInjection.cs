﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PwC.DDS.Core;
using PwC.DDS.Database;
using PwC.DDS.Infrastructure;
using System.Security.Cryptography;
using PwC.FMRE.Tools;
using System.Text;

namespace PwC.DDS.ServerApp
{
    public static class DependencyInjection
    {
        public static void AddDataContext(this IServiceCollection services, IConfiguration config)
        {
            var appSettings = config.GetSection(nameof(AppSettings)).Get<AppSettings>();
            var connectionString = Parse(appSettings?.SQLConnectionString);

            services.AddDbContext<DataContext>(o => o.UseSqlServer(connectionString,
                opts =>
                {
                    opts.CommandTimeout((int)TimeSpan.FromMinutes(5).TotalSeconds);
                    opts.EnableRetryOnFailure(3);
                }));
        }

        public static void AddJwtAuthentication(this IServiceCollection services, IConfiguration config)
        {
            services.AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
                {
                    var jwtSettings = config.GetSection(nameof(JwtSettings)).Get<JwtSettings>();
                    if (string.IsNullOrEmpty(jwtSettings?.SecurityKey))
                    {
                        throw new Exception("Failed to get authentication configuration information.");
                    }
                    var key = Encoding.UTF8.GetBytes(jwtSettings.SecurityKey);
                    var rsa = RSA.Create();
                    rsa.ImportRSAPublicKey(Convert.FromBase64String(jwtSettings.RsaPublicKey), out _);
                    var newPublicKey = new RsaSecurityKey(rsa);
                    options.SaveToken = true;
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidIssuer = jwtSettings.Issuer,
                        ValidAudience = jwtSettings.Issuer,
                        IssuerSigningKey = newPublicKey
                    };
                });
        }

        public static void RegisterService(this IServiceCollection services)
        {
            services.AddMemoryCache();
            services.AddAutoMapper(typeof(AutoMapperProfile));
            services.AddScoped<DataContext>();
            services.AddScoped<IMemoryCacheHelper, MemoryCacheHelper>();
            services.AddScoped<IUserProvider, UserProvider>();
            services.AddScoped<IDealProvider, DealProvider>();
            services.AddScoped<IImportProvider, ImportProvider>();
            services.AddScoped<ILoanProvider, LoanProvider>();
            services.AddScoped<ILoanReviewProvider, LoanReviewProvider>();
            services.AddScoped<IHeaderReviewProvider, HeaderReviewProvider>();
            services.AddScoped<IHeaderMapProvider, HeaderMapProvider>();
            services.AddScoped<IContentTypeProvider, FileExtensionContentTypeProvider>();
            services.AddScoped<IReportProvider, ReportProvider>();
            services.AddScoped<ISectionProvider, SectionProvider>();
            services.AddScoped<ISellerProvider, SellerProvider>();
            services.AddScoped<IReviewerProvider, ReviewerProvider>();
            services.AddScoped<IEmailProvider, EmailProvider>();
            services.AddScoped<ICalculatorProvider, CalculatorProvider>();
        }

        public static string Parse(string connectionString)
        {
            var parts = connectionString.Split(";");
            var result = new StringBuilder();
            foreach (var part in parts)
            {
                if (string.IsNullOrEmpty(part)) continue;

                var key = part.Substring(0, part.IndexOf('='));
                var val = part.Substring(part.IndexOf('=') + 1);
                if (key == "User ID" || key == "Password")
                {
                    val = Cryptography.Decrypt(val);
                }
                result.Append($"{key}={val};");
            }

            return result.ToString();
        }
    }
}
