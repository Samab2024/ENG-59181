﻿using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Core
{
    public interface ILoanReviewProvider
    {
        Task<LoanReviewDTO> GetLoanReview(DdsActionContext ax, long dealId, long loanId, long sectionId);
        Task UpdateLoanReview(DdsActionContext ax, long dealId, long loanId, LoanReviewSection loanReviews);
		Task UpdateLoanReview(DdsActionContext ax, long dealId, long loanId, LoanReviewCell loanReview);
        Task<ReviewStatusDTO> LoanReviewStatus(DdsActionContext ax, long dealId, long sectionId);
    }
}
