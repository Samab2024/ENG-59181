﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using PwC.DDS.Core.Common;

namespace PwC.DDS.Core
{
    public class LoanReviewProvider: ILoanReviewProvider
    {
        readonly IDealProvider _deal;
        readonly IReviewerProvider _reviewer;
        public LoanReviewProvider(IDealProvider deal, IReviewerProvider reviewer)
        {
            _deal = deal;
            _reviewer = reviewer;
        }

        public async Task<LoanReviewDTO> GetLoanReview(DdsActionContext ax, long dealId, long loanId, long sectionId)
        {
            var result = new LoanReviewDTO();
            var allLoans = await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).ToArrayAsync();
            bool isRandomReview = allLoans.Any(l => l.IsRandomReview);
            var loans = allLoans.Where(l => !isRandomReview || l.IsRandomReview == isRandomReview).OrderBy(l => l.SellerId).ThenBy(l => l.DisplayOrder).ToArray();
            var data = loans.Where(l => l.LoanId == loanId).FirstOrDefault();
            var childLoanIds = loans.Where(l => l.ParentId == loanId).Select(l => l.LoanId).ToArray();
            if (data != null)
            {
                var deal = await _deal.GetDeal(ax, dealId);
                var curIndex = Array.IndexOf(loans, data);
                var prvLoan = curIndex == 0 ? null : loans[curIndex - 1];
                var nextLoan = curIndex == loans.Count() - 1 ? null : loans[curIndex + 1];
                var sections = await ax.Query<SourceDocSection>().Where(s => s.DealId == dealId && s.SectionId == sectionId).ToArrayAsync();
                var maps = ax.Query<HeaderMap>().Where(h => h.DealId == dealId && h.IsActive == true
                                                            && (h.ProcessType == ProcessType.Review.GetDisplayName() ||
                                                                h.ProcessType == ProcessType.ReviewCalculation.GetDisplayName() ||
                                                                h.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()))
                                                .Include(h => h.SourceDocSection).Include(h => h.DataFormat).AsEnumerable()
                                                .Where(h => sections.Any(l => l.SourceDocSectionId == h.SourceDocSectionId)).ToArray();
                var loanReviewer = await ax.Query<Reviewer>().Where(h => h.DealId == dealId && h.LoanId == loanId && h.SectionId == sectionId).FirstOrDefaultAsync();
                var reviews = await ax.Query<LoanReview>().Where(h => h.DealId == dealId && (h.LoanId == loanId || childLoanIds.Contains(h.LoanId))).ToArrayAsync();                
                var categoryOptions = await ax.Query<DropdownCategoryOption>().Where(h => h.DealId == dealId && h.IsActive == true).OrderBy(h => h.CategoryId).OrderBy(h => h.DisplayOrder).ToArrayAsync();

                result.LoanId = data.LoanId;
                result.LoanNumber = data.LoanNumber;
                result.PropertyName = data.PropertyName;
                result.LevelOfReview = deal.LevelOfReview;
                result.DealName = deal.DealName;
                result.IsDealAdmin = deal.IsDealAdmin;
                result.DisplayOrder = data.DisplayOrder;
                result.MissingDoc = data.MissingDoc;
                result.IsBlindReview = deal.IsBlindReview;
                result.PrvLoanId = prvLoan?.LoanId;
                result.PrvLoanNumber = prvLoan?.LoanNumber;
                result.NextLoanId = nextLoan?.LoanId;
                result.NextLoanNumber = nextLoan?.LoanNumber;
                result.ReviewSection = maps.GroupBy(m => m.SourceDocSectionId).Select(m => m.FirstOrDefault())
                    .Select(s => new LoanReviewSection
                    {
                        SectionId = sectionId,
                        SourceDocSectionId = s.SourceDocSection.SourceDocSectionId,
                        SourceDocSectionName = s.SourceDocSection.Name,
                        IsAllowCopy = s.SourceDocSection.IsAllowCopy,
                        DisplayOrder = s.SourceDocSection.DisplayOrder,
                    }).OrderBy(m => m.DisplayOrder).ToArray();

                foreach (var section in result.ReviewSection)
                {
                    section.Permission = GetLoanReviewPermission(loanReviewer, ax.IsAdmin, deal.IsDealAdmin, ax.UserEmail);
                    section.ReviewData = (from hm in maps
                                          join rv in reviews on hm.HeaderMapId equals rv.HeaderMapId
                                          join ln in loans on rv.LoanId equals ln.LoanId
                                          where hm.SourceDocSectionId == section.SourceDocSectionId
                                          select new LoanReviewData
                                          {
                                              HeaderMapId = hm.HeaderMapId,
                                              ParentId = data.LoanId == rv.LoanId ? null : data.LoanId,
                                              LoanNumber = ln.LoanNumber,
                                              PropertyName = ln.PropertyName,
                                              ClientHeader = hm.ClientHeader,
                                              PwCHeader = hm.PwCHeader,
                                              DisplayOrder = hm.DisplayOrder,
                                              ProcessType = hm.ProcessType,
                                              ClientValue = ConvertExtension.ToStringFromExponentialNullable(rv.ClientValue),
                                              ClientDisplayValue = rv.ClientDisplayValue,
                                              FirstReviewValue = rv.FirstReviewValue,
                                              FirstReviewFormula = rv.FirstReviewFormula,
                                              IsFirstReviewed = rv.IsFirstReviewed,
                                              SecondReviewValue = Math.Min(deal.LevelOfReview, hm.LevelOfReview) > 1 ? rv.SecondReviewValue : string.Empty,
                                              SecondReviewFormula = Math.Min(deal.LevelOfReview, hm.LevelOfReview) > 1 ? rv.SecondReviewFormula : string.Empty,
                                              IsSecondReviewed = Math.Min(deal.LevelOfReview, hm.LevelOfReview) > 1 ? rv.IsSecondReviewed : false,
                                              ThirdReviewValue = Math.Min(deal.LevelOfReview, hm.LevelOfReview) > 2 ? rv.ThirdReviewValue : string.Empty,
                                              ThirdReviewFormula = Math.Min(deal.LevelOfReview, hm.LevelOfReview) > 2 ? rv.ThirdReviewFormula : string.Empty,
                                              IsThirdReviewed = Math.Min(deal.LevelOfReview, hm.LevelOfReview) > 2 ? rv.IsThirdReviewed : false,
                                              PwCComments = rv.PwCComments,
                                              InternalComments = rv.InternalComments,
                                              IsTie = rv.IsTie,
                                              FieldGuide = hm.FieldGuide,
                                              DataFormatId = hm.DataFormat.DataFormatId,
                                              DataFormatType = hm.DataFormat.Type,
                                              DataFormatCode = hm.DataFormat.Code,
                                              DropdownCategoryId = hm.DropdownCategoryId,
                                              DropdownCategoryOptions = categoryOptions.Where(c => c.CategoryId == hm.DropdownCategoryId).Select(c => c.OptionName).ToArray(),
                                              LevelOfReview = Math.Min(deal.LevelOfReview, hm.LevelOfReview),
                                              IsBlindReview = hm.IsBlindReview,
                                              Threadhold = hm.Threadhold,
                                          }).OrderBy(r => r.DisplayOrder).ThenBy(r => r.HeaderMapId).ToArray();
                }
            }
            return result;
        }

        private string GetLoanReviewPermission(Reviewer? reviewer, bool isSysAdmin, bool isDealAdmin, string email)
        {
            if (isSysAdmin || isDealAdmin)
                return "1,2,3";

            var result = string.Empty;
            if (reviewer?.Reviewer1?.ToLower() == email.ToLower())
                result += "1,";
            if (reviewer?.Reviewer2?.ToLower() == email.ToLower() &&
                !string.IsNullOrEmpty(reviewer.ReviewerStatus1) &&
                reviewer.ReviewerStatus1 != ReviewStatus.NotStarted.GetDisplayName())
                result += "2,";
            if (reviewer?.Reviewer3?.ToLower() == email.ToLower() &&
                !string.IsNullOrEmpty(reviewer.ReviewerStatus1) &&
                reviewer.ReviewerStatus1 != ReviewStatus.NotStarted.GetDisplayName() &&
                !string.IsNullOrEmpty(reviewer.ReviewerStatus2) &&
                reviewer.ReviewerStatus2 != ReviewStatus.NotStarted.GetDisplayName())
                result += "3,";
            return result == string.Empty ? string.Empty : result.Substring(0, result.Length - 1);
        }

        public async Task UpdateLoanReview(DdsActionContext ax, long dealId, long loanId, LoanReviewSection section)
        {
            var loan = await ax.Query<Loan>().Where(h => h.DealId == dealId && h.LoanId == loanId).FirstAsync();
            var existReviews = await ax.Query<LoanReview>().Where(h => h.DealId == dealId && h.LoanId == loanId).ToArrayAsync();
            var rs = await ax.Query<Reviewer>().Where(l => l.DealId == dealId && l.LoanId == loanId && l.HeaderMapId == 0 && l.SectionId == section.SectionId).FirstOrDefaultAsync();
            var headermap = await ax.Query<HeaderMap>().Where(h => h.DealId == dealId).ToArrayAsync();

            bool needRecalc = false;
            if (!string.IsNullOrEmpty(section.Permission) && rs != null && headermap != null)
            {
                var mapIds = section.ReviewData.Select(m => m.HeaderMapId).ToArray();
                var changedRvs = existReviews.Where(m => mapIds.Any(l => l == m.HeaderMapId)).ToArray();
                foreach (var rv in changedRvs)
                {
                    var review = section.ReviewData.Where(m => m.HeaderMapId == rv.HeaderMapId).FirstOrDefault();
                    var hm = headermap.Where(m => m.HeaderMapId == rv.HeaderMapId).FirstOrDefault();
                    var levelOfReview = hm?.LevelOfReview ?? 0;
                    var hasChanged = false;

                    if (section.Permission.Contains("1") && rv.FirstReviewValue != review?.FirstReviewValue)
                    {
                        rv.FirstReviewUpdatedTime = DateTime.UtcNow;
                        rv.FirstReviewUpdatedBy = ax.UserId;
                        rv.FirstReviewValue = review?.FirstReviewValue;
                        rv.FirstReviewFormula = review?.FirstReviewFormula;
                        rv.IsFirstReviewed = !string.IsNullOrEmpty(review?.FirstReviewValue) || review.IsFirstReviewed;
                        rs.ReviewerStatus1 = ReviewStatus.InProgress.GetDisplayName();
                        hasChanged = true;
                    }
                    if (section.Permission.Contains("2") && rv.SecondReviewValue != review?.SecondReviewValue && levelOfReview > 1)
                    {
                        rv.SecondReviewUpdatedTime = DateTime.UtcNow;
                        rv.SecondReviewUpdatedBy = ax.UserId;
                        rv.SecondReviewValue = review?.SecondReviewValue;
                        rv.SecondReviewFormula = review?.SecondReviewFormula;
                        rv.IsSecondReviewed = !string.IsNullOrEmpty(review?.SecondReviewValue) || review.IsSecondReviewed;
                        rs.ReviewerStatus2 = ReviewStatus.InProgress.GetDisplayName();
                        hasChanged = true;
                    }
                    if (section.Permission.Contains("3") && rv.ThirdReviewValue != review?.ThirdReviewValue && levelOfReview > 2)
                    {
                        rv.ThirdReviewUpdatedTime = DateTime.UtcNow;
                        rv.ThirdReviewUpdatedBy = ax.UserId;
                        rv.ThirdReviewValue = review?.ThirdReviewValue;
                        rv.ThirdReviewFormula = review?.ThirdReviewFormula;
                        rv.IsThirdReviewed = !string.IsNullOrEmpty(review?.ThirdReviewValue) || review.IsThirdReviewed;
                        rs.ReviewerStatus3 = ReviewStatus.InProgress.GetDisplayName();
                        hasChanged = true;
                    }
                    if (rv.PwCComments != review?.PwCComments)
                    {
                        rv.PwCComments = review?.PwCComments;
                        hasChanged = true;
                    }
                    if (rv.InternalComments != review?.InternalComments)
                    {
                        rv.InternalComments = review?.InternalComments;
                        hasChanged = true;
                    }

                    if (hasChanged)
                    {
                        if (!string.IsNullOrEmpty(hm?.CalculatorHeader))
                            needRecalc = true;
                        rv.FinalValueUpdatedTime = DateTime.UtcNow;
                        rv.FinalValueUpdatedBy = ax.UserId;
                        if ((!string.IsNullOrEmpty(rv.ThirdReviewValue) || rv.IsThirdReviewed) && levelOfReview > 2)
                            rv.FinalValue = rv.ThirdReviewValue;
                        else if ((!string.IsNullOrEmpty(rv.SecondReviewValue) || rv.IsSecondReviewed) && levelOfReview > 1)
                            rv.FinalValue = rv.SecondReviewValue;
                        else
                            rv.FinalValue = rv.FirstReviewValue;
                        if (rv.IsFirstReviewed || rv.IsSecondReviewed || rv.IsThirdReviewed)
                            rv.IsTie = review?.IsTie;
                        else
                            rv.IsTie = null;
                        ax.Update(rv.UpdateBy(ax.UserId));
                        ax.Update(loan.UpdateBy(ax.UserId));
                    }
                }

                if (needRecalc)
                    await _deal.ResetNeedRecalculatation(ax, dealId);

                await ax.Save();
            }
        }

		public async Task UpdateLoanReview(DdsActionContext ax, long dealId, long loanId, LoanReviewCell review)
		{
            var rv = await ax.Query<LoanReview>().Where(h => h.DealId == dealId && h.LoanId == loanId && h.HeaderMapId == review.HeaderMapId).FirstOrDefaultAsync();
            var rs = await ax.Query<Reviewer>().Where(l => l.DealId == dealId && l.LoanId == loanId && l.HeaderMapId == 0 && l.SectionId == review.SectionId).FirstOrDefaultAsync();
            var hm = await ax.Query<HeaderMap>().Where(h => h.DealId == dealId && h.HeaderMapId == review.HeaderMapId).FirstOrDefaultAsync();

            //check if the old review value is diff with database, it means the database value is already updated by other user
            if (rv != null && rs != null && hm != null)
			{               
                if (review?.ReviewLevel == ReviewLevel.FirstReview) 
                {
                    if (rv.FirstReviewValue != review?.OldReviewValue)
                    {
						throw new DdsInvalidOperationException("The first review value has been already updated by other user, please refresh page.");
					}
                    else 
                    {
						rv.FirstReviewUpdatedTime = DateTime.UtcNow;
						rv.FirstReviewUpdatedBy = ax.UserId;
						rv.FirstReviewValue = review?.NewReviewValue;
                        rv.FirstReviewFormula = review?.Formula;
                        rv.IsFirstReviewed = !string.IsNullOrEmpty(review?.NewReviewValue) || review.IsReviewed;
                        rs.ReviewerStatus1 = ReviewStatus.InProgress.GetDisplayName();
                    }
                }
				else if (review?.ReviewLevel == ReviewLevel.SecondReview)
				{
					if (rv.SecondReviewValue != review?.OldReviewValue)
					{
						throw new DdsInvalidOperationException("The second review value has been already updated by other user, please refresh page.");
					}
					else
					{
						rv.SecondReviewUpdatedTime = DateTime.UtcNow;
						rv.SecondReviewUpdatedBy = ax.UserId;
						rv.SecondReviewValue = review?.NewReviewValue;
                        rv.SecondReviewFormula = review?.Formula;
                        rv.IsSecondReviewed = !string.IsNullOrEmpty(review?.NewReviewValue) || review.IsReviewed;
                        rs.ReviewerStatus2 = ReviewStatus.InProgress.GetDisplayName();
                    }
				}
				else if (review?.ReviewLevel == ReviewLevel.ThirdReview)
				{
					if (rv.ThirdReviewValue != review?.OldReviewValue)
					{
						throw new DdsInvalidOperationException("The third review value has been already updated by other user, please refresh page.");
					}
					else
					{
						rv.ThirdReviewUpdatedTime = DateTime.UtcNow;
						rv.ThirdReviewUpdatedBy = ax.UserId;
						rv.ThirdReviewValue = review?.NewReviewValue;
                        rv.ThirdReviewFormula = review?.Formula;
                        rv.IsThirdReviewed = !string.IsNullOrEmpty(review?.NewReviewValue) || review.IsReviewed;
                        rs.ReviewerStatus3 = ReviewStatus.InProgress.GetDisplayName();
                    }
				}

                var finalValue = rv.FirstReviewValue;
                if ((!string.IsNullOrEmpty(rv.ThirdReviewValue) || rv.IsThirdReviewed) && hm.LevelOfReview > 2)
                    finalValue = rv.ThirdReviewValue;
                else if ((!string.IsNullOrEmpty(rv.SecondReviewValue) || rv.IsSecondReviewed) && hm.LevelOfReview > 1)
                    finalValue = rv.SecondReviewValue;

                if (finalValue != rv.FinalValue)
				{
					rv.FinalValueUpdatedTime = DateTime.UtcNow;
					rv.FinalValueUpdatedBy = ax.UserId;
					rv.FinalValue = finalValue;
                    if (!string.IsNullOrEmpty(hm.CalculatorHeader))
                        await _deal.ResetNeedRecalculatation(ax, dealId);
				}

				rv.PwCComments = review?.PwCComments;
                rv.InternalComments = review?.InternalComments;
                if (rv.IsFirstReviewed || rv.IsSecondReviewed || rv.IsThirdReviewed)
                    rv.IsTie = review?.IsTie;
                else
                    rv.IsTie = null;
				ax.Update(rv.UpdateBy(ax.UserId));
				await ax.Save();
			}
		}

        public async Task<ReviewStatusDTO> LoanReviewStatus(DdsActionContext ax, long dealId, long sectionId)
        {
            var deal = await _deal.GetDeal(ax, dealId);
            var reviewers = await _reviewer.GetLoanReviewers(ax, dealId, sectionId);
            var level = deal?.LevelOfReview ?? 3;

            var result = new ReviewStatusDTO();
            foreach (var r in reviewers)
            {
                if (r.ReviewerStatus1 == ReviewStatus.NotStarted.GetDisplayName() ||
                    r.ReviewerStatus1 == ReviewStatus.InProgress.GetDisplayName())
                {
                    result.ReadyFor1stReviewCount++;
                    continue;
                }

                if (level > 1 &&
                   (r.ReviewerStatus2 == ReviewStatus.NotStarted.GetDisplayName() ||
                    r.ReviewerStatus2 == ReviewStatus.InProgress.GetDisplayName()))
                {
                    result.ReadyFor2ndReviewCount++;
                    continue;
                }

                if (level > 2 &&
                   (r.ReviewerStatus3 == ReviewStatus.NotStarted.GetDisplayName() ||
                    r.ReviewerStatus3 == ReviewStatus.InProgress.GetDisplayName()))
                {
                    result.ReadyForFinalReviewCount++;
                    continue;
                }

                result.CompletedCount++;
            }
            return result;
        }
    }
}
