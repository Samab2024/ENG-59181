﻿using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core
{
    public interface IReviewerProvider
    {
        Task<HeaderDTO[]> GetAttributeReviewers(DdsActionContext ax, long dealId);
        Task<HeaderDTO> GetAttributeReviewer(DdsActionContext ax, long headerMapId);
        Task UpdateAttributeReviewer(DdsActionContext ax, HeaderDTO reviewer);
        Task<ReviewerDTO[]> GetLoanReviewers(DdsActionContext ax, long dealId, long sectionId);
        Task<ReviewerDTO> GetLoanReviewer(DdsActionContext ax, long loanId, long sectionId);
        Task UpdateLoanReviewer(DdsActionContext ax, ReviewerDTO reviewer);
    }
}
