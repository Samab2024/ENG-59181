﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Core.Common;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Interface;
using PwC.DDS.Types.Interface.Reviewer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core
{
    public class ReviewerProvider : IReviewerProvider
    {
        public async Task<HeaderDTO[]> GetAttributeReviewers(DdsActionContext ax, long dealId)
        {
            var reviewers = await (from header in ax.Query<HeaderMap>()
                                   join reviewer in ax.Query<Reviewer>() on header.HeaderMapId equals reviewer.HeaderMapId
                                   where header.DealId == dealId
                                      && header.IsActive == true
                                      && header.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()
                                   orderby header.DisplayOrder
                                   select new HeaderDTO
                                   {
                                       ReviewerId = reviewer.ReviewerId,
                                       DealId = reviewer.DealId,
                                       HeaderMapId = reviewer.HeaderMapId,
                                       ClientHeader = header.ClientHeader,
                                       PwCHeader = header.PwCHeader,
                                       Reviewer1 = reviewer.Reviewer1,
                                       ReviewerStatus1 = reviewer.ReviewerStatus1,
                                       Reviewer2 = reviewer.Reviewer2,
                                       ReviewerStatus2 = reviewer.ReviewerStatus2,
                                       Reviewer3 = reviewer.Reviewer3,
                                       ReviewerStatus3 = reviewer.ReviewerStatus3
                                   }).ToArrayAsync();

            int count = 1;
            foreach(var reviewer in reviewers)
            {
                reviewer.DisplayOrder = count++;
            }

            return reviewers;
        }

        public async Task<HeaderDTO> GetAttributeReviewer(DdsActionContext ax, long headerMapId)
        {
            var data = await (from header in ax.Query<HeaderMap>()
                              join reviewer in ax.Query<Reviewer>() on header.HeaderMapId equals reviewer.HeaderMapId
                              where header.HeaderMapId == headerMapId
                                 && header.IsActive == true
                                 && header.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()
                              select new HeaderDTO
                              {
                                  ReviewerId = reviewer.ReviewerId,
                                  DealId = reviewer.DealId,
                                  HeaderMapId = reviewer.HeaderMapId,
                                  DisplayOrder = header.DisplayOrder,
                                  ClientHeader = header.ClientHeader,
                                  PwCHeader = header.PwCHeader,
                                  Reviewer1 = reviewer.Reviewer1,
                                  ReviewerStatus1 = reviewer.ReviewerStatus1,
                                  Reviewer2 = reviewer.Reviewer2,
                                  ReviewerStatus2 = reviewer.ReviewerStatus2,
                                  Reviewer3 = reviewer.Reviewer3,
                                  ReviewerStatus3 = reviewer.ReviewerStatus3
                              }).FirstOrDefaultAsync();
            return data;
        }

        public async Task UpdateAttributeReviewer(DdsActionContext ax, HeaderDTO reviewer)
        {
            var existReviewer = await ax.First<Reviewer>(d => d.ReviewerId == reviewer.ReviewerId) ?? throw new DdsInvalidOperationException("invalid reviewer id");
            existReviewer = ax.Mapper.Map(reviewer, existReviewer).UpdateBy(ax.UserId);
            ax.Update(existReviewer);
            await ax.Save();
        }

        public async Task<ReviewerDTO[]> GetLoanReviewers(DdsActionContext ax, long dealId, long sectionId)
        {
            //check if exsiting loan random reviewed
            bool isRandomReview = await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).AnyAsync(l => l.IsRandomReview);

            //check if need to show display loan number
            LoanReview[]? displayLoanNumbers = null;
            var currDeal = await ax.Query<DealSetup>().Where(l => l.DealId == dealId).FirstOrDefaultAsync();
            if (!String.IsNullOrEmpty(currDeal?.LoanNumberDisplayColumn))
            {
                var displayHeaderMapId = await ax.Query<HeaderMap>().Where(h => h.DealId == dealId && h.ClientHeader.ToLower() == currDeal.LoanNumberDisplayColumn.ToLower())
                                                                    .Select(h => h.HeaderMapId).FirstOrDefaultAsync();
                displayLoanNumbers = await ax.Query<LoanReview>().Where(h => h.DealId == dealId && h.HeaderMapId == displayHeaderMapId).ToArrayAsync();
            }

            var sections = await ax.Query<SourceDocSection>().Where(s => s.DealId == dealId && s.SectionId == sectionId)
                                                             .Select(s => s.SourceDocSectionId).ToArrayAsync();
            var reviewStatus = await (from deal in ax.Query<DealSetup>()
                                      join header in ax.Query<HeaderMap>() on deal.DealId equals header.DealId into dh
                                      from dealHeader in dh.DefaultIfEmpty()
                                      join seller in ax.Query<Seller>() on deal.DealId equals seller.DealId into ds
                                      from dealSeller in ds.DefaultIfEmpty()
                                      join loan in ax.Query<Loan>() on new { deal.DealId, dealSeller.SellerId } equals new { loan.DealId, loan.SellerId } into dl
                                      from dealLoan in dl.DefaultIfEmpty()
                                      join review in ax.Query<LoanReview>() on new { deal.DealId, dealLoan.LoanId, dealHeader.HeaderMapId } equals new { review.DealId, review.LoanId, review.HeaderMapId } into lr
                                      from review in lr.DefaultIfEmpty()
                                      where deal.DealId == dealId
                                         && !string.IsNullOrEmpty(dealHeader.ClientHeader)
                                         && (dealHeader.ProcessType == ProcessType.Review.GetDisplayName() ||
                                             dealHeader.ProcessType == ProcessType.ReviewAttribute.GetDisplayName() ||
                                             dealHeader.ProcessType == ProcessType.ReviewCalculation.GetDisplayName())
                                         && dealHeader.IsActive
                                         && dealLoan.IsActive
                                         && (!isRandomReview || dealLoan.IsRandomReview == isRandomReview)
                                         && sections.Contains(dealHeader.SourceDocSectionId)
                                      select new LoanReviewStatusDTO
                                      {
                                          LoanId = dealLoan.LoanId,
                                          HeaderMapId = dealHeader.HeaderMapId,
                                          LevelOfReview = Math.Min(deal.LevelOfReview, dealHeader.LevelOfReview),
                                          IsFirstReviewed = review.IsFirstReviewed,
                                          IsSecondReviewed = review.IsSecondReviewed,
                                          IsThirdReviewed = review.IsThirdReviewed,
                                          IsTie = review.IsTie
                                      }).ToArrayAsync();

            var reviewers = await (from loan in ax.Query<Loan>()
                                   join reviewer in ax.Query<Reviewer>() on loan.LoanId equals reviewer.LoanId
                                   where loan.DealId == dealId
                                      && loan.IsActive == true
                                      && (!isRandomReview || loan.IsRandomReview == isRandomReview)
                                      && reviewer.SectionId == sectionId
                                   orderby loan.SellerId, loan.DisplayOrder
                                   select new ReviewerDTO
                                   {
                                       ReviewerId = reviewer.ReviewerId,
                                       DealId = reviewer.DealId,
                                       LoanId = reviewer.LoanId,
                                       HeaderMapId = reviewer.HeaderMapId,
                                       SectionId = reviewer.SectionId,
                                       DisplayOrder = loan.DisplayOrder,
                                       SellerName = loan.Seller.Name,
                                       LoanNumber = ConvertExtension.GetDisplayLoanNumberByLoanID(displayLoanNumbers, loan.LoanNumber, loan.LoanId, loan.DisplayOrder.ToString()),
                                       PropertyName = loan.PropertyName,
                                       MissingDoc = loan.MissingDoc,
                                       Reviewer1 = reviewer.Reviewer1,
                                       ReviewerStatus1 = reviewer.ReviewerStatus1,
                                       Reviewer2 = reviewer.Reviewer2,
                                       ReviewerStatus2 = reviewer.ReviewerStatus2,
                                       Reviewer3 = reviewer.Reviewer3,
                                       ReviewerStatus3 = reviewer.ReviewerStatus3
                                   }).ToArrayAsync();

            foreach (var reviewer in reviewers)
            {
                var loanReviewStatus = reviewStatus.Where(r => r.LoanId == reviewer.LoanId).ToArray();
                var loanReviewStatusSum = new ReviewStatusSummaryDTO
                {
                    LoanId = reviewer.LoanId,
                    TotalFields = loanReviewStatus.Count(),
                    ReviewedFields = loanReviewStatus.Where(l => l.IsThirdReviewed == true || l.IsSecondReviewed == true || l.IsFirstReviewed == true).Count(),
                    ReviewCompleteFields = loanReviewStatus.Where(l =>
                                              (l.IsThirdReviewed == true && l.LevelOfReview == 3) ||
                                              (l.IsSecondReviewed == true && l.LevelOfReview == 2) ||
                                              (l.IsFirstReviewed == true && l.LevelOfReview == 1)).Count(),
                    ExceptionFields = loanReviewStatus.Where(l => l.IsTie == false).Count()
                };
                reviewer.LoanReviewStatus = ConvertExtension.GetLoanReviewStatus(loanReviewStatusSum);
            }
            return reviewers;
        }

        public async Task<ReviewerDTO> GetLoanReviewer(DdsActionContext ax, long loanId, long sectionId)
        {
            var data = await (from loan in ax.Query<Loan>()
                              join reviewer in ax.Query<Reviewer>() on loan.LoanId equals reviewer.LoanId
                              where loan.LoanId == loanId
                                 && reviewer.SectionId == sectionId
                              select new ReviewerDTO
                              {
                                  ReviewerId = reviewer.ReviewerId,
                                  DealId = reviewer.DealId,
                                  LoanId = reviewer.LoanId,
                                  HeaderMapId = reviewer.HeaderMapId,
                                  SectionId = reviewer.SectionId,
                                  DisplayOrder = loan.DisplayOrder,
                                  LoanNumber = loan.LoanNumber,
                                  PropertyName = loan.PropertyName,
                                  MissingDoc = loan.MissingDoc,
                                  Reviewer1 = reviewer.Reviewer1,
                                  ReviewerStatus1 = reviewer.ReviewerStatus1,
                                  Reviewer2 = reviewer.Reviewer2,
                                  ReviewerStatus2 = reviewer.ReviewerStatus2,
                                  Reviewer3 = reviewer.Reviewer3,
                                  ReviewerStatus3 = reviewer.ReviewerStatus3
                              }).FirstOrDefaultAsync();
            return data;
        }

        public async Task UpdateLoanReviewer(DdsActionContext ax, ReviewerDTO reviewer)
        {
            var existReviewer = await ax.First<Reviewer>(d => d.ReviewerId == reviewer.ReviewerId) ?? throw new DdsInvalidOperationException("invalid reviewer id");
            existReviewer = ax.Mapper.Map(reviewer, existReviewer).UpdateBy(ax.UserId);
            ax.Update(existReviewer);
            await ax.Save();
        }
    }
}
