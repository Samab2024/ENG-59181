﻿using Aspose.Cells;
using Microsoft.EntityFrameworkCore;
using PwC.DDS.Core.Aspose;
using PwC.DDS.Core.Common;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System.Drawing;

namespace PwC.DDS.Core
{
    public class ReportProvider : IReportProvider
	{
		private readonly IUserProvider _userProvider;
        private readonly ICalculatorProvider _calculatorProvider;
        public ReportProvider(IUserProvider userProvider, ICalculatorProvider calculatorProvider)
		{
			_userProvider = userProvider;
			_calculatorProvider = calculatorProvider;

        }

		public async Task<MemoryStream> DownloadExceptionReport(DdsActionContext ax, long dealId, List<long> sellerIds, int levelOfReview, ReportOrder reportOrder, bool includeCalculationException)
		{
			var templateFile = $"Templates/ExceptionReport.xlsx";
			var wb = new ImportWorkBook();
			var memoryStream = new MemoryStream();
			try
			{
                var dealSetup = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId);
                if (includeCalculationException && dealSetup.NeedRecalculation)
                {
                    await _calculatorProvider.ReCalculateAll(ax, dealId);
                }

                //initail template
                wb.OpenExcel(templateFile);
				WorkbookDesigner workbookDesigner = new WorkbookDesigner(wb.WorkBook);

				#region Exception Report
				wb.ActiveWorkSheet("Exception List");

				//check if exsiting loan random reviewed
				bool exsitingLoanRandom = await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).AnyAsync(l => l.IsRandomReview);

                //check if need to show display loan number
                var displayLoanNumbers = await GetDisplayLoanNumberList(ax, dealId, dealSetup?.LoanNumberDisplayColumn);

                var exceptionItemList = await (from deal in ax.Query<DealSetup>()
											   join header in ax.Query<HeaderMap>() on deal.DealId equals header.DealId into dh
											   from dealHeader in dh.DefaultIfEmpty()
											   join format in ax.Query<DataFormat>() on dealHeader.DataFormatId equals format.DataFormatId into ft
											   from headerFormat in ft.DefaultIfEmpty()
											   join seller in ax.Query<Seller>() on deal.DealId equals seller.DealId into ds
											   from dealSeller in ds.DefaultIfEmpty()
											   join loan in ax.Query<Loan>() on new { deal.DealId, dealSeller.SellerId } equals new { loan.DealId, loan.SellerId } into dl
											   from dealLoan in dl.DefaultIfEmpty()
											   join review in ax.Query<LoanReview>() on new { deal.DealId, dealLoan.LoanId, dealHeader.HeaderMapId } equals new { review.DealId, review.LoanId, review.HeaderMapId } into lr
											   from review in lr.DefaultIfEmpty()
											   where deal.DealId == dealId &&
													 dealHeader.IsActive &&
													 !dealHeader.IsExcludedInReport &&
													 !string.IsNullOrEmpty(dealHeader.ClientHeader) &&
													 (dealHeader.ProcessType == ProcessType.Review.GetDisplayName()
													  || dealHeader.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()
													  || dealHeader.ProcessType == ProcessType.ReviewCalculation.GetDisplayName()
													  || (includeCalculationException ? dealHeader.ProcessType == ProcessType.Calculation.GetDisplayName() : true)) &&
													 dealLoan.IsActive &&
													 dealLoan.IsRandomReview == exsitingLoanRandom &&
													 (dealHeader.ProcessType == ProcessType.Calculation.GetDisplayName() ? true : (dealHeader.LevelOfReview < levelOfReview ||
													  ((levelOfReview == 1 && (review.IsFirstReviewed || review.IsSecondReviewed || review.IsThirdReviewed))
													   || (levelOfReview == 2 && (review.IsSecondReviewed || review.IsThirdReviewed))
													   || (levelOfReview == 3 && review.IsThirdReviewed)))) &&
													 (review.IsTie == false || (deal.IsExRptIncludePwCComments && !string.IsNullOrEmpty(review.PwCComments))) &&
													 sellerIds.Contains(dealLoan.SellerId)
											   orderby dealLoan.SellerId,
													   (reportOrder == ReportOrder.ByAttribute ? dealHeader.DisplayOrder : dealLoan.DisplayOrder),
													   (reportOrder == ReportOrder.ByAttribute ? dealLoan.DisplayOrder : dealHeader.DisplayOrder)
											   select new ExceptionReportDTO
											   {
												   LoanNumber = ConvertExtension.GetDisplayLoanNumberByLoanID(displayLoanNumbers, dealLoan.LoanNumber, dealLoan.LoanId, null),
												   PropertyName = dealLoan.PropertyName,
												   ProcessType = dealHeader.ProcessType,
												   FieldName = dealHeader.ClientHeader,
												   DealLevelOfReview = dealHeader.LevelOfReview,
												   ClientValue = ConvertExtension.ToStringFromExponentialNullable(review.ClientValue),
												   OriginalCustomFormat = review.ClientValueFormat,
												   PwCValue = review.FinalValue,
												   FirstReviewValue = review.FirstReviewValue,
												   SecondReviewValue = review.SecondReviewValue,
												   ThirdReviewValue = review.ThirdReviewValue,
												   DataFormatType = headerFormat.Type,
												   CustomFormat = headerFormat.Format,
												   PwCComments = review.PwCComments,
												   IsFirstReviewed = review.IsFirstReviewed,
												   IsSecondReviewed = review.IsSecondReviewed,
												   IsThirdReviewed = review.IsThirdReviewed,
											   }).ToArrayAsync();
				//import data into excel
                int rowIndex = 2;
				//header
				wb.SetText("A" + rowIndex.ToString(), $"PwC Exception Report - {dealSetup?.DealName} ({DateTime.Now.ToString("MMMM dd, yyyy")})");

				//column title
				rowIndex++;
				wb.SetText("A" + rowIndex.ToString(), $"{dealSetup?.ClientName} Loan Number").SetAllBorder().SetTextWrapped();
				wb.SetText("C" + rowIndex.ToString(), $"{dealSetup?.ClientName} Field").SetAllBorder().SetTextWrapped();
				wb.SetText("D" + rowIndex.ToString(), $"{dealSetup?.ClientName} Value").SetAllBorder().SetTextWrapped();
				wb.SetText("F" + rowIndex.ToString(), $"{dealSetup?.ClientName}/\r\nAccountants/\r\nNeither").SetAllBorder().SetTextWrapped();
				wb.SetText("H" + rowIndex.ToString(), $"{dealSetup?.ClientName} Comments").SetAllBorder().SetTextWrapped();

				//row data
				rowIndex++;
				foreach (var exception in exceptionItemList)
				{
					wb.SetText("A" + rowIndex.ToString(), exception.LoanNumber ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("B" + rowIndex.ToString(), exception.PropertyName ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("C" + rowIndex.ToString(), exception.FieldName ?? string.Empty).SetAllBorder().SetTextWrapped();

					//client value
					var clientValueFormat = string.IsNullOrEmpty(exception.OriginalCustomFormat) ? string.Empty : exception.OriginalCustomFormat;
					wb.SetText("D" + rowIndex.ToString(), exception.ClientValue ?? string.Empty, clientValueFormat).SetAllBorder().SetTextWrapped();

					//PwC value
					if (exception.ProcessType == ProcessType.Calculation.GetDisplayName() || levelOfReview == 1 || exception.DealLevelOfReview == 1 ||
						(levelOfReview == 2 && (exception.IsSecondReviewed || exception.IsThirdReviewed)) ||
						(levelOfReview == 3 && exception.IsThirdReviewed) ||
						(levelOfReview == 3 && exception.DealLevelOfReview == 2 && (exception.IsSecondReviewed || exception.IsThirdReviewed)))
					{
						var pwcValueFormat = string.IsNullOrEmpty(exception.CustomFormat) ? string.Empty : exception.CustomFormat.Split('|')[0];
						if (exception.DataFormatType == DataFormatType.IsString.GetDisplayName())
							wb.SetTextWithoutAutoFormat("E" + rowIndex.ToString(), exception.PwCValue ?? string.Empty, pwcValueFormat).SetAllBorder().SetTextWrapped();
						else
							wb.SetText("E" + rowIndex.ToString(), exception.PwCValue ?? string.Empty, pwcValueFormat).SetAllBorder().SetTextWrapped();
					}
					else
					{
						wb.SetText("E" + rowIndex.ToString(), string.Empty).SetAllBorder().SetTextWrapped();
					}

					wb.SetText("F" + rowIndex.ToString(), exception.AccountantsNeither ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("G" + rowIndex.ToString(), exception.NeitherValue ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("H" + rowIndex.ToString(), exception.Comments ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("I" + rowIndex.ToString(), exception.PwCComments ?? string.Empty).SetAllBorder().SetTextWrapped();

					rowIndex++;
				}
				#endregion

				#region Missing Docs List
				wb.ActiveWorkSheet("Missing Docs List");

				//load data
				var loanMissingDocList = await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive && l.IsRandomReview == exsitingLoanRandom && !string.IsNullOrEmpty(l.MissingDoc)).ToArrayAsync();

				//import missing doc data into excel
				rowIndex = 1;
				//header
				wb.SetText("A" + rowIndex.ToString(), $"PwC Missing Docs List - {dealSetup?.DealName} ({DateTime.Now.ToString("MMMM dd, yyyy")})");
				//column title
				rowIndex++;
				wb.SetText("A" + rowIndex.ToString(), $"{dealSetup?.ClientName} Loan Number").SetAllBorder().SetTextWrapped();
				rowIndex++;
				foreach (var loan in loanMissingDocList)
				{
					wb.SetText("A" + rowIndex.ToString(), loan.LoanNumber ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("B" + rowIndex.ToString(), loan.PropertyName ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("C" + rowIndex.ToString(), loan.MissingDoc ?? string.Empty).SetAllBorder().SetTextWrapped();
					rowIndex++;
				}
				#endregion

				//save into memory stream
				workbookDesigner.Workbook.Save(memoryStream, SaveFormat.Xlsx);
				memoryStream.Position = 0;
			}
			catch (Exception ex)
			{
				throw new DdsInvalidOperationException("Error when downloading exception report. " + ex.Message);
			}
			finally
			{
				wb.CloseExcel();
			}
			return memoryStream;
		}

        public async Task<MemoryStream> DownloadMasterTapeReport(DdsActionContext ax, long dealId, List<long> sellerIds, int levelOfReview, ReportOrder reportOrder)
        {
			var templateFile = $"Templates/MasterTapeReport.xlsx";
			var wb = new ImportWorkBook();
			var memoryStream = new MemoryStream();
			try
			{
				//initail template
				wb.OpenExcel(templateFile);
				WorkbookDesigner workbookDesigner = new WorkbookDesigner(wb.WorkBook);
				wb.ActiveWorkSheet("Master Tape List");

				//load data
				var dealSetup = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId);

                //check if exsiting loan random reviewed
                bool exsitingLoanRandom = ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).Any(l => l.IsRandomReview);

                //check if need to show display loan number
                var displayLoanNumbers = await GetDisplayLoanNumberList(ax, dealId, dealSetup.LoanNumberDisplayColumn);

                var masterTapeItemList = await (from deal in ax.Query<DealSetup>()
												join header in ax.Query<HeaderMap>() on deal.DealId equals header.DealId into dh
												from dealHeader in dh.DefaultIfEmpty()
												join format in ax.Query<DataFormat>() on dealHeader.DataFormatId equals format.DataFormatId into ft
												from headerFormat in ft.DefaultIfEmpty()
                                                join seller in ax.Query<Seller>() on deal.DealId equals seller.DealId into ds
                                                from dealSeller in ds.DefaultIfEmpty()
                                                join loan in ax.Query<Loan>() on new { deal.DealId, dealSeller.SellerId } equals new { loan.DealId, loan.SellerId } into dl
                                                from dealLoan in dl.DefaultIfEmpty()
												join review in ax.Query<LoanReview>() on new { deal.DealId, dealLoan.LoanId, dealHeader.HeaderMapId } equals new { review.DealId, review.LoanId, review.HeaderMapId } into lr
												from review in lr.DefaultIfEmpty()                                                
                                                where deal.DealId == dealId &&
													  dealHeader.IsActive &&
													  (dealHeader.ProcessType == ProcessType.Review.GetDisplayName()
													  || dealHeader.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()
													  || dealHeader.ProcessType == ProcessType.ReviewCalculation.GetDisplayName()) &&
													  dealLoan.IsActive &&
													  dealLoan.IsRandomReview == exsitingLoanRandom &&
													  dealHeader.LevelOfReview >= levelOfReview &&
													  ((levelOfReview == 1 && (review.IsFirstReviewed || review.IsSecondReviewed|| review.IsThirdReviewed))
													  || (levelOfReview == 2 && (review.IsSecondReviewed || review.IsThirdReviewed))
													  || (levelOfReview == 3 && review.IsThirdReviewed)) &&
                                                      sellerIds.Contains(dealLoan.SellerId)
                                                orderby dealLoan.SellerId,
														(reportOrder == ReportOrder.ByAttribute ? dealHeader.DisplayOrder : dealLoan.DisplayOrder),
                                                        (reportOrder == ReportOrder.ByAttribute ? dealLoan.DisplayOrder : dealHeader.DisplayOrder)
                                                select new MasterTapeReportDTO
												{
                                                    FreddieMacLoanNumber = ConvertExtension.GetDisplayLoanNumberByLoanID(displayLoanNumbers, dealLoan.LoanNumber, dealLoan.LoanId, null),
                                                    PropertyName = dealLoan.PropertyName,
													FieldName = dealHeader.ClientHeader ?? dealHeader.PwCHeader,
													ClientValue = ConvertExtension.ToStringFromExponentialNullable(review.ClientValue),
													OriginalCustomFormat = review.ClientValueFormat,
													PwCValue = review.FinalValue,
													PwCComments = review.PwCComments,
													InternalComments = review.InternalComments,
													LastUpdatedTime = review.FinalValueUpdatedTime,
													LastUpdatedBy = review.FinalValueUpdatedBy,
													DataFormatType = headerFormat.Type,
													CustomFormat = headerFormat.Format
												}).ToArrayAsync();
				//import data into excel
				int rowIndex = 2;
				//header
				wb.SetText("A" + rowIndex.ToString(), $"PwC Master Tape Report - {dealSetup?.DealName} ({DateTime.Now.ToString("MMMM dd, yyyy")})");

				//column title
				rowIndex++;
				wb.SetText("A" + rowIndex.ToString(), $"{dealSetup?.ClientName} Loan Number").SetAllBorder().SetTextWrapped();
				wb.SetText("C" + rowIndex.ToString(), $"{dealSetup?.ClientName} Field").SetAllBorder().SetTextWrapped();
				wb.SetText("D" + rowIndex.ToString(), $"{dealSetup?.ClientName} Value").SetAllBorder().SetTextWrapped();

				//row data
				rowIndex++;
				foreach (var master in masterTapeItemList)
				{
					wb.SetText("A" + rowIndex.ToString(), master.FreddieMacLoanNumber ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("B" + rowIndex.ToString(), master.PropertyName ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("C" + rowIndex.ToString(), master.FieldName ?? string.Empty).SetAllBorder().SetTextWrapped();

                    //client value
                    var clientValueFormat = string.IsNullOrEmpty(master.OriginalCustomFormat) ? string.Empty : master.OriginalCustomFormat;
                    wb.SetText("D" + rowIndex.ToString(), master.ClientValue ?? string.Empty, clientValueFormat).SetAllBorder().SetTextWrapped();

                    //PwC value
                    var pwcValueFormat = string.IsNullOrEmpty(master.CustomFormat) ? string.Empty : master.CustomFormat.Split('|')[0];
                    if (master.DataFormatType == DataFormatType.IsString.GetDisplayName())
                        wb.SetTextWithoutAutoFormat("E" + rowIndex.ToString(), master.PwCValue ?? string.Empty, pwcValueFormat).SetAllBorder().SetTextWrapped();
                    else
                        wb.SetText("E" + rowIndex.ToString(), master.PwCValue ?? string.Empty, pwcValueFormat).SetAllBorder().SetTextWrapped();

                    wb.SetText("F" + rowIndex.ToString(), master.PwCComments ?? string.Empty).SetAllBorder().SetTextWrapped();
                    wb.SetText("G" + rowIndex.ToString(), master.InternalComments ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("H" + rowIndex.ToString(), master.LastUpdatedTime.ToString() ?? string.Empty, "MM/dd/yyyy HH:mm:ss").SetAllBorder().SetTextWrapped();
					wb.SetText("I" + rowIndex.ToString(), master.LastUpdatedBy ?? string.Empty).SetAllBorder().SetTextWrapped();

					rowIndex++;
				}
				//save into memory stream
				workbookDesigner.Workbook.Save(memoryStream, SaveFormat.Xlsx);
				memoryStream.Position = 0;
			}
			catch (Exception ex)
			{
				throw new DdsInvalidOperationException("Error when downloading master tape report. " + ex.Message);
			}
			finally
			{
				wb.CloseExcel();
			}
			return memoryStream;
		}

        public async Task<MemoryStream> DownloadPwCTapeReport(DdsActionContext ax, long dealId, List<long> sellerIds, int levelOfReview, bool includePwcHeaderFields, bool includePwcComments)
        {
            var templateFile = $"Templates/PwCTapeReport.xlsx";
            var wb = new ImportWorkBook();
            var memoryStream = new MemoryStream();
            try
            {
                var dealSetup = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId);
				if (dealSetup.NeedRecalculation)
				{
                    await _calculatorProvider.ReCalculateAll(ax, dealId);
                }

                //initail template
                wb.OpenExcel(templateFile);
                WorkbookDesigner workbookDesigner = new WorkbookDesigner(wb.WorkBook);
                wb.ActiveWorkSheet("Loan List");

                //load data                
				var headerMapList = await ax.Query<HeaderMap>().Where(h => h.DealId == dealId && h.IsActive == true 
						&& (includePwcHeaderFields || (!includePwcHeaderFields && (!string.IsNullOrEmpty(h.ClientHeader)))))
					.OrderBy(d => d.ReportOrder > 0 ? d.ReportOrder : int.MaxValue)
					.ThenBy(d => d.DisplayOrder).ToArrayAsync();
                var loanList = await ax.Query<Loan>().Where(d => d.DealId == dealId && d.IsActive == true).OrderBy(d => d.DisplayOrder).ToArrayAsync();
				var loanReviewList = await (from deal in ax.Query<DealSetup>()
											join header in ax.Query<HeaderMap>() on deal.DealId equals header.DealId into dh
											from dealHeader in dh.DefaultIfEmpty()
											join format in ax.Query<DataFormat>() on dealHeader.DataFormatId equals format.DataFormatId into ft
											from headerFormat in ft.DefaultIfEmpty()
                                            join seller in ax.Query<Seller>() on deal.DealId equals seller.DealId into ds
                                            from dealSeller in ds.DefaultIfEmpty()
                                            join loan in ax.Query<Loan>() on new { deal.DealId, dealSeller.SellerId } equals new { loan.DealId, loan.SellerId } into dl
                                            from dealLoan in dl.DefaultIfEmpty()
											join review in ax.Query<LoanReview>() on new { deal.DealId, dealLoan.LoanId, dealHeader.HeaderMapId } equals new { review.DealId, review.LoanId, review.HeaderMapId } into lr
											from review in lr.DefaultIfEmpty()                                           
                                            where deal.DealId == dealId &&
												  dealHeader.IsActive &&
												  dealLoan.IsActive &&
                                                  sellerIds.Contains(dealLoan.SellerId)
                                            orderby dealHeader.ReportOrder ascending, dealLoan.DisplayOrder ascending
											select new PwCTapeReportDTO
											{
												LoanId = dealLoan.LoanId,
												HeaderMapId = dealHeader.HeaderMapId,
												HeaderMapName = dealHeader.ClientHeader,
												ProcessType = dealHeader.ProcessType,
												LevelOfReview = dealHeader.LevelOfReview,
												ClientValue = ConvertExtension.ToStringFromExponentialNullable(review.ClientValue),                                                
                                                OriginalCustomFormat = review.ClientValueFormat,
												FirstReviewValue = review.FirstReviewValue,
												SecondReviewValue = review.SecondReviewValue,
												ThirdReviewValue = review.ThirdReviewValue,
												PwCValue = review.FinalValue,
												PwCComments = review.PwCComments,
												DataFormatType = headerFormat.Type,
												CustomFormat = headerFormat.Format,
												IsFirstReviewed = review.IsFirstReviewed,
												IsSecondReviewed = review.IsSecondReviewed,
												IsThirdReviewed = review.IsThirdReviewed,
											}).ToArrayAsync();

                //import data into excel
                int rowIndex = 2;
                //header
                wb.SetText("A" + rowIndex.ToString(), $"PwC Tape Report - {dealSetup?.DealName} ({DateTime.Now.ToString("MMMM dd, yyyy")})");
                rowIndex++;
                List<int> columns = new List<int>();
                //columns
                int colIndex = 1;				
                foreach (var header in headerMapList)
				{
					var colName = ConvertExtension.GetColNameFromIndex(colIndex);
					if (header.ProcessType == ProcessType.Calculation.GetDisplayName())
                        wb.SetText($"{colName}{rowIndex}", header.ClientHeader ?? header.PwCHeader ?? string.Empty).SetBold().SetAllBorder().SetFontColor(Color.Black).SetBackGroundColor(Color.Yellow);
					else
						wb.SetText($"{colName}{rowIndex}", header.ClientHeader ?? header.PwCHeader ?? string.Empty).SetBold().SetAllBorder().SetFontColor(Color.White).SetBackGroundColor(Color.FromArgb(0, 32, 96)); //blue background

                    //fill data
                    var colReviewData = loanReviewList.Where(l => l.HeaderMapId == header.HeaderMapId).ToList();
                    var needTextWrap = includePwcComments ? true : false;
                    rowIndex++;
					foreach (var review in colReviewData)
					{
						var cellValue = string.Empty;
						var format = string.Empty;
						Color color = Color.White;
						bool isPwCValue = false;

						if ((levelOfReview == 1 && review.IsThirdReviewed) ||
							(levelOfReview == 2 && review.IsThirdReviewed) ||
							(levelOfReview == 3 && review.IsThirdReviewed))
						{
							color = Color.FromArgb(140, 228, 60); //#8CE43C
						}
						else if ((levelOfReview == 1 && review.IsSecondReviewed) ||
							(levelOfReview == 2 && review.IsSecondReviewed))
						{
							color = Color.FromArgb(204, 255, 204); //#CCFFCC
						}
						else if (levelOfReview == 1 && review.IsFirstReviewed)
						{
							color = Color.FromArgb(255, 204, 102); //#FFCC66
						}

						if (levelOfReview == 1 && (review.IsFirstReviewed || review.IsSecondReviewed || review.IsThirdReviewed)
							|| levelOfReview == 2 && (review.IsSecondReviewed || review.IsThirdReviewed)
							|| levelOfReview == 3 && review.IsThirdReviewed
							|| string.IsNullOrEmpty(header.ClientHeader))
						{
							//PwC value
							isPwCValue = true;
							cellValue = review.PwCValue;
							format = string.IsNullOrEmpty(review.CustomFormat) ? string.Empty : review.CustomFormat.Split('|')[0];
						}
						else
						{
							//use client value without review value
							cellValue = review.ClientValue;
							format = string.IsNullOrEmpty(review.OriginalCustomFormat) ? string.Empty : review.OriginalCustomFormat;
						}

						if (review.HeaderMapName != null && review.HeaderMapName.Contains("Loan Number"))
						{
							color = Color.White;
							cellValue = loanList.FirstOrDefault(l => l.LoanId == review.LoanId)?.LoanNumber ?? string.Empty;
						}
						else if (review.HeaderMapName != null && review.HeaderMapName.Contains("Property Name"))
						{
							color = Color.White;
							cellValue = loanList.FirstOrDefault(l => l.LoanId == review.LoanId)?.PropertyName ?? string.Empty;
						}

						if (review.ProcessType == ProcessType.Review.GetDisplayName() ||
							review.ProcessType == ProcessType.ReviewAttribute.GetDisplayName() ||
							review.ProcessType == ProcessType.ReviewCalculation.GetDisplayName())
						{
							if (includePwcComments && !string.IsNullOrEmpty(review.PwCComments))
								wb.SetTextWithoutAutoFormat($"{colName}{rowIndex}", (cellValue ?? string.Empty) + " -- " + review.PwCComments, format).SetAllBorder().SetBackGroundColor(color).SetFontColor(Color.Red).SetTextWrapped(needTextWrap);
							else if (isPwCValue && review.DataFormatType == DataFormatType.IsString.GetDisplayName())
								wb.SetTextWithoutAutoFormat($"{colName}{rowIndex}", cellValue ?? string.Empty, format).SetAllBorder().SetBackGroundColor(color).SetTextWrapped(needTextWrap);
							else
								wb.SetText($"{colName}{rowIndex}", cellValue ?? string.Empty, format).SetAllBorder().SetBackGroundColor(color).SetTextWrapped(needTextWrap);
						}
						else if (review.ProcessType == ProcessType.Provided.GetDisplayName() ||
								 review.ProcessType == ProcessType.PassThrough.GetDisplayName())
						{
							var clientValueFormat = string.IsNullOrEmpty(review.OriginalCustomFormat) ? string.Empty : review.OriginalCustomFormat;
							wb.SetText($"{colName}{rowIndex}", review.ClientValue ?? string.Empty, clientValueFormat).SetAllBorder().SetTextWrapped(needTextWrap);
						}
						else if (review.ProcessType == ProcessType.Calculation.GetDisplayName())
						{
							wb.SetText($"{colName}{rowIndex}", review.PwCValue ?? string.Empty, format).SetAllBorder();
						}

						rowIndex++;
					}

					columns.Add(colIndex);
					colIndex++;
					//reset data row
					rowIndex = 3;
				}
                //auto fit row and columns
                wb.SetAutoFit(columns);
                //save into memory stream
                workbookDesigner.Workbook.Save(memoryStream, SaveFormat.Xlsx);
                memoryStream.Position = 0;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when downloading PwC tape report. " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return memoryStream;
        }

        public async Task<MemoryStream> DownloadFeedbackReport(DdsActionContext ax, long dealId, List<long> sellerIds, ReportOrder reportOrder)
        {
            var templateFile = $"Templates/FeedbackReport.xlsx";
            var wb = new ImportWorkBook();
            var memoryStream = new MemoryStream();
            try
            {
                //initail template
                wb.OpenExcel(templateFile);
                WorkbookDesigner workbookDesigner = new WorkbookDesigner(wb.WorkBook);
                var sheet = wb.ActiveWorkSheet("Feedback");

                //load data
                var dealSetup = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId);
                var keyColumns = ConvertExtension.GetKeyColumns(dealSetup.KeyColumn);

				//check if exsiting loan random reviewed
				bool exsitingLoanRandom = ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).Any(l => l.IsRandomReview);

                //check if need to show display loan number
                var displayLoanNumbers = await GetDisplayLoanNumberList(ax, dealId, dealSetup.LoanNumberDisplayColumn);

                var itemList = await (from deal in ax.Query<DealSetup>()
									  join header in ax.Query<HeaderMap>() on deal.DealId equals header.DealId into dh
									  from dealHeader in dh.DefaultIfEmpty()
									  join format in ax.Query<DataFormat>() on dealHeader.DataFormatId equals format.DataFormatId into ft
									  from headerFormat in ft.DefaultIfEmpty()
									  join sourceDocSection in ax.Query<SourceDocSection>() on dealHeader.SourceDocSectionId equals sourceDocSection.SourceDocSectionId into sd
									  from headerSourceDoc in sd.DefaultIfEmpty()
                                      join seller in ax.Query<Seller>() on deal.DealId equals seller.DealId into ds
                                      from dealSeller in ds.DefaultIfEmpty()
                                      join loan in ax.Query<Loan>() on new { deal.DealId, dealSeller.SellerId } equals new { loan.DealId, loan.SellerId } into dl
                                      from dealLoan in dl.DefaultIfEmpty()
									  join review in ax.Query<LoanReview>() on new { deal.DealId, dealLoan.LoanId, dealHeader.HeaderMapId } equals new { review.DealId, review.LoanId, review.HeaderMapId } into lr
									  from review in lr.DefaultIfEmpty()
                                      where deal.DealId == dealId &&
											dealHeader.IsActive &&
											(dealHeader.ProcessType == ProcessType.Review.GetDisplayName()
											|| dealHeader.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()
											|| dealHeader.ProcessType == ProcessType.ReviewCalculation.GetDisplayName()) &&
											dealLoan.IsActive &&
											dealLoan.IsRandomReview == exsitingLoanRandom &&
                                            sellerIds.Contains(dealLoan.SellerId)
                                      orderby dealLoan.SellerId,
                                              (reportOrder == ReportOrder.ByAttribute ? dealHeader.DisplayOrder : dealLoan.DisplayOrder),
                                              (reportOrder == ReportOrder.ByAttribute ? dealLoan.DisplayOrder : dealHeader.DisplayOrder)
                                      select new FeedbackReportDTO
									  {
                                          LoanNumber = ConvertExtension.GetDisplayLoanNumberByLoanID(displayLoanNumbers, dealLoan.LoanNumber, dealLoan.LoanId, null),
                                          PropertyName = dealLoan.PropertyName,
										  FieldName = dealHeader.ClientHeader ?? dealHeader.PwCHeader,
										  SourceDocSection = headerSourceDoc.Name,
										  Reviewer1 = review.FirstReviewUpdatedBy,
										  Reviewer2 = review.SecondReviewUpdatedBy,
										  Reviewer3 = review.ThirdReviewUpdatedBy,
										  ReviewValue1 = review.FirstReviewValue,
										  ReviewValue2 = review.SecondReviewValue,
										  ReviewValue3 = review.ThirdReviewValue,
										  PwCComments = review.PwCComments,
										  LevelOfReview = dealHeader.LevelOfReview,
										  DataFormatType = headerFormat.Type,
										  CustomFormat = headerFormat.Format
									  }).ToArrayAsync();
                //import data into excel
                int rowIndex = 2;
                //header
                wb.SetText("A" + rowIndex.ToString(), $"PwC Feedback Report - {dealSetup?.DealName} ({DateTime.Now.ToString("MMMM dd, yyyy")})");

                //column title
                rowIndex++;
                wb.SetText("A" + rowIndex.ToString(), $"{keyColumns[0]}").SetAllBorder().SetTextWrapped();
                wb.SetText("B" + rowIndex.ToString(), $"{keyColumns[1]}").SetAllBorder().SetTextWrapped();

                //row data
                rowIndex++;
				foreach (var item in itemList)
				{
					if (ConvertExtension.ToComparePwCValues(item.ReviewValue1, item.ReviewValue2, item.ReviewValue3, item.LevelOfReview, item.DataFormatType, item.CustomFormat))
						continue;

					wb.SetText("A" + rowIndex.ToString(), item.LoanNumber ?? string.Empty).SetAllBorder();
					wb.SetText("B" + rowIndex.ToString(), item.PropertyName ?? string.Empty).SetAllBorder();
					wb.SetText("C" + rowIndex.ToString(), item.FieldName ?? string.Empty).SetAllBorder();
					wb.SetText("D" + rowIndex.ToString(), item.SourceDocSection ?? string.Empty).SetAllBorder();
					wb.SetText("E" + rowIndex.ToString(), item.Reviewer1 ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("F" + rowIndex.ToString(), item.Reviewer2 ?? string.Empty).SetAllBorder().SetTextWrapped();
					wb.SetText("G" + rowIndex.ToString(), item.Reviewer3 ?? string.Empty).SetAllBorder().SetTextWrapped();

					var pwcValueFormat = string.IsNullOrEmpty(item.CustomFormat) ? string.Empty : item.CustomFormat.Split('|')[0];
                    var reviewValue2 = item.LevelOfReview > 1 ? item.ReviewValue2 ?? string.Empty : string.Empty;
                    var reviewValue3 = item.LevelOfReview > 2 ? item.ReviewValue3 ?? string.Empty : string.Empty;
                    if (item.DataFormatType == DataFormatType.IsString.GetDisplayName())
					{
						wb.SetTextWithoutAutoFormat("H" + rowIndex.ToString(), item.ReviewValue1 ?? string.Empty, pwcValueFormat).SetAllBorder().SetTextWrapped();                    
                        wb.SetTextWithoutAutoFormat("I" + rowIndex.ToString(), reviewValue2, pwcValueFormat).SetAllBorder().SetTextWrapped();
                        wb.SetTextWithoutAutoFormat("J" + rowIndex.ToString(), reviewValue3, pwcValueFormat).SetAllBorder().SetTextWrapped();
					}
					else
					{
						wb.SetText("H" + rowIndex.ToString(), item.ReviewValue1 ?? string.Empty, pwcValueFormat).SetAllBorder().SetTextWrapped();
						wb.SetText("I" + rowIndex.ToString(), reviewValue2, pwcValueFormat).SetAllBorder().SetTextWrapped();
						wb.SetText("J" + rowIndex.ToString(), reviewValue3, pwcValueFormat).SetAllBorder().SetTextWrapped();
					}
					wb.SetText("K" + rowIndex.ToString(), item.PwCComments ?? string.Empty).SetAllBorder();

					rowIndex++;
				}

                if (dealSetup.LevelOfReview < 3)
                {
                    sheet.Cells.DeleteColumn(6, true);  //ReviewStatus3
                    sheet.Cells.DeleteColumn(8, true);
					if (dealSetup.LevelOfReview < 2)
					{
						sheet.Cells.DeleteColumn(5, true);  //ReviewStatus2
                        sheet.Cells.DeleteColumn(7, true);
                    }
                }

                //save into memory stream
                workbookDesigner.Workbook.Save(memoryStream, SaveFormat.Xlsx);
                memoryStream.Position = 0;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when downloading feedback report. " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return memoryStream;
        }

		public async Task<MemoryStream> DownloadLoanStatusReport(DdsActionContext ax, long dealId, List<long> sellerIds, ReportOrder reportOrder)
		{
			var templateFile = $"Templates/LoanStatusReport.xlsx";
			var wb = new ImportWorkBook();
			var memoryStream = new MemoryStream();
			try
			{
				//initail template
				wb.OpenExcel(templateFile);
				WorkbookDesigner workbookDesigner = new WorkbookDesigner(wb.WorkBook);
				var sheet = wb.ActiveWorkSheet("Status List");

				//load data
				var dealSetup = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId);
				var keyColumns = ConvertExtension.GetKeyColumns(dealSetup.KeyColumn);
				
				//check if exsiting loan random reviewed
				bool exsitingLoanRandom = ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).Any(l => l.IsRandomReview);

                //check if need to show display loan number
                var displayLoanNumbers = await GetDisplayLoanNumberList(ax, dealId, dealSetup.LoanNumberDisplayColumn);

                var itemList = await (from deal in ax.Query<DealSetup>()
                                      join header in ax.Query<HeaderMap>() on deal.DealId equals header.DealId into dh
                                      from dealHeader in dh.DefaultIfEmpty()
                                      join seller in ax.Query<Seller>() on deal.DealId equals seller.DealId into ds
                                      from dealSeller in ds.DefaultIfEmpty()
                                      join loan in ax.Query<Loan>() on new { deal.DealId, dealSeller.SellerId } equals new { loan.DealId, loan.SellerId } into dl
                                      from dealLoan in dl.DefaultIfEmpty()
                                      join review in ax.Query<LoanReview>() on new { deal.DealId, dealLoan.LoanId, dealHeader.HeaderMapId } equals new { review.DealId, review.LoanId, review.HeaderMapId } into lr
                                      from review in lr.DefaultIfEmpty()
                                      where deal.DealId == dealId &&
                                            dealHeader.IsActive &&
                                            !string.IsNullOrEmpty(dealHeader.ClientHeader) &&
                                            (dealHeader.ProcessType == ProcessType.Review.GetDisplayName()
                                            || dealHeader.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()
                                            || dealHeader.ProcessType == ProcessType.ReviewCalculation.GetDisplayName()) &&
                                            dealLoan.IsActive &&
                                            dealLoan.IsRandomReview == exsitingLoanRandom &&
                                            sellerIds.Contains(dealLoan.SellerId)
                                      orderby dealLoan.SellerId,
                                              (reportOrder == ReportOrder.ByAttribute ? dealHeader.DisplayOrder : dealLoan.DisplayOrder),
                                              (reportOrder == ReportOrder.ByAttribute ? dealLoan.DisplayOrder : dealHeader.DisplayOrder)
                                      group review by review.LoanId into g
                                      select new LoanStatusReportDTO
                                      {
                                          LoanNumber = ConvertExtension.GetDisplayLoanNumberByLoanID(displayLoanNumbers, g.Select(l => l.Loan.LoanNumber).FirstOrDefault(), g.Select(l => l.Loan.LoanId).FirstOrDefault(), null),
                                          PropertyName = g.Select(l => l.Loan.PropertyName).FirstOrDefault(),
                                          TotalFields = g.Count(),
                                          ReviewStatus1 = g.Where(l => l.IsFirstReviewed).Count(),
                                          ReviewStatus2 = g.Where(l => l.IsSecondReviewed).Count(),
                                          ReviewStatus3 = g.Where(l => l.IsThirdReviewed).Count(),
                                          ExceptionStatus = g.Where(l => l.IsTie == false).Count()
                                      }).ToArrayAsync();
                //import data into excel
                int rowIndex = 2;
				//header
				wb.SetText("A" + rowIndex.ToString(), $"PwC Loan Status Report - {dealSetup?.DealName} ({DateTime.Now.ToString("MMMM dd, yyyy")})");

				//column title
				rowIndex++;
				wb.SetText("A" + rowIndex.ToString(), $"{keyColumns[0]}").SetAllBorder().SetTextWrapped();
				wb.SetText("B" + rowIndex.ToString(), $"{keyColumns[1]}").SetAllBorder().SetTextWrapped();

				//row data
				rowIndex++;
				foreach (var loan in itemList)
				{
					wb.SetText("A" + rowIndex.ToString(), loan.LoanNumber ?? string.Empty).SetAllBorder();
					wb.SetText("B" + rowIndex.ToString(), loan.PropertyName ?? string.Empty).SetAllBorder();
					wb.SetText("C" + rowIndex.ToString(), loan.TotalFields ?? 0).SetAllBorder();
					wb.SetText("D" + rowIndex.ToString(), loan.ReviewStatus1 ?? 0).SetAllBorder();
					wb.SetText("E" + rowIndex.ToString(), loan.ReviewStatus2 ?? 0).SetAllBorder();
					wb.SetText("F" + rowIndex.ToString(), loan.ReviewStatus3 ?? 0).SetAllBorder();
					wb.SetText("G" + rowIndex.ToString(), loan.ExceptionStatus ?? 0).SetAllBorder();
					rowIndex++;
				}

				if (dealSetup.LevelOfReview < 3)
				{
					sheet.Cells.DeleteColumn(5, true);  //ReviewStatus3 
					if (dealSetup.LevelOfReview < 2)
						sheet.Cells.DeleteColumn(4, true);  //ReviewStatus2
				}

				//save into memory stream
				workbookDesigner.Workbook.Save(memoryStream, SaveFormat.Xlsx);
				memoryStream.Position = 0;
			}
			catch (Exception ex)
			{
				throw new DdsInvalidOperationException("Error when downloading loan status report. " + ex.Message);
			}
			finally
			{
				wb.CloseExcel();
			}
			return memoryStream;
		}

		private async Task<LoanReview[]?> GetDisplayLoanNumberList(DdsActionContext ax, long dealId, string? LoanNumberDisplayColumn)
		{
			LoanReview[]? displayLoanNumbers = null;
			if (!String.IsNullOrEmpty(LoanNumberDisplayColumn))
			{
				var displayHeaderMapId = await ax.Query<HeaderMap>().Where(h => h.DealId == dealId && h.ClientHeader.ToLower() == LoanNumberDisplayColumn.ToLower())
																	.Select(h => h.HeaderMapId).FirstOrDefaultAsync();
				displayLoanNumbers = await ax.Query<LoanReview>().Where(h => h.DealId == dealId && h.HeaderMapId == displayHeaderMapId).ToArrayAsync();
			}

			return displayLoanNumbers;
		}
    }
}
