﻿using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core
{
	public interface IReportProvider
	{
        Task<MemoryStream> DownloadMasterTapeReport(DdsActionContext ax, long dealId, List<long> sellerIds, int levelOfReview, ReportOrder reportOrder);
        Task<MemoryStream> DownloadExceptionReport(DdsActionContext ax, long dealId, List<long> sellerIds, int levelOfReview, ReportOrder reportOrder, bool includeCalculationException);
        Task<MemoryStream> DownloadPwCTapeReport(DdsActionContext ax, long dealId, List<long> sellerIds, int levelOfReview, bool includePwcHeaderFields, bool includePwcComments);
        Task<MemoryStream> DownloadFeedbackReport(DdsActionContext ax, long dealId, List<long> sellerIds, ReportOrder reportOrder);
        Task<MemoryStream> DownloadLoanStatusReport(DdsActionContext ax, long dealId, List<long> sellerIds, ReportOrder reportOrder);
    }
}
