﻿using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core
{
    public interface ICalculatorProvider
    {
        Task<CalculationResult> TestFormula(DdsActionContext ax, long dealId, long headerMapId, string script, bool isCalculateAllReferenceFormulas);

        Task<CalculatorFieldDTO[]> SaveFormulaAndCaculatedResult(DdsActionContext ax, CalculatorInfoDTO calculatorInfo);

        Task<CalculatorFieldDTO[]> ReCalculateAll(DdsActionContext ax, long dealId);

        Task<CalculatorGlobalFieldDTO[]> GetCalculatorGlobalField(DdsActionContext ax, long dealId);

        Task UpdateCalculatorGlobalField(DdsActionContext ax, long dealId, CalculatorGlobalFieldDTO[] fields);

        void UpdateFormulaWithNewCalculatorHeader(DdsActionContext ax, HeaderMap[] allCalculatedHeaderMaps, string oldHeader, string newHeader, string globalPattern, string globalReplacement, string loanPattern, string loanReplacement);
    }
}
