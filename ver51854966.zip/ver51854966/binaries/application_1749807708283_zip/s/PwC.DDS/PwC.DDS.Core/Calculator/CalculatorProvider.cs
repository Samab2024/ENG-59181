﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.PythonEngine;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using PwC.DDS.Infrastructure;
using PwC.DDS.Core.Common;
using System.Text.RegularExpressions;
using PwC.DDS.Types.Database.Extensions;
using IronPython.Runtime;
using static IronPython.Modules.PythonRegex;

namespace PwC.DDS.Core
{
    public class CalculatorProvider : ICalculatorProvider
    {
        protected PyEngine _engine;
        protected PyEngine PyEngine => _engine ?? (_engine = new PyEngine());

        public async Task<CalculationResult> TestFormula(DdsActionContext ax, long dealId, long headerMapId, string script, bool isCalculateAllReferenceFormulas)
        {
            try
            {
                var deal = await ax.First<DealSetup>(d => d.DealId == dealId);
                var dealLevelFields = await ax.Query<CalculatorGlobalField>().Where(f => f.DealId == dealId).ToArrayAsync();
                var allLoanReviews = await ax.Query<LoanReview>().Where(l => l.DealId == dealId).ToArrayAsync();
                var allHeaderMaps = await ax.Query<HeaderMap>().Where(hm => hm.DealId == dealId && hm.IsActive == true).ToArrayAsync();
                var dataFormats = await ax.Query<DataFormat>().ToArrayAsync();
                var loans = await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true)
                                                  .Select(l => new LoanCalculatorDto { LoanId = l.LoanId, LoanNumber = l.LoanNumber, ParentId = l.ParentId }).ToArrayAsync();

                var headerMapWithCalcFields = allHeaderMaps.Where(hm => !string.IsNullOrEmpty(hm.CalculatorHeader)).ToArray();
                List<CalculatorFieldDTO> dealLevelConfig = new();
                foreach (var field in dealLevelFields)
                {
                    var format = dataFormats.FirstOrDefault(d => d.DataFormatId == field.DataFormatId);
                    dealLevelConfig.Add(new CalculatorFieldDTO
                    {
                        DealId = dealId,
                        Field = field.FieldName,
                        Value = field.FieldValue,
                        DataFormatType = format?.Type,
                        DataFormat = format?.Format,
                        IsDealLevel = true
                    });
                }

                if (headerMapWithCalcFields.Length == 0)
                {
                    throw new DdsInvalidOperationException("No any valid calculator header.");
                }
                var loanIds = loans.Select(l => l.LoanId).ToArray();
                var headerMapIds = headerMapWithCalcFields.Select(hm => hm.HeaderMapId).ToArray();
                var loanReviews = allLoanReviews.Where(lr => headerMapIds.Contains(lr.HeaderMapId) && loanIds.Contains(lr.LoanId)).ToArray();

                if (isCalculateAllReferenceFormulas)
                {
                    List<HeaderMap> refHeaderList = new();
                    refHeaderList = GetRefHeadersWithOrder(allHeaderMaps, headerMapId, script);

                    var reCalcHeaders = refHeaderList.Where(h => h.ProcessType == ProcessType.Calculation.GetDisplayName() && !string.IsNullOrEmpty(h.CalculatorFormula)).ToList();
                    foreach (HeaderMap refField in reCalcHeaders)
                    {
                        var result = ExceteFormulaWithPython(ax, dealId, refField.HeaderMapId, refField.CalculatorFormula, deal, dealLevelConfig, loans, allHeaderMaps, loanReviews, headerMapWithCalcFields, dataFormats, false).Result;

                        var dataFormat = dataFormats.FirstOrDefault(d => d.DataFormatId == refField.DataFormatId);
                        UpdateLoanReview(ax, dealId, refField, allLoanReviews, dataFormat, result.Results.ToArray());
                    }

                    await ax.Save();
                }

                var newLoanReviews = isCalculateAllReferenceFormulas
                    ? await ax.Query<LoanReview>().Where(lr => lr.DealId == dealId && headerMapIds.Contains(lr.HeaderMapId) && loanIds.Contains(lr.LoanId)).ToArrayAsync()
                    : loanReviews;
                var calResult = ExceteFormulaWithPython(ax, dealId, headerMapId, script, deal, dealLevelConfig, loans, allHeaderMaps, newLoanReviews, headerMapWithCalcFields, dataFormats, true).Result;

                var calcFieldHeaderMap = allHeaderMaps.First(hm => hm.HeaderMapId == headerMapId);
                var calcFieldDataFormat = dataFormats.FirstOrDefault(d => d.DataFormatId == calcFieldHeaderMap.DataFormatId);
                UpdateLoanReview(ax, dealId, calcFieldHeaderMap, allLoanReviews, calcFieldDataFormat, calResult.Results.ToArray(), true);

                return calResult;
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    throw new DdsInvalidOperationException(ex.InnerException.Message);
                }
                else
                {
                    throw new DdsInvalidOperationException(ex.Message);
                }
            }

            return null;
        }

        private void UpdateLoanReview(DdsActionContext ax, long dealId, HeaderMap headerMap, LoanReview[] allLoanReviews, DataFormat dataFormat, CalculatorFieldDTO[] calcResult, bool isCaculatedFieldTestFormula = false)
        {
            var loanGroups = calcResult.GroupBy(r => r.LoanId).ToArray();
            var calcLoanIds = loanGroups.Select(l => l.Key).ToArray();
            var dbLoanReviews = allLoanReviews.Where(lr => calcLoanIds.Contains(lr.LoanId));
            var isPwCHeader = string.IsNullOrEmpty(headerMap.ClientHeader);
            foreach (var loan in loanGroups)
            {
                var dbLoanReview = dbLoanReviews.First(l => l.LoanId == loan.Key && l.HeaderMapId == headerMap.HeaderMapId);
                if (isCaculatedFieldTestFormula)
                {
                    var calcFieldItem = loan.First(l => l.DisplayOrder == 3);
                    calcFieldItem.IsTie =  ConvertExtension.ToCompareClientAndPwCValue(dbLoanReview.ClientDisplayValue, dbLoanReview.ClientValue, calcFieldItem.Value, dataFormat?.Type, dataFormat?.Format, headerMap.Threadhold, isPwCHeader);
                }
                else
                {
                    dbLoanReview.FinalValue = loan.First(l => l.DisplayOrder == 3).Value;
                    dbLoanReview.IsTie = ConvertExtension.ToCompareClientAndPwCValue(dbLoanReview.ClientDisplayValue, dbLoanReview.ClientValue, dbLoanReview.FinalValue, dataFormat?.Type, dataFormat?.Format, headerMap.Threadhold, isPwCHeader);
                    ax.Update(dbLoanReview);
                }
                
            }
        }

        public async Task<CalculatorFieldDTO[]> ReCalculateAll(DdsActionContext ax, long dealId)
        {
            try
            {
                var deal = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId && d.IsActive == true);
                if (deal.NeedRecalculation)
                {
                    deal.NeedRecalculation = false;
                    ax.Update(deal.UpdateBy(ax.UserId));
                    await ax.Save();
                }

                var allHeaderMaps = await ax.Query<HeaderMap>().Where(hm => hm.DealId == dealId && hm.IsActive == true).ToArrayAsync();
                var headerMapWithCalcFields = allHeaderMaps.Where(hm => !string.IsNullOrEmpty(hm.CalculatorHeader)).ToArray();
                if (headerMapWithCalcFields.Length == 0)
                {
                    //no need to recalculate as no any header set as Calculator Header
                    return null;
                }
                var allLoanReviews = await ax.Query<LoanReview>().Where(l => l.DealId == dealId).ToArrayAsync();
                var loans = await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true)
                                                  .Select(l => new LoanCalculatorDto { LoanId = l.LoanId, LoanNumber = l.LoanNumber, ParentId = l.ParentId }).ToArrayAsync();
                var loanIds = loans.Select(l => l.LoanId).ToArray();
                var headerMapIds = headerMapWithCalcFields.Select(hm => hm.HeaderMapId).ToArray();
                var loanReviews = allLoanReviews.Where(lr => headerMapIds.Contains(lr.HeaderMapId) && loanIds.Contains(lr.LoanId)).ToArray();

                List<CalculatorFieldDTO> dealLevelConfig = new();
                var dealLevelFields = await ax.Query<CalculatorGlobalField>().Where(f => f.DealId == dealId).ToArrayAsync();
                var dataFormats = await ax.Query<DataFormat>().ToArrayAsync();
                foreach (var field in dealLevelFields)
                {
                    var format = dataFormats.FirstOrDefault(d => d.DataFormatId == field.DataFormatId);
                    dealLevelConfig.Add(new CalculatorFieldDTO
                    {
                        DealId = dealId,
                        Field = field.FieldName,
                        Value = field.FieldValue,
                        DataFormatType = format?.Type,
                        DataFormat = format?.Format,
                        IsDealLevel = true
                    });
                }

                List<HeaderMap> refHeaderList = new();
                refHeaderList = GetRefHeadersWithOrder(allHeaderMaps, 0, string.Empty, true);

                var reCalcHeaders = refHeaderList.Where(h => h.ProcessType == ProcessType.Calculation.GetDisplayName() && !string.IsNullOrEmpty(h.CalculatorFormula)).ToList();
                foreach (HeaderMap refField in reCalcHeaders)
                {
                    var result = ExceteFormulaWithPython(ax, dealId, refField.HeaderMapId, refField.CalculatorFormula, deal, dealLevelConfig, loans, allHeaderMaps, loanReviews, headerMapWithCalcFields, dataFormats, false).Result;
                    var dataFormat = dataFormats.FirstOrDefault(d => d.DataFormatId == refField.DataFormatId);
                    UpdateLoanReview(ax, dealId, refField, allLoanReviews, dataFormat, result.Results.ToArray());
                }

                await ax.Save();
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    throw new DdsInvalidOperationException(ex.InnerException.Message);
                }
                else
                {
                    throw new DdsInvalidOperationException(ex.Message);
                }
            }

            return null;
        }

        private List<HeaderMap> GetRefHeadersWithOrder(HeaderMap[] headerMaps, long headerMapId, string formula, bool isReCaculateAll = false)
        {
            List<HeaderMap> refHeadersWithOrder = new();
            List<HeaderMap> restRefHeaders = new();
            if (isReCaculateAll)
            {
                var refHeadersWithoutFormula = headerMaps.Where(h => string.IsNullOrEmpty(h.CalculatorFormula)).ToList();
                if (!refHeadersWithoutFormula.Any())
                {
                    throw new DdsInvalidOperationException("Cannot calculate due to all the headers contains formula.");
                }

                refHeadersWithOrder.AddRange(refHeadersWithoutFormula);
                restRefHeaders.AddRange(headerMaps.Where(h => !string.IsNullOrEmpty(h.CalculatorFormula)));
            }
            else
            {
                List<HeaderMap> refHeaders = new();

                GetAllCalcHeadersByFormula(headerMaps, headerMapId, formula, ref refHeaders);
                var distinctRefHeaders = refHeaders.DistinctBy(h => h.HeaderMapId).ToList();
                var refHeadersWithoutFormula = distinctRefHeaders.Where(h => string.IsNullOrEmpty(h.CalculatorFormula)).ToList();

                if (!refHeadersWithoutFormula.Any())
                {
                    throw new DdsInvalidOperationException("Cannot calculate due to all the headers contains formula.");
                }

                refHeadersWithOrder.AddRange(refHeadersWithoutFormula);
                restRefHeaders.AddRange(distinctRefHeaders.Where(h => !string.IsNullOrEmpty(h.CalculatorFormula)));
            }

            GetCalcOrder(headerMaps, ref refHeadersWithOrder, ref restRefHeaders);

            if (restRefHeaders.Any())
            {
                throw new DdsInvalidOperationException("Cannot calculate due to circular reference in the formula.");
            }

            return refHeadersWithOrder;

        }

        private void GetAllCalcHeadersByFormula(HeaderMap[] headerMaps, long headerMapId, string formula, ref List<HeaderMap> refHeaders)
        {
            List<HeaderMap> tempRefHeaders = new();
            foreach (var item in headerMaps)
            {
                var loanLevelRegex = new Regex($@"\b\]\.{item.CalculatorHeader}\b");
                var totalLoanLevelRegex = new Regex($@"\bloans\.{item.CalculatorHeader}\b");
                var globalLevelRegex = new Regex($@"\bdeal\.{item.CalculatorHeader}\b");
                if (!string.IsNullOrEmpty(item.CalculatorHeader))
                {
                    if (loanLevelRegex.IsMatch(formula))
                    {
                        tempRefHeaders.Add(item);
                    }
                    else if (totalLoanLevelRegex.IsMatch(formula))
                    {
                        tempRefHeaders.Add(item);
                    }
                    else if (globalLevelRegex.IsMatch(formula))
                    {
                        tempRefHeaders.Add(item);
                    }
                }
            }

            if (tempRefHeaders.Any())
            {
                /*****Per discussed, filter out the header itself in formula
                     * For example: A	IF(1=1, DIV(B+1, C), Loan(row - 1).A)
                     * 
                                    B	10
                                    C	20
                                    A   IF(1=1, DIV(B+1, C), Loan(row - 1).A
                     * Then only check if the list contains B & C, 
                     * the system would consider this field as computable ******/
                var refHeaderIds = refHeaders.Select(h => h.HeaderMapId).ToList();
                var tempHeadersWithoutItself = tempRefHeaders.Where(h => h.HeaderMapId != headerMapId && !refHeaderIds.Contains(h.HeaderMapId));
                refHeaders.AddRange(tempHeadersWithoutItself);

                foreach (var header in tempHeadersWithoutItself)
                {
                    if (!string.IsNullOrEmpty(header.CalculatorFormula))
                    {
                        GetAllCalcHeadersByFormula(headerMaps, header.HeaderMapId, header.CalculatorFormula, ref refHeaders);
                    }
                }
            }
        }

        private void GetCalcOrder(HeaderMap[] headerMaps, ref List<HeaderMap> refHeadersWithOrder, ref List<HeaderMap> restRefHeaders)
        {
            var shouldRunAgain = false;
            foreach (var header in restRefHeaders.ToArray())
            {
                List<HeaderMap> headers = new();
                GetAllCalcHeadersByFormula(headerMaps, header.HeaderMapId, header.CalculatorFormula, ref headers);
                var distinctHeaderIds = headers.DistinctBy(h => h.HeaderMapId).Select(h => h.HeaderMapId).ToList();
                var refHeaderIdsWithOrder = refHeadersWithOrder.Select(h => h.HeaderMapId).ToList();
                bool containsAll = distinctHeaderIds.Cast<long>().All(item => refHeaderIdsWithOrder.Cast<long>().Contains(item));
                if (containsAll)
                {
                    refHeadersWithOrder.Add(header);
                    restRefHeaders.Remove(header);
                    shouldRunAgain = true;
                }
            }

            if (shouldRunAgain)
            {
                GetCalcOrder(headerMaps, ref refHeadersWithOrder, ref restRefHeaders);
                shouldRunAgain = false;
            }
        }


        public async Task<CalculatorFieldDTO[]> SaveFormulaAndCaculatedResult(DdsActionContext ax, CalculatorInfoDTO calculatorInfo)
        {
            var dealId = calculatorInfo.DealId;
            var headerMapId = calculatorInfo.HeaderMapId;
            var result = calculatorInfo.CalculatedResult;

            var dbHeaderMap = await ax.First<HeaderMap>(hm => hm.DealId == dealId && hm.HeaderMapId == headerMapId);
            var dataFormat = await ax.First<DataFormat>(df => df.DataFormatId == dbHeaderMap.DataFormatId);
            dbHeaderMap.CalculatorFormula = calculatorInfo.Script;
            ax.Update(dbHeaderMap);

            var allLoanReviews = await ax.Where<LoanReview>(l => l.DealId == dealId ).ToArrayAsync();
            UpdateLoanReview(ax, dealId, dbHeaderMap, allLoanReviews, dataFormat, result);

            await ax.Save();

            return [.. FormatResult([.. result])];
        }

        private async Task<CalculationResult> ExceteFormulaWithPython(DdsActionContext ax, long dealId, long headerMapId, string script,
            DealSetup deal, List<CalculatorFieldDTO> dealLevelConfig, LoanCalculatorDto[] loans, HeaderMap[] allHeaderMaps, LoanReview[] loanReviews, HeaderMap[] headerMapWithCalcFields, DataFormat[] dataFormats,
            bool isTest = false)
        {
            List<CalculatorFieldDTO> loanValues = new();
            foreach (var loanReview in loanReviews)
            {
                var headerMap = headerMapWithCalcFields.FirstOrDefault(hm => hm.DealId == dealId && hm.HeaderMapId == loanReview.HeaderMapId);
                var dataFormat = dataFormats.FirstOrDefault(d => d.DataFormatId == headerMap.DataFormatId);
                var loan = loans.FirstOrDefault(l => l.LoanId == loanReview.LoanId);

                var actualReviewLevel = Math.Min(deal.LevelOfReview, headerMap.LevelOfReview);
                var calculateFactorValue = string.Empty;
                if (headerMap.ProcessType == ProcessType.Calculation.GetDisplayName())
                {
                    calculateFactorValue = loanReview?.FinalValue;
                }
                else if (deal.LevelOfReviewForCalculation == 0)
                {
                    calculateFactorValue = !string.IsNullOrEmpty(loanReview.FinalValue) ? loanReview.FinalValue : loanReview.ClientValue;
                }
                else
                {
                    /***calculate level		review level	review 1	review 2	review 3	final value		
                                3		            1			 1			                        1		    r1 => final value
                                2		            1			 2			                        2		    r1 => final value
                                1		            1			 5			                        5		    r1 => final value									
										
                        calculate level		review level    review 1	review 2	review 3	final value		
                                3		            2			 1			                        1		    r2
                                2		            2			 1			                        1		    r2
                                1		            2			 5			                        5		    r2 > r1 => final value									
										
                        calculate level		review level	review 1	review 2	review 3	final value		
                                3		            3			 1	        2		                2		    r3
                                2		            3			 1			                        1		    r3 > r2
                                1		            3			 5			                        5		    r3 > r2 > r1  => final value								
                    ***/
                    if (actualReviewLevel == 2 && (deal.LevelOfReviewForCalculation == 2 || deal.LevelOfReviewForCalculation == 3))
                    {
                        calculateFactorValue = loanReview.SecondReviewValue;
                    }
                    else if (actualReviewLevel == 3 && (deal.LevelOfReviewForCalculation == 2 || deal.LevelOfReviewForCalculation == 3))
                    {
                        if (deal.LevelOfReviewForCalculation == 3)
                        {
                            calculateFactorValue = loanReview.ThirdReviewValue;
                        }
                        else if (deal.LevelOfReviewForCalculation == 2)
                        {
                            calculateFactorValue = !string.IsNullOrEmpty(loanReview.ThirdReviewValue) ? loanReview.ThirdReviewValue : loanReview.SecondReviewValue;
                        }
                    }
                    else
                    {
                        calculateFactorValue = loanReview.FinalValue;
                    }
                }

                if (dataFormat?.Type == "IsDateTime")
                {
                    DateTime date;
                    if (DateTime.TryParse(calculateFactorValue, out date))
                    {
                        calculateFactorValue = date.ToString("yyyy-MM-dd");
                    }
                    else
                    {
                        Console.WriteLine("Invalid date string");
                    }
                }

                var loanValue = new CalculatorFieldDTO
                {
                    LoanId = loanReview.LoanId,
                    ParentId = loan?.ParentId,
                    Field = headerMap?.CalculatorHeader,
                    Value = calculateFactorValue,
                    DataFormatType = dataFormat?.Type,
                    DataFormat = dataFormat?.Format,
                };

                loanValues.Add(loanValue);
            }

            var calcHeaderMap = headerMapWithCalcFields.FirstOrDefault(hm => hm.HeaderMapId == headerMapId);
            var calcFieldLoanReviews = loanReviews.Where(lr => lr.HeaderMapId == headerMapId).ToArray();
            try
            {
                if (!string.IsNullOrEmpty(calcHeaderMap?.CalculatorHeader))
                {
                    var resultFieldDdataFormat = dataFormats.FirstOrDefault(d => d.DataFormatId == calcHeaderMap.DataFormatId);
                    var calcResult = PyEngine.Execute(script, calcHeaderMap?.CalculatorHeader, resultFieldDdataFormat, loans, loanValues.ToArray(), dealLevelConfig.ToArray(), allHeaderMaps.ToArray(), calcFieldLoanReviews);

                    if (isTest)
                    {
                        calcResult.Results = FormatResult(calcResult.Results);
                    }

                    return calcResult;
                }
                else
                {
                    throw new DdsInvalidOperationException("Invalid calculated field.");
                }
            }
            catch (Exception ex)
            {
                var errorMsg = ex != null ? ex.Message : "Invalid syntax error.";
                throw new DdsInvalidOperationException(errorMsg);
            }
        }

        private List<CalculatorFieldDTO> FormatResult(List<CalculatorFieldDTO> calcResult)
        {
            foreach (var result in calcResult)
            {
                if (result.DataFormatType == DataFormatType.IsNumeric.GetDisplayName())
                {
                    result.DisplayValue = ConvertExtension.ToDecimalNullable(result.Value, result.DataFormat?.Split('|')[0]);

                }
                else if (result.DataFormatType == DataFormatType.IsDateTime.GetDisplayName())
                {
                    result.DisplayValue = ConvertExtension.ToDateTimeNullable(result.Value, result.DataFormat?.Split('|')[0]);
                }
            }

            return calcResult;
        }


        public async Task<CalculatorGlobalFieldDTO[]> GetCalculatorGlobalField(DdsActionContext ax, long dealId)
        {
            var data = await ax.Query<CalculatorGlobalField>().Where(f => f.DealId == dealId && f.IsActive == true)
                                                              .OrderBy(f => f.DisplayOrder).ToArrayAsync();
            return ax.Mapper.Map<CalculatorGlobalFieldDTO[]>(data);
        }

        public async Task UpdateCalculatorGlobalField(DdsActionContext ax, long dealId, CalculatorGlobalFieldDTO[] calculatorGlobalFields)
        {
            var existCGF = await ax.Query<CalculatorGlobalField>().Where(f => f.DealId == dealId).ToArrayAsync();
            var allIds = calculatorGlobalFields.Select(e => e.CalculatorGlobalFieldId).ToArray();
            var existMaps = await ax.Query<HeaderMap>().Where(m => m.DealId == dealId).ToArrayAsync();

            // Delete missing entry
            var deleteCGF = existCGF.Where(f => !allIds.Any(e => e == f.CalculatorGlobalFieldId)).ToArray();
            foreach(var cgf in deleteCGF)
            {
                var pattern = $@"\bdeal\.(?<!\w){cgf.FieldName}\b";
                var regex = new Regex(pattern);
                var refHeaders = existMaps.Where(h => h.ProcessType == ProcessType.Calculation.GetDisplayName() && !string.IsNullOrEmpty(h.CalculatorFormula) && regex.IsMatch(h.CalculatorFormula)).ToList();
                if (refHeaders.Any())
                {
                    throw new DdsInvalidOperationException($"Cannot delete the Calculator Global Field: {cgf.FieldName} as it has been used in other calculation fields: {string.Join(",", refHeaders.Select(h => h.CalculatorHeader))}");
                }
            }            
            ax.RemoveRange(deleteCGF);

            // Add new entry
            var newCGF = ax.Mapper.Map<CalculatorGlobalField[]>(calculatorGlobalFields.Where(f => f.CalculatorGlobalFieldId == 0));
            foreach (var cgf in newCGF)
            {
                cgf.DealId = dealId;
                cgf.IsActive = true;
                cgf.CreateBy(ax.UserId);
            }
            ax.AddRange(newCGF);

            // Update entry
            var updateCGF = existCGF.Where(f => allIds.Any(e => e == f.CalculatorGlobalFieldId)).ToArray();
            foreach (var cgf in updateCGF)
            {
                var data = calculatorGlobalFields.Where(f => f.CalculatorGlobalFieldId == cgf.CalculatorGlobalFieldId).FirstOrDefault();

                if (cgf.FieldName != data.FieldName)
                {
                    var headerMapsWithFormula = existMaps.Where(m => !string.IsNullOrEmpty(m.CalculatorFormula)).ToArray();
                    var pattern = $@"\bdeal\.(?<!\w){cgf.FieldName}\b";
                    string replacement = $"deal.{data.FieldName}";
                    UpdateFormulaWithNewCalculatorHeader(ax, headerMapsWithFormula, cgf.FieldName, data.FieldName, pattern, replacement, string.Empty, string.Empty);
                }

                cgf.FieldName = data.FieldName;
                cgf.FieldValue = data.FieldValue;
                cgf.DataFormatId = data.DataFormatId;
                cgf.DisplayOrder = data.DisplayOrder;
                cgf.UpdateBy(ax.UserId);
            }
            ax.UpdateRange(updateCGF);
            await ax.Save();
        }

        public void UpdateFormulaWithNewCalculatorHeader(DdsActionContext ax, HeaderMap[] allCalculatedHeaderMaps, string oldHeader, string newHeader, 
            string globalPattern, string globalReplacement, string loanPattern, string loanReplacement)
        {
            var globalRegex = new Regex(globalPattern);
            var loanRegex = new Regex(loanPattern);
            if (string.IsNullOrEmpty(oldHeader))
            {
                return;
            }
            if (string.IsNullOrEmpty(newHeader))
            {
                var refHeaders = allCalculatedHeaderMaps.Where(h => globalRegex.IsMatch(h.CalculatorFormula) || loanRegex.IsMatch(h.CalculatorFormula)).ToList();
                if (refHeaders.Any())
                {
                    throw new DdsInvalidOperationException($"Cannot leave the Calculator Header: {oldHeader} empty as it has been used in other calculation fields: {string.Join(",", refHeaders.Select(h => h.CalculatorHeader))}");
                }
            }

            foreach (var item in allCalculatedHeaderMaps)
            {
                if (!string.IsNullOrEmpty(item.CalculatorHeader))
                {
                    if (globalRegex.IsMatch(item.CalculatorFormula))
                    {                        
                        item.CalculatorFormula = Regex.Replace(item.CalculatorFormula, globalPattern, globalReplacement);
                        
                    }
                    if (loanRegex.IsMatch(item.CalculatorFormula))
                    {
                        item.CalculatorFormula = Regex.Replace(item.CalculatorFormula, loanPattern, loanReplacement);
                        
                    }
                    ax.Update(item.UpdateBy(ax.UserId));
                }
            }
        }
    }
}
