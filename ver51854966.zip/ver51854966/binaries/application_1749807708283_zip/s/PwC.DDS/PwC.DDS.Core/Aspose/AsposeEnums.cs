﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core
{
    public enum AlignmentType
    {
        Bottom = 0,
        Center = 1,
        CenterAcross = 2,
        Distributed = 3,
        Fill = 4,
        General = 5,
        Justify = 6,
        Left = 7,
        Right = 8,
        Top = 9,
        JustifiedLow = 10,
        ThaiDistributed = 11
    }
    public enum BorderLineType
    {
        None = 0,
        Thin = 1,
        Medium = 2,
        Dashed = 3,
        Dotted = 4,
        Thick = 5,
        Double = 6,
        Hair = 7,
        MediumDashed = 8,
        DashDot = 9,
        MediumDashDot = 10,
        DashDotDot = 11,
        MediumDashDotDot = 12,
        SlantedDashDot = 13
    }
    public enum BackgroundPatternType
    {
        None = 0,
        Solid = 1,
        Gray50 = 2,
        Gray75 = 3,
        Gray25 = 4,
        HorizontalStripe = 5,
        VerticalStripe = 6,
        ReverseDiagonalStripe = 7,
        DiagonalStripe = 8,
        DiagonalCrosshatch = 9,
        ThickDiagonalCrosshatch = 10,
        ThinHorizontalStripe = 11,
        ThinVerticalStripe = 12,
        ThinReverseDiagonalStripe = 13,
        ThinDiagonalStripe = 14,
        ThinHorizontalCrosshatch = 15,
        ThinDiagonalCrosshatch = 16,
        Gray12 = 17,
        Gray6 = 18
    }
}
