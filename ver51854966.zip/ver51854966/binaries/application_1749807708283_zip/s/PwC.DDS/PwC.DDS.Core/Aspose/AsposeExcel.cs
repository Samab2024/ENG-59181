﻿using Aspose.Cells;
using PwC.DDS.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Range = Aspose.Cells.Range;

namespace PwC.DDS.Core.Aspose
{
    public class ImportWorkBook
    {
        public Workbook WorkBook;
        public Worksheet WorkSheet;
        public List<ImportWorkSheet> SheetList { get; set; }

        #region workbook operation

        public void OpenExcel(Stream stream)
        {
            SetAsposeCellsLicense();
            stream.Position = 0;
            WorkBook = new Workbook(stream);
        }

        public void OpenExcel(string filePath)
        {
            SetAsposeCellsLicense();
            WorkBook = new Workbook(filePath);
        }

        public void OpenExcel()
        {
            SetAsposeCellsLicense();
            WorkBook = new Workbook();
        }

        public void SaveExcel(string filePath)
        {
            WorkBook.Save(filePath);
        }

        public void CloseExcel()
        {
            if (WorkBook != null)
                WorkBook.Dispose();
        }

        public Worksheet ActiveWorkSheet(string sheetName)
        {
            try
            {
                WorkSheet = WorkBook.Worksheets[sheetName];
                return WorkSheet;
            }
            catch
            {
                throw new DdsInvalidOperationException($"The sheet {sheetName} cannot be found.");
            }
        }

        public Worksheet CreateWorkSheet(string sheetName)
        {
            try
            {
                WorkSheet = WorkBook.Worksheets["Sheet1"];
                if (WorkSheet != null)
                    WorkSheet.Name = sheetName;
                else
                    WorkSheet = WorkBook.Worksheets.Add(sheetName);

                return WorkSheet;
            }
            catch
            {
                throw new DdsInvalidOperationException($"The sheet {sheetName} cannot be added.");
            }
        }

        #endregion

        #region load data from sheets

        public List<string> LoadSheets()
        {
            return WorkBook.Worksheets.Select(w => w.Name).ToList();
        }

        public void ReadExcel()
        {
            var sheetName = string.Empty;
            try
            {
                foreach (var ws in SheetList)
                {
                    sheetName = ws.SheetName;
                    var sheet = WorkBook.Worksheets[sheetName];
                    ws.Columns = LoadColumns(sheet);
                    ws.SheetData_av = LoadData(sheet, ws.PkColumns, true); //Actual Value
                    ws.SheetData_dv = LoadData(sheet, ws.PkColumns, false); //Display Value 
                }
            }
            catch
            {
                throw new DdsInvalidOperationException("Error when read sheet " + sheetName);
            }
        }

        public void ReadExcel(string[] pkColumns)
        {
            var sheetName = string.Empty;
            try
            {
                foreach (var ws in SheetList)
                {
                    sheetName = ws.SheetName;
                    var sheet = WorkBook.Worksheets[sheetName];
                    ws.Columns = LoadColumns(sheet);
                    ws.SheetData_av = LoadData(sheet, pkColumns, true);
                }
            }
            catch
            {
                throw new DdsInvalidOperationException("Error when read sheet " + sheetName);
            }
        }

        private DataTable LoadData(Worksheet sheet, string[] pkColumns, bool isActValue)
        {
            var table = new DataTable { TableName = sheet.Name + (isActValue ? "_av" : "_dv") };

            //Get column details
            for (int iCol = 0; iCol < sheet.Cells.MaxDataColumn + 1; iCol++)
            {
                Cell cell = sheet.Cells[0, iCol];
                if (cell.Value == null)
                    table.Columns.Add(string.Empty);
                else
                    table.Columns.Add(cell.Value?.ToString()?.Trim());
            }

            //Get row details
            for (var rowNum = 1; rowNum < sheet.Cells.MaxDataRow + 1; rowNum++)
            {
                var row = table.Rows.Add();
                for (int iCol = 0; iCol < table.Columns.Count; iCol++)
                {
                    Cell cell = sheet.Cells[rowNum, iCol];
                    if (isActValue)
                    {
                        row[iCol] = cell.Value;
                    }
                    else
                    {
                        var displayValue = string.Empty;
                        if (cell.Type == CellValueType.IsString)
                            displayValue = cell.Value.ToString();
                        else
                            displayValue = cell.DisplayStringValue.Trim();
                        row[iCol] = displayValue + "|" + cell.GetDisplayStyle().CultureCustom;
                    }
                }
            }

            if (pkColumns != null && pkColumns.Length > 0)
            {
                string filter = "";
                foreach (string col in pkColumns)
                {
                    if (filter.Length > 0)
                        filter += " OR ";
                    filter += $"([{col}] IS NOT NULL AND [{col}] <> '' AND NOT ([{col}] LIKE '|%'))";
                }

                table.DefaultView.RowFilter = filter;
                return table.DefaultView.ToTable();
            }
            else
            {
                return table;
            }
        }

        private ColumnDetail[] LoadColumns(Worksheet sheet)
        {
            var columns = new ColumnDetail[sheet.Cells.MaxDataColumn + 1];
            for (int iCol = 0; iCol < sheet.Cells.MaxDataColumn + 1; iCol++)
            {
                Cell headerCell = sheet.Cells[0, iCol];
                Cell dataCell = sheet.Cells[1, iCol];
                columns[iCol] = new ColumnDetail()
                {
                    ColName = headerCell.Value?.ToString()?.Trim() ?? string.Empty,
                    ColType = dataCell?.Type.ToString(),
                    ColFormat = dataCell?.GetDisplayStyle().CultureCustom
                };
            }
            return columns;
        }

        public void CheckSheets()
        {
            var missedSheets = new List<string>();
            try
            {
                var sheetNames = WorkBook.Worksheets.Select(x => x.Name).ToList();
                SheetList.ForEach(s =>
                {
                    if (!sheetNames.Contains(s.SheetName))
                    {
                        missedSheets.Add(s.SheetName);
                    }
                });

                if (missedSheets.Count <= 0) 
                    return;

                throw new DdsInvalidOperationException(string.Join(",", missedSheets) + " sheet(s) cannot be found in upload Excel");
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException(ex.Message);
            }
        }

        public void CheckColumns()
        {
            var errMsg = new StringBuilder();
            try
            {
                var columnsTable = new List<DataTable>();
                foreach (var sheet in SheetList)
                {
                    var ws = WorkBook.Worksheets[sheet.SheetName];
                    var excelTable = new DataTable { TableName = ws.Name };
                    //Get column details
                    for (int iCol = 0; iCol < ws.Cells.MaxDataColumn + 1; iCol++)
                    {
                        Cell cell = ws.Cells[0, iCol];
                        if (cell.Value != null)
                            excelTable.Columns.Add(cell.Value?.ToString()?.Trim());
                    }
                    columnsTable.Add(excelTable);

                    var missedColumns = new List<string>();
                    foreach (var col in sheet.PkColumns)
                    {
                        if (!excelTable.Columns.Contains(col))
                            missedColumns.Add(col);
                    }
                    if (missedColumns.Any())
                        errMsg.Append(string.Join(",", missedColumns)).Append(" column(s) in ")
                              .Append(sheet.SheetName).Append(" cannot be found.");
                }

                if (errMsg.Length > 0)
                {
                    throw new DdsInvalidOperationException("Column missing: " + errMsg);
                }
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException(ex.Message);
            }
        }

        private void SetAsposeCellsLicense()
        {
            License license = new License();
            license.SetLicense("Aspose.Cells.NET.lic");
        }

        #endregion

        #region worksheet cell/range operation

        public Cell GetCell(string cellCode)
        {
            return WorkSheet.Cells[cellCode];
        }

        public Cell GetCell(int rowNumber, int columNumber)
        {
            return WorkSheet.Cells[rowNumber, columNumber];
        }

        public Cell SetText(string cellCode, object data, string custom = "", AlignmentType horizontalAlignment = AlignmentType.Left, AlignmentType verticalAlignment = AlignmentType.Center)
        {
            Cell cell = GetCell(cellCode);
            cell.PutValue(data.ToString(), true);
            Style style = cell.GetStyle();
            style.VerticalAlignment = (TextAlignmentType)verticalAlignment;
            style.HorizontalAlignment = (TextAlignmentType)horizontalAlignment;
            if (!string.IsNullOrEmpty(custom))
            {
                style.Custom = custom;
            }
            cell.SetStyle(style);
            return cell;
        }

        public Cell SetTextWithoutAutoFormat(string cellCode, object data, string custom = "", AlignmentType horizontalAlignment = AlignmentType.Left, AlignmentType verticalAlignment = AlignmentType.Center)
        {
            Cell cell = GetCell(cellCode);
            cell.PutValue(data.ToString());
            Style style = cell.GetStyle();
            style.VerticalAlignment = (TextAlignmentType)verticalAlignment;
            style.HorizontalAlignment = (TextAlignmentType)horizontalAlignment;
            if (!string.IsNullOrEmpty(custom))
            {
                style.Custom = custom;
            }
            cell.SetStyle(style);
            return cell;
        }

        public Range getRange(int startRow, int startCol, int endRow, int endCol)
        {
            var cell1 = GetCell(startRow, startCol);
            var cell2 = GetCell(endRow, endCol);
            return WorkSheet.Cells.CreateRange(cell1.Name, cell2.Name);
        }

        public void SetColumsWidth(int startCol, int endCol, double width)
        {
            for (int col = startCol; col <= endCol; col++)
            {
                WorkSheet.Cells.SetColumnWidth(col, width);
            }
        }

        public void SetAutoFit(List<int> needToFitColumns)
        {
            AutoFitterOptions options = new AutoFitterOptions();
            WorkSheet.AutoFitRows(options);

            foreach (var column in needToFitColumns)
            {
                WorkSheet.AutoFitColumn(column, 2, 2);
            }
        }

        public int FindIndexByValue(int startRow, int startCol, int endCol, string value)
        {
            int index = -1;
            for (int columnIndex = 0; columnIndex <= endCol; columnIndex++)
            {
                var cellValue = WorkSheet.Cells[startRow, columnIndex].Value?.ToString();
                if (cellValue == value)
                {
                    index = columnIndex;
                    break;
                }
            }
            return index;
        }
        #endregion
    }

    public class ImportWorkSheet
    {
        public string SheetName { get; set; }
        public string[] PkColumns { get; set; }
        public ColumnDetail[] Columns { get; set; }
        public DataTable SheetData_av { get; set; }
        public DataTable SheetData_dv { get; set; }
        
        public ImportWorkSheet(string sSheetName, string[] pkColumns)
        {
            SheetName = sSheetName;
            PkColumns = pkColumns;
        }
    }

    public class ColumnDetail
    {
        public string ColName { get; set; }
        public string? ColType { get; set; }
        public string? ColFormat { get; set; }
    }
}
