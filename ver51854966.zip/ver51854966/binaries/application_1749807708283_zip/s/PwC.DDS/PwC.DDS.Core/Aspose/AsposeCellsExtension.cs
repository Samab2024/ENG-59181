﻿using Aspose.Cells;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core.Aspose
{
    public static class AsposeCellsExtension
    {
        public static Cell SetAllBorder(this Cell cell, Color? color = null, BorderLineType cellBorderType = BorderLineType.Thin)
        {
            if (color == null) color = Color.Black;
            Style style = cell.GetStyle();
            style.SetBorder(BorderType.BottomBorder, (CellBorderType)cellBorderType, color.Value);
            style.SetBorder(BorderType.TopBorder, (CellBorderType)cellBorderType, color.Value);
            style.SetBorder(BorderType.LeftBorder, (CellBorderType)cellBorderType, color.Value);
            style.SetBorder(BorderType.RightBorder, (CellBorderType)cellBorderType, color.Value);
            cell.SetStyle(style);
            return cell;
        }

        public static Cell SetTextWrapped(this Cell cell, bool isWrapped = true)
        {
            Style style = cell.GetStyle();
            style.IsTextWrapped = isWrapped;
            cell.SetStyle(style);
            return cell;
        }

        public static Cell SetBold(this Cell cell)
        {
            Style style = cell.GetStyle();
            Font font = style.Font;
            font.IsBold = true;
            cell.SetStyle(style);
            return cell;
        }

        public static Cell SetBackGroundColor(this Cell cell, Color color, BackgroundPatternType backgroundType = BackgroundPatternType.Solid)
        {
            Style style = cell.GetStyle();
            style.Pattern = (BackgroundType)backgroundType;
            style.ForegroundColor = color;
            cell.SetStyle(style);
            return cell;
        }

        public static Cell SetFontColor(this Cell cell, Color color)
        {
            Style style = cell.GetStyle();
            Font font = style.Font;
            font.Color = color;
            cell.SetStyle(style);
            return cell;
        }
    }
}
