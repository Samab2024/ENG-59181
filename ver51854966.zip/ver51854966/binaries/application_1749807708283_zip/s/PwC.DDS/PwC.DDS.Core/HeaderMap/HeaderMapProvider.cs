﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System.Collections;
using PwC.DDS.Core.Common;
using Aspose.Cells;
using PwC.DDS.Core.Aspose;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using System.Data;
using System.Drawing;
using System.Text.RegularExpressions;

namespace PwC.DDS.Core
{
    public class HeaderMapProvider : IHeaderMapProvider
    {
        readonly IDealProvider _deal;
        readonly ICalculatorProvider _calculator;
        public HeaderMapProvider(IDealProvider deal, ICalculatorProvider calculator)
        {
            _deal = deal;
            _calculator = calculator;
        }

        public async Task<DealHeaderMapDTO> GetDealHeaderMap(DdsActionContext ax, long dealId)
        {
            var dealHeaderMap = new DealHeaderMapDTO();
            var deal = await _deal.GetDeal(ax, dealId);
            dealHeaderMap.DealId = deal.DealId;
            dealHeaderMap.DealName = deal.DealName;
            dealHeaderMap.LevelOfReview = deal.LevelOfReview;
            dealHeaderMap.IsEditable = deal.IsEditable;
            var data = await ax.Query<HeaderMap>().Where(l => l.DealId == dealId && l.IsActive == true)
                                                  .OrderBy(l => l.DisplayOrder).ThenBy(l => l.HeaderMapId).ToArrayAsync();
            dealHeaderMap.HeaderMap = ax.Mapper.Map<HeaderMapDTO[]>(data);
            return dealHeaderMap;
        }

        public async Task<HeaderMapDTO> CreateHeaderMap(DdsActionContext ax, long dealId, HeaderMapDTO headerMap)
        {
            var deal = await _deal.GetDeal(ax, dealId);
            if (string.IsNullOrWhiteSpace(headerMap.PwCHeader))
            {
                throw new DdsInvalidOperationException("PwC header cannot be empty");
            }
            if (await ax.Any<HeaderMap>(h => h.DealId == dealId && h.PwCHeader == headerMap.PwCHeader.Trim()))
            {
                throw new DdsInvalidOperationException("duplicate PwC header");
            }

            var sources = await ax.Query<Source>().Where(s => s.DealId == dealId).ToArrayAsync();
            var sourceDocSections = await ax.Query<SourceDocSection>().Where(sds => sds.DealId == dealId).ToArrayAsync();

            if (headerMap.ProcessType == ProcessType.Provided.GetDisplayName()
                || headerMap.ProcessType == ProcessType.Calculation.GetDisplayName()
                || headerMap.ProcessType == ProcessType.PassThrough.GetDisplayName())
            {
                headerMap.SourceDocSectionId = sourceDocSections.Min(s => s.SourceDocSectionId);
                headerMap.SourceId = sources.Min(s => s.SourceId);
            }

            var newHeaderMap = ax.Mapper.Map<HeaderMap>(headerMap).CreateBy(ax.UserId);
            newHeaderMap.IsActive = true;
            newHeaderMap.PwCHeader = newHeaderMap.PwCHeader?.Trim();
            newHeaderMap.DealId = dealId;
            newHeaderMap.DisplayOrder = ax.Query<HeaderMap>().Where(h => h.DealId == dealId).Select(h => h.DisplayOrder).DefaultIfEmpty().Max() + 1;
            newHeaderMap.ReportOrder = 0;
            newHeaderMap.LevelOfReview = deal.LevelOfReview;
            var data = ax.Add(newHeaderMap);
            await ax.Save();

            // initial attribute review when process type equals Review-Attribute
            if (headerMap.ProcessType == ProcessType.ReviewAttribute.GetDisplayName())
            {
                var newReviewer = new Reviewer
                {
                    DealId = dealId,
                    LoanId = 0,
                    HeaderMapId = data.HeaderMapId,
                    SectionId = 0,
                    ReviewerStatus1 = ReviewStatus.NotStarted.GetDisplayName(),
                    ReviewerStatus2 = ReviewStatus.NotStarted.GetDisplayName(),
                    ReviewerStatus3 = ReviewStatus.NotStarted.GetDisplayName()
                };
                ax.Add(newReviewer.CreateBy(ax.UserId));
            }

            // initial new header on loan review
            var loanList = await ax.Query<Loan>().Where(h => h.DealId == dealId).ToArrayAsync();
            foreach (var loan in loanList)
            {
                var newLoanReview = new LoanReview()
                {
                    DealId = dealId,
                    LoanId = loan.LoanId,
                    HeaderMapId = data.HeaderMapId,
                };
                ax.Add(newLoanReview.CreateBy(ax.UserId));
            }
            await ax.Save();
            return ax.Mapper.Map<HeaderMapDTO>(data);
        }

        public async Task UpdateDealHeaderMap(DdsActionContext ax, long dealId, HeaderMapDTO[] headerMaps)
        {
            // Update changed maps based on Id
            var dealSetup = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId && d.IsActive == true);
            var existMaps = await ax.Query<HeaderMap>().Where(m => m.DealId == dealId).ToArrayAsync();
            var mapActiveIds = headerMaps.Where(m => m.IsActive == true).Select(m => m.HeaderMapId).ToArray();
            var changeActiveMaps = existMaps.Where(m => mapActiveIds.Any(l => l == m.HeaderMapId)).ToArray();
            var sources = await ax.Query<Source>().Where(s => s.DealId == dealId).ToArrayAsync();
            var sourceDocSections = await ax.Query<SourceDocSection>().Where(sds => sds.DealId == dealId).ToArrayAsync();
            var reCompareHeaderMaps = new List<HeaderMapDTO>();
            foreach (var map in changeActiveMaps)
            {
                var newMap = headerMaps.Where(m => m.HeaderMapId == map.HeaderMapId).FirstOrDefault();

                var isDuplicatedCalcHeader = existMaps.Any(m => !string.IsNullOrEmpty(m.CalculatorHeader) && m.HeaderMapId != map.HeaderMapId && m.CalculatorHeader == newMap.CalculatorHeader);
                if (isDuplicatedCalcHeader)
                {
                    throw new DdsInvalidOperationException($"Duplicated calculator header: {newMap.CalculatorHeader}");
                }

                var isDuplicatedPwCHeader = existMaps.Any(m => !string.IsNullOrEmpty(m.PwCHeader) && m.HeaderMapId != map.HeaderMapId && m.PwCHeader == newMap.PwCHeader);
                if (isDuplicatedPwCHeader)
                {
                    throw new DdsInvalidOperationException($"Duplicated pwc header: {newMap.PwCHeader}");
                }

                if (map.CalculatorHeader != newMap.CalculatorHeader)
                {
                    var headerMapsWithFormula = existMaps.Where(m => !string.IsNullOrEmpty(m.CalculatorFormula)).ToArray();
                    var globalPattern = $@"\bloans\.(?<!\w){map.CalculatorHeader}\b";
                    string globalReplacement = $"loans.{newMap.CalculatorHeader}";
                    var loanPattern = $@"\b\]\.(?<!\w){map.CalculatorHeader}\b";
                    string loanReplacement = $"].{newMap.CalculatorHeader}";
                    _calculator.UpdateFormulaWithNewCalculatorHeader(ax, headerMapsWithFormula, map.CalculatorHeader, newMap.CalculatorHeader, globalPattern, globalReplacement, loanPattern, loanReplacement);
                }

                //check if settings are changed for the review fields
                if (newMap.ProcessType == ProcessType.Review.GetDisplayName() ||
                    newMap.ProcessType == ProcessType.ReviewAttribute.GetDisplayName() ||
                    newMap.ProcessType == ProcessType.ReviewCalculation.GetDisplayName())
                {
                    newMap.CalculatorFormula = null;
                    if (map.DataFormatId != newMap?.DataFormatId || map.Threadhold != newMap?.Threadhold || map.LevelOfReview != newMap?.LevelOfReview || map.ProcessType != newMap?.ProcessType)
                        reCompareHeaderMaps.Add(newMap);
                }
                else if (newMap.ProcessType == ProcessType.Provided.GetDisplayName() ||
                         newMap.ProcessType == ProcessType.Calculation.GetDisplayName() ||
                         newMap.ProcessType == ProcessType.PassThrough.GetDisplayName())
                {
                    newMap.SourceDocSectionId = sourceDocSections.Min(s => s.SourceDocSectionId);
                    newMap.SourceId = sources.Min(s => s.SourceId);
                }

                ax.Mapper.Map(newMap, map);
                map.UpdateBy(ax.UserId);
            }
            ax.UpdateRange(changeActiveMaps);

            // Delete inactive header
            var mapInActiveIds = headerMaps.Where(m => m.IsActive == false && string.IsNullOrEmpty(m.ClientHeader)).Select(m => m.HeaderMapId).ToArray();
            var deleteInActiveMaps = existMaps.Where(m => mapInActiveIds.Any(l => l == m.HeaderMapId)).ToArray();
            if (deleteInActiveMaps != null && deleteInActiveMaps.Count() > 0)
            {
                ax.RemoveRange(deleteInActiveMaps);
            }

            // Delete inactive header on review
            var deleteLoanReviews = await ax.Query<LoanReview>().Where(m => m.DealId == dealId && mapInActiveIds.Any(l => l == m.HeaderMapId)).ToArrayAsync();
            if (deleteLoanReviews != null && deleteLoanReviews.Count() > 0)
            {
                ax.RemoveRange(deleteLoanReviews);
            }

            //Re-Calc FinalValue & Re-Compare client and PwC value
            foreach (var headerMap in reCompareHeaderMaps)
            {
                var dataFormat = await ax.Query<DataFormat>().FirstOrDefaultAsync(d => d.DataFormatId == headerMap.DataFormatId);
                var loanReviews = await ax.Query<LoanReview>().Where(m => m.DealId == dealId && m.HeaderMapId == headerMap.HeaderMapId).ToArrayAsync();
                var levelOfReview = Math.Min(dealSetup.LevelOfReview, headerMap.LevelOfReview);
                var isPwCHeader = string.IsNullOrEmpty(headerMap.ClientHeader);
                foreach (var loanReview in loanReviews)
                {
                    if (loanReview.IsFirstReviewed || loanReview.IsSecondReviewed || loanReview.IsThirdReviewed)
                    {
                        loanReview.FinalValue = ReCalcFinalValue(loanReview, levelOfReview);
                        loanReview.IsTie = ConvertExtension.ToCompareClientAndPwCValue(loanReview.ClientDisplayValue, loanReview.ClientValue, loanReview.FinalValue, dataFormat?.Type, dataFormat?.Format, headerMap.Threadhold, isPwCHeader);
                    }
                    else 
                    {
                        loanReview.FinalValue = null;
                        loanReview.IsTie = null;
                    }
                    ax.Update(loanReview.UpdateBy(ax.UserId));
                }
            }

            // initial attribute review when process type equals Review-Attribute
            var reviewByAttri = headerMaps.Where(h => h.IsActive == true && h.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()).ToArray();
            var reviewers = await ax.Query<Reviewer>().Where(m => m.DealId == dealId && m.HeaderMapId > 0).Select(m => m.HeaderMapId).ToArrayAsync();
            var missingReviewers = reviewByAttri.Where(h => !reviewers.Any(r => r == h.HeaderMapId)).ToArray();
            var newReviewers = missingReviewers.Select(r => new Reviewer
            {
                DealId = dealId,
                LoanId = 0,
                HeaderMapId = r.HeaderMapId,
                SectionId = 0,
                ReviewerStatus1 = ReviewStatus.NotStarted.GetDisplayName(),
                ReviewerStatus2 = ReviewStatus.NotStarted.GetDisplayName(),
                ReviewerStatus3 = ReviewStatus.NotStarted.GetDisplayName()
            }.CreateBy(ax.UserId)).ToArray();
            ax.AddRange(newReviewers);

            await ax.Save();
            await _deal.ResetNeedRecalculatation(ax, dealId);
        }

        #region Copy Header Map
        public async Task CopyHeaderMap(DdsActionContext ax, long dealId, long dealIdRef, bool isOverride)
        {
            var deal = await _deal.GetDeal(ax, dealId);
            var curSections = await ax.Query<Section>().Where(m => m.DealId == dealId).ToListAsync();
            var curDocs = await ax.Query<SourceDocSection>().Where(m => m.DealId == dealId).Include(m => m.Section).ToListAsync();
            var refDocs = await ax.Query<SourceDocSection>().Where(m => m.DealId == dealIdRef).Include(m => m.Section).ToListAsync();
            var curCategory = await ax.Query<DropdownCategory>().Where(m => m.DealId == dealId).Include(m => m.DropdownCategoryOptions).ToListAsync();
            var refCategory = await ax.Query<DropdownCategory>().Where(m => m.DealId == dealIdRef).Include(m => m.DropdownCategoryOptions).ToListAsync();
            var curSources = await ax.Query<Source>().Where(m => m.DealId == dealId).ToListAsync();
            var refSources = await ax.Query<Source>().Where(m => m.DealId == dealIdRef).ToListAsync();
            var curMaps = await ax.Query<HeaderMap>().Where(m => m.DealId == dealId && m.IsActive == true).ToArrayAsync();
            var refMaps = await ax.Query<HeaderMap>().Where(m => m.DealId == dealIdRef && m.IsActive == true).ToArrayAsync();

            // Copy Client Header Map
            var updateClientMaps = curMaps.Where(m => !string.IsNullOrEmpty(m.ClientHeader)).ToArray();
            foreach (var map in updateClientMaps)
            {
                if (!isOverride && !string.IsNullOrEmpty(map.PwCHeader))
                {
                    map.DisplayOrder = 0;
                    continue;
                }

                var newMap = refMaps.Where(m => m.ClientHeader == map.ClientHeader).FirstOrDefault();
                if (newMap == null)
                {
                    map.DisplayOrder = 0;
                    continue;
                }

                map.PwCHeader = newMap.PwCHeader;
                map.CalculatorHeader = newMap.CalculatorHeader;
                map.CalculatorFormula = newMap.CalculatorFormula;
                map.ProcessType = newMap.ProcessType;
                map.SourceDocSectionId = await CopySourceDocSection(ax, dealId, newMap.SourceDocSectionId, refDocs, curDocs, curSections);
                map.DropdownCategoryId = await CopyDropDownCategory(ax, dealId, newMap.DropdownCategoryId, refCategory, curCategory);
                map.SourceId = await CopySource(ax, dealId, newMap.SourceId, refSources, curSources);
                map.DataFormatId = newMap.DataFormatId;
                map.FieldGuide = newMap.FieldGuide;
                map.ScreenShotId = await CopyScreenShot(ax, dealId, dealIdRef, newMap.ScreenShotId);
                map.LevelOfReview = Math.Min(deal.LevelOfReview, newMap.LevelOfReview);
                map.IsBlindReview = newMap.IsBlindReview;
                map.IsExcludedInReport = newMap.IsExcludedInReport;
                map.DisplayOrder = newMap.DisplayOrder;
                map.Threadhold = newMap.Threadhold;
                ax.Update(map.UpdateBy(ax.UserId));
            }

            // Copy PwC Header Map
            var updatePwCMaps = curMaps.Where(m => string.IsNullOrEmpty(m.ClientHeader)).ToArray();
            foreach (var map in updatePwCMaps)
            {
                var newMap = refMaps.Where(m => string.IsNullOrEmpty(m.ClientHeader) && m.PwCHeader == map.PwCHeader).FirstOrDefault();
                if (newMap == null)
                {
                    map.DisplayOrder = 0;
                    continue;
                }

                map.CalculatorHeader = newMap.CalculatorHeader;
                map.CalculatorFormula = newMap.CalculatorFormula;
                map.ProcessType = newMap.ProcessType;
                map.SourceDocSectionId = await CopySourceDocSection(ax, dealId, newMap.SourceDocSectionId, refDocs, curDocs, curSections);
                map.DropdownCategoryId = await CopyDropDownCategory(ax, dealId, newMap.DropdownCategoryId, refCategory, curCategory);
                map.SourceId = await CopySource(ax, dealId, newMap.SourceId, refSources, curSources);
                map.DataFormatId = newMap.DataFormatId;
                map.FieldGuide = newMap.FieldGuide;
                map.ScreenShotId = await CopyScreenShot(ax, dealId, dealIdRef, newMap.ScreenShotId);
                map.LevelOfReview = Math.Min(deal.LevelOfReview, newMap.LevelOfReview);
                map.IsBlindReview = newMap.IsBlindReview;
                map.IsExcludedInReport = newMap.IsExcludedInReport;
                map.DisplayOrder = newMap.DisplayOrder;
                map.Threadhold = newMap.Threadhold;
                ax.Update(map.UpdateBy(ax.UserId));
            }

            // Reset display order after mapping
            var maps = curMaps.Where(m => m.DisplayOrder != 0).OrderBy(m => m.DisplayOrder)
                .Union(curMaps.Where(m => m.DisplayOrder == 0).OrderBy(m => m.ReportOrder)).ToArray();
            var count = 1;
            foreach (var map in maps)
            {
                map.DisplayOrder = count++;
                ax.Update(map);
            }

            await ax.Save();
        }

        private async Task<long> CopySource(DdsActionContext ax, long dealId, long SourceIdRef,
            List<Source> refSources, List<Source> curSources)
        {
            var refSD = refSources.Where(s => s.SourceId == SourceIdRef).First();
            var newId = curSources.Where(s => s.Name.ToLower() == refSD.Name.ToLower()).FirstOrDefault()?.SourceId;
            if (newId != null)
                return newId.Value;
            else
            {
                var newSD = ax.Add(new Source()
                {
                    DealId = dealId,
                    Name = refSD.Name,
                    DisplayOrder = curSources.Max(s => s.DisplayOrder) + 1,
                    IsActive = true
                }).CreateBy(ax.UserId);
                await ax.Save();
                curSources.Add(newSD);
                return newSD.SourceId;
            }
        }

        private async Task<long> CopySourceDocSection(DdsActionContext ax, long dealId, long SourceDocSectionIdRef,
            List<SourceDocSection> refDocs, List<SourceDocSection> curDocs, List<Section> curSections)
        {
            var refSD = refDocs.Where(s => s.SourceDocSectionId == SourceDocSectionIdRef).First();
            var curSD = curDocs.Where(s => s.Name.ToLower() == refSD.Name.ToLower()).FirstOrDefault();
            if (curSD != null)
            {
                if (curSD.IsActive == false)
                {
                    curSD.IsActive = true;
                    ax.Update(curSD.UpdateBy(ax.UserId));
                    await ax.Save();
                }
                return curSD.SourceDocSectionId;
            }
            else
            {
                var curSectionId = curSections.Where(c => c.Name.ToLower() == refSD.Section.Name.ToLower()).FirstOrDefault()?.SectionId;
                if (curSectionId == null)
                    curSectionId = curSections.First().SectionId;

                var curSectionMaxId = curDocs.Where(s => s.SectionId == curSectionId).Select(s => s.DisplayOrder).DefaultIfEmpty().Max();
                var newSD = ax.Add(new SourceDocSection()
                {
                    DealId = dealId,
                    SectionId = (long)curSectionId,
                    Name = refSD.Name,
                    DisplayOrder = curSectionMaxId + 1,
                    IsAllowCopy = refSD.IsAllowCopy,
                    IsActive = true
                }).CreateBy(ax.UserId);
                await ax.Save();
                curDocs.Add(newSD);
                return newSD.SourceDocSectionId;
            }
        }

        private async Task<long?> CopyDropDownCategory(DdsActionContext ax, long dealId, long? CategoryIdRef,
            List<DropdownCategory> refItems, List<DropdownCategory> curItems)
        {
            if (CategoryIdRef == null)
                return null;

            var refItem = refItems.Where(s => s.CategoryId == CategoryIdRef).First();
            var curItem = curItems.Where(s => s.CategoryName.ToLower() == refItem.CategoryName.ToLower()).FirstOrDefault();
            if (curItem != null)
            {
                if (curItem.IsActive == false)
                {
                    curItem.IsActive = true;
                    ax.Update(curItem.UpdateBy(ax.UserId));
                    await ax.Save();
                }
                return curItem.CategoryId;
            }
            else
            {
                var curMaxId = curItems.Select(s => s.DisplayOrder).DefaultIfEmpty().Max();
                var newSD = ax.Add(new DropdownCategory()
                {
                    DealId = dealId,
                    CategoryName = refItem.CategoryName,
                    DisplayOrder = curMaxId + 1,
                    IsActive = true
                }).CreateBy(ax.UserId);
                newSD.DropdownCategoryOptions = refItem.DropdownCategoryOptions
                    .Select(d => new DropdownCategoryOption()
                    {
                        DealId = dealId,
                        OptionName = d.OptionName,
                        DisplayOrder = d.DisplayOrder,
                        IsActive = d.IsActive
                    }.CreateBy(ax.UserId)).ToArray();

                await ax.Save();
                curItems.Add(newSD);
                return newSD.CategoryId;
            }
        }

        private async Task<long?> CopyScreenShot(DdsActionContext ax, long dealId, long dealIdRef, long? ScreenShotIdRef)
        {
            if (ScreenShotIdRef == null)
                return null;

            var screenShot = await ax.First<ScreenShot>(s => s.DealId == dealIdRef && s.ScreenShotId == ScreenShotIdRef);
            var newScreenShot = ax.Add(new ScreenShot()
            {
                DealId = dealId,
                Image = screenShot.Image
            });
            await ax.Save();
            return newScreenShot.ScreenShotId;
        }

        #endregion

        #region Import/Export Header Map
        public async Task<MemoryStream> DownloadHeaderMap(DdsActionContext ax, long dealId)
        {
            var templateFile = $"Templates/HeaderMapTemplate.xlsx";
            var wb = new ImportWorkBook();
            var memoryStream = new MemoryStream();
            try
            {
                //initail template
                wb.OpenExcel(templateFile);

                //load list
                wb.ActiveWorkSheet("List");
                var sourceDocs = await ax.Query<SourceDocSection>().Where(l => l.DealId == dealId && l.IsActive == true).Select(l => l.Name).ToArrayAsync();
                var sources = await ax.Query<Source>().Where(l => l.DealId == dealId && l.IsActive == true).Select(l => l.Name).ToArrayAsync();
                var categorys = await ax.Query<DropdownCategory>().Where(l => l.DealId == dealId && l.IsActive == true).Select(l => l.CategoryName).ToArrayAsync();
                var formats = await ax.Query<DataFormat>().OrderBy(f => f.DisplayOrder).Select(l => l.Name).ToArrayAsync();

                int columnIndex = wb.FindIndexByValue(0, 0, wb.WorkSheet.Cells.MaxColumn, HeaderMapData.SourceDocSection);
                if (columnIndex != -1 && sourceDocs.Any())
                    wb.WorkSheet.Cells.ImportArray(sourceDocs, 1, columnIndex, true);

                columnIndex = wb.FindIndexByValue(0, 0, wb.WorkSheet.Cells.MaxColumn, HeaderMapData.Source);
                if (columnIndex != -1 && sources.Any())
                    wb.WorkSheet.Cells.ImportArray(sources, 1, columnIndex, true);

                columnIndex = wb.FindIndexByValue(0, 0, wb.WorkSheet.Cells.MaxColumn, HeaderMapData.LookupCategory);
                if (columnIndex != -1 && categorys.Any())
                    wb.WorkSheet.Cells.ImportArray(categorys, 1, columnIndex, true);

                columnIndex = wb.FindIndexByValue(0, 0, wb.WorkSheet.Cells.MaxColumn, HeaderMapData.Format);
                if (columnIndex != -1 && formats.Any())
                    wb.WorkSheet.Cells.ImportArray(formats, 1, columnIndex, true);

                //load data
                wb.ActiveWorkSheet("Header Map");
                var headerList = await (from deal in ax.Query<DealSetup>()
                                        join header in ax.Query<HeaderMap>() on deal.DealId equals header.DealId into dh
                                        from dealHeader in dh.DefaultIfEmpty()
                                        join format in ax.Query<DataFormat>() on dealHeader.DataFormatId equals format.DataFormatId into ft
                                        from headerFormat in ft.DefaultIfEmpty()
                                        join source in ax.Query<Source>() on dealHeader.SourceId equals source.SourceId into ss
                                        from headerSource in ss.DefaultIfEmpty()
                                        join sourceDocSection in ax.Query<SourceDocSection>() on dealHeader.SourceDocSectionId equals sourceDocSection.SourceDocSectionId into sd
                                        from headerSourceDoc in sd.DefaultIfEmpty()
                                        join dropdownCategory in ax.Query<DropdownCategory>() on dealHeader.DropdownCategoryId equals dropdownCategory.CategoryId into dc
                                        from headerDropdown in dc.DefaultIfEmpty()
                                        where deal.DealId == dealId &&
                                              dealHeader.IsActive
                                        orderby dealHeader.DisplayOrder
                                        select new HeaderMapReportDTO
                                        {
                                            DisplayOrder = dealHeader.DisplayOrder,
                                            ClientHeader = dealHeader.ClientHeader,
                                            PwCHeader = dealHeader.PwCHeader,
                                            CalculatorHeader = dealHeader.CalculatorHeader,
                                            Formula = dealHeader.CalculatorFormula,
                                            ProcessType = dealHeader.ProcessType,
                                            SourceDocSection = headerSourceDoc.Name,
                                            Source = headerSource.Name,
                                            DataFormat = headerFormat.Name,
                                            Threadhold = dealHeader.Threadhold,
                                            DropdownCategory = headerDropdown.CategoryName,
                                            FieldGuide = dealHeader.FieldGuide,
                                            LevelOfReview = dealHeader.LevelOfReview,
                                            IsBlindReview = dealHeader.IsBlindReview,
                                            IsExcludedInReport = dealHeader.IsExcludedInReport,
                                            HasScreenShot = dealHeader.ScreenShotId == null ? false : true
                                        }).ToArrayAsync();

                int rowIndex = 2;
                foreach (var header in headerList)
                {
                    wb.SetText("A" + rowIndex.ToString(), header.ClientHeader ?? string.Empty).SetAllBorder();
                    wb.SetText("B" + rowIndex.ToString(), header.PwCHeader ?? string.Empty).SetAllBorder();
                    wb.SetText("C" + rowIndex.ToString(), header.CalculatorHeader ?? string.Empty).SetAllBorder();
                    wb.SetText("D" + rowIndex.ToString(), header.Formula ?? string.Empty).SetAllBorder();
                    wb.SetText("E" + rowIndex.ToString(), header.ProcessType ?? string.Empty).SetAllBorder();
                    if (header.ProcessType == ProcessType.Provided.GetDisplayName() ||
                        header.ProcessType == ProcessType.Calculation.GetDisplayName() ||
                        header.ProcessType == ProcessType.PassThrough.GetDisplayName())
                    {
                        wb.SetText("F" + rowIndex.ToString(), string.Empty).SetAllBorder();
                        wb.SetText("G" + rowIndex.ToString(), string.Empty).SetAllBorder();
                    }
                    else
                    {
                        wb.SetText("F" + rowIndex.ToString(), header.SourceDocSection ?? string.Empty).SetAllBorder();
                        wb.SetText("G" + rowIndex.ToString(), header.Source ?? string.Empty).SetAllBorder();
                    }
                    wb.SetTextWithoutAutoFormat("H" + rowIndex.ToString(), header.DataFormat ?? string.Empty, "General").SetAllBorder();
                    if (header.DataFormat == Constent.DF_Text)
                        wb.SetText("I" + rowIndex.ToString(), string.Empty).SetAllBorder();
                    else
                        wb.SetText("I" + rowIndex.ToString(), header.Threadhold).SetAllBorder();
                    wb.SetText("J" + rowIndex.ToString(), header.DropdownCategory ?? string.Empty).SetAllBorder();
                    wb.SetText("K" + rowIndex.ToString(), header.FieldGuide ?? string.Empty).SetAllBorder();
                    wb.SetText("L" + rowIndex.ToString(), header.LevelOfReview).SetAllBorder();
                    wb.SetText("M" + rowIndex.ToString(), header.IsBlindReview).SetAllBorder();
                    wb.SetText("N" + rowIndex.ToString(), header.IsExcludedInReport).SetAllBorder();
                    wb.SetText("O" + rowIndex.ToString(), header.HasScreenShot).SetAllBorder();
                    rowIndex++;
                }

                //save into memory stream
                WorkbookDesigner workbookDesigner = new WorkbookDesigner(wb.WorkBook);
                workbookDesigner.Workbook.Save(memoryStream, SaveFormat.Xlsx);
                memoryStream.Position = 0;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when downloading header map. " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return memoryStream;
        }

        public async Task<object?> ImportHeaderMap(DdsActionContext ax, ImportHeaderMapDataDTO importInfo)
        {
            bool exception = false;
            var expFileName = importInfo.DealId + "_" + DateTime.Now.Ticks + "_HeaderMap_ExceptionList.xlsx";
            DataTable tblHeaderMapErrors = new DataTable();

            try
            {
                // Load Key Columns
                var sheetType = Constent.HeaderMap + "Data";
                var columns = DataLoader.GetFieldsList(sheetType);
                var keyColumns = new string[] { HeaderMapData.ClientHeader };

                // Load data from import excel
                var userTmpData = LoadDataFromFile(importInfo.File, importInfo.SheetName, columns, keyColumns);
                if (userTmpData != null && userTmpData.Count > 0)
                {
                    tblHeaderMapErrors = userTmpData[0].SheetData_av.Clone();
                    if (!tblHeaderMapErrors.Columns.Contains(Constent.ErrorMessage))
                        tblHeaderMapErrors.Columns.Add(Constent.ErrorMessage);

                    var validateException = await ValidateInputHeaderMap(ax, importInfo.DealId, userTmpData[0].SheetData_av, tblHeaderMapErrors);
                    var updateException = await UpdateHeaderMap(ax, importInfo.DealId, userTmpData[0].SheetData_av, tblHeaderMapErrors);
                    exception = validateException || updateException;

                    await _deal.ResetNeedRecalculatation(ax, importInfo.DealId);
                }
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException(ex.Message);
            }
            finally
            {
                if (tblHeaderMapErrors.Rows.Count > 0)
                    InsertExceptionList(tblHeaderMapErrors, expFileName);
            }

            return new
            {
                statusMsg = exception ? string.Empty : "Import Successfully",
                ExceptionFile = exception ? expFileName : string.Empty
            };
        }

        public async Task<MemoryStream> DownloadHeaderMapException(DdsActionContext ax, string fileName)
        {
            var wb = new ImportWorkBook();
            var memoryStream = new MemoryStream();

            try
            {
                var expFilePath = $"Tmp" + Path.DirectorySeparatorChar.ToString() + fileName;
                wb.OpenExcel(expFilePath);
                WorkbookDesigner workbookDesigner = new WorkbookDesigner(wb.WorkBook);
                workbookDesigner.Workbook.Save(memoryStream, SaveFormat.Xlsx);
                memoryStream.Position = 0;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when downloading header map exception. " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return memoryStream;
        }

        #region import validate & exception

        private List<ImportWorkSheet> LoadDataFromFile(IFormFile file, string sheetName, string[] columns, string[] keyColumns)
        {
            var wb = new ImportWorkBook();
            try
            {
                using (var stream = new MemoryStream())
                {
                    file.CopyTo(stream);
                    wb.OpenExcel(stream);
                }
                wb.SheetList = new List<ImportWorkSheet>();
                wb.SheetList.Add(new ImportWorkSheet(sheetName, columns));
                wb.CheckSheets();
                wb.CheckColumns();
                wb.ReadExcel(keyColumns);
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when loading " + sheetName + ". " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return wb.SheetList;
        }

        private async Task<bool> ValidateInputHeaderMap(DdsActionContext ax, long dealId, DataTable tblHeaderMaps, DataTable tblHeaderMapErrors)
        {
            bool bError;
            string errMsg;
            bool bReturn = false;
            if (tblHeaderMaps != null)
            {
                var existMaps = await ax.Query<HeaderMap>().Where(m => m.DealId == dealId && !string.IsNullOrEmpty(m.ClientHeader) && m.IsActive == true)
                                                           .Select(m => m.ClientHeader).Distinct().ToArrayAsync();

                for (int i = 0; i < tblHeaderMaps.Rows.Count; i++)
                {
                    bError = false;
                    errMsg = string.Empty;
                    DataRow rowHeaderMapData = tblHeaderMaps.Rows[i];

                    if (!existMaps.Contains(rowHeaderMapData[HeaderMapData.ClientHeader].ToString()?.Trim()))
                    {
                        bError = true;
                        errMsg = "Client Header not exist.  ";
                    }

                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.PwCHeader, ref errMsg, false, false, false, 200) || bError;
                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.CalculatorHeader, ref errMsg, false, false, false, 200) || bError;
                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.ProcessType, ref errMsg, false, false, false, 20) || bError;
                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.SourceDocSection, ref errMsg, false, false, false, 200) || bError;
                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.Source, ref errMsg, false, false, false, 200) || bError;
                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.Format, ref errMsg, true, false, false, 100) || bError;
                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.Threadhold, ref errMsg, false, true, false, 0) || bError;
                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.LookupCategory, ref errMsg, false, false, false, 200) || bError;
                    bError = ValidateObject(rowHeaderMapData, HeaderMapData.FieldGuide, ref errMsg, false, false, false, 2000) || bError;

                    if (rowHeaderMapData[HeaderMapData.LevelOfReview].ToString() != "1" &&
                        rowHeaderMapData[HeaderMapData.LevelOfReview].ToString() != "2" &&
                        rowHeaderMapData[HeaderMapData.LevelOfReview].ToString() != "3")
                    {
                        bError = true;
                        errMsg += HeaderMapData.LevelOfReview + ": " + rowHeaderMapData[HeaderMapData.LevelOfReview].ToString() + " is invalid, the valid values are 1,2,3.  ";
                    }

                    var type = new ProcessType();
                    var processTypes = EnumHelper<ProcessType>.GetDisplayValues(type).ToArray();
                    if (!processTypes.Contains(rowHeaderMapData[HeaderMapData.ProcessType].ToString()))
                    {
                        bError = true;
                        errMsg += HeaderMapData.ProcessType + ": " + rowHeaderMapData[HeaderMapData.ProcessType].ToString() + " is invalid.  ";
                    }

                    if (rowHeaderMapData[HeaderMapData.ProcessType].ToString() == ProcessType.Calculation.GetDisplayName() &&
                        string.IsNullOrEmpty(rowHeaderMapData[HeaderMapData.CalculatorHeader].ToString()))
                    {
                        bError = true;
                        errMsg += HeaderMapData.CalculatorHeader + ": " + "Calculator Header is mandatory when process type is " + rowHeaderMapData[HeaderMapData.ProcessType].ToString() + ".  ";
                    }

                    if (!string.IsNullOrEmpty(rowHeaderMapData[HeaderMapData.CalculatorHeader].ToString()))
                    {
                        var calculatorHeaderRegex = new Regex("^[a-zA-Z_][a-zA-Z0-9_]*$");
                        if (!calculatorHeaderRegex.IsMatch(rowHeaderMapData[HeaderMapData.CalculatorHeader].ToString()))
                        {
                            bError = true;
                            errMsg += HeaderMapData.CalculatorHeader + ": " + rowHeaderMapData[HeaderMapData.CalculatorHeader].ToString() + " is invalid.  ";
                        }
                    }

                    if (rowHeaderMapData[HeaderMapData.BlindReview].ToString() != "True" &&
                        rowHeaderMapData[HeaderMapData.BlindReview].ToString() != "False")
                    {
                        bError = true;
                        errMsg += HeaderMapData.BlindReview + ": " + rowHeaderMapData[HeaderMapData.BlindReview].ToString() + " is invalid, the valid values are True and False.  ";
                    }

                    if (rowHeaderMapData[HeaderMapData.ExcludedInExceptionReport].ToString() != "True" &&
                        rowHeaderMapData[HeaderMapData.ExcludedInExceptionReport].ToString() != "False")
                    {
                        bError = true;
                        errMsg += HeaderMapData.ExcludedInExceptionReport + ": " + rowHeaderMapData[HeaderMapData.ExcludedInExceptionReport].ToString() + " is invalid, the valid values are True and False.  ";
                    }

                    if (bError)
                    {
                        InsertExceptionRow(tblHeaderMapErrors, rowHeaderMapData, errMsg);
                        tblHeaderMaps.Rows.Remove(rowHeaderMapData);
                        i--;
                        bReturn = true;
                        continue;
                    }
                }
            }

            return bReturn;
        }

        private async Task<bool> UpdateHeaderMap(DdsActionContext ax, long dealId, DataTable tblHeaderMaps, DataTable tblHeaderMapErrors)
        {
            bool bReturn = false;
            var dealSetup = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId && d.IsActive == true);
            var existMaps = await ax.Query<HeaderMap>().Where(m => m.DealId == dealId && !string.IsNullOrEmpty(m.ClientHeader) && m.IsActive == true).ToArrayAsync();
            var sources = await ax.Query<Source>().Where(l => l.DealId == dealId && l.IsActive == true).ToArrayAsync();
            var sourceDocs = await ax.Query<SourceDocSection>().Where(l => l.DealId == dealId && l.IsActive == true).ToArrayAsync();
            var categorys = await ax.Query<DropdownCategory>().Where(l => l.DealId == dealId && l.IsActive == true).ToArrayAsync();
            var formats = await ax.Query<DataFormat>().OrderBy(f => f.DisplayOrder).ToArrayAsync();

            // Update header maps
            var rowsHeaderMap = tblHeaderMaps.AsEnumerable().ToArray();
            var reCompareHeaderMaps = new List<HeaderMap>();
            foreach (var map in existMaps)
            {
                var newMap = rowsHeaderMap.Where(m => m[HeaderMapData.ClientHeader].ToString()?.Trim() == map.ClientHeader).FirstOrDefault();
                if (newMap == null)
                    continue;

                bool bError = false;
                bool bWarning = false;
                string errMsg = string.Empty;
                var orgDataFormatId = map.DataFormatId;
                var orgThreadhold = map.Threadhold;
                var orgLevelOfReview = map.LevelOfReview;
                var orgProcessType = map.ProcessType;

                map.PwCHeader = newMap[HeaderMapData.PwCHeader].ToString()?.Trim();
                map.CalculatorHeader = newMap[HeaderMapData.CalculatorHeader].ToString()?.Trim();
                map.ProcessType = newMap[HeaderMapData.ProcessType].ToString();

                // SourceDocSectionId
                if (map.ProcessType == ProcessType.Provided.GetDisplayName() ||
                    map.ProcessType == ProcessType.Calculation.GetDisplayName() ||
                    map.ProcessType == ProcessType.PassThrough.GetDisplayName())
                {
                    map.SourceDocSectionId = sourceDocs.Min(s => s.SourceDocSectionId);
                    if (!string.IsNullOrEmpty(newMap[HeaderMapData.SourceDocSection].ToString()?.Trim()))
                    {
                        errMsg += "Warning: " + HeaderMapData.SourceDocSection + ": " + newMap[HeaderMapData.SourceDocSection].ToString() + " is ignored since ProcessType is " + newMap[HeaderMapData.ProcessType].ToString() + ".  ";
                        bWarning = true;
                    }
                }
                else
                {
                    map.SourceDocSectionId = sourceDocs.Where(s => s.Name == newMap[HeaderMapData.SourceDocSection].ToString()?.Trim()).FirstOrDefault()?.SourceDocSectionId ?? 0;
                    if (map.SourceDocSectionId == 0)
                    {
                        errMsg += HeaderMapData.SourceDocSection + ": " + newMap[HeaderMapData.SourceDocSection].ToString() + " is invalid.  ";
                        bError = true;
                    }
                }

                // SourceId
                if (map.ProcessType == ProcessType.Provided.GetDisplayName() ||
                    map.ProcessType == ProcessType.Calculation.GetDisplayName() ||
                    map.ProcessType == ProcessType.PassThrough.GetDisplayName())
                {
                    map.SourceId = sources.Min(s => s.SourceId);
                    if (!string.IsNullOrEmpty(newMap[HeaderMapData.Source].ToString()?.Trim()))
                    {
                        errMsg += "Warning: " + HeaderMapData.Source + ": " + newMap[HeaderMapData.Source].ToString() + " is ignored since ProcessType is " + newMap[HeaderMapData.ProcessType].ToString() + ".  ";
                        bWarning = true;
                    }
                }
                else
                {
                    map.SourceId = sources.Where(s => s.Name == newMap[HeaderMapData.Source].ToString()?.Trim()).FirstOrDefault()?.SourceId ?? 0;
                    if (map.SourceId == 0)
                    {
                        errMsg += HeaderMapData.Source + ": " + newMap[HeaderMapData.Source].ToString() + " is invalid.  ";
                        bError = true;
                    }
                }

                // DataFormatId
                map.DataFormatId = formats.Where(s => s.Name == newMap[HeaderMapData.Format].ToString()?.Trim()).FirstOrDefault()?.DataFormatId ?? 0;
                if (map.DataFormatId == 0)
                {
                    errMsg += HeaderMapData.Format + ": " + newMap[HeaderMapData.Format].ToString() + " is invalid.  ";
                    bError = true;
                }

                // DropdownCategoryId
                if (string.IsNullOrEmpty(newMap[HeaderMapData.LookupCategory].ToString()?.Trim()))
                    map.DropdownCategoryId = null;
                else
                {
                    if (newMap[HeaderMapData.Format].ToString()?.Trim() != Constent.DF_Text)
                    {
                        errMsg += "Warning: " + HeaderMapData.LookupCategory + ": " + newMap[HeaderMapData.LookupCategory].ToString() + " is ignored since Format is not Text.  ";
                        bWarning = true;
                        map.DropdownCategoryId = null;
                    }
                    else
                    {
                        map.DropdownCategoryId = categorys.Where(s => s.CategoryName == newMap[HeaderMapData.LookupCategory].ToString()?.Trim()).FirstOrDefault()?.CategoryId;
                        if (map.DropdownCategoryId == null)
                        {
                            errMsg += HeaderMapData.LookupCategory + ": " + newMap[HeaderMapData.LookupCategory].ToString() + " is invalid.  ";
                            bError = true;
                        }
                    }
                }

                // Threadhold
                if (string.IsNullOrEmpty(newMap[HeaderMapData.Threadhold].ToString()) || newMap[HeaderMapData.Threadhold].ToString() == "0")
                    map.Threadhold = 0;
                else
                {
                    if (newMap[HeaderMapData.Format].ToString()?.Trim() == Constent.DF_Text)
                    {
                        errMsg += "Warning: " + HeaderMapData.Threadhold + ": " + newMap[HeaderMapData.Threadhold].ToString() + " is ignored since Format is Text.  ";
                        bWarning = true;
                        map.Threadhold = 0;
                    }
                    else
                        map.Threadhold = Convert.ToDecimal(newMap[HeaderMapData.Threadhold].ToString());
                }

                map.FieldGuide = newMap[HeaderMapData.FieldGuide].ToString()?.Trim();
                map.LevelOfReview = Math.Min(dealSetup.LevelOfReview, Convert.ToInt32(newMap[HeaderMapData.LevelOfReview].ToString()));
                map.IsBlindReview = newMap[HeaderMapData.BlindReview].ToString() == "True" ? true : false;
                map.IsExcludedInReport = newMap[HeaderMapData.ExcludedInExceptionReport].ToString() == "True" ? true : false;

                if (bError || bWarning)
                {
                    InsertExceptionRow(tblHeaderMapErrors, newMap, errMsg);
                    bReturn = true;

                    if (bError)
                        continue;
                }

                //check if settings are changed for the review fields
                if (map.ProcessType == ProcessType.Review.GetDisplayName() ||
                    map.ProcessType == ProcessType.ReviewAttribute.GetDisplayName() ||
                    map.ProcessType == ProcessType.ReviewCalculation.GetDisplayName())
                {
                    map.CalculatorFormula = null;
                    if (map.DataFormatId != orgDataFormatId || map.Threadhold != orgThreadhold || map.LevelOfReview != orgLevelOfReview || map.ProcessType != orgProcessType)
                        reCompareHeaderMaps.Add(map);
                }
                ax.Update(map.UpdateBy(ax.UserId));
            }

            //Re-Calc FinalValue & Re-Compare client and PwC value
            foreach (var headerMap in reCompareHeaderMaps)
            {
                var dataFormat = formats.FirstOrDefault(d => d.DataFormatId == headerMap.DataFormatId);
                var loanReviews = await ax.Query<LoanReview>().Where(m => m.DealId == dealId && m.HeaderMapId == headerMap.HeaderMapId).ToArrayAsync();
                var levelOfReview = Math.Min(dealSetup.LevelOfReview, headerMap.LevelOfReview);
                var isPwCHeader = string.IsNullOrEmpty(headerMap.ClientHeader);
                foreach (var loanReview in loanReviews)
                {
                    if (loanReview.IsFirstReviewed || loanReview.IsSecondReviewed || loanReview.IsThirdReviewed)
                    {
                        loanReview.FinalValue = ReCalcFinalValue(loanReview, levelOfReview);
                        loanReview.IsTie = ConvertExtension.ToCompareClientAndPwCValue(loanReview.ClientDisplayValue, loanReview.ClientValue, loanReview.FinalValue, dataFormat?.Type, dataFormat?.Format, headerMap.Threadhold, isPwCHeader);
                    }
                    else 
                    {
                        loanReview.FinalValue = null;
                        loanReview.IsTie = null;
                    }
                    ax.Update(loanReview.UpdateBy(ax.UserId));
                }
            }

            await ax.Save();

            return bReturn;
        }

        private string ReCalcFinalValue(LoanReview loanReview, int levelOfReview)
        {
            var finalValue = loanReview.FirstReviewValue;
            if (levelOfReview == 3)
            {
                if (loanReview.IsThirdReviewed)
                {
                    finalValue = loanReview.ThirdReviewValue;
                }
                else if (loanReview.IsSecondReviewed)
                {
                    finalValue = loanReview.SecondReviewValue;
                }
            }
            else if (levelOfReview == 2)
            {
                //loanReview.ThirdReviewValue = string.Empty;
                //loanReview.IsThirdReviewed = false;
                //loanReview.ThirdReviewFormula = string.Empty;

                if (loanReview.IsSecondReviewed)
                {
                    finalValue = loanReview.SecondReviewValue;
                }
            }

            return finalValue;
        }

        private bool ValidateObject(DataRow row, string colName, ref string ErrMsg, bool bNotNull, bool bNumber, bool bHasDefaultNumber, int length)
        {
            bool bError = false;

            if (bNotNull && row[colName].ToString()?.Trim() == "")
            {
                bError = true;
                ErrMsg += colName + " is null.  ";
            }

            if (!bError && bNumber)
            {
                double dNumber;
                decimal dec;
                if (row[colName].ToString() == "")
                {
                    if (bHasDefaultNumber)
                        row[colName] = 0;
                }
                else if (row[colName].ToString() == "-")
                {
                    row[colName] = 0;
                }
                else if (row[colName].ToString() == "NaN")
                {
                    if (bHasDefaultNumber)
                        row[colName] = 0;
                    else
                        row[colName] = null;
                }
                else if (!double.TryParse(row[colName].ToString(), out dNumber) && !decimal.TryParse(row[colName].ToString(), out dec))
                {
                    if (double.TryParse(row[colName].ToString()?.Replace("%", ""), out dNumber))
                        row[colName] = dNumber / 100;
                    else
                    {
                        bError = true;
                        ErrMsg += colName + ": " + row[colName].ToString() + " is not numeric.  ";
                    }
                }
            }

            if (!bError && length > 0 && row[colName].ToString()?.Trim().Length > length)
            {
                bError = true;
                ErrMsg += colName + ": " + " length should be less than " + length + ".  ";
            }
            return bError;
        }

        private void InsertExceptionRow(DataTable tblDataError, DataRow rowException, string errMsg)
        {
            var dr = tblDataError.NewRow();
            foreach (DataColumn col in tblDataError.Columns)
            {
                if (col.ColumnName == Constent.ErrorMessage)
                    dr[Constent.ErrorMessage] = errMsg;
                else
                    dr[col.ColumnName] = rowException[col.ColumnName];
            }
            tblDataError.Rows.Add(dr);
        }

        private void InsertExceptionList(DataTable tblDataError, string expFileName)
        {
            var expFilePath = $"Tmp" + Path.DirectorySeparatorChar.ToString() + expFileName;
            var wb = new ImportWorkBook();
            try
            {
                wb.OpenExcel();
                var ws = wb.CreateWorkSheet("Header Map");
                ws.Cells.ImportData(tblDataError, 0, 0, new ImportTableOptions());

                var maxCol = ws.Cells.MaxColumn;
                wb.SetColumsWidth(0, maxCol, 28);
                var header = wb.getRange(0, 0, 0, maxCol);
                Style style = header.GetCellOrNull(0, 0).GetStyle();
                style.Font.IsBold = true;
                header.SetStyle(style);

                wb.SaveExcel(expFilePath);
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when generating exception list. " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
        }

        #endregion

        #endregion

        #region Fields Settings
        public async Task<string[]> GetProcessType(DdsActionContext ax)
        {
            var type = new ProcessType();
            var data = EnumHelper<ProcessType>.GetDisplayValues(type).ToArray();
            return data;
        }

        public async Task<SourceDTO[]> GetSource(DdsActionContext ax, long dealId)
        {
            var data = await ax.Query<Source>().Where(l => l.DealId == dealId && l.IsActive == true)
                .Include(l => l.HeaderMaps)
                .Select(l => new SourceDTO
                {
                    DisplayOrder = l.DisplayOrder,
                    Name = l.Name,
                    SourceId = l.SourceId,
                    IsDeleteable = !l.HeaderMaps.Any()
                })
                .OrderBy(l => l.DisplayOrder).ToArrayAsync();
            return data;
        }

        public async Task UpdateSource(DdsActionContext ax, long dealId, SourceDTO[] sources)
        {
            var existSDS = await ax.Query<Source>().Where(l => l.DealId == dealId).ToArrayAsync();
            var allIds = sources.Select(e => e.SourceId).ToArray();

            // Delete missing entry
            var deleteSDS = existSDS.Where(s => !allIds.Any(e => e == s.SourceId)).ToArray();
            ax.RemoveRange(deleteSDS);

            // Add new entry
            var newSDS = ax.Mapper.Map<Source[]>(sources.Where(s => s.SourceId == 0));
            foreach (var sds in newSDS)
            {
                sds.DealId = dealId;
                sds.IsActive = true;
                sds.CreateBy(ax.UserId);
            }
            ax.AddRange(newSDS);

            // Update entry
            var updateSDS = existSDS.Where(s => allIds.Any(e => e == s.SourceId)).ToArray();
            foreach (var sds in updateSDS)
            {
                var data = sources.Where(s => s.SourceId == sds.SourceId).FirstOrDefault();
                sds.Name = data.Name;
                sds.DisplayOrder = data.DisplayOrder;
                sds.UpdateBy(ax.UserId);
            }
            ax.UpdateRange(updateSDS);
            await ax.Save();
        }

        public async Task<SourceDocSectionDTO[]> GetSourceDocSection(DdsActionContext ax, long dealId)
        {
            var data = await ax.Query<SourceDocSection>().Where(l => l.DealId == dealId && l.IsActive == true)
                .Include(l => l.HeaderMaps)
                .Select(l => new SourceDocSectionDTO
                {
                    DisplayOrder = l.DisplayOrder,
                    SourceDocSectionId = l.SourceDocSectionId,
                    SectionId = l.SectionId,
                    Name = l.Name,
                    IsAllowCopy = l.IsAllowCopy,
                    IsDeleteable = !l.HeaderMaps.Any()
                })
                .OrderBy(l => l.SectionId).ThenBy(l => l.DisplayOrder).ToArrayAsync();
            return data;
        }

        public async Task UpdateSourceDocSection(DdsActionContext ax, long dealId, SourceDocSectionDTO[] sourceDocSections)
        {
            var existSDS = await ax.Query<SourceDocSection>().Where(l => l.DealId == dealId).ToArrayAsync();
            var allIds = sourceDocSections.Select(e => e.SourceDocSectionId).ToArray();

            // Delete missing entry
            var deleteSDS = existSDS.Where(s => !allIds.Any(e => e == s.SourceDocSectionId)).ToArray();
            ax.RemoveRange(deleteSDS);

            // Add new entry
            var newSDS = ax.Mapper.Map<SourceDocSection[]>(sourceDocSections.Where(s => s.SourceDocSectionId == 0));
            foreach (var sds in newSDS)
            {
                sds.DealId = dealId;
                sds.IsActive = true;
                sds.CreateBy(ax.UserId);
            }
            ax.AddRange(newSDS);

            // Update entry
            var updateSDS = existSDS.Where(s => allIds.Any(e => e == s.SourceDocSectionId)).ToArray();
            foreach (var sds in updateSDS)
            {
                var data = sourceDocSections.Where(s => s.SourceDocSectionId == sds.SourceDocSectionId).FirstOrDefault();
                sds.Name = data.Name;
                sds.SectionId = data.SectionId;
                sds.DisplayOrder = data.DisplayOrder;
                sds.IsAllowCopy = data.IsAllowCopy;
                sds.UpdateBy(ax.UserId);
            }
            ax.UpdateRange(updateSDS);
            await ax.Save();
        }

        public async Task<DropdownCategoryDTO[]> GetDropdownCategory(DdsActionContext ax, long dealId)
        {
            var usedCategory = await ax.Query<HeaderMap>().Where(l => l.DealId == dealId).Select(l => l.DropdownCategoryId).Distinct().ToListAsync();
            var categorys = await ax.Query<DropdownCategory>().Where(l => l.DealId == dealId && l.IsActive == true)
                .Include(l => l.DropdownCategoryOptions).OrderBy(c => c.DisplayOrder).ToArrayAsync();
            var result = ax.Mapper.Map<DropdownCategoryDTO[]>(categorys);
            foreach (var category in result)
            {
                if (usedCategory.Any(c => c == category.CategoryId))
                    category.IsDeleteable = false;
                else
                    category.IsDeleteable = true;
            }
            return result;
        }

        public async Task UpdateDropdownCategory(DdsActionContext ax, long dealId, DropdownCategoryDTO[] dropdownCategorys)
        {
            var curDBCategorys = await ax.Query<DropdownCategory>().Where(l => l.DealId == dealId).Include(l => l.DropdownCategoryOptions).ToArrayAsync();
            var newCategorys = ax.Mapper.Map<DropdownCategory[]>(dropdownCategorys);

            // Delete missing category
            var newCategoryIds = newCategorys.Select(e => e.CategoryId).ToArray();
            var deleteDBCategorys = curDBCategorys.Where(s => !newCategoryIds.Any(e => e == s.CategoryId)).ToArray();
            ax.RemoveRange(deleteDBCategorys);

            // Add new category
            var newCGs = newCategorys.Where(s => s.CategoryId == 0);
            foreach (var category in newCGs)
            {
                category.DealId = dealId;
                category.IsActive = true;
                category.CreateBy(ax.UserId);
                foreach (var option in category.DropdownCategoryOptions)
                {
                    var newOption = ax.Mapper.Map<DropdownCategoryOption>(option);
                    newOption.DealId = dealId;
                    newOption.IsActive = true;
                    newOption.CreateBy(ax.UserId);
                }
                ax.Add(category);
            }

            // Update category
            var updateDBCGs = curDBCategorys.Where(s => newCategoryIds.Any(e => e == s.CategoryId)).ToArray();
            foreach (var category in updateDBCGs)
            {
                var newCategory = newCategorys.Where(s => s.CategoryId == category.CategoryId).FirstOrDefault();
                category.CategoryName = newCategory.CategoryName;
                category.DisplayOrder = newCategory.DisplayOrder;
                category.UpdateBy(ax.UserId);

                #region update category options
                var dbOptions = category.DropdownCategoryOptions.ToArray();
                var newOptions = ax.Mapper.Map<DropdownCategoryOption[]>(newCategory.DropdownCategoryOptions.ToArray());

                // Delete missing category options
                var newOptionIds = newOptions.Select(e => e.CategoryOptionId).ToArray();
                var deleteDBOptions = dbOptions.Where(s => !newOptionIds.Any(e => e == s.CategoryOptionId)).ToArray();
                ax.RemoveRange(deleteDBOptions);

                // Update category options
                var updateDBOptions = dbOptions.Where(s => newOptionIds.Any(e => e == s.CategoryOptionId)).ToArray();
                foreach (var option in updateDBOptions)
                {
                    var newOption = newOptions.Where(s => s.CategoryOptionId == option.CategoryOptionId).FirstOrDefault();
                    option.OptionName = newOption.OptionName;
                    option.DisplayOrder = newOption.DisplayOrder;
                    option.UpdateBy(ax.UserId);
                }

                // Add new category options
                var newDBOptions = newOptions.Where(e => e.CategoryOptionId == 0);
                foreach (var newOption in newDBOptions)
                {
                    newOption.DealId = dealId;
                    newOption.IsActive = true;
                    newOption.CategoryId = category.CategoryId;
                    newOption.CreateBy(ax.UserId);
                    ax.Add(newOption);
                }
                #endregion
            }
            ax.UpdateRange(updateDBCGs);
            await ax.Save();
        }

        public async Task<DataFormatDTO[]> GetDataFormat(DdsActionContext ax)
        {
            var data = await ax.Query<DataFormat>().OrderBy(f => f.DisplayOrder).ToArrayAsync();
            var usedFormatIds = await ax.Query<HeaderMap>().Select(s => s.DataFormatId).Distinct().ToArrayAsync();
            data.Where(d => d.IsEditable && usedFormatIds.Contains(d.DataFormatId)).ToList().ForEach(f => f.IsEditable = false);
            return ax.Mapper.Map<DataFormatDTO[]>(data);
        }

        public async Task UpdateDataFormat(DdsActionContext ax, DataFormatDTO[] dataFormats)
        {
            var curDBAllDataFormats = await ax.Query<DataFormat>().ToArrayAsync();
            var usedFormatIds = await ax.Query<HeaderMap>().Select(s => s.DataFormatId).Distinct().ToArrayAsync();

            // If Editable = true but already used by header map, these kind of data should be filtered out as they can not be deleted or updated
            var curDBDataFormats = curDBAllDataFormats.Where(f => f.IsEditable && !usedFormatIds.Contains(f.DataFormatId));
            var newDataFormatIds = dataFormats.Select(e => e.DataFormatId).ToArray();

            // Delete missing data format
            var deleteDBFormats = curDBDataFormats.Where(s => !newDataFormatIds.Any(e => e == s.DataFormatId)).ToArray();
            ax.RemoveRange(deleteDBFormats);

            // Add new data format
            var newFormats = ax.Mapper.Map<DataFormat[]>(dataFormats.Where(s => s.DataFormatId == 0));
            foreach (var format in newFormats)
            {
                format.IsEditable = true;
                format.CreateBy(ax.UserId);
                ax.Add(format);
            }

            // Update data format
            var updateDBFormatIds = curDBDataFormats.Where(s => newDataFormatIds.Any(e => e == s.DataFormatId)).Select(d => d.DataFormatId).ToArray();
            var updatedDataFormatList = new List<DataFormat>();
            foreach (var format in curDBAllDataFormats)
            {
                var newFormat = dataFormats.Where(s => s.DataFormatId == format.DataFormatId).FirstOrDefault();
                if (newFormat == null)
                    continue;

                // The records that can be edited
                if (updateDBFormatIds.Any(id => id == format.DataFormatId))
                {
                    format.Name = newFormat.Name;
                    format.Type = newFormat.Type;
                    format.Code = newFormat.Code;
                    format.Format = newFormat.Format;
                    format.DisplayOrder = newFormat.DisplayOrder;
                    format.UpdateBy(ax.UserId);

                    updatedDataFormatList.Add(format);
                }
                else
                {
                    // The records that can not be editable -- if the display order has been changed, then update as well
                    if (format.DisplayOrder != newFormat.DisplayOrder)
                    {
                        format.DisplayOrder = newFormat.DisplayOrder;
                        format.UpdateBy(ax.UserId);

                        updatedDataFormatList.Add(format);
                    }
                }
            }
            ax.UpdateRange(updatedDataFormatList.ToArray());
            await ax.Save();
        }

        public async Task<long> UploadScreenShot(DdsActionContext ax, ImageInfo imgInfo)
        {
            if (imgInfo.Image.Length == 0)
                throw new DdsInvalidOperationException("invalid screen shot");

            using (var ms = new MemoryStream())
            {
                imgInfo.Image.CopyTo(ms);
                var img = new ScreenShot()
                {
                    DealId = imgInfo.DealId,
                    Image = ms.ToArray()
                };

                var data = ax.Add(img);
                await ax.Save();

                return data.ScreenShotId;
            }
        }

        public async Task<byte[]?> DownloadScreenShot(DdsActionContext ax, long screenShotId)
        {
            var img = await ax.Query<ScreenShot>().Where(s => s.ScreenShotId == screenShotId).Select(s => s.Image).FirstOrDefaultAsync() ??
                throw new DdsInvalidOperationException("invalid screen shot id");
            return img;
        }
        #endregion
    }
}
