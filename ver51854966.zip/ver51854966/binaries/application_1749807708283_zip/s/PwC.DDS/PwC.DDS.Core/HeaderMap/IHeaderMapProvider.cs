﻿using Microsoft.AspNetCore.Http;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Core
{
    public interface IHeaderMapProvider
    {
        Task<DealHeaderMapDTO> GetDealHeaderMap(DdsActionContext ax, long dealId);
        Task<HeaderMapDTO> CreateHeaderMap(DdsActionContext ax, long dealId, HeaderMapDTO headerMap);
        Task<MemoryStream> DownloadHeaderMap(DdsActionContext ax, long dealId);
        Task<object?> ImportHeaderMap(DdsActionContext ax, ImportHeaderMapDataDTO importInfo);
        Task<MemoryStream> DownloadHeaderMapException(DdsActionContext ax, string filePath);
        Task UpdateDealHeaderMap(DdsActionContext ax, long dealId, HeaderMapDTO[] headerMaps);
        Task CopyHeaderMap(DdsActionContext ax, long dealId, long dealIdRef, bool isOverride);
        Task<SourceDTO[]> GetSource(DdsActionContext ax, long dealId);
        Task UpdateSource(DdsActionContext ax, long dealId, SourceDTO[] sources);
        Task<SourceDocSectionDTO[]> GetSourceDocSection(DdsActionContext ax, long dealId);
        Task UpdateSourceDocSection(DdsActionContext ax, long dealId, SourceDocSectionDTO[] sourceDocSections);
        Task<DropdownCategoryDTO[]> GetDropdownCategory(DdsActionContext ax, long dealId);
        Task UpdateDropdownCategory(DdsActionContext ax, long dealId, DropdownCategoryDTO[] dropdownCategorys);
        Task<string[]> GetProcessType(DdsActionContext ax);
        Task<DataFormatDTO[]> GetDataFormat(DdsActionContext ax);
        Task UpdateDataFormat(DdsActionContext ax, DataFormatDTO[] dataFormats);
        Task<long> UploadScreenShot(DdsActionContext ax, ImageInfo imgInfo);
        Task<byte[]?> DownloadScreenShot(DdsActionContext ax, long screenShotId);        
    }
}
