﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System.Net.Mail;

namespace PwC.DDS.Core
{
    public class DealProvider: IDealProvider
    {
        readonly ISectionProvider _section;
        readonly ISellerProvider _seller;
        readonly IEmailProvider _email;
        public DealProvider(ISectionProvider section, ISellerProvider seller, IEmailProvider email)
        {
            _section = section;
            _seller = seller;
            _email = email;
        }

        public async Task<DealSetupDTO> CreateDeal(DdsActionContext ax, DealSetupWithSectionDTO deal)
        {
            if (string.IsNullOrWhiteSpace(deal.DealName))
            {
                throw new DdsInvalidOperationException("deal name cannot be empty");
            }
            if (await ax.Any<DealSetup>(d => d.IsActive && d.DealName == deal.DealName.Trim()))
            {
                throw new DdsInvalidOperationException("duplicate deal name");
            }

            var newDeal = ax.Mapper.Map<DealSetup>(deal).CreateBy(ax.UserId);
            newDeal.IsActive = true;
            newDeal.DealState = DealState.Active.GetDisplayName();
            newDeal.DealName = newDeal.DealName.Trim();
            var data = ax.Add(newDeal);
            await ax.Save();

            await _section.InitSection(ax, data.DealId, deal.DocSections);
            await _seller.InitSeller(ax, data.DealId);

            var result = await GetDeal(ax, data.DealId);
            return result;
        }

        public async Task<DealSetupDTO> UpdateDeal(DdsActionContext ax, DealSetupDTO deal)
        {
            var existDeal = await ax.First<DealSetup>(d => d.DealId == deal.DealId) ?? throw new DdsInvalidOperationException("invalid deal id");
            deal.DealName = deal.DealName.Trim();

            if (string.IsNullOrWhiteSpace(deal.DealName))
            {
                throw new DdsInvalidOperationException("new deal name cannot be empty");
            }
            if (await ax.Any<DealSetup>(d => d.IsActive && d.DealId != deal.DealId && d.DealName == deal.DealName))
            {
                throw new DdsInvalidOperationException("duplicate deal name");
            }

            bool isEmailEnabled = ax.Config.EmailSettings.EmailEnabled;
			if (isEmailEnabled && !string.IsNullOrEmpty(deal.DealAdmin) && deal.DealAdmin != existDeal.DealAdmin)
			{
				string subject = $"Deal Admin Changed for {deal.DealName}";
				//need to send email
				_email.SendEmail(ax, subject, deal.DealAdmin, existDeal.DealAdmin);
			}

            if (deal.LevelOfReviewForCalculation != existDeal.LevelOfReviewForCalculation)
                existDeal.NeedRecalculation = true;

			existDeal = ax.Mapper.Map(deal, existDeal).UpdateBy(ax.UserId); 
            ax.Update(existDeal);
            await ax.Save();

			return ax.Mapper.Map<DealSetupDTO>(existDeal);
        }

        public async Task<DealSetupDTO[]> GetDeals(DdsActionContext ax, string dealState)
        {
            DealSetup[] deals = [];
            if (ax.IsAdmin)
            {
                deals = await ax.Query<DealSetup>().Where(d => d.DealState == dealState).OrderByDescending(d => d.DealId).ToArrayAsync();
            }
            else
            {
                if (dealState == DealState.Active.GetDisplayName())
                {
                    deals = await ax.Query<DealSetup>().Where(d => d.DealState == dealState &&
                                                                  ((d.DealAdmin != null && d.DealAdmin.Contains(ax.UserEmail)) ||
                                                                   (d.DealContact != null && d.DealContact.Contains(ax.UserEmail))))
                                                       .OrderByDescending(d => d.DealId).ToArrayAsync();
                }
                else if (dealState == DealState.Archived.GetDisplayName()) 
                {
                    deals = await ax.Query<DealSetup>().Where(d => d.DealState == dealState && d.DealAdmin != null && d.DealAdmin.Contains(ax.UserEmail))
                                                       .OrderByDescending(d => d.DealId).ToArrayAsync();
                }
            }
            
            var dealsDTO = ax.Mapper.Map<DealSetupDTO[]>(deals);
            foreach (var dealDTO in dealsDTO)
            {
                dealDTO.IsDealAdmin = ax.IsAdmin || (dealDTO.DealAdmin?.Contains(ax.UserEmail) ?? false);
                dealDTO.IsReadOnly = (dealState != DealState.Active.GetDisplayName());
                dealDTO.IsEditable = !dealDTO.IsReadOnly && dealDTO.IsDealAdmin;
            }
            return dealsDTO;
        }

        public async Task<DealSetupDTO> GetDeal(DdsActionContext ax, long dealId)
        {
            var deal = await ax.First<DealSetup>(d => d.DealId == dealId) ?? throw new DdsInvalidOperationException("invalid deal id");
            var dealDTO = ax.Mapper.Map<DealSetupDTO>(deal);
            var isDealAdmin = deal.DealAdmin?.Contains(ax.UserEmail) ?? false;
            dealDTO.IsDealAdmin = ax.IsAdmin || isDealAdmin;
            dealDTO.IsReadOnly = (deal.DealState != DealState.Active.GetDisplayName());
            dealDTO.IsEditable = !dealDTO.IsReadOnly && dealDTO.IsDealAdmin;
            if (deal.AssetType == AssetType.CMBS.GetDisplayName())
                dealDTO.IsAllowRandomReview = false;
            else
                dealDTO.IsAllowRandomReview = true;
            dealDTO.IsRandomReview = ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).Any(l => l.IsRandomReview);
            return dealDTO;
        }

        public async Task UpdateDealState(DdsActionContext ax, long dealId, string dealState) 
        {
            var deal = await ax.First<DealSetup>(d => d.DealId == dealId) ?? throw new DdsInvalidOperationException("invalid deal id");

            var isDealAdmin = deal.DealAdmin?.Contains(ax.UserEmail) ?? false;
            if (!ax.IsAdmin && !isDealAdmin)
                throw new DdsInvalidOperationException("no permission");

            object? state;
            if (deal.DealState == dealState || !Enum.TryParse(typeof(DealState), dealState, true, out state))
                throw new DdsInvalidOperationException("invalid deal state");

            deal.DealState = state.ToString();
            deal.IsActive = !(deal.DealState == DealState.Deleted.GetDisplayName());
            deal.DealStateChangeTime = DateTime.UtcNow;
            deal.DealStateChangeBy = ax.UserId;
            ax.Update(deal.UpdateBy(ax.UserId));
            await ax.Save();
        }

        public async Task DeleteDeal(DdsActionContext ax, long dealId)
        {
            if (!ax.IsAdmin)
                throw new DdsInvalidOperationException("no permission");

            var deal = await ax.First<DealSetup>(d => d.DealId == dealId) ?? throw new DdsInvalidOperationException("invalid deal id");
            ax.Remove(deal);
            await ax.Save();
        }

        public async Task ResetNeedRecalculatation(DdsActionContext ax, long dealId) 
        {
            var deal = await ax.Query<DealSetup>().FirstAsync(d => d.DealId == dealId && d.IsActive == true) ?? throw new DdsInvalidOperationException("invalid deal id");
            if (!deal.NeedRecalculation)
            {
                deal.NeedRecalculation = true;
                ax.Update(deal.UpdateBy(ax.UserId));
                await ax.Save();
            }
        }

        public async Task<string> GetDealName(DdsActionContext ax, long dealId)
        {
            var deal = await ax.First<DealSetup>(d => d.DealId == dealId) ?? throw new DdsInvalidOperationException("invalid deal id");
            return deal.DealName;
        }
    }
}
