﻿using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Core
{
    public interface IDealProvider
    {
        Task<DealSetupDTO> CreateDeal(DdsActionContext ax, DealSetupWithSectionDTO deal);
        Task<DealSetupDTO> UpdateDeal(DdsActionContext ax, DealSetupDTO deal);
        Task<DealSetupDTO[]> GetDeals(DdsActionContext ax, string dealState);
        Task<DealSetupDTO> GetDeal(DdsActionContext ax, long dealId);
        Task UpdateDealState(DdsActionContext ax, long dealId, string dealState);
        Task DeleteDeal(DdsActionContext ax, long dealId);
        Task ResetNeedRecalculatation(DdsActionContext ax, long dealId);
        Task<string> GetDealName(DdsActionContext ax, long dealId);
    }
}
