﻿using PwC.DDS.Types;
using Microsoft.EntityFrameworkCore;
using PwC.DDS.Types.Database;

namespace PwC.DDS.Core
{
    public class LookupService
    {
        public readonly LookupData Lookups;
        public readonly DealLevelData SourceDocSections;

        public LookupService(DdsActionContext ax, IMemoryCacheHelper cacheHelper)
        {
            Lookups = new LookupData(() => cacheHelper.GetOrCreateAsync(CacheKey.LookUp,
                    async e => (await ax.Where<Lookup>(k => k.IsActive)
                            .OrderBy(k => k.Category)
                            .ThenBy(k => k.Sequence)
                            .Select(k => new { k.Category, k.Code, k.Display, k.Sequence }).ToArrayAsync())
                        .GroupBy(k => k.Category)
                        .ToDictionary(g => g.Key,
                            g => g.Select(k => new LookupCodeDisplay { Code = k.Code, Display = k.Display, Sequence = k.Sequence }).ToArray())),
                () => cacheHelper.Remove(CacheKey.LookUp));
            SourceDocSections = new DealLevelData(dealId => cacheHelper.GetOrCreateAsync(CacheKey.DealLevel,
                    async e => (await ax.Where<SourceDocSection>(i => i.DealId == dealId)
                            .OrderBy(i => i.Name)
                            .Select(i => new { i.SourceDocSectionId, i.Name }).ToArrayAsync())
                        .Select(i => new LookupIdName { DealId = dealId, Id = i.SourceDocSectionId, Name = i.Name }).ToArray()),
                () => cacheHelper.Remove(CacheKey.DealLevel));
        }

        public class LookupData
        {
            private readonly Func<Task<Dictionary<string, LookupCodeDisplay[]>?>> _get;
            private readonly Action _clear;
            private Dictionary<string, LookupCodeDisplay[]>? _items;

            public LookupData(Func<Task<Dictionary<string, LookupCodeDisplay[]>?>> get, Action clear)
            {
                _get = get;
                _clear = clear;
            }

            public void Clear()
            {
                _clear();
            }

            public async Task<Dictionary<string, LookupCodeDisplay[]>?> Gets()
            {
                _items = await _get();
                return _items;
            }

            public async Task<LookupCodeDisplay[]> Gets(string categoryName)
            {
                // return empty for invalid name or unexpected database content
                var lookups = await Gets();
                if (lookups == null || !lookups.ContainsKey(categoryName))
                {
                    return Array.Empty<LookupCodeDisplay>();
                }

                return lookups[categoryName];
            }

            // normalize code
            public async Task<string?> Get(string categoryName, string code)
            {
                return (await Gets(categoryName)).FirstOrDefault(c => StringComparer.InvariantCultureIgnoreCase.Equals(c.Code, code))?.Code;
            }

            public Task<LookupCodeDisplay[]> this[string categoryName] => Gets(categoryName);
            public Task<string?> this[string categoryName, string code] => Get(categoryName, code);
        }

        public class DealLevelData
        {
            private readonly Func<long, Task<LookupIdName[]?>> _get;
            private readonly Action _clear;
            private readonly Dictionary<long, LookupIdName[]?> _items;

            public DealLevelData(Func<long, Task<LookupIdName[]?>> get, Action clear)
            {
                _get = get;
                _clear = clear;
                _items = new Dictionary<long, LookupIdName[]?>();
            }

            public async Task<LookupIdName[]?> Gets(long dealId)
            {
                if (!_items.ContainsKey(dealId))
                {
                    _items[dealId] = await _get(dealId);
                }

                return _items[dealId];
            }

            public async Task<LookupIdName?> Get(long dealId, long? itemId)
            {
                if (itemId == null)
                {
                    return null;
                }

                return (await Gets(dealId))?.FirstOrDefault(i => i.Id == itemId);
            }

            public async Task<LookupIdName?> Get(long dealId, string name)
            {
                if (string.IsNullOrWhiteSpace(name))
                {
                    return null;
                }

                var result = (await Gets(dealId))?.FirstOrDefault(i => StringComparer.InvariantCultureIgnoreCase.Equals(i.Name, name));
                return result;
            }

            public Task<LookupIdName[]?> this[long dealId] => Gets(dealId);
            public Task<LookupIdName?> this[long dealId, long? itemId] => Get(dealId, itemId);
            public Task<LookupIdName?> this[long dealId, string name] => Get(dealId, name);
        }

        public enum CacheKey
        {
            LookUp,
            DealLevel,
        }
    }
}
