﻿using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using PwC.DDS.Types.Interface.Reviewer;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace PwC.DDS.Core.Common
{
    public static class ConvertExtension
    {
        public static string? ToDecimalNullable(string? obj, string? format)
        {
            if (obj == null) 
                return null;

            decimal nmb = 0;
            if (decimal.TryParse(obj.Trim(), out nmb))
            {
                try
                {
                    if (nmb >= 0)
                        format = format?.Replace("_)", string.Empty);
                    var result = nmb.ToString(format);
                    return result;
                }
                catch
                {

                }
            }
            return obj;
        }

        public static string? ToDateTimeNullable(string? strDate, string? format)
		{
			if (strDate == null) 
                return null;

            DateTime date;
            if (DateTime.TryParse(strDate.Trim(), out date)) 
            {
                try
                {
                    var result = date.ToString(format);
                    return result;
                }
                catch
                {

                }
            }
			return strDate;
		}

		public static string ToStringFromExponentialNullable(string? value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            double result;
            bool hasExponential = (value.Contains("E") || value.Contains("e")) && double.TryParse(value, out result);
            if (hasExponential)
            {
                return decimal.Parse(value, NumberStyles.Float).ToString();
            }
            return value;
        }

        public static string GetDisplayLoanNumberByLoanID(LoanReview[]? DisplayLoanNumbers, string? LoanNumber, long LoanID, string? DisplayOrder)
        {
            string DisplayLoanNumber = string.Empty;
            if (DisplayLoanNumbers != null && DisplayLoanNumbers.Any())
                DisplayLoanNumber = DisplayLoanNumbers.Where(l => l.LoanId == LoanID).Select(l => l.ClientValue).FirstOrDefault() ?? string.Empty;
            else if (!string.IsNullOrEmpty(LoanNumber))
                DisplayLoanNumber = LoanNumber;
            else if (!string.IsNullOrEmpty(DisplayOrder))
                DisplayLoanNumber = DisplayOrder;
            return DisplayLoanNumber;
        }

        public static string GetLoanReviewStatus(ReviewStatusSummaryDTO? reviewStatus)
        {
            var status = string.Empty;
            if (reviewStatus == null || reviewStatus.ReviewedFields == 0)
                status = LoanStatus.NotStart.GetDisplayName();
            else if (reviewStatus.ExceptionFields > 0)
                status = LoanStatus.Exception.GetDisplayName();
            else if (reviewStatus.ReviewCompleteFields == reviewStatus.TotalFields)
                status = LoanStatus.Completed.GetDisplayName();
            else
                status = LoanStatus.InReview.GetDisplayName();

            return status;
        }

        public static bool ToCompareClientAndPwCValue(string? clientDisplayValue, string? clientValue, string? pwcValue, string? dataFormatType, string? dataFormat, 
            decimal threadhold, bool isPwCHeader)
        {
            decimal clientValueDecimal, pwcValueDecimal;
            DateTime clientValueDate, pwcValueDate;
            bool isTie;

            //If it is PwC Header (means there is no Client Header & Client Value, it shoud be always Tie)
            if (isPwCHeader) 
                return true;

            if (string.IsNullOrEmpty(clientValue) && string.IsNullOrEmpty(pwcValue))
                return true;

            if (string.IsNullOrEmpty(clientValue) && !string.IsNullOrEmpty(pwcValue))
                return false;

            if (!string.IsNullOrEmpty(clientValue) && string.IsNullOrEmpty(pwcValue))
                return false;
            
            if (dataFormatType == DataFormatType.IsNumeric.GetDisplayName())
            {
                isTie = string.Equals(clientDisplayValue.Trim(), ToDecimalNullable(pwcValue, dataFormat?.Split('|')[0]));
                if (!isTie && threadhold != 0)
                {
                    try
                    {
                        if (decimal.TryParse(clientValue.Trim(), out clientValueDecimal) && decimal.TryParse(pwcValue.Trim(), out pwcValueDecimal))
                        {
                            decimal lowerBound = clientValueDecimal - threadhold;
                            decimal upperBound = clientValueDecimal + threadhold;
                            isTie = pwcValueDecimal >= lowerBound && pwcValueDecimal <= upperBound;
                            if (isTie)
                            {
                                isTie = string.Equals(clientDisplayValue.Trim(), ToDecimalNullable(clientValue, dataFormat?.Split('|')[0]));
                            }
                        }
                    }
                    catch { }
                }

                return isTie;
            }
            else if (dataFormatType == DataFormatType.IsDateTime.GetDisplayName())
            {
                isTie = string.Equals(clientDisplayValue.Trim(), ToDateTimeNullable(pwcValue, dataFormat?.Split('|')[0]));
                if (!isTie && threadhold != 0)
                {
                    try
                    {
                        if (DateTime.TryParse(clientValue.Trim(), out clientValueDate) && DateTime.TryParse(pwcValue.Trim(), out pwcValueDate))
                        {
                            TimeSpan difference = clientValueDate - pwcValueDate;
                            isTie = Math.Abs((decimal)difference.TotalDays) <= threadhold;
                            if (isTie)
                            {
                                isTie = string.Equals(clientDisplayValue.Trim(), ToDateTimeNullable(clientValue, dataFormat?.Split('|')[0]));
                            }
                        }
                    }
                    catch { }
                }

                return isTie;
            }
            else
            {
                return string.Equals(clientDisplayValue, pwcValue);
            }
        }

        public static bool ToComparePwCValues(string? pwcValue1, string? pwcValue2, string? pwcValue3, int? levelOfReview, string? dataFormatType, string? dataFormat)
        {
            var format = dataFormat?.Split('|')[0];
            if (dataFormatType == DataFormatType.IsNumeric.GetDisplayName())
            {
                pwcValue1 = ToDecimalNullable(pwcValue1, format);
                pwcValue2 = ToDecimalNullable(pwcValue2, format);
                pwcValue3 = ToDecimalNullable(pwcValue3, format);
            }
            else if (dataFormatType == DataFormatType.IsDateTime.GetDisplayName())
            {
                pwcValue1 = ToDateTimeNullable(pwcValue1, format);
                pwcValue2 = ToDateTimeNullable(pwcValue2, format);
                pwcValue3 = ToDateTimeNullable(pwcValue3, format);
            }

            if (levelOfReview < 2)
                return true;
            else if (levelOfReview < 3)
                return string.Equals(pwcValue1, pwcValue2);
            else
                return string.Equals(pwcValue1, pwcValue2) && string.Equals(pwcValue2, pwcValue3);
        }

        //public static string[] GetKeyColumns(string? dealKeyColumn)
        //{
        //    var keyColumns = new string[2];
        //    var columns = string.IsNullOrEmpty(dealKeyColumn) ? new string[0] : dealKeyColumn.Split(';');
        //    keyColumns[0] = columns.Length > 0 && !string.IsNullOrEmpty(columns[0].Trim()) ? columns[0].Trim() : "Freddie Mac Loan Number";
        //    keyColumns[1] = columns.Length > 1 && !string.IsNullOrEmpty(columns[1].Trim()) ? columns[1].Trim() : "Property Name";

        //    return keyColumns;
        //}

        public static string[] GetKeyColumns(string? dealKeyColumn)
        {
            var keyColumns = new string[2];
            if (string.IsNullOrEmpty(dealKeyColumn))
            {
                keyColumns[0] = "Freddie Mac Loan Number";
                keyColumns[1] = "Property Name";
            }
            else if (!dealKeyColumn.Contains(';'))
            {
                keyColumns[0] = "Freddie Mac Loan Number";
                keyColumns[1] = dealKeyColumn.Trim();
            }
            else
            {
                var columns = dealKeyColumn.Split(';');
                keyColumns[0] = !string.IsNullOrEmpty(columns[0].Trim()) ? columns[0].Trim() : "Freddie Mac Loan Number";
                keyColumns[1] = !string.IsNullOrEmpty(columns[1].Trim()) ? columns[1].Trim() : "Property Name";
            }
            return keyColumns;
        }

        /// <summary>
        /// Excel column name
        /// (1 = A, 2 = B...27 = AA...703 = AAA...)
        /// </summary>
        public static string GetColNameFromIndex(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;
        }
    }
}
