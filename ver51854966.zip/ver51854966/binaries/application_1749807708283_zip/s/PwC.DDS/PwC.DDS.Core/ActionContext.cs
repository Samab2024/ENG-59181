﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PwC.DDS.Database;
using PwC.DDS.Infrastructure;
using System.Linq.Expressions;

namespace PwC.DDS.Core
{
    public class DdsActionContext
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public bool IsAdmin { get; set; }

        public long? DealId { get; set; }

        public string[] Permissions { get; set; }
        public void CheckPermission(params string[] actions)
        {
            if (!actions.All(a => Permissions.Contains(a)))
            {
                throw new DdsPermissionException($"Permission Validation failed: current user does not have {string.Join(" or ", actions)} permission.");
            }
        }

        [Obsolete("use .Cache instead")]
        public IMemoryCacheHelper ICache { get; set; }
        [Obsolete("use .Config instead")]
        public IConfiguration IConfig { get; set; }
        public IMapper Mapper { get; set; }
        public DataContext DataContext { get; set; }
        public IQueryable<T> Query<T>() where T : class => DataContext.Set<T>().AsNoTracking();
        public Task<bool> Any<T>(Expression<Func<T, bool>> predicate) where T : class => DataContext.Set<T>().AsNoTracking().AnyAsync(predicate);
        public IQueryable<T> Where<T>(Expression<Func<T, bool>> predicate) where T : class => DataContext.Set<T>().AsNoTracking().Where(predicate);
        // this is firstordefault, don't use iqueryable.first because that does not give reasonable error message
        public Task<T> First<T>(Expression<Func<T, bool>> predicate) where T : class => DataContext.Set<T>().AsNoTracking().FirstOrDefaultAsync(predicate);
        public IQueryable<T> QueryTracking<T>() where T : class => DataContext.Set<T>().AsTracking();
        public IQueryable<T> TrackingWhere<T>(Expression<Func<T, bool>> predicate) where T : class => DataContext.Set<T>().AsTracking().Where(predicate);
        public Task<T> TrackingFirst<T>(Expression<Func<T, bool>> predicate) where T : class => DataContext.Set<T>().AsTracking().FirstOrDefaultAsync(predicate);
        public T Add<T>(T entity) where T : class => DataContext.Set<T>().Add(entity).Entity;
        public void AddRange<T>(T[] entities) where T : class => DataContext.Set<T>().AddRange(entities);
        public List<T> AddRange<T>(List<T> entities) where T : class { DataContext.Set<T>().AddRange(entities); return entities; }
        public void Remove<T>(T entity) where T : class => DataContext.Set<T>().Remove(entity);
        public void RemoveRange<T>(IEnumerable<T> entities) where T : class => DataContext.Set<T>().RemoveRange(entities);
        public void RemoveWhere<T>(Expression<Func<T, bool>> predicate) where T : class => DataContext.Set<T>().RemoveRange(DataContext.Set<T>().Where(predicate));
        public void Update<T>(T entity) where T : class => DataContext.Set<T>().Update(entity);
        public void UpdateRange<T>(T[] entity) where T : class => DataContext.Set<T>().UpdateRange(entity);
        public Task Save() => DataContext.SaveChangesAsync();

        private DdsConfiguration? _config;
        public DdsConfiguration Config { get { if (_config == null) { _config = new DdsConfiguration(IConfig); } return _config; } }
        private LookupService? _cache;
        public LookupService Cache { get { if (_cache == null) { _cache = new LookupService(this, ICache); } return _cache; } }
    }
}