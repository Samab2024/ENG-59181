﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using PwC.DDS.Core.Aspose;
using Microsoft.AspNetCore.Http;
using AutoMapper;
using System.IO;
using System.Data;
using PwC.DDS.Core.Common;
using System.Collections.Generic;
using Aspose.Cells;
using System.Drawing;
using System.Reflection.PortableExecutable;
using System;
using System.Data.Common;
using System.Text.Json;

namespace PwC.DDS.Core
{
    public class ImportProvider : IImportProvider
    {
        readonly IDealProvider _deal;
        readonly ISectionProvider _section;
        private Process? _process = null;
        public ImportProvider(IDealProvider deal, ISectionProvider section)
        {
            _deal = deal;
            _section = section;
        }

        #region Load Sheets
        public async Task<List<string>> LoadSheets(DdsActionContext ax, IFormFile file)
        {
            var sheets = new List<string>();
            var wb = new ImportWorkBook();
            try
            {
                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    wb.OpenExcel(stream);
                    sheets = wb.LoadSheets();
                }
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when loading sheets. " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return sheets;
        }
        #endregion

        #region Import Data
        public async Task<object?> ImportData(DdsActionContext ax, ImportDataDTO importInfo)
        {
            if (importInfo.ImportRunType == ImportRunType.ValidateCD || importInfo.ImportRunType == ImportRunType.ImportCD)
            {
                var result = await ImportClientData(ax, importInfo);
                return result;
            }
            else if (importInfo.ImportRunType == ImportRunType.ValidateRD || importInfo.ImportRunType == ImportRunType.ImportRD)
            {
                var result = await ImportReviewData(ax, importInfo);
                return result;
            }

            return null;
        }

        #region File load and import rocess track
        private List<ImportWorkSheet> LoadDataFromFile(IFormFile file, string sheetName, string[] keyColumns)
        {
            var wb = new ImportWorkBook();
            try
            {
                using (var stream = new MemoryStream())
                {
                    file.CopyTo(stream);
                    wb.OpenExcel(stream);
                }
                wb.SheetList = new List<ImportWorkSheet>();
                wb.SheetList.Add(new ImportWorkSheet(sheetName, keyColumns));
                wb.CheckSheets();
                wb.CheckColumns();
                wb.ReadExcel();
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when loading " + sheetName + ". " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return wb.SheetList;
        }

        private async Task InitProcess(DdsActionContext ax, ImportDataDTO importInfo)
        {
            try
            {
                var process = ax.Mapper.Map<Process>(importInfo).CreateBy(ax.UserId);
                ax.Add(process);
                await ax.Save();

                _process = process;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when init process. " + ex.Message);
            }
        }

        private async Task EndProcess(DdsActionContext ax, string errMsg, string data)
        {
            try
            {
                if (_process != null)
                {
                    _process.EndTime = DateTime.Now;
                    if (errMsg == string.Empty)
                    {
                        _process.Status = "Success";
                        _process.Message = data.Length > 2000 ? data.Substring(0, 2000) : data;
                    }
                    else
                    {
                        _process.Status = "Exception";
                        _process.Message = errMsg.Length > 2000 ? errMsg.Substring(0, 2000) : errMsg;
                    }
                    ax.Update(_process);
                    await ax.Save();
                }
            }
            catch
            {

            }
        }

        private DataTable LoadKeyColumnsData(DataTable userTmpData, string[] keyColumns)
        {
            var tblKeyColData = userTmpData.DefaultView.ToTable(true, keyColumns);
            var keyFields = tblKeyColData.AsEnumerable();
            foreach (var key in keyFields)
            {
                key[0] = key[0].ToString()?.Split('|')[0].Trim();
                key[1] = key[1].ToString()?.Split('|')[0].Trim();
            }
            return tblKeyColData;
        }
        #endregion

        #region Import Client Data
        private async Task<object?> ImportClientData(DdsActionContext ax, ImportDataDTO importInfo)
        {
            string errMsg = string.Empty;
            string statusMsg = string.Empty;

            try
            {
                var deal = await _deal.GetDeal(ax, importInfo.DealId);

                // Skip validation when deal is empty and only one seller has been selected
                var isInitImport = !ax.Query<HeaderMap>().Any(d => d.DealId == importInfo.DealId);
                if (isInitImport && importInfo.SellerIds.Count == 1)
                    importInfo.ImportRunType = ImportRunType.ImportCD;

                // Init Process
                await InitProcess(ax, importInfo);

                // Load Key Columns
                var keyColumns = ConvertExtension.GetKeyColumns(deal.KeyColumn);

                // Load data from import excel
                var userTmpData = LoadDataFromFile(importInfo.File, importInfo.SheetName, keyColumns);
                var keyColData = LoadKeyColumnsData(userTmpData[0].SheetData_dv, keyColumns);

                var tblKeyColData = userTmpData[0].SheetData_av.DefaultView.ToTable(false, keyColumns);
                var IsAnyDupKeyData = tblKeyColData.AsEnumerable().GroupBy(row => new
                {
                    LoanNumber = row[0].ToString(),
                    PropertyName = row[1].ToString()
                }).Where(g => g.Count() > 1).Select(g => g.Key).Any();

                if (IsAnyDupKeyData)
                {
                    throw new DdsInvalidOperationException("Duplicate data with the same LoanNumber and PropertyName is not allowed in the same uploaded file");
                }

                if (importInfo.ImportRunType == ImportRunType.ValidateCD)
                {
                    var validateInfo = new ImportDataValidateDTO();

                    // Validate client headers
                    await ValidateClientHeader(ax, importInfo.DealId, userTmpData[0].Columns, validateInfo);

                    // Validate loans
                    await ValidateLoan(ax, importInfo.DealId, importInfo.SellerIds, keyColData, validateInfo);

                    statusMsg = JsonSerializer.Serialize(validateInfo);
                    return validateInfo;
                }
                else if (importInfo.ImportRunType == ImportRunType.ImportCD)
                {
                    var sections = await _section.GetSections(ax, importInfo.DealId);

                    // Init Source
                    var source = await InitSource(ax, importInfo.DealId);

                    // Init SourceDocSection
                    var sourceDoc = await InitSourceDocSection(ax, importInfo.DealId, sections);

                    // Update header map
                    var headers = await ImportClientHeader(ax, importInfo.DealId, deal.LevelOfReview, deal.IsBlindReview, userTmpData[0].Columns, importInfo.HeaderMaps, sourceDoc, source);

                    // Update loan
                    var loans = await ImportLoan(ax, importInfo.DealId, importInfo.SellerIds, keyColData, importInfo.LoanMaps);

                    // Update Reviewer
                    await InitReviewer(ax, importInfo.DealId, sections, loans);

                    // Update loan review
                    var warningMsg = await ImportLoanReview(ax, importInfo.DealId, headers, loans, userTmpData[0], keyColData);

                    // Achive excel file in database
                    await AchriveImportFile(ax, importInfo.DealId, importInfo.File);

                    await _deal.ResetNeedRecalculatation(ax, importInfo.DealId);

                    return new
                    {
                        statusMsg = "Import Successfully",
                        warningMsg = warningMsg
                    };

                }
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                throw new DdsInvalidOperationException(errMsg);
            }
            finally
            {
                await EndProcess(ax, errMsg, statusMsg);
            }

            return null;
        }

        #region File Validate
        private async Task ValidateClientHeader(DdsActionContext ax, long dealId, ColumnDetail[] clientHeader, ImportDataValidateDTO validateResult)
        {
            var existMaps = await ax.Query<HeaderMap>().Where(d => d.DealId == dealId && d.IsActive == true && d.ClientHeader != null).ToArrayAsync();
            var clientMaps = clientHeader.Select(d => d.ColName).ToArray();
            var missingMaps = existMaps.Where(m => !clientMaps.Any(c => c.ToLower() == m.ClientHeader?.ToLower()))
                .Select(l => new HeaderValidateInfoDTO { HeaderId = l.HeaderMapId, HeaderName = l.ClientHeader }).ToArray();
            var newMaps = clientMaps.Where(m => !existMaps.Any(c => m.ToLower() == c.ClientHeader?.ToLower()))
                .Select(l => new HeaderValidateInfoDTO { HeaderId = Array.IndexOf(clientMaps, l), HeaderName = l }).ToArray();

            validateResult.MissingFields = missingMaps;
            validateResult.NewFields = newMaps;
        }

        private async Task ValidateLoan(DdsActionContext ax, long dealId, List<long> sellerIds, DataTable tblKeyColData, ImportDataValidateDTO validateResult)
        {
            var allExistLoans = await ax.Query<Loan>().Where(d => d.DealId == dealId && d.IsActive == true).ToArrayAsync();
            var existLoans = allExistLoans.Where(d => d.DealId == dealId && sellerIds.Contains(d.SellerId) && d.IsActive == true).ToArray();
            var loansInOtherSeller = allExistLoans.Except(existLoans).ToArray();

            var clientLoans = tblKeyColData.AsEnumerable().ToArray();
            var missingLoans = existLoans.Where(l => !clientLoans.Any(c => c[0]?.ToString()?.ToLower() == l.LoanNumber.ToLower() &&
                                                                           c[1]?.ToString()?.ToLower() == l.PropertyName?.ToLower()))
                .Select(l => new LoanValidateInfoDTO { LoanId = l.LoanId, LoanNumber = string.IsNullOrEmpty(l.LoanNumber) ? l.PropertyName : l.LoanNumber }).ToArray();
            var newClientLoans = clientLoans.Where(l => !existLoans.Any(c => l[0]?.ToString()?.ToLower() == c.LoanNumber.ToLower() &&
                                                                             l[1]?.ToString()?.ToLower() == c.PropertyName?.ToLower())).ToArray();

            //Check new loan is duplicated or not in this deal
            List<LoanValidateInfoDTO> newLoans = new();
            foreach (var newClientLoan in newClientLoans)
            {
                var isDuplidatedLoan = loansInOtherSeller.Any(l => l.LoanNumber.ToLower() == newClientLoan[0]?.ToString()?.ToLower() && l.PropertyName.ToLower() == newClientLoan[1]?.ToString()?.ToLower());
                newLoans.Add(new LoanValidateInfoDTO
                {
                    LoanId = Array.IndexOf(clientLoans, newClientLoan),
                    LoanNumber = string.IsNullOrEmpty(newClientLoan[0].ToString()) ? newClientLoan[1].ToString() : newClientLoan[0].ToString(),
                    //Duplicate loan can not allowed to re-map
                    IsAllowRemap = !isDuplidatedLoan,
                });
            }

            validateResult.MissingLoans = missingLoans;
            validateResult.NewLoans = newLoans.ToArray();
        }
        #endregion

        #region File Import
        private async Task<Source[]> InitSource(DdsActionContext ax, long dealId)
        {
            try
            {
                var source = await ax.Query<Source>().Where(s => s.DealId == dealId).ToArrayAsync();
                if (!source.Any())
                {
                    var pfSection = await ax.Cache.Lookups.Gets(Constent.Source);
                    source = pfSection.Select(s => new Source()
                    {
                        DealId = dealId,
                        Name = s.Display,
                        DisplayOrder = s.Sequence,
                        IsActive = true
                    }.CreateBy(ax.UserId)).ToArray();
                    ax.AddRange(source);
                    await ax.Save();
                }

                return source;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when init sections. " + ex.Message);
            }
        }

        private async Task<SourceDocSection[]> InitSourceDocSection(DdsActionContext ax, long dealId, SectionDTO[] sections)
        {
            try
            {
                var sourceDoc = await ax.Query<SourceDocSection>().Where(s => s.DealId == dealId).ToArrayAsync();
                if (!sourceDoc.Any())
                {
                    var defaultSection = sections.FirstOrDefault();
                    var sd = new SourceDocSection()
                    {
                        DealId = dealId,
                        SectionId = defaultSection.SectionId,
                        Name = defaultSection.Name,
                        DisplayOrder = 1,
                        IsAllowCopy = true,
                        IsActive = true
                    }.CreateBy(ax.UserId);
                    ax.Add(sd);
                    await ax.Save();
                    sourceDoc = new[] { sd };
                }
                return sourceDoc;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when init source doc sections. " + ex.Message);
            }
        }

        private async Task<List<HeaderMap>> ImportClientHeader(DdsActionContext ax, long dealId, int reviewLevel, bool isBlindReview, ColumnDetail[] clientHeader,
            ImportHeaderMapDTO[]? headerMaps, SourceDocSection[] sourceDoc, Source[] source)
        {
            try
            {
                var existMaps = await ax.Query<HeaderMap>().Where(d => d.DealId == dealId).ToArrayAsync();
                var defaultSourceDocId = sourceDoc.Min(s => s.SourceDocSectionId);
                var defaultSourceId = source.Min(s => s.SourceId);

                // Step1 - Remap Headers
                if (headerMaps != null && headerMaps.Any())
                {
                    var changedHeaders = existMaps.Where(d => headerMaps.Select(l => l.OrgHeaderId).Contains(d.HeaderMapId)).ToArray();
                    foreach (var header in changedHeaders)
                    {
                        var index = headerMaps?.FirstOrDefault(l => l.OrgHeaderId == header.HeaderMapId)?.NewHeaderId;
                        if (index == null)
                            continue;
                        var key = clientHeader[(int)index];
                        header.ClientHeader = key.ColName.Trim();
                        ax.Update(header.UpdateBy(ax.UserId));
                    }
                }

                // Step2 - Set no longer exist columns to inactive and reset its SourceDocSectionId & DropdownCategoryId & ReportOrder
                var missingMaps = existMaps.Where(m => m.IsActive == true && !string.IsNullOrEmpty(m.ClientHeader)).AsEnumerable()
                                           .Where(m => !clientHeader.Any(c => c.ColName.ToLower() == m.ClientHeader?.ToLower())).ToArray();
                foreach (var map in missingMaps)
                {
                    map.SourceDocSectionId = defaultSourceDocId;
                    map.DropdownCategoryId = null;
                    map.SourceId = defaultSourceId;
                    map.ReportOrder = 0;
                    map.IsActive = false;
                    ax.Update(map.UpdateBy(ax.UserId));
                }

                // Step3 - Reactive existing maps order and add new maps
                var reportOrder = 1;
                var formats = await ax.Query<DataFormat>().ToListAsync();
                var newMaps = new List<HeaderMap>();
                foreach (var header in clientHeader)
                {
                    if (header.ColName == string.Empty)
                        continue;

                    var map = existMaps.Where(m => m.ClientHeader?.ToLower() == header.ColName.ToLower()).FirstOrDefault();
                    if (map != null)
                    {
                        map.ReportOrder = reportOrder;
                        map.IsActive = true;
                        map.UpdateBy(ax.UserId);
                        ax.Update(map);
                    }
                    else
                    {
                        var newMap = new HeaderMap()
                        {
                            DealId = dealId,
                            ClientHeader = header.ColName,
                            PwCHeader = string.Empty,
                            DisplayOrder = reportOrder,
                            ReportOrder = reportOrder,
                            ProcessType = ProcessType.Review.GetDisplayName(),
                            SourceDocSectionId = defaultSourceDocId,
                            SourceId = defaultSourceId,
                            DataFormatId = HeaderMapMapping(formats, header),
                            IsActive = true,
                            IsExcludedInReport = false,
                            IsBlindReview = isBlindReview,
                            LevelOfReview = reviewLevel
                        };
                        newMap.CreateBy(ax.UserId);
                        newMaps.Add(newMap);
                    }
                    reportOrder++;
                }

                // Step4 - Update Display Order
                var maps = existMaps.Where(m => m.IsActive == true).OrderBy(l => l.DisplayOrder).ThenBy(l => l.HeaderMapId).ToArray();
                var displayOrder = 1;
                foreach (var map in maps) 
                {
                    map.DisplayOrder = displayOrder;
                    displayOrder++;
                    ax.Update(map);
                }

                foreach (var map in newMaps) 
                {
                    map.DisplayOrder = displayOrder;
                    displayOrder++;
                    ax.Add(map);
                }

                await ax.Save();

                var headers = await ax.Query<HeaderMap>().Where(m => m.DealId == dealId && m.IsActive == true).ToListAsync();
                return headers;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when import client headers. " + ex.Message);
            }
        }

        private async Task<List<Loan>> ImportLoan(DdsActionContext ax, long dealId, List<long> sellerIds, DataTable tblKeyColData, ImportLoanMapDTO[]? loanMaps)
        {
            try
            {
                var keyFields = tblKeyColData.AsEnumerable();
                var allExistLoans = await ax.Query<Loan>().Where(d => d.DealId == dealId).ToArrayAsync();
                var existLoans = allExistLoans.Where(d => sellerIds.Contains(d.SellerId)).ToArray();
                var loansInOtherSeller = allExistLoans.Except(existLoans).ToArray();

                // Step1 - Remap loans
                if (loanMaps != null && loanMaps.Any())
                {
                    var changedLoans = existLoans.Where(d => loanMaps.Select(l => l.OrgLoanId).Contains(d.LoanId)).ToArray();
                    foreach (var loan in changedLoans)
                    {
                        var index = loanMaps?.FirstOrDefault(l => l.OrgLoanId == loan.LoanId)?.NewLoanId;
                        if (index == null)
                            continue;
                        var key = tblKeyColData.Rows[(int)index];
                        loan.LoanNumber = key[0].ToString();
                        loan.PropertyName = key[1].ToString();
                        ax.Update(loan.UpdateBy(ax.UserId));
                    }
                }

                // Step2 - Set no longer exist loans to inactive
                var missingLoans = existLoans.Where(l => l.IsActive == true).AsEnumerable()
                                             .Where(l => !keyFields.Any(c => c[0]?.ToString()?.ToLower() == l.LoanNumber.ToLower() &&
                                                                             c[1]?.ToString()?.ToLower() == l.PropertyName?.ToLower())).ToArray();
                foreach (var loan in missingLoans)
                {
                    loan.IsActive = false;
                    ax.Update(loan.UpdateBy(ax.UserId));
                }

                // Step3 - Reactive existing loans or add new loans
                var displayOrder = 1;
                foreach (var key in keyFields)
                {
                    //Multipler sellers selected or duplicate loan -- Reactive existing loans or add new loans
                    var isDuplidatedLoan = loansInOtherSeller.Any(l => l.LoanNumber.ToLower() == key[0]?.ToString()?.ToLower() && l.PropertyName.ToLower() ==  key[1]?.ToString()?.ToLower());
                    if (sellerIds.Count > 1 || isDuplidatedLoan)
                        continue;

                    var loan = existLoans.Where(d => d.LoanNumber.ToLower() == key[0].ToString()?.ToLower() &&
                                                     d.PropertyName?.ToLower() == key[1].ToString()?.ToLower()).FirstOrDefault();
                    if (loan != null)
                    {
                        loan.IsActive = true;
                        loan.DisplayOrder = displayOrder;
                        loan.UpdateBy(ax.UserId);
                        ax.Update(loan);
                    }
                    else
                    {
                        var newLoan = new Loan()
                        {
                            DealId = dealId,
                            SellerId = sellerIds[0],
                            LoanNumber = key[0].ToString(),
                            PropertyName = key[1].ToString(),
                            DisplayOrder = displayOrder,
                            IsActive = true
                        };

                        newLoan.CreateBy(ax.UserId);
                        ax.Add(newLoan);
                    }
                    displayOrder++;
                }
                await ax.Save();

                var loans = await ax.Query<Loan>().Where(d => d.DealId == dealId && d.IsActive == true).ToListAsync();
                return loans;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when import loans. " + ex.Message);
            }
        }

        private async Task<bool> InitReviewer(DdsActionContext ax, long dealId, SectionDTO[] sections, List<Loan> loans)
        {
            try
            {
                var reviewers = await ax.Query<Reviewer>().Where(s => s.DealId == dealId && s.LoanId != 0).ToArrayAsync();
                var existReviewLoanIds = reviewers.Select(l => l.LoanId).ToArray();
                var missingLoans = loans.Where(l => !existReviewLoanIds.Contains(l.LoanId));

                foreach (var section in sections)
                {
                    var reviewer = missingLoans.Select(l => new Reviewer()
                    {
                        DealId = dealId,
                        LoanId = l.LoanId,
                        HeaderMapId = 0,
                        SectionId = section.SectionId,
                        ReviewerStatus1 = ReviewStatus.NotStarted.GetDisplayName(),
                        ReviewerStatus2 = ReviewStatus.NotStarted.GetDisplayName(),
                        ReviewerStatus3 = ReviewStatus.NotStarted.GetDisplayName()
                    }.CreateBy(ax.UserId)).ToArray();
                    ax.AddRange(reviewer);
                }
                await ax.Save();

                return true;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when import reviewers. " + ex.Message);
            }
        }

        private async Task<string> ImportLoanReview(DdsActionContext ax, long dealId, List<HeaderMap> headers, List<Loan> loans, ImportWorkSheet data, DataTable tblKeyColData)
        {
            try
            {
                var existReviews = await ax.Query<LoanReview>().Where(d => d.DealId == dealId).ToArrayAsync();
                var dataFormats = await ax.Query<DataFormat>().ToArrayAsync();
                var keyFields = tblKeyColData.AsEnumerable();
                var actualData = data.SheetData_av.AsEnumerable();
                var displayData = data.SheetData_dv.AsEnumerable();
                var warningMsg = string.Empty;

                foreach (var loan in loans)
                {
                    var keyEntry = keyFields.Where(a => a[0].ToString()?.ToLower() == loan.LoanNumber.ToLower() &&
                                                        a[1].ToString()?.ToLower() == loan.PropertyName?.ToLower()).FirstOrDefault();
                    if (keyEntry == null)
                        continue;
                    var rowIndex = tblKeyColData.Rows.IndexOf(keyEntry);
                    var displayEntry = displayData.ElementAt(rowIndex);
                    var actualEntry = actualData.ElementAt(rowIndex);

                    foreach (var header in headers)
                    {
                        var review = existReviews.FirstOrDefault(r => r.LoanId == loan.LoanId && r.HeaderMapId == header.HeaderMapId);
                        if (string.IsNullOrEmpty(header.ClientHeader)) 
                        {
                            if (review == null) 
                            {
                                var newReview = new LoanReview()
                                {
                                    DealId = dealId,
                                    LoanId = loan.LoanId,
                                    HeaderMapId = header.HeaderMapId
                                };
                                ax.Add(newReview.CreateBy(ax.UserId));  
                            }
                            continue;
                        }

                        var actualValue = actualEntry?[header.ClientHeader ?? string.Empty].ToString();
                        var displayValueFormat = displayEntry?[header.ClientHeader ?? string.Empty].ToString();
                        var displayValue = displayValueFormat?.ToString()?.Split('|')[0];
                        var displayFormat = displayValueFormat?.ToString()?.Split('|')[1];
                        var dataFormat = dataFormats.FirstOrDefault(d => d.DataFormatId == header.DataFormatId);
                        var isPwCHeader = string.IsNullOrEmpty(header.ClientHeader);

                        if (actualValue?.Length > 2000 || displayValue?.Length > 2000)
                        {
                            if (actualValue?.Length > 2000)
                                actualValue = actualValue.Substring(0, 2000);
                            if (displayValue?.Length > 2000)
                                displayValue = displayValue.Substring(0, 2000);
                            warningMsg += "Loan:" + loan.LoanNumber + " Field:" + header.ClientHeader + " only kept first 2000 characters. \n";
                        }

                        if (review != null)
                        {
                            if (review.ClientValue != actualValue?.ToString() ||
                                review.ClientDisplayValue != displayValue?.ToString() ||
                                review.ClientValueFormat != displayFormat?.ToString())
                            {
                                review.ClientValue = actualValue?.ToString();
                                review.ClientDisplayValue = displayValue?.ToString();
                                review.ClientValueFormat = displayFormat?.ToString();
                                if (review.IsFirstReviewed || review.IsSecondReviewed || review.IsThirdReviewed)
                                    review.IsTie = ConvertExtension.ToCompareClientAndPwCValue(review.ClientDisplayValue, review.ClientValue, review.FinalValue, dataFormat?.Type, dataFormat?.Format, header.Threadhold, isPwCHeader);
                                else
                                    review.IsTie = null;
                                ax.Update(review.UpdateBy(ax.UserId));
                            }
                        }
                        else
                        {
                            var newReview = new LoanReview()
                            {
                                DealId = dealId,
                                LoanId = loan.LoanId,
                                HeaderMapId = header.HeaderMapId,
                                ClientValue = actualValue?.ToString(),
                                ClientDisplayValue = displayValue?.ToString(),
                                ClientValueFormat = displayFormat?.ToString()
                            };
                            ax.Add(newReview.CreateBy(ax.UserId));
                        }
                    }
                }
                await ax.Save();

                return warningMsg;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when import loan reviews. " + ex.Message);
            }
        }

        private int HeaderMapMapping(List<DataFormat> formats, ColumnDetail colInfo)
        {
            var textFormatId = formats.Where(f => f.Name == Constent.DF_Text).Select(f => f.DataFormatId).FirstOrDefault();

            if (colInfo.ColFormat == "General" || colInfo.ColType == "IsString")
                return textFormatId;
            else
            {
                var formatId = formats.Where(f => f.Type == colInfo.ColType && f.Format.Split('|').Any(f => f == colInfo.ColFormat)).Select(f => f.DataFormatId).FirstOrDefault();
                return formatId == 0 ? textFormatId : formatId;
            }
        }

        private async Task AchriveImportFile(DdsActionContext ax, long dealId, IFormFile file)
        {
            try
            {
                var uploadFileInfo = await ax.Query<UploadFileInfo>().Where(d => d.DealId == dealId).FirstOrDefaultAsync();
                if (uploadFileInfo != null)
                {
                    //update
                    using (var stream = new MemoryStream())
                    {
                        file.CopyTo(stream);
                        uploadFileInfo.UpdateFile = stream.ToArray();
                    }
                    uploadFileInfo.UpdateFileName = file.FileName;
                    ax.Update(uploadFileInfo.UpdateBy(ax.UserId));
                }
                else
                {
                    //add
                    var uploadFileInfoNew = new UploadFileInfo();
                    uploadFileInfoNew.DealId = dealId;
                    uploadFileInfoNew.InitiateFileName = file.FileName;
                    using (var stream = new MemoryStream())
                    {
                        file.CopyTo(stream);
                        uploadFileInfoNew.InitiateFile = stream.ToArray();
                    }
                    ax.Add(uploadFileInfoNew.CreateBy(ax.UserId));
                }
                await ax.Save();
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when achrive import file. " + ex.Message);
            }
        }

        #endregion

        #endregion

        #region Import Review Data
        private async Task<object?> ImportReviewData(DdsActionContext ax, ImportDataDTO importInfo)
        {
            string errMsg = string.Empty;
            string statusMsg = string.Empty;

            try
            {
                var deal = await _deal.GetDeal(ax, importInfo.DealId);

                // Init Process
                await InitProcess(ax, importInfo);

                // Load Key Columns
                var keyColumns = ConvertExtension.GetKeyColumns(deal.KeyColumn);

                // Load data from import excel
                var userTmpData = LoadDataFromFile(importInfo.File, importInfo.SheetName, keyColumns);
                var keyColData = LoadKeyColumnsData(userTmpData[0].SheetData_dv, keyColumns);

                if (importInfo.ImportRunType == ImportRunType.ValidateRD)
                {
                    var validateInfo = new ImportReviewDataValidateDTO();

                    // Validate client headers
                    await ValidateClientHeader(ax, importInfo.DealId, userTmpData[0].Columns, validateInfo);

                    // Validate loans
                    await ValidateLoan(ax, importInfo.DealId, importInfo.SellerIds, keyColData, validateInfo);

                    statusMsg = JsonSerializer.Serialize(validateInfo);
                    return validateInfo;
                }
                else if (importInfo.ImportRunType == ImportRunType.ImportRD)
                {
                    // Update loan review
                    var warningMsg = await UpdateLoanReview(ax, importInfo.DealId, importInfo.SellerIds, importInfo.ReviewLevel, userTmpData[0].SheetData_av, keyColData);

                    await _deal.ResetNeedRecalculatation(ax, importInfo.DealId);

                    return new
                    {
                        statusMsg = "Import Successfully",
                        warningMsg = warningMsg
                    };
                }
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                throw new DdsInvalidOperationException(errMsg);
            }
            finally
            {
                await EndProcess(ax, errMsg, statusMsg);
            }

            return null;
        }

        private async Task ValidateClientHeader(DdsActionContext ax, long dealId, ColumnDetail[] clientHeader, ImportReviewDataValidateDTO validateResult)
        {
            var existMaps = await ax.Query<HeaderMap>().Where(d => d.DealId == dealId && d.IsActive == true &&
                      (d.ProcessType == ProcessType.Review.GetDisplayName() ||
                       d.ProcessType == ProcessType.ReviewCalculation.GetDisplayName() ||
                       d.ProcessType == ProcessType.ReviewAttribute.GetDisplayName()))
                .Select(d => string.IsNullOrEmpty(d.PwCHeader) ? d.ClientHeader : d.PwCHeader).ToArrayAsync();
            var clientMaps = clientHeader.Select(d => d.ColName).ToArray();
            var updateMaps = existMaps.Where(m => clientMaps.Any(c => c == m)).ToArray();
            validateResult.UpdateFields = updateMaps;
        }

        private async Task ValidateLoan(DdsActionContext ax, long dealId, List<long> sellerIds, DataTable tblKeyColData, ImportReviewDataValidateDTO validateResult)
        {
            var existLoans = await ax.Query<Loan>().Where(d => d.DealId == dealId && sellerIds.Contains(d.SellerId) && d.IsActive == true).ToArrayAsync();
            var clientLoans = tblKeyColData.AsEnumerable().ToArray();
            var updateLoans = existLoans.Where(l => clientLoans.Any(c => c[0]?.ToString()?.ToLower() == l.LoanNumber.ToLower() &&
                                                                         c[1]?.ToString()?.ToLower() == l.PropertyName?.ToLower()))
                .Select(l => string.IsNullOrEmpty(l.LoanNumber) ? l.PropertyName : l.LoanNumber).ToArray();

            if (updateLoans.Length == 0)
            {
                throw new DdsInvalidOperationException("No loans can be updated.");
            }

            validateResult.UpdateLoans = updateLoans;
        }

        private async Task<string> UpdateLoanReview(DdsActionContext ax, long dealId, List<long> sellerIds, ReviewLevel? reviewLevel, DataTable tblActualData, DataTable tblKeyColData)
        {
            try
            {
                var existReviews = await ax.Query<LoanReview>().Where(d => d.DealId == dealId).ToArrayAsync();
                var existLoans = await ax.Query<Loan>().Where(d => d.DealId == dealId && sellerIds.Contains(d.SellerId) && d.IsActive == true).ToArrayAsync();
                var existHeaders = await ax.Query<HeaderMap>().Where(d => d.DealId == dealId && d.IsActive == true &&
                      (d.ProcessType == ProcessType.Review.GetDisplayName() ||
                       d.ProcessType == ProcessType.ReviewCalculation.GetDisplayName() ||
                       d.ProcessType == ProcessType.ReviewAttribute.GetDisplayName())).ToArrayAsync();
                var dataFormats = await ax.Query<DataFormat>().ToArrayAsync();
                var keyFields = tblKeyColData.AsEnumerable();
                var actualData = tblActualData.AsEnumerable();
                var warningMsg = string.Empty;

                foreach (var loan in existLoans)
                {
                    var keyEntry = keyFields.Where(a => a[0].ToString()?.ToLower() == loan.LoanNumber.ToLower() &&
                                                        a[1].ToString()?.ToLower() == loan.PropertyName?.ToLower()).FirstOrDefault();
                    if (keyEntry == null)
                        continue;
                    var rowIndex = tblKeyColData.Rows.IndexOf(keyEntry);
                    var actualEntry = actualData.ElementAt(rowIndex);

                    foreach (var header in existHeaders)
                    {
                        var columnName = (string.IsNullOrEmpty(header.PwCHeader) ? header.ClientHeader : header.PwCHeader) ?? string.Empty;
                        // If client header not exist, skip it from processing
                        if (string.IsNullOrEmpty(columnName) || !actualEntry.Table.Columns.Contains(columnName))
                            continue;

                        var rv = existReviews.FirstOrDefault(r => r.LoanId == loan.LoanId && r.HeaderMapId == header.HeaderMapId);
                        // If loan review not exist, skip it from processing
                        if (rv == null)
                            continue;

                        var actualValue = actualEntry?[columnName].ToString();
                        if (actualValue?.Length > 2000)
                        {
                            actualValue = actualValue.Substring(0, 2000);
                            warningMsg += "Loan:" + loan.LoanNumber + " Field:" + header.ClientHeader + " only kept first 2000 characters. \n";
                        }

                        // If value not changed, skip it from processing
                        if ((reviewLevel == ReviewLevel.FirstReview && rv.FirstReviewValue == actualValue) ||
                            (reviewLevel == ReviewLevel.SecondReview && rv.SecondReviewValue == actualValue) ||
                            (reviewLevel == ReviewLevel.ThirdReview && rv.ThirdReviewValue == actualValue))
                            continue;

                        if (reviewLevel == ReviewLevel.FirstReview)
                        {
                            rv.FirstReviewUpdatedTime = DateTime.UtcNow;
                            rv.FirstReviewUpdatedBy = ax.UserId;
                            rv.FirstReviewValue = actualValue;
                            rv.FirstReviewFormula = null;
                            rv.IsFirstReviewed = !string.IsNullOrEmpty(actualValue);
                        }
                        else if (reviewLevel == ReviewLevel.SecondReview)
                        {
                            rv.SecondReviewUpdatedTime = DateTime.UtcNow;
                            rv.SecondReviewUpdatedBy = ax.UserId;
                            rv.SecondReviewValue = actualValue;
                            rv.SecondReviewFormula = null;
                            rv.IsSecondReviewed = !string.IsNullOrEmpty(actualValue);
                        }
                        else if (reviewLevel == ReviewLevel.ThirdReview)
                        {
                            rv.ThirdReviewUpdatedTime = DateTime.UtcNow;
                            rv.ThirdReviewUpdatedBy = ax.UserId;
                            rv.ThirdReviewValue = actualValue;
                            rv.ThirdReviewFormula = null;
                            rv.IsThirdReviewed = !string.IsNullOrEmpty(actualValue);
                        }

                        var finalValue = rv.FirstReviewValue;
                        if (!string.IsNullOrEmpty(rv.ThirdReviewValue) || rv.IsThirdReviewed)
                            finalValue = rv.ThirdReviewValue;
                        else if (!string.IsNullOrEmpty(rv.SecondReviewValue) || rv.IsSecondReviewed)
                            finalValue = rv.SecondReviewValue;

                        if (finalValue != rv.FinalValue)
                        {
                            rv.FinalValueUpdatedTime = DateTime.UtcNow;
                            rv.FinalValueUpdatedBy = ax.UserId;
                            rv.FinalValue = finalValue;
                            if (rv.IsFirstReviewed || rv.IsSecondReviewed || rv.IsThirdReviewed)
                            {
                                var dataFormat = dataFormats.FirstOrDefault(d => d.DataFormatId == header.DataFormatId);
                                var isPwCHeader = string.IsNullOrEmpty(header.ClientHeader);
                                rv.IsTie = ConvertExtension.ToCompareClientAndPwCValue(rv.ClientDisplayValue, rv.ClientValue, rv.FinalValue, dataFormat?.Type, dataFormat?.Format, header.Threadhold, isPwCHeader);
                            }
                            else 
                            {
                                rv.IsTie = null;
                            }
                        }

                        ax.Update(rv.UpdateBy(ax.UserId));
                    }
                }
                await ax.Save();

                return warningMsg;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when import loan reviews. " + ex.Message);
            }
        }
        #endregion

        #endregion

        #region Last Import Info
        public async Task<LastImportInfoDTO?> GetLastImportInfo(DdsActionContext ax, long dealId)
        {
            var info = await ax.Query<UploadFileInfo>().Where(l => l.DealId == dealId)
                .Select(l => new LastImportInfoDTO()
                {
                    FileName = string.IsNullOrEmpty(l.UpdateFileName) ? l.InitiateFileName : l.UpdateFileName,
                    ImportBy = string.IsNullOrEmpty(l.UpdateFileName) ? l.CreatedBy : l.LastUpdatedBy,
                    ImportTime = string.IsNullOrEmpty(l.UpdateFileName) ? l.CreatedTime : l.LastUpdatedTime
                }).FirstOrDefaultAsync();

            return info;
        }

        public async Task<MemoryStream> GetLastImportFile(DdsActionContext ax, long dealId)
        {
            var info = await ax.Query<UploadFileInfo>().Where(l => l.DealId == dealId).FirstOrDefaultAsync();
            var stream = new MemoryStream(string.IsNullOrEmpty(info.UpdateFileName) ? info.InitiateFile : info.UpdateFile);
            return stream;
        }

        #endregion

        #region Compare File
        public async Task<MemoryStream> CompareData(DdsActionContext ax, CompareFile compareFile)
        {
            var templateFile = $"Templates/ComparedExceptionReport.xlsx";
            var wb = new ImportWorkBook();
            var memoryStream = new MemoryStream();
            try
            {
                //initail template
                wb.OpenExcel(templateFile);
                WorkbookDesigner workbookDesigner = new WorkbookDesigner(wb.WorkBook);
                wb.ActiveWorkSheet("Exception List");

                //import data into excel
                int rowIndex = 2;
                //header
                wb.SetText("A" + rowIndex.ToString(), $"Client and PwC Exception Report ({DateTime.Now.ToString("MMMM dd, yyyy")})");
                rowIndex++;

                //load and compare data
                var clientWorkSheets = LoadFile(compareFile.ClientFile);
                var pwcWorkSheets = LoadFile(compareFile.PwCFile);
                if (clientWorkSheets != null && clientWorkSheets.Count > 0 &&
                    pwcWorkSheets != null && pwcWorkSheets.Count > 0)
                {
                    var clientAVLoans = clientWorkSheets[0].SheetData_av.AsEnumerable();
                    var clientDVLoans = clientWorkSheets[0].SheetData_dv.AsEnumerable();
                    var pwcAVLoans = pwcWorkSheets[0].SheetData_av.AsEnumerable();
                    var pwcDVLoans = pwcWorkSheets[0].SheetData_dv.AsEnumerable();

                    for (int i = 0; i < clientAVLoans.Count(); i++)
                    {
                        //get the load (Assume: the colum order is the same between client and PwC)
                        var clientAVLoan = clientAVLoans.ElementAt(i);
                        var clientDVLoan = clientDVLoans.ElementAt(i);
                        var pwcAVLoan = pwcAVLoans.ElementAt(i);
                        var pwcDVLoan = pwcDVLoans.ElementAt(i);

                        for (int j = 2; j < clientAVLoan.Table.Columns.Count; j++)
                        {
                            var clientValue = clientDVLoan[j]?.ToString()?.Split('|');
                            var pwcValue = pwcDVLoan[j]?.ToString()?.Split('|');
                            if (clientValue?[0].ToString() != pwcValue?[0].ToString())
                            {
                                rowIndex++;
                                wb.SetText("A" + rowIndex.ToString(), clientAVLoan[0] ?? string.Empty).SetAllBorder().SetTextWrapped();
                                wb.SetText("B" + rowIndex.ToString(), clientAVLoan[1] ?? string.Empty).SetAllBorder().SetTextWrapped();
                                wb.SetText("C" + rowIndex.ToString(), clientAVLoan.Table.Columns[j]?.ToString() ?? string.Empty).SetAllBorder().SetTextWrapped();
                                wb.SetText("D" + rowIndex.ToString(), clientAVLoan[j] ?? string.Empty, clientValue?[1] ?? string.Empty).SetAllBorder().SetTextWrapped();
                                wb.SetText("E" + rowIndex.ToString(), pwcAVLoan[j] ?? string.Empty, pwcValue?[1] ?? string.Empty).SetAllBorder().SetTextWrapped();
                            }
                        }
                    }
                }
                //save into memory stream
                workbookDesigner.Workbook.Save(memoryStream, SaveFormat.Xlsx);
                memoryStream.Position = 0;
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when comparing Client and PwC exception report. " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return memoryStream;
        }

        private List<ImportWorkSheet> LoadFile(IFormFile fromFile)
        {
            var wb = new ImportWorkBook();
            try
            {
                using (var stream = new MemoryStream())
                {
                    fromFile.CopyTo(stream);
                    wb.OpenExcel(stream);
                }
                var sheets = wb.LoadSheets();
                if (sheets != null && sheets.Count > 0)
                {
                    wb.SheetList = new List<ImportWorkSheet>();
                    wb.SheetList.Add(new ImportWorkSheet(sheets[0], null));
                    wb.ReadExcel();
                }
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when loading file. " + ex.Message);
            }
            finally
            {
                wb.CloseExcel();
            }
            return wb.SheetList;
        }

        #endregion
    }
}
