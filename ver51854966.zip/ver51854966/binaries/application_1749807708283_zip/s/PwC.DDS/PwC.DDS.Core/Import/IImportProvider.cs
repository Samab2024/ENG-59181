﻿using Microsoft.AspNetCore.Http;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Core
{
    public interface IImportProvider
    {
        Task<List<string>> LoadSheets(DdsActionContext ax, IFormFile file);
        Task<object?> ImportData(DdsActionContext ax, ImportDataDTO importInfo);
        Task<LastImportInfoDTO?> GetLastImportInfo(DdsActionContext ax, long dealId);
        Task<MemoryStream> GetLastImportFile(DdsActionContext ax, long dealId);
        Task<MemoryStream> CompareData(DdsActionContext ax, CompareFile compareFile);
	}
}
