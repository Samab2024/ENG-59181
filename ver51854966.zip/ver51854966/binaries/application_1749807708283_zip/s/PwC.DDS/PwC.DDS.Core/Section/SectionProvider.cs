﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PwC.DDS.Infrastructure;

namespace PwC.DDS.Core
{
    public class SectionProvider : ISectionProvider
    {
        public async Task<SectionDTO[]> GetSections(DdsActionContext ax, long dealId)
        {
            var sections = await ax.Query<Section>().Where(s => s.DealId == dealId && s.IsActive == true)
                .Include(l => l.SourceDocSections)
                .Select(l => new SectionDTO
                {
                    SectionId = l.SectionId,
                    Name = l.Name,
                    DisplayOrder = l.DisplayOrder,
                    IsDeleteable = !l.SourceDocSections.Any()
                })
                .OrderBy(l => l.DisplayOrder).ToArrayAsync();
            return sections;
        }

        public async Task UpdateSections(DdsActionContext ax, long dealId, SectionDTO[] sections)
        {
            var existSDS = await ax.Query<Section>().Where(l => l.DealId == dealId && l.IsActive == true)
                .Include(l => l.SourceDocSections).ToArrayAsync();
            var allIds = sections.Select(e => e.SectionId).ToArray();

            // Delete missing entry
            var deleteSDS = existSDS.Where(s => !s.SourceDocSections.Any() && !allIds.Any(e => e == s.SectionId)).ToArray();
            if (deleteSDS.Any())
            {
                foreach (var sds in deleteSDS) 
                {
                    var reviewers = await ax.Query<Reviewer>().Where(d => d.DealId == dealId && d.SectionId == sds.SectionId).ToArrayAsync();
                    ax.RemoveRange(reviewers);
                }
                ax.RemoveRange(deleteSDS);
                await ax.Save();
            }

            // Add new entry
            var newSDS = ax.Mapper.Map<Section[]>(sections.Where(s => s.SectionId == 0));
            if (newSDS.Any())
            {
                var loans = await ax.Query<Loan>().Where(d => d.DealId == dealId && d.IsActive == true).ToArrayAsync();
                foreach (var sds in newSDS)
                {
                    sds.DealId = dealId;
                    sds.IsActive = true;
                    sds.CreateBy(ax.UserId);
                    ax.Add(sds);
                    await ax.Save();

                    var reviewer = loans.Select(l => new Reviewer()
                    {
                        DealId = dealId,
                        LoanId = l.LoanId,
                        HeaderMapId = 0,
                        SectionId = sds.SectionId,
                        ReviewerStatus1 = ReviewStatus.NotStarted.GetDisplayName(),
                        ReviewerStatus2 = ReviewStatus.NotStarted.GetDisplayName(),
                        ReviewerStatus3 = ReviewStatus.NotStarted.GetDisplayName()
                    }.CreateBy(ax.UserId)).ToArray();
                    ax.AddRange(reviewer);
                    await ax.Save();
                }
            }

            // Update entry
            var updateSDS = existSDS.Where(s => allIds.Any(e => e == s.SectionId)).ToArray();
            foreach (var sds in updateSDS)
            {
                var data = sections.Where(s => s.SectionId == sds.SectionId).FirstOrDefault();
                sds.Name = data.Name;
                sds.DisplayOrder = data.DisplayOrder;
                sds.UpdateBy(ax.UserId);
            }
            ax.UpdateRange(updateSDS);
            await ax.Save();
        }

        public async Task InitSection(DdsActionContext ax, long dealId, string[]? sections)
        {
            try
            {
                if (sections != null && sections.Any())
                {
                    var count = 1;
                    var data = sections.Select(s => new Section()
                    {
                        DealId = dealId,
                        Name = s,
                        DisplayOrder = count++,
                        IsActive = true
                    }.CreateBy(ax.UserId)).ToArray();
                    ax.AddRange(data);
                    await ax.Save();
                }
                else
                {
                    var pfSection = await ax.Cache.Lookups.Gets(Constent.Section);
                    var data = pfSection.Select(s => new Section()
                    {
                        DealId = dealId,
                        Name = s.Display,
                        DisplayOrder = s.Sequence,
                        IsActive = true
                    }.CreateBy(ax.UserId)).ToArray();
                    ax.AddRange(data);
                    await ax.Save();
                }
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when init sections. " + ex.Message);
            }
        }
    }
}
