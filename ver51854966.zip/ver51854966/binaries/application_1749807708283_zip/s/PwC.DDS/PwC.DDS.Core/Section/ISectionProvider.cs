﻿using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core
{
    public interface ISectionProvider
    {
        Task<SectionDTO[]> GetSections(DdsActionContext ax, long dealId);
        Task UpdateSections(DdsActionContext ax, long dealId, SectionDTO[] sections);
        Task InitSection(DdsActionContext ax, long dealId, string[]? sections);       
    }
}
