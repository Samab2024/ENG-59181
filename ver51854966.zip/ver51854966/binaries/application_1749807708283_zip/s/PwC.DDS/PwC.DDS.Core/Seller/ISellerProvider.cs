﻿using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core
{
    public interface ISellerProvider
    {
        Task<SellerDTO[]> GetSellers(DdsActionContext ax, long dealId);
        Task UpdateSeller(DdsActionContext ax, long dealId, SellerDTO[] sellers);
        Task InitSeller(DdsActionContext ax, long dealId);
    }
}
