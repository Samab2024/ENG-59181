﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PwC.DDS.Infrastructure;

namespace PwC.DDS.Core
{
    public class SellerProvider : ISellerProvider
    {
        public async Task<SellerDTO[]> GetSellers(DdsActionContext ax, long dealId)
        {
            var sellers = await ax.Query<Seller>().Where(s => s.DealId == dealId && s.IsActive == true).Include(l => l.Loans)
                .Select(l => new SellerDTO
                {
                    DisplayOrder = l.DisplayOrder,
                    Name = l.Name,
                    SellerId = l.SellerId,
                    IsDeleteable = !l.Loans.Any()
                })
                .OrderBy(l => l.DisplayOrder).ToArrayAsync();
            return sellers;
        }

        public async Task UpdateSeller(DdsActionContext ax, long dealId, SellerDTO[] sellers)
        {
            var existSDS = await ax.Query<Seller>().Where(l => l.DealId == dealId).ToArrayAsync();
            var allIds = sellers.Select(e => e.SellerId).ToArray();

            // Delete missing entry
            var deleteSDS = existSDS.Where(s => !allIds.Any(e => e == s.SellerId)).ToArray();
            ax.RemoveRange(deleteSDS);

            // Add new entry
            var newSDS = ax.Mapper.Map<Seller[]>(sellers.Where(s => s.SellerId == 0));
            foreach (var sds in newSDS)
            {
                sds.DealId = dealId;
                sds.IsActive = true;
                sds.CreateBy(ax.UserId);
            }
            ax.AddRange(newSDS);

            // Update entry
            var updateSDS = existSDS.Where(s => allIds.Any(e => e == s.SellerId)).ToArray();
            foreach (var sds in updateSDS)
            {
                var data = sellers.Where(s => s.SellerId == sds.SellerId).FirstOrDefault();
                sds.Name = data.Name;
                sds.DisplayOrder = data.DisplayOrder;
                sds.UpdateBy(ax.UserId);
            }
            ax.UpdateRange(updateSDS);
            await ax.Save();
        }

        public async Task InitSeller(DdsActionContext ax, long dealId)
        {
            try
            {
                var sellers = await ax.Query<Seller>().Where(s => s.DealId == dealId).ToArrayAsync();
                if (!sellers.Any())
                {
                    var seller = new Seller
                    {
                        DealId = dealId,
                        Name = "Default",
                        DisplayOrder = 1,
                        IsActive = true
                    }.CreateBy(ax.UserId);
                    ax.Add(seller);
                    await ax.Save();
                }
            }
            catch (Exception ex)
            {
                throw new DdsInvalidOperationException("Error when init seller. " + ex.Message);
            }
        }
    }
}
