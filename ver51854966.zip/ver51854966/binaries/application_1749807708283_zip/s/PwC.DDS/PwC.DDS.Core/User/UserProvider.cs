﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using I = PwC.DDS.Types.Interface;

namespace PwC.DDS.Core
{
    public class UserProvider : IUserProvider
    {
        public async Task<bool> IsAdmin(DdsActionContext ax, string userId)
        {
            var isAdmin = await ax.Any<AdminUser>(d => d.Guid == userId);
            return isAdmin;
        }

        public async Task<vEmployeeDetails[]> GetUsers(DdsActionContext ax)
        {
            var users = await ax.Where<vEmployeeDetails>(u => u.Email != null)
                .Select(u => new vEmployeeDetails
                {
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email.ToLower(),
                    Guid = u.Guid
                }).Distinct().ToArrayAsync();
            return users;
        }

        public async Task<vEmployeeDetails[]> GetReviewers(DdsActionContext ax, long dealId)
        {
            var deal = await ax.First<DealSetup>(d => d.DealId == dealId) ?? throw new DdsInvalidOperationException("invalid deal id");
            var admins = deal.DealAdmin?.Split(',').ToList();
            var contacts = deal.DealContact?.Split(',').ToList();

            var userEmails = new List<string>();
            if (ax.IsAdmin || (deal.DealAdmin != null && deal.DealAdmin.Contains(ax.UserEmail)))
            {
                if (admins != null && admins.Any())
                    userEmails.AddRange(admins);
                if (contacts != null && contacts.Any())
                    userEmails.AddRange(contacts);
            }
            else
                userEmails.Add(ax.UserEmail);

            var users = await ax.Where<vEmployeeDetails>(u => userEmails.Any(m => m == u.Email))
                .Select(u => new vEmployeeDetails
                {
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email.ToLower(),
					Guid = u.Guid
				}).Distinct().ToArrayAsync();
            return users;
        }
    }
}
