﻿using PwC.DDS.Types.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Core
{
    public interface IUserProvider
    {
        Task<bool> IsAdmin(DdsActionContext ax, string userId);
        Task<vEmployeeDetails[]> GetUsers(DdsActionContext ax);
        Task<vEmployeeDetails[]> GetReviewers(DdsActionContext ax, long dealId);
    }
}
