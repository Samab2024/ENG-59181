﻿using Microsoft.Extensions.Configuration;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using PwC.DDS.Infrastructure;
using System.Xml.Linq;

namespace PwC.DDS.Core
{
	public class EmailProvider : IEmailProvider
	{
		public void SendEmail(DdsActionContext ax, string subject, string currentDealAdmin, string previousDealAdmin)
		{
			try
			{
				var templatePath = $"Templates/AssignDealAdminEmail.xml";
				var body = GetEmailContent(templatePath);
				SendMail(ax.Config.EmailSettings.EmailFrom,
							 currentDealAdmin,
							 subject,
							 string.Format(body, previousDealAdmin, currentDealAdmin),
							 ax.Config.EmailSettings.EmailHost);
			}
			catch (Exception ex)
			{
				throw new DdsInvalidOperationException("Error sending email.");
			}
		}

		private void SendMail(string mailFrom, string mailTo, string subject, string body, string host)
		{
			var mailMessage = new MailMessage { From = new MailAddress(mailFrom, "DueDiligence", Encoding.UTF8) };
			AddRecipient("To", mailTo, mailMessage);
			mailMessage.Priority = MailPriority.Normal;
			mailMessage.IsBodyHtml = true;
			mailMessage.SubjectEncoding = Encoding.Default;
			mailMessage.BodyEncoding = Encoding.Default;

			mailMessage.Subject = subject;
			mailMessage.Body = body;


			SmtpClient smtpClient = new SmtpClient();
			smtpClient.Port = 25;
			smtpClient.Host = host;
			smtpClient.EnableSsl = true;
			smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;


			smtpClient.Send(mailMessage);
			mailMessage.Dispose();
		}

		private static void AddRecipient(string recipientType, string recipient, MailMessage mailMessage)
		{
			if (!string.IsNullOrEmpty(recipient))
			{
				recipient = recipient.Replace(";", ",");
				switch (recipientType)
				{
					case "To":
						mailMessage.To.Add(recipient);
						break;
					case "Cc":
						mailMessage.CC.Add(recipient);
						break;
					case "Bcc":
						mailMessage.Bcc.Add(recipient);
						break;
				}
			}
		}

		private string GetEmailContent(string templatePath)
		{
			var xml = XElement.Load(templatePath);
			string body = Uri.UnescapeDataString(xml.Element("Body").Value);
			StringBuilder content = new StringBuilder();
			content.Append(body);
			return content.ToString();
		}
	}
}
