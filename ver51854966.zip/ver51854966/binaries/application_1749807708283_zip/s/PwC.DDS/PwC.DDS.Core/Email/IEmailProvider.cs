﻿using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Core
{
	public interface IEmailProvider
	{
		void SendEmail(DdsActionContext ax, string subject, string currentDealAdmin, string previousDealAdmin);
	}
}
