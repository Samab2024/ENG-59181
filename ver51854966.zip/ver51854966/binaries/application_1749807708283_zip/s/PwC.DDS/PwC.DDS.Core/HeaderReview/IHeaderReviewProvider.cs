﻿using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Core
{
    public interface IHeaderReviewProvider
    {
        Task<HeaderReviewDTO> GetHeaderReview(DdsActionContext ax, long dealId, long headerMapId);
        Task UpdateHeaderReview(DdsActionContext ax, long dealId, long headerMapId, HeaderReviewSection headerReviews);
        Task UpdateHeaderReview(DdsActionContext ax, long dealId, long headerMapId, HeaderReviewCell headerReview);
        Task<ReviewStatusDTO> GetHeaderReviewStatus(DdsActionContext ax, long dealId);
    }
}
