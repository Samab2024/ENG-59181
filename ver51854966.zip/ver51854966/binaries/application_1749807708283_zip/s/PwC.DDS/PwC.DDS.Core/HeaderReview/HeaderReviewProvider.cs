﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;

namespace PwC.DDS.Core
{
    public class HeaderReviewProvider : IHeaderReviewProvider
    {
        readonly IDealProvider _deal;
        readonly IReviewerProvider _reviewer;
        public HeaderReviewProvider(IDealProvider deal, IReviewerProvider reviewer)
        {
            _deal = deal;
            _reviewer = reviewer;
        }

        public async Task<HeaderReviewDTO> GetHeaderReview(DdsActionContext ax, long dealId, long headerMapId)
        {
            var result = new HeaderReviewDTO();
            var deal = await _deal.GetDeal(ax, dealId);
            if (deal != null)
            {
                var headerMap = await ax.Query<HeaderMap>().Where(h => h.HeaderMapId == headerMapId && h.IsActive == true)
                    .Include(h => h.DataFormat).Include(h => h.SourceDocSection).FirstOrDefaultAsync() ?? throw new DdsInvalidOperationException("invalid header map id");
                var headerReviewer = await ax.Query<Reviewer>().Where(h => h.DealId == dealId && h.HeaderMapId == headerMapId).FirstOrDefaultAsync();
                var categoryOptions = await ax.Query<DropdownCategoryOption>().Where(h => h.DealId == dealId && h.CategoryId == headerMap.DropdownCategoryId && h.IsActive == true)
                    .OrderBy(h => h.DisplayOrder).Select(h => h.OptionName).ToArrayAsync();

                var headerMaps = await ax.Query<HeaderMap>().Where(h => h.DealId == dealId && h.IsActive == true && h.ProcessType == ProcessType.ReviewAttribute.GetDisplayName())
                    .OrderBy(h => h.DisplayOrder).ToArrayAsync();
                var prvheaderMap = headerMaps.Where(l => l.HeaderMapId < headerMapId).LastOrDefault();
                var nextheaderMap = headerMaps.Where(l => l.HeaderMapId > headerMapId).FirstOrDefault();

                result.HeaderMapId = headerMap.HeaderMapId;
                result.ClientHeader = headerMap.ClientHeader;
                result.PwCHeader = headerMap.PwCHeader;
                result.FieldGuide = headerMap.FieldGuide;
                result.DataFormatId = headerMap.DataFormat.DataFormatId;
                result.DataFormatType = headerMap.DataFormat.Type;
                result.DataFormatCode = headerMap.DataFormat.Code;
                result.DropdownCategoryId = headerMap.DropdownCategoryId;
                result.Threadhold = headerMap.Threadhold;
                result.DropdownCategoryOptions = categoryOptions;
                result.LevelOfReview = Math.Min(deal.LevelOfReview, headerMap.LevelOfReview);
                result.DealName = deal.DealName;
                result.IsDealAdmin = deal.IsDealAdmin;
                result.IsBlindReview = deal.IsBlindReview == true ? true : headerMap.IsBlindReview;
                result.PrvHeaderMapId = prvheaderMap?.HeaderMapId;
                result.PrvClientHeader = prvheaderMap?.ClientHeader;
                result.NextHeaderMapId = nextheaderMap?.HeaderMapId;
                result.NextClientHeader = nextheaderMap?.ClientHeader;
                result.ReviewSection = new HeaderReviewSection[] {
                    new HeaderReviewSection
                        {
                            SourceDocSectionId = headerMap.SourceDocSection.SourceDocSectionId,
                            SourceDocSectionName = headerMap.SourceDocSection.Name,
                            IsAllowCopy = headerMap.SourceDocSection.IsAllowCopy,
                            DisplayOrder = headerMap.SourceDocSection.DisplayOrder,
                            Permission = GetHeaderMapReviewPermission(headerReviewer, ax.IsAdmin, deal.IsDealAdmin, ax.UserEmail),
                            ReviewData = (from loan in ax.Query<Loan>()
                                          join review in ax.Query<LoanReview>() on loan.LoanId equals review.LoanId
                                          where loan.DealId == dealId &&
                                                loan.IsActive == true &&
                                                review.HeaderMapId == headerMapId
                                          orderby loan.DisplayOrder
                                          select new HeaderReviewData
                                          {
                                                LoanId = loan.LoanId,
                                                LoanNumber = loan.LoanNumber,
                                                PropertyName = loan.PropertyName,
                                                ClientValue = review.ClientValue,
                                                ClientDisplayValue = review.ClientDisplayValue,
                                                FirstReviewValue = review.FirstReviewValue,
                                                SecondReviewValue = review.SecondReviewValue,
                                                ThirdReviewValue = review.ThirdReviewValue,
                                                IsFirstReviewed = review.IsFirstReviewed,
                                                IsSecondReviewed = review.IsSecondReviewed,
                                                IsThirdReviewed = review.IsThirdReviewed,
                                                PwCComments = review.PwCComments,
                                                InternalComments = review.InternalComments,
                                                IsTie = review.IsTie,
                                                LevelOfReview = Math.Min(deal.LevelOfReview, headerMap.LevelOfReview),
                                          }).ToArray()
                        }
                };
            }
            return result;
        }

        private string GetHeaderMapReviewPermission(Reviewer? reviewer, bool isSysAdmin, bool isDealAdmin, string email)
        {
            if (isSysAdmin || isDealAdmin)
                return "1,2,3";

            var result = string.Empty;
            if (reviewer?.Reviewer1?.ToLower() == email.ToLower())
                result += "1,";
            if (reviewer?.Reviewer2?.ToLower() == email.ToLower() &&
                !string.IsNullOrEmpty(reviewer.ReviewerStatus1) &&
                reviewer.ReviewerStatus1 != ReviewStatus.NotStarted.GetDisplayName())
                result += "2,";
            else if (reviewer?.Reviewer3?.ToLower() == email.ToLower() &&
                !string.IsNullOrEmpty(reviewer.ReviewerStatus1) &&
                reviewer.ReviewerStatus1 != ReviewStatus.NotStarted.GetDisplayName() &&
                !string.IsNullOrEmpty(reviewer.ReviewerStatus2) &&
                reviewer.ReviewerStatus2 != ReviewStatus.NotStarted.GetDisplayName())
                result += "3,";
            return result == string.Empty ? string.Empty : result.Substring(0, result.Length - 1);
        }

        public async Task UpdateHeaderReview(DdsActionContext ax, long dealId, long headerMapId, HeaderReviewSection section)
        {
            var hm = await ax.Query<HeaderMap>().Where(h => h.DealId == dealId && h.HeaderMapId == headerMapId).FirstOrDefaultAsync();
            var existReviews = await ax.Query<LoanReview>().Where(h => h.DealId == dealId && h.HeaderMapId == headerMapId).ToArrayAsync();
            var rs = await ax.Query<Reviewer>().Where(l => l.DealId == dealId && l.HeaderMapId == headerMapId && l.LoanId == 0).FirstOrDefaultAsync();

            bool needRecalc = false;
            if (!string.IsNullOrEmpty(section.Permission) && rs != null && hm != null)
            {
                var mapIds = section.ReviewData.Select(m => m.LoanId).ToArray();
                var changedRvs = existReviews.Where(m => mapIds.Any(l => l == m.LoanId)).ToArray();
                foreach (var rv in changedRvs)
                {
                    var review = section.ReviewData.Where(m => m.LoanId == rv.LoanId).FirstOrDefault();
                    var hasChanged = false;

                    if (section.Permission.Contains("1") && rv.FirstReviewValue != review?.FirstReviewValue)
                    {
                        rv.FirstReviewUpdatedTime = DateTime.UtcNow;
                        rv.FirstReviewUpdatedBy = ax.UserId;
                        rv.FirstReviewValue = review?.FirstReviewValue;
                        rv.IsFirstReviewed = !string.IsNullOrEmpty(review?.FirstReviewValue) || review.IsFirstReviewed;
                        rs.ReviewerStatus1 = ReviewStatus.InProgress.GetDisplayName();
                        hasChanged = true;
                    }
                    if (section.Permission.Contains("2") && rv.SecondReviewValue != review?.SecondReviewValue && hm.LevelOfReview > 1)
                    {
                        rv.SecondReviewUpdatedTime = DateTime.UtcNow;
                        rv.SecondReviewUpdatedBy = ax.UserId;
                        rv.SecondReviewValue = review?.SecondReviewValue;
                        rv.IsSecondReviewed = !string.IsNullOrEmpty(review?.SecondReviewValue) || review.IsSecondReviewed;
                        rs.ReviewerStatus2 = ReviewStatus.InProgress.GetDisplayName();
                        hasChanged = true;
                    }
                    if (section.Permission.Contains("3") && rv.ThirdReviewValue != review?.ThirdReviewValue && hm.LevelOfReview > 2)
                    {
                        rv.ThirdReviewUpdatedTime = DateTime.UtcNow;
                        rv.ThirdReviewUpdatedBy = ax.UserId;
                        rv.ThirdReviewValue = review?.ThirdReviewValue;
                        rv.IsThirdReviewed = !string.IsNullOrEmpty(review?.ThirdReviewValue) || review.IsThirdReviewed;
                        rs.ReviewerStatus3 = ReviewStatus.InProgress.GetDisplayName();
                        hasChanged = true;
                    }
                    if (rv.PwCComments != review?.PwCComments)
                    {
                        rv.PwCComments = review?.PwCComments;
                        hasChanged = true;
                    }
                    if (rv.InternalComments != review?.InternalComments)
                    {
                        rv.InternalComments = review?.InternalComments;
                        hasChanged = true;
                    }

                    if (hasChanged)
                    {
                        if (!string.IsNullOrEmpty(hm.CalculatorHeader))
                            needRecalc = true;
                        rv.FinalValueUpdatedTime = DateTime.UtcNow;
                        rv.FinalValueUpdatedBy = ax.UserId;
                        if ((!string.IsNullOrEmpty(rv.ThirdReviewValue) || rv.IsThirdReviewed) && hm.LevelOfReview > 2)
                            rv.FinalValue = rv.ThirdReviewValue;
                        else if ((!string.IsNullOrEmpty(rv.SecondReviewValue) || rv.IsSecondReviewed) && hm.LevelOfReview > 1)
                            rv.FinalValue = rv.SecondReviewValue;
                        else
                            rv.FinalValue = rv.FirstReviewValue;
                        if (rv.IsFirstReviewed || rv.IsSecondReviewed || rv.IsThirdReviewed)
                            rv.IsTie = review?.IsTie;
                        else
                            rv.IsTie = null;
                        ax.Update(rv.UpdateBy(ax.UserId));
                    }
                }

                if (needRecalc)
                    await _deal.ResetNeedRecalculatation(ax, dealId);

                await ax.Save();
            }
        }

        public async Task UpdateHeaderReview(DdsActionContext ax, long dealId, long headerMapId, HeaderReviewCell headerReview)
        {
            var rv = await ax.Query<LoanReview>().Where(h => h.DealId == dealId && h.LoanId == headerReview.LoanId && h.HeaderMapId == headerMapId).FirstOrDefaultAsync();
            var rs = await ax.Query<Reviewer>().Where(l => l.DealId == dealId && l.HeaderMapId == headerMapId && l.LoanId == 0).FirstOrDefaultAsync();
            var hm = await ax.Query<HeaderMap>().Where(h => h.DealId == dealId && h.HeaderMapId == headerMapId).FirstOrDefaultAsync();

            //check if the old review value is diff with database, it means the database value is already updated by other user
            if (rv != null && rs != null && hm != null)
            {
                if (headerReview?.ReviewLevel == ReviewLevel.FirstReview)
                {
                    if (rv.FirstReviewValue != headerReview?.OldReviewValue)
                    {
                        throw new DdsInvalidOperationException("The first review value has been already updated by other user, please refresh page.");
                    }
                    else
                    {
                        rv.FirstReviewUpdatedTime = DateTime.UtcNow;
                        rv.FirstReviewUpdatedBy = ax.UserId;
                        rv.FirstReviewValue = headerReview?.NewReviewValue;
                        rv.IsFirstReviewed =  !string.IsNullOrEmpty(headerReview?.NewReviewValue) || headerReview.IsReviewed;
                        rs.ReviewerStatus1 = ReviewStatus.InProgress.GetDisplayName();
                    }
                }
                else if (headerReview?.ReviewLevel == ReviewLevel.SecondReview)
                {
                    if (rv.SecondReviewValue != headerReview?.OldReviewValue)
                    {
                        throw new DdsInvalidOperationException("The second review value has been already updated by other user, please refresh page.");
                    }
                    else
                    {
                        rv.SecondReviewUpdatedTime = DateTime.UtcNow;
                        rv.SecondReviewUpdatedBy = ax.UserId;
                        rv.SecondReviewValue = headerReview?.NewReviewValue;
                        rv.IsSecondReviewed = !string.IsNullOrEmpty(headerReview?.NewReviewValue) || headerReview.IsReviewed;
                        rs.ReviewerStatus2 = ReviewStatus.InProgress.GetDisplayName();
                    }
                }
                else if (headerReview?.ReviewLevel == ReviewLevel.ThirdReview)
                {
                    if (rv.ThirdReviewValue != headerReview?.OldReviewValue)
                    {
                        throw new DdsInvalidOperationException("The third review value has been already updated by other user, please refresh page.");
                    }
                    else
                    {
                        rv.ThirdReviewUpdatedTime = DateTime.UtcNow;
                        rv.ThirdReviewUpdatedBy = ax.UserId;
                        rv.ThirdReviewValue = headerReview?.NewReviewValue;
                        rv.IsThirdReviewed =  !string.IsNullOrEmpty(headerReview?.NewReviewValue) || headerReview.IsReviewed;
                        rs.ReviewerStatus3 = ReviewStatus.InProgress.GetDisplayName();
                    }
                }

                var finalValue = rv.FirstReviewValue;
                if ((!string.IsNullOrEmpty(rv.ThirdReviewValue) || rv.IsThirdReviewed) && hm.LevelOfReview > 2)
                    finalValue = rv.ThirdReviewValue;
                else if ((!string.IsNullOrEmpty(rv.SecondReviewValue) || rv.IsSecondReviewed) && hm.LevelOfReview > 1)
                    finalValue = rv.SecondReviewValue;

                if (finalValue != rv.FinalValue)
                {
                    rv.FinalValueUpdatedTime = DateTime.UtcNow;
                    rv.FinalValueUpdatedBy = ax.UserId;
                    rv.FinalValue = finalValue;
                    if (!string.IsNullOrEmpty(hm.CalculatorHeader))
                        await _deal.ResetNeedRecalculatation(ax, dealId);
                }

                rv.PwCComments = headerReview?.PwCComments;
                rv.InternalComments = headerReview?.InternalComments;
                if (rv.IsFirstReviewed || rv.IsSecondReviewed || rv.IsThirdReviewed)
                    rv.IsTie = headerReview?.IsTie;
                else
                    rv.IsTie = null;
                ax.Update(rv.UpdateBy(ax.UserId));
                await ax.Save();
            }
        }

        public async Task<ReviewStatusDTO> GetHeaderReviewStatus(DdsActionContext ax, long dealId)
        {
            var deal = await _deal.GetDeal(ax, dealId);
            var reviewers = await _reviewer.GetAttributeReviewers(ax, dealId);
            var level = deal?.LevelOfReview ?? 3;

            var result = new ReviewStatusDTO();
            foreach (var r in reviewers)
            {
                if (r.ReviewerStatus1 == ReviewStatus.NotStarted.GetDisplayName() ||
                    r.ReviewerStatus1 == ReviewStatus.InProgress.GetDisplayName())
                {
                    result.ReadyFor1stReviewCount++;
                    continue;
                }

                if (level > 1 &&
                   (r.ReviewerStatus2 == ReviewStatus.NotStarted.GetDisplayName() ||
                    r.ReviewerStatus2 == ReviewStatus.InProgress.GetDisplayName()))
                {
                    result.ReadyFor2ndReviewCount++;
                    continue;
                }

                if (level > 2 &&
                   (r.ReviewerStatus3 == ReviewStatus.NotStarted.GetDisplayName() ||
                    r.ReviewerStatus3 == ReviewStatus.InProgress.GetDisplayName()))
                {
                    result.ReadyForFinalReviewCount++;
                    continue;
                }

                result.CompletedCount++;
            }
            return result;
        }
    }
}
