﻿using Microsoft.EntityFrameworkCore;
using PwC.DDS.Infrastructure;
using PwC.DDS.Types.Database.Extensions;
using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System.Linq;
using System.Security.Cryptography;

namespace PwC.DDS.Core
{
    public class LoanProvider : ILoanProvider
    {
        public async Task<LoanDTO[]> GetLoans(DdsActionContext ax, long dealId, bool isActive)
        {
            bool isRandomReview = ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).Any(l => l.IsRandomReview);
            var loans = await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == isActive && (!isActive || !isRandomReview || l.IsRandomReview == isRandomReview))
                .OrderBy(l => l.SellerId).ThenBy(l => l.DisplayOrder).ToArrayAsync();
            return ax.Mapper.Map<LoanDTO[]>(loans);
        }

        public async Task UpdateLoan(DdsActionContext ax, LoanDTO loan)
        {
            var existLoan = await ax.First<Loan>(d => d.LoanId == loan.LoanId) ?? throw new DdsInvalidOperationException("invalid loan id");
            if (loan.IsActive != null && existLoan.IsActive != loan.IsActive)
            {
                existLoan.IsActive = loan.IsActive ?? true;
                existLoan.DisplayOrder = ax.Query<Loan>().Where(l => l.DealId == existLoan.DealId && l.IsActive == true).Max(d => d.DisplayOrder) + 1;
            }
            else
            {
                existLoan.MissingDoc = loan.MissingDoc;
            }
            ax.Update(existLoan.UpdateBy(ax.UserId));
            await ax.Save();
        }

        public async Task UpdateLoanRandom(DdsActionContext ax, LoanRandomDTO loanRandom)
        {
            var loanList = await ax.Query<Loan>().Where(l => l.DealId == loanRandom.DealId && l.IsActive == true).ToArrayAsync();
            var loanRandomIDs = loanList.Where(l => l.IsRandomReview == true).Select(l => l.LoanId).ToList();
            if (loanRandom.RandomNumber == 0)
            {
                //reset
                foreach (var loanID in loanRandomIDs)
                {
                    var loan = loanList.First<Loan>(l => l.LoanId == loanID);
                    loan.IsRandomReview = false;
                    ax.Update(loan.UpdateBy(ax.UserId));
                }
                await ax.Save();
            }
            else
            {
                var diffNumber = loanRandom.RandomNumber - loanRandomIDs.Count;
                if (diffNumber > 0)
                {
                    var loanUnRandomIDs = loanList.Select(l => l.LoanId).Except(loanRandomIDs).ToList();
                    using (var rng = new RNGCryptoServiceProvider())
                    {
                        byte[] randomNumber = new byte[4];
                        var newRandomLoanIDs = loanUnRandomIDs.OrderBy(x =>
                        {
                            rng.GetBytes(randomNumber);
                            int value = BitConverter.ToInt32(randomNumber, 0);
                            return value % loanUnRandomIDs.Count;
                        }).Take((int)diffNumber).ToList();

                        foreach (var loanID in newRandomLoanIDs)
                        {
                            var loan = loanList.First<Loan>(l => l.LoanId == loanID);
                            loan.IsRandomReview = true;
                            ax.Update(loan.UpdateBy(ax.UserId));
                        }
                        await ax.Save();
                    }
                }
            }
        }

        public async Task<LoanDependencyDTO[]> GetLoanDependency(DdsActionContext ax, long dealId)
        {
            return await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).Include(l => l.Seller)
                .Select(l => new LoanDependencyDTO
                {
                    LoanId = l.LoanId,
                    ParentId = l.ParentId,
                    SellerId = l.SellerId,
                    LoanNumber = l.LoanNumber,
                    PropertyName = l.PropertyName,
                    SellerName = l.Seller.Name,
                    DisplayOrder = l.DisplayOrder,
                })
                .OrderBy(l => l.SellerId).ThenBy(l => l.DisplayOrder).ToArrayAsync();
        }

        public async Task UpdateLoanDependency(DdsActionContext ax, long dealId, LoanDependencyDTO[] loanDependencyDTOs)
        {
            var loans = await ax.Query<Loan>().Where(l => l.DealId == dealId && l.IsActive == true).ToArrayAsync();
            foreach (var loan in loans)
            {
                var data = loanDependencyDTOs.Where(dto => dto.LoanId == loan.LoanId).FirstOrDefault();
                loan.ParentId = data.ParentId;
                loan.DisplayOrder = data.DisplayOrder;
                loan.UpdateBy(ax.UserId);
            }
            ax.UpdateRange(loans);
            await ax.Save();
        }
    }
}
