﻿using PwC.DDS.Types.Database;
using PwC.DDS.Types.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PwC.DDS.Core
{
    public interface ILoanProvider
    {
        Task<LoanDTO[]> GetLoans(DdsActionContext ax, long dealId, bool isActive);
        Task UpdateLoan(DdsActionContext ax, LoanDTO loan);
        Task UpdateLoanRandom(DdsActionContext ax, LoanRandomDTO loanRandom);
        Task<LoanDependencyDTO[]> GetLoanDependency(DdsActionContext ax, long dealId);
        Task UpdateLoanDependency(DdsActionContext ax, long dealId, LoanDependencyDTO[] loanDependencyDTOs);
    }
}
