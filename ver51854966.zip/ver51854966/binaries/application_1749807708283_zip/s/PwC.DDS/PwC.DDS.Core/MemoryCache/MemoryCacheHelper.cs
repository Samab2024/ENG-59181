﻿using Microsoft.Extensions.Caching.Memory;
using System.Collections;
using PwC.DDS.Infrastructure;

namespace PwC.DDS.Core
{
    public class MemoryCacheHelper : IMemoryCacheHelper
    {
        private readonly IMemoryCache _memoryCache;

        public MemoryCacheHelper(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        private static void ValidateValueType<TResult>()
        {
            //Because IEnumerable, IQueryable etc. have delayed execution problems and cause trouble, the use of these types is prohibited.
            Type typeResult = typeof(TResult);
            //If it is a generic type such as IEnumerable<String>, remove the specific type information such as String, and then compare
            if (typeResult.IsGenericType)
            {
                typeResult = typeResult.GetGenericTypeDefinition();
            }

            //Be careful to use equality comparison instead of IsAssignableTo
            if (typeResult == typeof(IEnumerable<>) || typeResult == typeof(IEnumerable)
                                                    || typeResult == typeof(IAsyncEnumerable<TResult>)
                                                    || typeResult == typeof(IQueryable<TResult>) || typeResult == typeof(IQueryable))
            {
                throw new DdsInvalidOperationException($"TResult of {typeResult} is not allowed, please use List<T> or T[] instead.");
            }
        }

        private static void InitCacheEntry(ICacheEntry entry, int baseExpireSeconds)
        {
            double sec = Random.Shared.NextDouble(baseExpireSeconds, baseExpireSeconds * 2);
            TimeSpan expiration = TimeSpan.FromSeconds(sec);
            entry.AbsoluteExpirationRelativeToNow = expiration;
        }

        public TResult? GetOrCreate<TResult>(Enum cacheKey, Func<ICacheEntry, TResult?> valueFactory, int baseExpireSeconds = 60)
        {
            ValidateValueType<TResult>();
            //Because IMemoryCache saves as CacheEntry, the null value is also considered legal, so returning null will not have the problem of "cache penetration"
            // Instead of calling the system's built-in CacheExtensions.GetOrCreate, use the code of GetOrCreate directly, so as not to wrap a delegate
            if (!_memoryCache.TryGetValue(cacheKey, out TResult result))
            {
                using ICacheEntry entry = _memoryCache.CreateEntry(cacheKey);
                InitCacheEntry(entry, baseExpireSeconds);
                result = valueFactory(entry)!;
                entry.Value = result;
            }

            return result;
        }

        public async Task<TResult?> GetOrCreateAsync<TResult>(Enum cacheKey, Func<ICacheEntry, Task<TResult?>> valueFactory, int baseExpireSeconds = 60)
        {
            ValidateValueType<TResult>();
            if (!_memoryCache.TryGetValue(cacheKey, out TResult result))
            {
                using ICacheEntry entry = _memoryCache.CreateEntry(cacheKey);
                InitCacheEntry(entry, baseExpireSeconds);
                result = (await valueFactory(entry))!;
                entry.Value = result;
            }

            return result;
        }

        public void Remove(Enum cacheKey)
        {
            _memoryCache.Remove(cacheKey);
        }
    }
}
