﻿using Microsoft.Extensions.Caching.Memory;

namespace PwC.DDS.Core
{
    public interface IMemoryCacheHelper
    {
        /// <typeparam name="TResult">the type of cache value</typeparam>
        /// <param name="cacheKey">cache key</param>
        /// <param name="valueFactory">Delegate to provide data</param>
        /// <param name="expireSeconds">The maximum value of cache expiration seconds. The actual cache time is between [expireSeconds, expireSeconds*2).
        /// This can avoid to a certain extent the "cache avalanche" problem caused by the centralized expiration of a large number of keys.</param>
        /// <returns></returns>
        TResult? GetOrCreate<TResult>(Enum cacheKey, Func<ICacheEntry, TResult?> valueFactory, int expireSeconds = 60);
        Task<TResult?> GetOrCreateAsync<TResult>(Enum cacheKey, Func<ICacheEntry, Task<TResult?>> valueFactory, int expireSeconds = 60);
        /// <summary>
        /// delete the value for specific cache key 
        /// </summary>
        /// <param name="cacheKey"></param>
        void Remove(Enum cacheKey);
    }
}