﻿using Microsoft.Extensions.Logging;

namespace PwC.DDS.Infrastructure.Logging
{
    public static class DdsLogger
    {
        private static ILoggerFactory s_factory;
        public static void SetFactory(ILoggerFactory factory)
        {
            s_factory = factory;
        }
        public static ILogger Create(string categoryName)
        {
            return s_factory.CreateLogger(categoryName);
        }
        public static ILogger Create<T>()
        {
            return s_factory.CreateLogger<T>();
        }
    }
}
