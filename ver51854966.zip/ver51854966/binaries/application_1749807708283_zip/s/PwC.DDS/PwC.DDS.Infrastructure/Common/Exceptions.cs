﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace PwC.DDS.Infrastructure
{
    [Serializable]
    public class DdsException : Exception
    {
        public DdsException(string message)
            : base(message)
        {
        }

        public DdsException(string message, Exception innerException)
         : base(message, innerException)
        {
        }

        protected DdsException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }

    [Serializable]
    public class DdsInvalidOperationException : DdsException
    {
        public DdsInvalidOperationException(string message)
            : base(message)
        {
        }

        public DdsInvalidOperationException(string message, Exception innerException)
         : base(message, innerException)
        {
        }
        protected DdsInvalidOperationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }

    [Serializable]
    public class DdsPermissionException : DdsException
    {
        public DdsPermissionException(string message)
            : base(message)
        {
        }

        public DdsPermissionException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
        protected DdsPermissionException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
