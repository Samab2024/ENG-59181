﻿using Microsoft.Extensions.Configuration;

namespace PwC.DDS.Infrastructure
{
    public class DdsConfiguration
    {
        private readonly IConfiguration _config;
        public DdsConfiguration(IConfiguration Configuration)
        {
            _config = Configuration;
        }

        public JwtSettings JWTSettings => _config.GetSection(nameof(JwtSettings)).Get<JwtSettings>();
        public AppSettings AppSettings => _config.GetSection(nameof(AppSettings)).Get<AppSettings>();
        public EmailSettings EmailSettings => _config.GetSection(nameof(EmailSettings)).Get<EmailSettings>();
    }

    public class JwtSettings
    {
        public string SecurityKey { get; set; }
        public string RsaPublicKey { get; set; }
        public string RsaPrivateKey { get; set; }
        public string Issuer { get; set; }
        public int? ExpireHours { get; set; }
    }

    public class AppSettings 
    {
        public string SQLConnectionString { get; set; }
        public string OFISACCESSURL { get; set; }
        public string OFISUSERPROFILEURL { get; set; }
        public string REDIRECTURL { get; set; }

    }

    public class EmailSettings 
    {
        public string EmailFrom { get; set; }
        public string EmailHost { get; set; }
        public string EmailDealAdminTemplate { get; set; }
        public bool EmailEnabled { get; set; }
    }
}
